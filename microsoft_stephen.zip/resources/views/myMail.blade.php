<html>
   <body style='width:100%;background:white'>
      <div style='width:100%; height: auto; margin: auto;margin-top: 20px;border-radius: 5px;'>
      <div style='width:100%;'>
      <div style='width:100%; margin:auto; text-align: justify; text-justify: inter-word;'>
     
      <br>
      
      <br>
      <div style='width:100%;height: auto; border-top: 1px solid #D3D3D3; margin: auto;border-radius: 6px;'>
        <br>
        
         <p style='font-family:Arial, Helvetica, sans-serif; font-weight:bold; font-size: 17px;'>{{$firstname}} </p>
         <br>
         <p style='font-family:Arial, Helvetica, sans-serif; font-size: 16px'>{!! $content !!}</p>
      </div>
      <div >
         <a style="text-decoration: none; font-size: 15px; text-align:center; font-weight: bold" href="#" ></a>
      </div>
      <br>
      
     
      <div style='background: #000e2e; color: white; padding:20px;'>
         <p style='text-align:center;'> © 2019 All Rights Reserved</p>
      </div>
   </body>
</html>