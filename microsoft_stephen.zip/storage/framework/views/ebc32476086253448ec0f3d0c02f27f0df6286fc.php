<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="theme-color" content="#33363f">
<meta property="og:locale" content="en_US" />
<meta property="og:site_name" content="Coinfinancepro" />

<meta property="og:url" content="" />
<meta property="og:type" content="website" />
<meta property="og:description" content="Sign up with Coinfinancepro to join thousands of investors." />
<meta property="og:image" content="public/img/Coinfinancepro.jpeg">


<link href="<?php echo e(asset('img/new/android-icon-48x48.png')); ?>" rel="icon">
<title>Coinfinancepro| Landing Page</title>
<link rel="stylesheet" href="public/css/style1.css">
<link rel="stylesheet" href="public/css/scale.css">
<link rel="stylesheet" type="text/css" href="public/vendor/DataTables/datatables.css" />
<link rel="stylesheet" href="public/vendor/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="public/vendor/fontawesome/css/all.css">

    
<link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/style11.css')); ?>" rel="stylesheet">   
	<style>
		@import  url(https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&family=Titillium+Web:wght@400;700&display=swap);
		select{
			font-size: 20px;
			font-weight: bolder;
			
		}
	</style>
<style>
    .article{margin-bottom:240px}.article__wrap{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}.article__left{width:10%;}.article__right{width:90%}.article__right-title{margin-bottom:121px}.article__right-info,.article__right-mining,.article__right-profit{font-size:32px;line-height:22px;margin-bottom:20px}.article__right-info:before,.article__right-mining:before,.article__right-profit:before{content:'';position:absolute;background-repeat:no-repeat;background-size:31px 36px;background-position:center;width:40px;height:40px;left:-69px;top:-15px}.article__right-men:before{background-image:url(images/articleimg/Union.svg)}.article__right-mining:before{background-image:url(images/articleimg/ico2.svg)}.article__right-profit:before{background-image:url(images/articleimg/ico13.svg)}.article__right-discription{max-width:509px;width:100%;line-height:22px;color:black;font-size:14px}.article__right-text{margin:0 0 58px 90px;position:relative}.technology{padding-bottom:130px;margin-bottom:115px}.technology__title-discription{max-width:463px;color:rgba(255,255,255,.6);font-family:Roboto;font-size:18px;font-style:normal;font-weight:400;line-height:22px;margin:40px 0 76px 0}.technology__rules{color:rgba(255,255,255,.6);max-width:447px;width:100%;padding-left:22px;position:relative;padding-bottom:28px}.technology__rules:before{content:'';position:absolute;width:6px;height:6px;background-color:#5555e8;left:0;top:5px}.technology__wrap{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;padding-bottom:130px;border-bottom:1px solid rgba(255,255,255,.6)}.technology__left{width:50%}.technology__right{width:50%;background-image:url(images/tc1.png);background-position:80% 60%;background-size:140%;background-repeat:no-repeat}.reviews__slider{margin:100px 0 0 0;padding-bottom:140px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;position:relative}.reviews__slider .slick-active{width:670px}.reviews__slider .slick-prev{position:absolute;top:-162px;right:85px;background-image:url(images/prev.svg);background-position:center;background-repeat:no-repeat}.reviews__slider .slick-next{position:absolute;right:0;top:-162px;background-image:url(images/next.svg);background-position:center;background-repeat:no-repeat}
    }.package-content{margin-bottom:150px;position:relative}.package-body{display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap}.package-item{-webkit-box-flex:0;-ms-flex:0 1 25%;flex:0 1 25%;padding:0 8px 15px 8px}@media (max-width:1140px){.package-item{-webkit-box-flex:0;-ms-flex:0 1 33.333333%;flex:0 1 33.333333%}}@media (max-width:868px){.package-item{-webkit-box-flex:0;-ms-flex:0 1 50%;flex:0 1 50%}}@media (max-width:480px){.package-item{-webkit-box-flex:0;-ms-flex:0 1 100%;flex:0 1 100%;padding:0 0 10px 0}}.package-itemContent{padding:20px 35px;background-color:#F0F8FF;background-image:url(images/bg-package.svg);background-position:0 0;background-repeat:repeat-x;border-radius:6px;position:relative;overflow:hidden}.package-itemAccount{-webkit-box-flex:0;-ms-flex:0 1 33.333333%;flex:0 1 33.333333%;padding:0 8px 20px 8px}@media (max-width:1140px){.package-itemAccount{-webkit-box-flex:0;-ms-flex:0 1 33.333333%;flex:0 1 33.333333%}}@media (max-width:868px){.package-itemAccount{-webkit-box-flex:0;-ms-flex:0 1 50%;flex:0 1 50%}}@media (max-width:580px){.package-itemAccount{-webkit-box-flex:0;-ms-flex:0 1 100%;flex:0 1 100%;padding:0 0 20px 0}}.package-itemAccountContent{padding:25px 30px;background-color:#151053;background-image:url(images/bg-package.svg);background-position:0 0;background-repeat:repeat-x;border-radius:6px;position:relative;overflow:hidden}.package-limited{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:end;-ms-flex-align:end;align-items:flex-end;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;max-width:130px;min-height:50px;padding:5px 15px;border-radius:40px;background:#a7885b;color:#fff;font-size:14px;font-family:Roboto,sans-serif;font-weight:400;position:absolute;top:-25px;left:0;right:0;margin:0 auto}.package-discount{width:120px;height:30px;padding-bottom:4px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;color:#fff;font-size:14px;font-family:Roboto,sans-serif;font-weight:400;position:absolute;top:10px;right:-31px;background:-webkit-gradient(linear,left top,left bottom,color-stop(-15%,#ff1f00),to(rgba(235,14,0,0)));background:linear-gradient(180deg,#ff1f00 -15%,rgba(235,14,0,0) 100%);-webkit-transform:rotate(45deg);transform:rotate(45deg)}.package-name{padding:20px 0;color:#1c1c1f;font-size:20px;font-family:'Titillium Web',sans-serif;font-weight:400;letter-spacing:2px;text-align:center}.package-price{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:end;-ms-flex-align:end;align-items:flex-end;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;padding-bottom:30px}.package-price span{color:#fff;font-size:44px;font-family:'Titillium Web',sans-serif;font-weight:400;text-align:center;position:relative}.package-price span.symbol{font-size:20px;position:absolute;left:-15px;top:7px}.package-price span.old-price{margin-left:20px;padding-bottom:5px;font-size:16px;color:rgba(255,255,255,.5);text-decoration:line-through}.package-price span.old-price span.symbol{color:#1c1c1f;font-size:12px;text-decoration:line-through;position:absolute;left:-8px;top:2px}.package-info>div.package-infoItem:last-of-type{border-bottom:0;margin-bottom:25px}.package-infoItem{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.1)}.package-infoItem p{color:#3d3d42;font-size:12px;font-family:'Titillium Web',sans-serif;font-weight:400;text-transform:uppercase}.package-infoItem span{color:#fff;font-size:14px;font-family:'Titillium Web',sans-serif;font-weight:400}.package-link{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.package-link a{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;min-height:56px;padding:5px 30px;border:1px solid #ec5598;border-radius:40px;background:0 0;color:#fff;font-size:16px;font-family:'Titillium Web',sans-serif;font-weight:700;-webkit-transition:background .5s linear;transition:background .5s linear}.package-link a:hover{background:#FF3737}</style>
</head>
<body>
<div id="custom-loader" class="">
<div id="app-loader-bg">
<div id="app-loader"></div>
</div>
</div>
<div id="app-base-header">
<div class="app-header">
<nav id="sticky-nav" class="navbar navbar-expand-md navbar-light fixed-header p-0">
<div class="container">
<a class="navbar-brand" href="trade/en-us">
<img id="branding" src="public/img/logo/log2.png" alt="" width="" height="40">
</a>
<span class="navbar-text">
<button onclick="location.href='./sign-up'" class=" btn btn-success">Open account</button>
</span>
</div>
</nav>
<div id="app-header-content">
<div class="container">
<div class="row">
<div class="col-10 col-md-8 col-lg-6">
<h1 class="hero-text">Trade Stocks, Forex,
Options and Crypto</h1>
<p class="hero-desc mt-4">
Join millions whove already discovered smarter investing in multiple types of assets. Choose an investment product to start with.
</p>
<div class="d-grid d-md-block mt-5 mb-5 mb-md-0 gap-2 gap-md-0">
<button onclick="location.href='./sign-in'" class="btn btn-success btn-lg me-md-2">Invest Now</button>

</div>
</div>
</div>
</div>
<div id="app-content-float" class="d-none d-md-block">
<div class="container lll">
<div class="row">
<div class="col-4">
<div class="custom-container-bg h-100">
<div class="p-3">
<h3 class="my-dark my-600 my-montserrat mb-4">Crypto Investment</h3>
<p class="my-dark my-montserrat">You can make profit not only by investing - Alvarium Block Ltd has developed a special level system of rewarding the partners who help us in promoting and attracting new investors.</p>
<button onclick="location.href='./sign-up'" class="btn btn-primary mt-3">Invest in Stocks</button>
</div>
<div class="">
<img src="public/img/crypto.webp" width="100%" alt="">
</div>
</div>
</div>
<div class="col-4">
<div class="custom-container-bg h-100">
<div class="p-3">
<h3 class="my-dark my-600 my-montserrat mb-4">Crypto</h3>
<p class="my-dark my-montserrat">Buy, sell and store Bitcoin and other leading cryptos with ease</p>
<button onclick="location.href='./sign-up" class=" btn btn-primary mt-3">Buy Crypto</button>
</div>
<div class="align-self-end">
<img src="public/img/stocks.webp" width="100%" alt="">
</div>
</div>
</div>
<div class="col-4">
<div class="custom-container-bg h-100">
<div class="p-3">
<h3 class="my-dark my-600 my-montserrat mb-4">NFT Market</h3>
<p class="my-dark my-montserrat">NFT or non-fungible tokens, becoming very popular in the last six months, is an attractive tool and a new possibility for digital investors.

</p>
<button onclick="location.href='./sign-up" class="btn btn-primary mt-3">Market Place</button>
</div>
<div class="">
<img src="public/img/nfts21.png" width="100%" alt="">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="container d-md-none">
<div class="row gap-5">
<div class="col-12">
<div class="custom-container-bg h-100">
<div class="p-3">
<h3 class="custom-container-h">Crypto Investment</h3>
<p class="my-dark my-montserrat">You can make profit not only by investing - Alvarium Block Ltd has developed a special level system of rewarding the partners who help us in promoting and attracting new investors.</p>
<button onclick="location.href='./sign-up'" class="btn btn-primary mt-3">Invest Now</button>
</div>
<div class="">
<img src="public/img/crypto.webp" width="100%" alt="">
</div>
</div>
</div>
<div class="col-12">
<div class="custom-container-bg h-100">
<div class="p-3">
<h3 class="custom-container-h">Crypto</h3>
<p class="my-dark my-montserrat">Buy, sell and store Bitcoin and other leading cryptos with ease</p>
<button onclick="location.href='./sign-up'" class="btn btn-primary mt-3">Buy Crypto</button>
</div>
<div class="align-self-end">
<img src="public/img/stocks.webp" width="100%" alt="">
</div>
</div>
</div>
<div class="col-12">
<div class="custom-container-bg h-100">
<div class="p-3">
<h3 class="custom-container-h">NFT Market</h3>
<p class="my-dark my-montserrat">NFT or non-fungible tokens, becoming very popular in the last six months, is an attractive tool and a new possibility for digital investors.</p>
<button onclick="location.href='./sign-up'" class="btn btn-primary mt-3">MarketPlace</button>
</div>
<div class="">
<img src="public/img/nfts21.png" width="100%" alt="">
</div>
</div>
</div>
</div>
</div>
<div class="container">
<div class="custom-container-dark mt-5">
<div class="row">
<div class="col-8">
<div class="p-3">
<h2 class="custom-container-h text-white">New to Trading?</h2>
<p class="text-white">Discover AM Trading™: Get help from our carefully picked experts to help you manage your trading account till you become a good trader.</p>
<button onclick="location.href='trade/en-us/managers'" class="btn btn-light">AM Trading™</button>
</div>
</div>
<div class="col-4">
<img src="https://marketing.etorostatic.com/cache1/hp/v_235/images/funnels/copytrader.png" width="100%" alt="">
</div>
</div>
</div>
<div class="mt-5">

<div class="tradingview-widget-container">
<div id="tradingview_eced3"></div>
<script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
<script type="text/javascript">
                    new TradingView.MediumWidget({
                        "symbols": [
                            [
                                "Microsoft"
                                , "MSFT"
                            ]
                            , [
                                "Apple"
                                , "AAPL"
                            ]
                            , [
                                "Google"
                                , "GOOGL"
                            ]
                        ]
                        , "chartOnly": false
                        , "width": "100%"
                        , "height": 400
                        , "locale": "en"
                        , "colorTheme": "light"
                        , "gridLineColor": "#F0F3FA"
                        , "trendLineColor": "rgba(255, 73, 14, 1)"
                        , "fontColor": "#787B86"
                        , "underLineColor": "rgba(227, 242, 253, 0)"
                        , "isTransparent": true
                        , "autosize": false
                        , "container_id": "tradingview_eced3"
                    });

                </script>
</div>

</div>
</div>
<section style="margin: 6%;">
<div class="service-block mt-5 pt-5 pb-5">
<div class="container">
<center class="mb-5">
<h1 class="my-dark my-montserrat my-300">NFT market today</h1>
<p class="my-dark my-montserrat">NFT or non-fungible tokens, becoming very popular in the last six months, is an attractive tool and a new possibility for digital investors.Technical nature of these currencies allows to use them effectively in copyright sphere. Pictures, songs and even newspaper columns are digitized and sold for hundreds of thousands USD dollars almost every day. <br>Manage to invest into advanced NFT</p>
</center>

</div>

      <div class="col-xl-12">
						<div class="overflow-hidden bg-transparent dz-crypto-scroll shadow-none">
							<div class="js-conveyor-example">
								<ul class="crypto-list" id="crypto-webticker">
                                    
                                <?php $__currentLoopData = $nft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<div class="card">
											<div class="card-body d-flex align-items-center">
											<div class="col-xl-3 col-xxl-4">
													<div class="">
														<div class="" style="margin-top: -10px;">
															<div class="text-center mb-3">
																<img src="<?php echo e(asset('nfts/'.$list->nft)); ?>" width="220" height="240" alt="" />										
															</div>
															<div class="text-left mb-3" style="">
																<h8 class=" mb-0"><?php echo e($list->username); ?>

																<?php if($list->verification_status == 1): ?> 
																<svg height="15" viewBox="0 0 512 512" width="13" xmlns="http://www.w3.org/2000/svg"><path d="m512 268c0 17.9-4.3 34.5-12.9 49.7s-20.1 27.1-34.6 35.4c.4 2.7.6 6.9.6 12.6 0 27.1-9.1 50.1-27.1 69.1-18.1 19.1-39.9 28.6-65.4 28.6-11.4 0-22.3-2.1-32.6-6.3-8 16.4-19.5 29.6-34.6 39.7-15 10.2-31.5 15.2-49.4 15.2-18.3 0-34.9-4.9-49.7-14.9-14.9-9.9-26.3-23.2-34.3-40-10.3 4.2-21.1 6.3-32.6 6.3-25.5 0-47.4-9.5-65.7-28.6-18.3-19-27.4-42.1-27.4-69.1 0-3 .4-7.2 1.1-12.6-14.5-8.4-26-20.2-34.6-35.4-8.5-15.2-12.8-31.8-12.8-49.7 0-19 4.8-36.5 14.3-52.3s22.3-27.5 38.3-35.1c-4.2-11.4-6.3-22.9-6.3-34.3 0-27 9.1-50.1 27.4-69.1s40.2-28.6 65.7-28.6c11.4 0 22.3 2.1 32.6 6.3 8-16.4 19.5-29.6 34.6-39.7 15-10.1 31.5-15.2 49.4-15.2s34.4 5.1 49.4 15.1c15 10.1 26.6 23.3 34.6 39.7 10.3-4.2 21.1-6.3 32.6-6.3 25.5 0 47.3 9.5 65.4 28.6s27.1 42.1 27.1 69.1c0 12.6-1.9 24-5.7 34.3 16 7.6 28.8 19.3 38.3 35.1 9.5 15.9 14.3 33.4 14.3 52.4zm-266.9 77.1 105.7-158.3c2.7-4.2 3.5-8.8 2.6-13.7-1-4.9-3.5-8.8-7.7-11.4-4.2-2.7-8.8-3.6-13.7-2.9-5 .8-9 3.2-12 7.4l-93.1 140-42.9-42.8c-3.8-3.8-8.2-5.6-13.1-5.4-5 .2-9.3 2-13.1 5.4-3.4 3.4-5.1 7.7-5.1 12.9 0 5.1 1.7 9.4 5.1 12.9l58.9 58.9 2.9 2.3c3.4 2.3 6.9 3.4 10.3 3.4 6.7-.1 11.8-2.9 15.2-8.7z" fill="#1da1f2"/></svg>
																<?php endif; ?>
																</h8>
																<p class=""><?php echo e($list->name); ?></p>											
															</div>
															<div class="mb-3" style="margin-left: 180px; margin-top:-50px;">
																<h6 class="fs-10 mb-0">Price</h6>
																<p class="fs-14 font-w600 text-black">
															     <img src="<?php echo e(asset('svg/'.$list->type.'.svg')); ?>" /><?php echo e($list->amount); ?></p>
																										
															</div>
															<div class="text-left" style="padding-bottom:">
																<a class="btn btn-primary" href="./sign-up"> <span style="color: white;"> Buy Now</span></a>
																									
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
						</div>
					</div>              
</section>


 <section class="article" style="margin-bottom:-40px;">
        <div class="container">
            <div class="article__wrap">
                <div class="article__left"></div>
                <div class="article__right">
                    <div class="article__right-title title">
                       <span style="font-size: 25px; font-weight:bold;"> How it works</span>
                    </div>
                <div class="article__right-text">
                        <div class="article__right-info article__right-men">
                           <span class="bl-yellow"> Register Your account <span>
                        </div> 
                    <div class="article__right-discription">
                        For registration you should enter your E-mail address and create a strong password for the system. Using your account, you can purchase cloud equipment, which is provided in profitable packages, withdraw funds and use the Referral Rrogram.
                    </div>  
                </div>
                <div class="article__right-text article__right-mining">
                        <div class="article__right-info">
                            <span class="bl-yellow"> Find the package that's right for you</span>
                        </div> 
                    <div class="article__right-discription">
                        The availability and variety of packages gives our users the ability to choose and invest with ease.
                    </div>  
                </div>
                <div class="article__right-text article__right-profit ">
                        <div class="article__right-info">
                            <span class="bl-yellow"> Receive Your payments every day</span>
                        </div> 
                    <div class="article__right-discription">
                        With Coinfinancepro company, you will receive regularly payments to your specified wallet. Crypto investments provides the opportunity for regular and promising profits.
                    </div>  
                </div>
                </div>
            </div>
        </div>
        </section>
        
        <section>
    </section>
    <section class="" style="margin: 6%">
                    
                    <div class="staticTitle" style="margin-bottom:30px;">
                        <h2 style="text-align: center; font-size:30px;">Packages</h2>
                    </div>
                    
                    <div class="package-content">
                                    <div class="timer-body">
                                
                                <div class="discount-timer"></div>
                            </div>
                    
                        <div class="tab_content tab-pane fade show active" id="plans1">
                            <div class="package-body">
                                <div class="package-item">
                                    <div class="package-itemContent">
                                            
                                            <div class="package-discount">
                                            
                                            </div>
                                        <div style="font-size:30px" class="package-name">
                                            Basic 
                                        </div>
                                        <div class="package-price">
                                            
                                                <span style="font-size: 25px; color:#1c1c1f;">
                                                    <span class="symbol"></span>
                                                5% After <br> 24Hrs
                                                </span>
                                        </div>
                                        
                                        <div class="package-info">
                                            <div class="package-infoItem">
                                               
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Min: $50</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Max: $1999</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;"> Referrals: 10%</p>
                                                
                                            </div>
                                            
                                        </div>
                                        <div class="package-link">
                                            <a href="./sign-up">Invest</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="package-item">
                                    <div class="package-itemContent">
                                            
                                            <div class="package-discount">
                                            
                                            </div>
                                        <div style="font-size:30px" class="package-name">
                                            Business 
                                        </div>
                                        <div class="package-price">
                                            
                                                <span style="font-size: 25px; color:#1c1c1f;">
                                                    <span class="symbol"></span>
                                                15% After 7 days
                                                </span>
                                        </div>
                                        
                                        <div class="package-info">
                                            <div class="package-infoItem">
                                               
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Min: $2000</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Max: $4999</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Referrals: 10%</p>
                                                
                                            </div>
                                            
                                        </div>
                                        <div class="package-link">
                                           <a href="./sign-up">Invest</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="package-item">
                                    <div class="package-itemContent">
                                            
                                            <div class="package-discount">
                                            
                                            </div>
                                        <div style="font-size:30px" class="package-name">
                                            Company 
                                        </div>
                                        <div class="package-price">
                                            
                                                <span style="font-size: 25px; color:#1c1c1f;">
                                                    <span class="symbol"></span>
                                                30% After 10 Days
                                                </span>
                                        </div>
                                        
                                        <div class="package-info">
                                            <div class="package-infoItem">
                                               
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Min: $5000</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Max: $9999</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Referrals: 10%</p>
                                                
                                            </div>
                                            
                                        </div>
                                        <div class="package-link">
                                            <a href="./sign-up">Invest</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="package-item">
                                    <div class="package-itemContent">
                                            
                                            <div class="package-discount">
                                            
                                            </div>
                                        <div style="font-size:30px" class="package-name">
                                            Expert
                                        </div>
                                        <div class="package-price">
                                            
                                                <span style="font-size: 25px; color:#1c1c1f">
                                                    <span class="symbol"></span>
                                               60% After <br> 30 Days
                                                </span>
                                        </div>
                                        
                                        <div class="package-info">
                                            <div class="package-infoItem">
                                               
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Min: $10000</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Max: Unlimited</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Referrals: 10%</p>
                                                
                                            </div>
                                            
                                        </div>
                                        <div class="package-link">
                                            <a href="./sign-up">Invest</a>
                                        </div>
                                    </div>
                                </div>
                                            
                            </div>
                        </div> 
                    </div> 
                <section>    
<div class="service-block mt-5 pt-5 pb-5">
<div class="container">
<center class="mb-5">
<h1 class="my-dark my-montserrat my-300">The global leader of profitable trading</h1>
<p class="my-dark my-montserrat">Discover why millions of users from over 140 countries choose to trade with Coinfinancepro</p>
</center>
<div class="row gap-4 gap-md-0">
<div class="col-12 col-md-4">
<center>
<div class="block-icon-container">
<img class="bounce delay-2s duration-5s" src="public/img/003-paper.svg" width="100%" alt="">
</div>
<h3 class="mt-4 my-gradient my-montserrat">Regulated</h3>
<p class="my-dark my-montserrat my-300">Our company is regulated by the FCA and CySec</p>
</center>
</div>
<div class="col-12 col-md-4">
<center>
<div class="block-icon-container">
<img class="bounce delay-3s duration-5s" src="public/img/002-cloud-computing.svg" width="100%" alt="">
</div>
<h3 class="mt-4 my-gradient my-montserrat">Swift & Reliable</h3>
<p class="my-dark my-montserrat my-300">Our API and trading equiptments are fast, reliable and easy to use accros multiple platforms</p>
</center>
</div>
<div class="col-12 col-md-4">
<center>
<div class="block-icon-container">
<img class="bounce delay-4s duration-5s" src="public/img/001-magnifying-glass.svg" width="100%" alt="">
</div>
<h3 class="mt-4 my-gradient my-montserrat">Privacy</h3>
<p class="my-dark my-montserrat my-300">We will never share your private data without your permission</p>
</center>
</div>
</div>
</div>
</div>
<div class="testimonia-block">
<div class="row no-gutter">
<div class="col-12 col-md-6">
<div class="h-100">
<div class="d-flex justify-content-center align-items-center h-80">
<div class="p-5">
<h2 class="text-center my-montserrat my-600 mb-3"><span class="bl-yellow">Earn 10% Referral Bonus</span></h2>
<br>
<h3 class="my-montserrat my-300">
You can make profit not only by investing - Coinfinancepro has developed a special level system of rewarding the partners who help us in promoting and attracting new investors. Your direct referrals will bring you a commission of 10% of the deposit amoun
.</h3>

</div>
</div>
</div>
</div>
<div class="col-12 col-md-6">
  <img class="shake" src="public/img/card.png" width="100%" alt="">
  <p style="margin-left: 20px;">Our Visa Debit Crypto Card are made available for free, to all our Premium and Ultimate plan investors.</p>
</div>
<div class="support-block pt-5 pb-5">
<div class="container">
<center class="mb-5">
<h1 class="my-dark my-montserrat my-300">Having an difficulty?</h1>
<p class="my-dark my-montserrat">Our award winning support team is on ground to help you out within few minutes. We can be reached through the following medium.</p>
</center>
<div class="row gap-4 gap-md-0">
<div class="col-12 col-md-6">

<center>
<div class="block-icon-container">
<img class="bounce delay-2s duration-5s" src="public/img/support.svg" width="100%" alt="">
</div>
<h3 class="mt-4 my-gradient my-montserrat">24/7 Live Chat</h3>
<p class="my-dark my-montserrat my-300">Click the chat button below to start a conversation with one of our agents.</p>
</center>
</div>
<div class="col-12 col-md-6">
<center>
<div class="block-icon-container bic-green">
<img class="shake delay-3s duration-3s" src="public/img/email.svg" width="100%" alt="">
</div>
<h3 class="mt-4 my-gradient my-montserrat">Support Email</h3>
<p class="my-dark my-montserrat my-300"><a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="f0938583849f9d9582b0918691829fde8482919495">[email&#160;protected]</a></p>
</center>
</div>
</div>
</div>
</div>
<div class="container">
<div class="cta-block p-5">
<h1 class="my-dark my-montserrat my-300 text-center">Trade with confidence. Trade with Coinfinancepro.</h1>
<p class="my-dark my-montserrat text-center mb-4">Join thousands of people who choose to trade with us, enjoying over 100 instruments including 24/7 trading of Digital Assets.</p>
<center class="mb-3">
<div class="col-12 col-md-6">
<button onclick="location.href='./sign-in'" class="btn btn-primary">Open an account</button>
</div>
</center>
</div>
</div>
<div class="footer-block">
<div class="container">
<div class="row">
<div class="col-6 col-md-4 mb-3 mb-md-0">
<div class="foot-header">Company</div>
<div class="foot-body">
<a href="./about" class="foot">About Us</a>
<a href="tel:+1(260) 488 6441" class="foot"><b>Phone:</b> +1(260) 488 6441</a>
<a href="https://maps.google.com/?q=Irvington, Carlisle CA6 4NW, United Kingdom" class="foot"><b>UK Address:</b> Irvington, Carlisle CA6 4NW, United Kingdom</a>
<a href="https://maps.google.com/?q=9030 Metropolitan Ave, Queens, NY 11374, United States" class="foot"><b>US Address:</b> 9030 Metropolitan Ave, Queens, NY 11374, United States</a>
</div>
</div>

<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Trading</div>
<div class="foot-body">
<a href="./sign-up" class="foot">Open Live Account</a>
<a href="./sign-up" class="foot">Instruments</a>

<a href="./sign-up" class="foot">Market Analysis</a>
</div>
</div>
<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Funding</div>
<div class="foot-body">
<a href="./sign-up" class="foot">Funding Methods</a>
<a href="./sign-up" class="foot">Clients Protection</a>
</div>
</div>
<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Legal</div>
<div class="foot-body">
<a href="./aml-policy" class="foot">AML Policy</a>
<a href="./cookie-policy" class="foot">Cookie Policy</a>
<a href="./privacy-policy" class="foot">Privacy Policy</a>
<a href="./risk-disclosure" class="foot">Risk Disclosure</a>
<a href="./terms" class="foot">Terms & Conditions</a>
</div>
</div>
</div>
<div class="footer-sub mb-4 mt-5">
<p><strong>Risk Warning:</strong> CFD and Spot Forex trading both come with a high degree of risk. You must be prepared to sustain a total loss of any funds deposited with us, as well as any additional losses, charges, or other costs we incur in recovering any payment from you. Given the possibility of losing more than your entire investment, speculation in certain investments should only be conducted with risk capital funds that if lost will not significantly affect your personal or institution’s financial well-being. Before deciding to trade the products offered by us, you should carefully consider your objectives, financial situation, needs and level of experience. You should also be aware of all the risks associated with trading on margin. Please read our <a href="./risk-disclosure">Risk Disclosure document</a></p>
</div>
<div class="footer-sub mb-2">
<p>© Copyright 2019 All Rights Reserved. Coinfinancepro Ltd, 8 Copthall, Roseau Valley 00152, The Commonwealth of Dominica. <br>
This website is not directed at any jurisdiction and is not intended for any use that would be contrary to local law or regulation.</p>
</div>
<div class="text-center mt-5">
<img src="https://www.eaglefx.com/images/logos_payments-1.png.webp" alt="">
</div>
<div class="text-center mt-4">
<p class="footer-credit">© 2019 Coinfinancepro - ALL RIGHTS RESERVED.</p>
</div>
<div class="text-center mt-4">
<center>
<div class="d-flex col-5 col-lg-3">
<div class=""><img src="public/img/award001.png" width="80%" alt=""></div>
<div class=""><img src="public/img/award002.png" width="80%" alt=""></div>
<div class=""><img src="public/img/award003.png" width="80%" alt=""></div>
</div>
</center>
</div>
</div>
</div>
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script src="public/js/app.js"></script>


    </script>
     <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/webticker/jquery.webticker.min.js')); ?>"></script>
	
	<script src="<?php echo e(asset('vendor/apexchart/apexchart.js')); ?>"></script>
	<!-- Dashboard 2 -->
	<script src="<?php echo e(asset('js/dashboard/dashboard-2.js')); ?>"></script>

	<script src="<?php echo e(asset('js/demo.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/deznav.js')); ?>"></script>
    <script>
		function carouselReview(){
			jQuery('.testimonial-one').owlCarousel({
				loop:true,
				autoplay:true,
				margin:20,
				nav:false,
				rtl:true,
				dots: false,
				navText: ['', ''],
				responsive:{
					0:{
						items:3
					},
					450:{
						items:4
					},
					600:{
						items:5
					},	
					991:{
						items:5
					},			
					
					1200:{
						items:7
					},
					1601:{
						items:5
					}
				}
			})
		}
		jQuery(window).on('load',function(){
			setTimeout(function(){
				carouselReview();
			}, 1000); 
		});			
	</script>
</body>
</html>
