
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>




<link href="https://fonts.googleapis.com/css2?family=Thasadith&amp;display=swap" rel="stylesheet">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />




	<!-- META -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />    
    <meta name="description" content="" />
    
    <!-- FAVICONS ICON -->
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
    
    <!-- PAGE TITLE HERE -->
    <title>Why us</title>
    
    <!-- MOBILE SPECIFIC -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
  <!-- PAYOUT PROGRESS BAR CSS -->
 

<link rel="stylesheet" href="payout/main.html">


    
    <!-- [if lt IE 9]>
        <script src="js/html5shiv.min.js"></script>
        <script src="js/respond.min.js"></script>
	<![endif] -->
    
    
    
    <!-- BOOTSTRAP STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- FONTAWESOME STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/fontawesome/css/font-awesome.min.css" />
    <!-- FLATICON STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/flaticon.min.css">
    <!-- ANIMATE STYLE SHEET --> 
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <!-- OWL CAROUSEL STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <!-- BOOTSTRAP SELECT BOX STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <!-- MAGNIFIC POPUP STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.min.css">
    <!-- LOADER STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/loader.min.css">    
    <!-- MAIN STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- THEME COLOR CHANGE STYLE SHEET -->
    <link rel="stylesheet" class="skin" type="text/css" href="css/skin/skin-1.css">
    <!-- CUSTOM  STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/custom.css">
   

    
    <!-- REVOLUTION SLIDER CSS -->
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/settings.css">
    <!-- REVOLUTION NAVIGATION STYLE -->
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/navigation.css">
    
    <!-- GOOGLE FONTS -->
	
 
<style type="text/css">
#apDiv1 {
	position:absolute;
	left:1px;
	top:3155px;
	width:445px;
	height:294px;
	z-index:100000;
	font-size: 0.9em;
	color: #FFF;
	background-color: #903;
	text-align: center;
	display:none;
}


.text {

   font-family: 'Thasadith', sans-serif;
	font-size:19px;
	color:#FFFFFF;
	padding:0;
	margin:0; 
	overflow-x: hidden;
} 





.title {

   font-family:sans-serif;
	font-size:40px;
	font-weight:bolder;
 
	color:#000;

}






 


a {
  color: #ec5598;
  outline: 0 none;
  text-decoration:none;
}

a:hover,
a:focus {
  text-decoration:none;
  outline: 0 none;
}

a:active,
a:hover,
a:focus{
  color: #333333;
}

p a {
	color:#333333;
}
</style>
</head>

<body>
 
 

<header class="site-header header-style-3 topbar-transparent">
        
            
            
            <div class="sticky-header main-bar-wraper">
                <div class="main-bar">
                    <div class="container">
                         <a href="index.html">
                            <div style="background-image:url(images/logo-light.png); width:200px; background-position:left; background-size:contain; background-repeat:no-repeat" class="logo-header mostion">
                               
                               
                             
                            </div>   </a>
                            
                            <!-- NAV Toggle Button -->
                            <button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            
                           
                            <!-- ETRA Nav -->
                            
                             
                            <!-- SITE Search -->
                            
                            <!-- MAIN Vav -->
                            <div class="header-nav navbar-collapse collapse ">
                            <ul class=" nav navbar-nav">
                                <li>
                                    <a href="index.html">TRADING<i></i></a>
                                       
                                </li>
                                
                                
                                 <li>
                                    <a href="market.html">MARKET<i></i></a>
                                       
                                </li>
                                
                                
                                <li>
                                    <a href="login.html">LOGIN<i></i></a>
                                       
                                </li>
                                
                                  <li>
                                    <a href="registration.html">REGISTER<i></i></a>
                                       
                                </li>
                            
                                <li>
                                    <a href="javascript:;">INVESTMENT<i class="fa fa-chevron-down"></i></a>
                                    <ul class="sub-menu">
                                       
                                        <li>
                                            <a href="#">MAKE NEW INVESTMENT</a>
                                            
                                        </li>
                                        <li>
                                            <a href="#">CASHOUT FUND</a>
                                           
                                        </li>
                                         <li>
                                            <a href="#">ACCOUNTS</a>
                                            
                                        </li>
                                       
                                                                          <li>
                                            <a href="#">BLOCKCHAIN</a>
                                           
                                        </li>
                                        
                                        
                                    </ul>
                                </li>
                                
                              <li>
                                    <a href="why.html">WHY US<i></i></a>
                                       
                              </li>
                                <li>
                                    <a href="about.html">ABOUT US<i></i></a>
                                       
                              </li>
                              
                                  <li>
                                    <a href="faq.html">HELP<i></i></a>
                                       
                                </li>
                                
                                  <li>
                                    <a href="contact.html">SUPPORT<i></i></a>
                                       
                                </li>
                                
                                
                                
                            </ul>
                        </div>
        
                    </div>
                </div>
            </div>
            
        </header>	<div class="page-wraper">
	   
       	
       
        <div class="page-content">
        
         <div class="wt-bnr-inr overlay-wraper" style="background-image:url(images/banner/terms.jpg);">
                <div class="overlay-main bg-black opacity-07"></div>
                <div class="container">
                    <div class="wt-bnr-inr-entry">
                        <h1 class="text-white">WHY WE ARE THE BEST</h1>
                    </div>
                </div>
            </div>
        
              
             
            <!-- MARQUEE SCROLL SECTION  END -->    
                      
               
            <!-- BREADCRUMB ROW -->                            
            <div style="background-color:#039" class="bg-gray-light p-tb05">
                <div class="container">
                    <ul class="wt-breadcrumb breadcrumb-style-2">
                        <div class="col-sm-9"> <h3 style="color:#FFFFFF; font-weight:100">BECOME A MEMBER NOW</h3></div>
                           <div class="col-sm-3"><center><a style="background-color:#0C0;color:#FFF;font-weight:bolder; border-radius:8px" href="market.html" class="m-b15 site-button m-t15"  >OPEN AN ACCOUNT&nbsp;&nbsp;&nbsp;<i class="fa fa-play"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center> </div>
                    </ul>
                </div>
            </div>
            <!-- BREADCRUMB ROW END -->
             
                              
            <!-- BREADCRUMB ROW -->                            
      <div style="background-image:url(images/bg.png); background-position:top; background-repeat:repeat-y" class="section-content no-col-gap">
                        <div class="row">
                               
                            <!-- COLUMNS 1 --><!-- COLUMNS 2 --><!-- COLUMNS 3 -->
                                <div style=" padding:30px; margin-bottom:30px" class="col-md-12 col-sm-12 step-number-block">
                              
                               <center> 
                               
                               <h1 style=" font-size:3em; color:#FFFFFF">  WEBTRADER</h1>
                               <hr />
                               <h2 style="color:#FFFFFF">

WebTrader is an award-winning proprietary platform that requires no download. It is user-friendly and intuitive and is a firm favourite of many AvaTrade traders.
</h2>
   <br />                            
            
                   <div style=" color:#FFF; text-align:left; padding:10px;color:#666666">.</div></center>
                            </div>
                             <div class="col-md-2 col-sm-2 step-number-block"></div>
                        </div>
                        <center>        
                          <p><a href="#"class="site-button" style=" margin-top:10px;max-width:300px; padding:10px; border-radius:10px; min-width:190px">&nbsp; LOGIN TO DASHBOARD&nbsp;</a></p>
                          <p>&nbsp;</p>
                        </center>
                    </div>
            <!-- ABOUT COMPANY SECTION START -->
            <div style="background-color:#06F; background-image:url(images/thumbnail.html); background-repeat:repeat-x; margin-top:40px; padding-bottom:40px; color:#FFF" class="section-full p-t40">
                <div class="container">
                    <div class="row">
                    
                      <div style="margin-bottom:40px" class="col-md-6 col-sm-6">
                             <div style="width:100%; height:600px; background-image:url(images/best.png); background-position:left; background-repeat:no-repeat; background-size:contain"></div>
                      </div>
                    
                    
                    
                        <div class="col-md-6 col-sm-6">
                            <div class="section-head text-left"  data-animate="fadeInDown" data-duration="1.0s" data-delay="0.1s" data-offset="100">
                               
                               
                               
                                <p>
                               
                             <h3 style="color:#FFFFFF"> <strong>We Want You to Succeed</strong> – Learn from the best with our wide range of educational tools, , technical and fundamental analysis and important market updates you don’t want to miss. </h3>
                                </p>
                                
                                    <p>
                                
                         <h3 style="color:#FFFFFF">   <strong>We Believe in Endless Possibilities </strong>- Access the world’s most popular instruments, ranging from forex pairs to cryptocurrencies - all at the palm of your hand with our mobile app, AvaTradeGO.</h3>
                                </p>
                                
                                    <p><h3 style="color:#FFFFFF">
                               <strong>Our suite of powerful trading platforms</strong> was designed to meet the demanding needs of currency traders </h3> 
                                </p>
                                
                                
                                     <p><h3 style="color:#FFFFFF">
                             <strong>We Provide Our Traders With Superior Trading Conditions - </strong>No restrictions on and scalping as well as ultra-low spreads.</h3>
                               
                                </p>
                                
                              
                                
                             
                                 
                                 <span>
                                 
                                       
                                
                                 
                                 </span>
                            </div>
                        </div>
                      
                    </div>
                </div>
                
                
                
                
                
            </div> 
            
            
            
       <div style="padding-top:0px; height:50px; overflow:hidden; background-color:#DBDBDB; padding-bottom:50px;">
            
            <div class="container">
          <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>

  <script type="text/javascript" src="../s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "proName": "FOREXCOM:SPXUSD",
      "title": "S&P 500"
    },
    {
      "proName": "FOREXCOM:NSXUSD",
      "title": "Nasdaq 100"
    },
    {
      "proName": "FX_IDC:EURUSD",
      "title": "EUR/USD"
    },
    {
      "proName": "BITSTAMP:BTCUSD",
      "title": "BTC/USD"
    },
    {
      "proName": "BITSTAMP:ETHUSD",
      "title": "ETH/USD"
    }
  ],
  "showSymbolLogo": true,
  "colorTheme": "light",
  "isTransparent": true,
  "displayMode": "compact",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
            </div>
          </div>       
            
            
            
            
            
      
      
      
      
      
      
      
      <div>
                <div class="container">
                   
                    <!-- IMAGE CAROUSEL START -->
                    <div class="section-content">
                        <div class="owl-carousel home-logo-carousel">
                         <!-- COLUMNS 11 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                   
                                        <a href="#"><img src="images/what%20we%20do/crypto.jpg" alt=""></a>
                                   
                                </div>
                            </div>
                            
                             <div class="item">
                                <div class="ow-client-logo">
                                   
                                        <a href="#"><img src="images/what%20we%20do/1.jpg" alt=""></a>
                                   
                                </div>
                            </div>
                            
                            
                             <div class="item">
                                <div class="ow-client-logo">
                                   
                                        <a href="#"><img src="images/what%20we%20do/2.jpg" alt=""></a>
                                   
                                </div>
                            </div>
  
                             <div class="item">
                                <div class="ow-client-logo">
                                   
                                        <a href="#"><img src="images/what%20we%20do/4.jpg" alt=""></a>
                                   
                                </div>
                            </div>                            
                            
                            
                             <div class="item">
                                <div class="ow-client-logo">
                                   
                                        <a href="#"><img src="images/what%20we%20do/3.jpg" alt=""></a>
                                   
                                </div>
                            </div>
                            
                            <!-- COLUMNS 12 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                 
                                        <a href="#"><img src="images/what%20we%20do/binary_trading.jpg" alt=""></a>
                                   
                                </div>
                            </div>                        
                        
                        </div>
                    </div>
                    <!-- IMAGE CAROUSEL START -->
                </div>
            
          </div>
      
      
            <div style="background-color:#06F; background-repeat:repeat-x; margin-top:40px; padding-bottom:40px; color:#FFF" class="section-full p-t40">
                <div class="container">
                    <div style="height:1000px;" class="row">
                  <center>  <img src="images/map.png" alt="map" width="1014" height="495" /></center></div>
                    
              </div>
                    
                    </div>
            
      
   

<footer class="site-footer bg-no-repeat bg-full-height bg-center"  style="padding:0px; margin:0px;background-image:url(images/background/footer-bg.jpg);">
            <!-- FOOTER BLOCKES START -->  
            <div class="footer-top overlay-wraper">
                <div class="overlay-main bg-black opacity-05"></div>
                <div class="container">
                    <div class="row">
                        <!-- ABOUT COMPANY -->
                        <div style="padding-right:20px" class="col-md-3 col-sm-6">  
                            <div class="widget widget_about">
                                <h4 class="widget-title text-white">About Company</h4>
                                <div class="logo-footer clearfix p-b15">
                                    <a href="#"><img src="images/logo-light.png" width="221" height="54" alt=""/></a>
                                </div>
                                <p style="color:#FFFFFF">Alphafxcoin is designed to give direct return to investors thereby limiting investor’s risk due to fatal loss.
                              </p>  
                            </div>
                            
                            
                            
                                <div class="logo-footer clearfix p-b15">
                                    <a href="http://www.forex.com/"><img src="images/british.png" width="221" height="95" alt=""/></a>
                                </div>
                                <p style="color:#FFFFFF"><strong style="font-weight:bold">Forex.com</strong> Trusted and Ofiicial forex broker. 
                              </p>  
                       
                            
                        </div> 
                        <!-- RESENT POST -->
                        <div class="col-md-3 col-sm-6">
                            <div class="widget recent-posts-entry-date">
                                <h4 class="widget-title text-white">Supporters</h4>
                                <div class="widget-post-bx">
                                 <span style="color:#FFF">Company House U.K <small style="color:#999">Office of the official register of company in North Ireland, Scotland,England and Wales</small></span>
                                    <a style="margin-bottom:20px" href="https://beta.companieshouse.gov.uk/company/11568582/officers"><img src="images/companyhousel.png" width="250" height="130" alt=""/></a>
                                    <div style="margin-top:30px" class="bdr-light-blue widget-post clearfix  bdr-b-1 m-b10 p-b10">
                                                     <span style="color:#FFF">Paxful <small style="color:#999">Trusted Online Bitcoin Exchang Market</small></span>
                                       <a href="https://paxful.com/"><img src="images/paxful.png" width="250" height="130"  alt=""/></a>
                                        
                                    </div>
                                    
                              </div>
                            </div>
                        </div>      
                        <!-- USEFUL LINKS -->
                        <div class="col-md-3 col-sm-6">
                            <div class="widget widget_services">
                                <h4 class="widget-title text-white">Useful links</h4>
                                <ul>
                                    <li><a href="about.html">About</a></li>
                                    <li><a href="faq.html">FAQ</a></li>
                                    <li><a href="team.html">Our Team</a></li>
                                    <li><a href="terms.html">Terms</a></li>
                                    <li><a href="contact%20us.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- NEWSLETTER -->
                        <div class="col-md-3 col-sm-6">
                        <div style="width:300px; height:270px; background-image:url(img/tv.html); background-position:center; background-repeat:no-repeat">
                            
                           <center>
 <div style="width:98%; padding-top:24px; overflow:hidden;height:240px">
 <iframe width="255" height="168" src="https://www.youtube.com/embed/kubGCSj5y3k?autoplay=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
 
 </div>
                            
</center>
                            
                             </div>
                            <div class="widget widget_newsletter">
                                <h4 class="widget-title text-white">Newsletter</h4>
                                <div class="newsletter-bx">
                                    <form role="search" method="post">
                                        <div class="input-group">
                                        <input name="news-letter" class="form-control" placeholder="ENTER YOUR EMAIL" type="text">
                                        <span class="input-group-btn">
                                            <button type="submit" class="site-button"><i class="fa fa-paper-plane-o"></i></button>
                                        </span>
                                    </div>
                                     </form>
                                </div>
                            </div>
                            <!-- SOCIAL LINKS -->
                            <div class="widget widget_social_inks">
                                <h4 class="widget-title text-white">Social Links</h4>
                                <ul class="social-icons social-square social-darkest">
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-facebook"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-twitter"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-linkedin"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-rss"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-youtube"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-instagram"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
              </div>
            </div>
            <!-- FOOTER COPYRIGHT --></footer>        
      </div>
        <!-- FOOTER END -->

        
        <!-- BUTTON TOP START -->
        <button class="scroltop"><span class=" iconmoon-house relative" id="btn-vibrate"></span>Top</button>

        <!-- MODAL  LOGIN -->
        <div id="Login-form" class="modal fade " role="dialog">
          <div class="modal-dialog modal-sm">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-white">Login Your Account</h4>
              </div>
              <div class="modal-body p-a30">
              <form id="form1" name="form1" method="POST">
              <div class="form-group">
   <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input name="username" id="username" class="form-control" placeholder="Enter Username" type="text">
                </div>
                </div>
     <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input class="form-control" placeholder="Enter Password" name="password" type="password">
                        </div>
                </div>
                  
    <p>
      <input class="site-button-secondry text-uppercase btn-block m-b10" type="submit" name="button" id="button" value="Submit" />
    </p>
  </form>
              
                    <span class="font-12">Don't have an account? <a href="#invest">Chose an Investment option</a></span>
              
              </div>
              <div style="background-color:#000019" class="modal-footer text-center">
                <div class="text-center"><img src="images/logo-light.png" alt=""></div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- MODAL  REGISTER -->
                     
                
</div>
 

<!-- JAVASCRIPT  FILES ========================================= --> 
<script src="js/jquery-1.12.4.min.js"></script><!-- JQUERY.MIN JS -->
<script   src="js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->

<script   src="js/bootstrap-select.min.js"></script><!-- FORM JS -->
<script   src="js/jquery.bootstrap-touchspin.min.js"></script><!-- FORM JS -->

<script   src="js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->

<script   src="js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script   src="js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script   src="js/waypoints-sticky.min.js"></script><!-- COUNTERUP JS -->

<script  src="js/isotope.pkgd.min.js"></script><!-- MASONRY  -->

<script   src="js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->

<script   src="js/stellar.min.js"></script><!-- PARALLAX BG IMAGE   --> 
<script   src="js/scrolla.min.js"></script><!-- ON SCROLL CONTENT ANIMTE   -->

<script   src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script   src="js/shortcode.js"></script><!-- SHORTCODE FUCTIONS  -->

<script  src="js/jquery.bgscroll.js"></script><!-- BACKGROUND SCROLL -->
<script  src="js/tickerNews.min.js"></script><!-- TICKERNEWS-->
<!-- TICKERNEWS FUNCTiON -->
<script type="text/javascript">
	jQuery(function(){
		var timer = !1;
		_Ticker = jQuery("#T1").newsTicker();
		_Ticker.on("mouseenter",function(){
			var __self = this;
			timer = setTimeout(function(){
				__self.pauseTicker();
			},200);
		});
		_Ticker.on("mouseleave",function(){
			clearTimeout(timer);
			if(!timer) return !1;
			this.startTicker();
		});
	});
</script>
<!-- REVOLUTION JS FILES -->

<script  src="plugins/revolution/revolution/js/jquery.themepunch.tools.min.js"></script>
<script  src="plugins/revolution/revolution/js/jquery.themepunch.revolution.min.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->	
<script  src="plugins/revolution/revolution/js/extensions/revolution-plugin.js"></script>

<!-- REVOLUTION SLIDER FUNCTION  ===== -->
<script   src="js/rev-script-1.js"></script>













<!-- JAVASCRIPT  FILES ========================================= --> 
<script src="js/jquery-1.12.4.min.js"></script><!-- JQUERY.MIN JS -->
<script   src="js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->

<script   src="js/bootstrap-select.min.js"></script><!-- FORM JS -->
<script   src="js/jquery.bootstrap-touchspin.min.js"></script><!-- FORM JS -->

<script   src="js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->

<script   src="js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script   src="js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script   src="js/waypoints-sticky.min.js"></script><!-- COUNTERUP JS -->

<script  src="js/isotope.pkgd.min.js"></script><!-- MASONRY  -->

<script   src="js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->

<script   src="js/stellar.min.js"></script><!-- PARALLAX BG IMAGE   --> 
<script   src="js/scrolla.min.js"></script><!-- ON SCROLL CONTENT ANIMTE   -->

<script   src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script   src="js/shortcode.js"></script><!-- SHORTCODE FUCTIONS  -->

<script  src="js/jquery.bgscroll.js"></script><!-- BACKGROUND SCROLL -->
<script  src="js/tickerNews.min.js"></script><!-- MARQUEE SCROLL -->
<!-- MARQUEE FUNCTiON -->
<script type="text/javascript">
	$(function(){
		var timer = !1;
		_Ticker = $("#T1").newsTicker();
		_Ticker.on("mouseenter",function(){
			var __self = this;
			timer = setTimeout(function(){
				__self.pauseTicker();
			},200);
		});
		_Ticker.on("mouseleave",function(){
			clearTimeout(timer);
			if(!timer) return !1;
			this.startTicker();
		});
	});
</script>
<!-- REVOLUTION JS FILES -->

<script  src="plugins/revolution/revolution/js/jquery.themepunch.tools.min.js"></script>
<script  src="plugins/revolution/revolution/js/jquery.themepunch.revolution.min.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->	
<script  src="plugins/revolution/revolution/js/extensions/revolution-plugin.js"></script>

<!-- REVOLUTION SLIDER FUNCTION  ===== -->
<script type="text/javascript"  src="js/rev-script-4.js"></script>

</body>


<!-- Mirrored from alphafxcoin.com/why.php by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 27 Nov 2020 21:51:30 GMT -->
</html>