
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Welcome to Credit Invest</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/themify-icons/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style4.css')); ?>">



    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>
    <!-- Left Panel -->

   <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo"></a>
                <a class="navbar-brand hidden" href="./"><img src="<?php echo e(asset('images/logo2.png')); ?>" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-home"></i>Home</a>
                    </li>
                    <li class="menu-item-has-children dropdown active">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-user"></i>My Profile</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-user"></i><a href="maps-gmap.html">Update Account</a></li>
                            
                            <li><i class="menu-icon fa fa-cogs"></i><a href="<?php echo e(route('walletDetails')); ?>">Wallet Details</a></li>
                            <li><i class="menu-icon fa fa-group"></i><a href="maps-vector.html">Verify Account</a></li>
                        </ul>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-th-list"></i>Withdrawal</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-th-list"></i>Deposit</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-list"></i>Transaction Log</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-suitcase"></i>Investment</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-suitcase"></i>Loan</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-users"></i>My Downlines</a>
                    </li>
                     <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-users"></i>Credit Score</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('logout')); ?>"> <i class="menu-icon fa fa-dashboard"></i>Logout</a>
                    </li>
                    
                   
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
           <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        <button class="search-trigger"><i class="fa fa-search"></i></button>
                        <div class="form-inline">
                            <form class="search-form">
                                <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                                <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                            </form>
                        </div>

                        
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="<?php echo e(asset('images/admin.jpg')); ?>" alt="User Avatar">
                        </a>

                       
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a class="dropdown-toggle" href="#" data-toggle="dropdown"  id="language" aria-haspopup="true" aria-expanded="true">
                            <i class="flag-icon flag-icon-us"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="language">
                            <div class="dropdown-item">
                                <span class="flag-icon flag-icon-fr"></span>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-es"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-us"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-it"></i>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </header><!-- /header -->
        

        <div class="content mt-3">
           <?php if(Session::has('message')): ?>   
                <div id="info" style="font-size:13px;" class="alert alert-success alert-dismissible fade show" role="alert">
                    <strong><?php echo e(Session::get('message')); ?></strong>
                    <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </a>
                </div>
            <?php endif; ?>
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-xl-4 col-lg-7">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-wallet text-primary border-primary"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-heading text-primary" style="font-size:20px; font-weight:bold;">Total Balance</div>
                                <div class="stat-digit" style="font-size:25px;"">$<?php echo e($det1->usd_balance); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-xl-3 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-wallet text-primary border-primary"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-heading text-primary" style="font-size:20px; font-weight:bold;">Earning</div>
                                <div class="stat-digit" style="font-size:25px;">$<?php echo e($det1->earnings); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-5 col-lg-9">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-wallet text-primary border-primary"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-heading text-primary" style="font-size:20px; font-weight:bold;">Current Investment</div>
                                <?php if($det1->invested_amount > 0): ?>
                                <div class="stat-digit" style="font-size:25px;"><?php echo e($det1->current_investment); ?> PLAN :- $<?php echo e($det1->invested_amount); ?></div>
                                <?php else: ?>
                                 <div class="stat-digit" style="font-size:25px;">0</div>
                                 <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                    

                    <div class="col-lg-12">
                        <div class="card">
                            <input type="hidden" id="balance"  name="balance" value="<?php echo e($det1->usd_balance); ?>">
                             <input type="hidden" id="ids"  name="ids" value="<?php echo e($det1->user_id); ?>">
                             <input type="hidden" id="investor_emails"  name="investor_emails" value="<?php echo e(Auth::user()->email); ?>">
                             <input type="hidden" id="investment_status"  name="investment_status" value="<?php echo e($det1->investment_status); ?>">
                            <div class="card-body">
                                <!-- Credit Card -->
                                <div class="snip1276">
                                    <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Basic Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">5% After 24Hrs</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                        <li><i class="ion-checkmark"> </i>Minimun: $50</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: $1999</li>
                                        <li><i class="ion-checkmark"> </i>5% Referral Bonus</li>
                                        
                                        </ul>
                                        <div class="plan-select"><a data-name="BASIC" data-min="50" data-max="1999" data-profit="5" data-validity="1" class="btn-choose">Join Now</a></div>
                                    </div>
                                     <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Business Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">15% After 7Days</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                        <li><i class="ion-checkmark"> </i>Minimun: $2000</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: $4999</li>
                                        <li><i class="ion-checkmark"> </i>5% Referral Bonus</li>
                                        </ul>
                                        <div class="plan-select"><a data-name="BUSINESS" data-min="2000" data-max="4999" data-profit="15" data-validity="7" class="btn-choose">Join Now</a></div>
                                    </div>
                                    <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Company Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">30% After 10Days</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                      <li><i class="ion-checkmark"> </i>Minimun: $5000</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: $9999</li>
                                        <li><i class="ion-checkmark"> </i>5% Referral Bonus</li>
                                        </ul>
                                        <div class="plan-select"><a data-name="COMPANY" data-min="5000" data-max="4999" data-profit="30" data-validity="10" class="btn-choose">Join Now</a></div>
                                    </div>
                                    <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Expert Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">50% After 30Days</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                         <li><i class="ion-checkmark"> </i>Minimun: $10000</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: unlimited</li>
                                        <li><i class="ion-checkmark"> </i>5% Referral Bonus</li>
                                        </ul>
                                        <div class="plan-select"><a data-name="EXPERT" data-min="10000" data-max="999999999999999999" data-profit="50" data-validity="30" class="btn-choose">Join Now</a></div>
                                    </div>
                                </div>

                            </div>
                        </div> <!-- .card -->
                    </div>
                
                </div>    

            </div>

    <script src="<?php echo e(asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <?php echo $__env->make('user.modal.selectPlan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
         
        });

        //=============invoke select plan Modal
        $('.btn-choose').on('click',function(e) {
            e.preventDefault();
            $('#max').val($(this).data('max'));
            $('#min').val($(this).data('min'));
            $('#profit').val($(this).data('profit'));
            $('#validity').val($(this).data('validity'));
            $('#name').val($(this).data('name'));
            $('#investor_id').val(parseInt($('#ids').val()));
            $('#investor_email').val($('#investor_emails').val());
            var title = document.getElementById('title')
            title.innerHTML = '*'+ $(this).data('name') + ' PLAN *';
           $('#form_selectPlan').modal('show');
        });


        $('.btn-selectPlan').on('click',async function(e) {
            e.preventDefault();
            var amount = $('#amount').val();
            var min = parseInt($('#min').val());
            var max = parseInt($('#max').val());
            var amounts = parseInt($('#amount').val());
            var name = $('#name').val();
            var status = $('#investment_status').val();
                $('#wait_tag').hide();
                $('#invalid_tag').hide();
                $('#max_tag').hide();
                $('#min_tag').hide();
                

            if(amount == 0 || amount=='')
            {
                
                $('#wait_tag').show();
                await sleep(2000);
                $('#wait_tag').hide();
                $('#invalid_tag').show();
               
            }
            else if(status == 'Processing')
            {
                $('#wait_tag').show();
                await sleep(2000);
                $('#wait_tag').hide();
                $('#status_tag').show();    
            }
            else if(amounts < min)
            {
                var show_min = document.getElementById('show_min')
                show_min.innerHTML = 'Error!, The mininum amount allowed for ' + name + ' PLAN is $' +min;
               $('#wait_tag').show();
                await sleep(2000);
                $('#wait_tag').hide();
                $('#min_tag').show();
                
            }
            else if(amounts > max)
            {
                var show_max= document.getElementById('show_max')
                show_max.innerHTML = 'Error!, The maximum amount allowed for ' + name + ' PLAN is $' +max;
               $('#wait_tag').show();
                await sleep(2000);
                $('#wait_tag').hide();
                $('#max_tag').show();
                
            }
            else
            {
                var data = $('#selectPlan').serialize();
                console.log(data);
                $('#wait_tag').show();
                    await sleep(2000);
                    $('#wait_tag').hide();
                $.post("<?php echo e(route('saveInvestment')); ?>", data, function(data) {
                    $('#form_selectPlan').modal('hide');
                        window.location.href = '<?php echo e(route('investment1')); ?>'  

                })
            }

            /*var data = $('#editPlan').serialize();
            $.post("<?php echo e(route('updatePlan')); ?>", data, function(data) {
                showPlan();
            })
            $('#form_editPlan').modal('hide');
            $('#wait1').show()
            setTimeout(function(){
                $('#wait1').hide()
                        },4000)*/
        })
        function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }
        </script>
  </script>    
    <script src="<?php echo e(asset('vendors/popper.js/dist/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>


</body>

</html>