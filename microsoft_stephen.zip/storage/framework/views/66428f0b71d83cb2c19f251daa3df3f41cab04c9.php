
<!DOCTYPE html>
<html>
<head lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>StartUI - Premium Bootstrap 4 Admin Dashboard Template</title>

	<link href="img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144">
	<link href="img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114">
	<link href="img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72">
	<link href="img/favicon.57x57.png" rel="apple-touch-icon" type="image/png">
	<link href="img/favicon.png" rel="icon" type="image/png">
	<link href="img/favicon.ico" rel="shortcut icon">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap-sweetalert/sweetalert.css')); ?>">
 	<link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/sweet-alert-animations.min.css"')); ?>>
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/lobipanel/lobipanel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/lobipanel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/jqueryui/jquery-ui.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/separate/pages/widgets.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('css/style4.css')); ?>">
</head>
<body class="with-side-menu control-panel control-panel-compact">

	<header class="site-header">
	    <div class="container-fluid">
	        <a href="#" class="site-logo">
	            <img class="hidden-md-down" src="<?php echo e(asset('img/logo-2.png')); ?>" alt="">
	            <img class="hidden-lg-down" src="<?php echo e(asset('img/logo-2-mob.png')); ?>" alt="">
	        </a>
	
	        <button id="show-hide-sidebar-toggle" class="show-hide-sidebar">
	            <span>toggle menu</span>
	        </button>
	
	        <button class="hamburger hamburger--htla">
	            <span>toggle menu</span>
	        </button>
	        <div class="site-header-content">
	            <div class="site-header-content-in">
	                <div class="site-header-shown">
	               
	                   
	
	                </div><!--.site-header-shown-->
	
	                <div class="mobile-menu-right-overlay"></div>
	                <div class="site-header-collapsed">
	                    <div class="site-header-collapsed-in">
	                        
	                       
	                    </div><!--.site-header-collapsed-in-->
	                </div><!--.site-header-collapsed-->
	            </div><!--site-header-content-in-->
	        </div><!--.site-header-content-->
	    </div><!--.container-fluid-->
	</header><!--.site-header-->

	<div class="mobile-menu-left-overlay"></div>
	<nav class="side-menu">
	    <ul class="side-menu-list">
	        <li class="grey with-sub">
	            <span>
	                <i class="font-icon font-icon-dashboard"></i>
	                <span class="lbl">Dashboard</span>
	            </span>
	            <ul>
	                <li><a href="index.html"><span class="lbl">Default</span><span class="label label-custom label-pill label-danger">new</span></a></li>
	              
	     
	            </ul>
	        </li>
	         <li class="blue with-sub">
	            <span>
	                <i class="font-icon font-icon-user"></i>
	                <span class="lbl">Profile</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Version 1</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">Version 2</span></a></li>
					<li><a href="profile-2.html"><span class="lbl">Version 2</span></a></li>
	            </ul>
	        </li>
			<li class="pink-red with-sub">
	            <span>
	                <i class="font-icon font-icon-case-2"></i>
	                <span class="lbl">Deposit</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Deposit</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
			<li class="blue with-sub">
	            <span>
	                <i class="font-icon font-icon-zigzag"></i>
	                <span class="lbl">Invest</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Invest</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
			<li class="pink-red with-sub">
	            <span>
	                <i class="font-icon font-icon-case-2"></i>
	                <span class="lbl">Withdraw</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Withdraw</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
	        
	        
	        <li class="blue-dirty">
	            <a href="tables.html">
	                <span class="glyphicon glyphicon-th"></span>
	                <span class="lbl">My Earnings</span>
	            </a>
	        </li>
	        <li class="magenta with-sub">
	            <a href="tables.html">
	                <span class="glyphicon glyphicon-list-alt"></span>
	                <span class="lbl">My Downlines</span>
	            </a>
	        </li>
	        <li class="green with-sub">
	             <a href="tables.html">
	                <i class="font-icon glyphicon glyphicon-log-out"></i>
	                <span class="lbl">Logout</span>
	            </a>
	            
	        </li>
	   
	        
	    </ul>
	
	</nav><!--.side-menu-->

<div class="page-content">
		<div class="container-fluid">
			 <div class="card col-md-6 blue" style=" border: 1px solid #00a8ff; padding: 12px;">  
			 	 <div class="stat-widget-one">
                        <div class="stat-content dib">
                            <div class="stat-heading text-primary" style="font-size:25px; font-weight:bold;">Withdrawable Balance: $<?php echo e($det1->earnings); ?></div>
                            <input type="hidden" id="earnings"  name="earnings" value="<?php echo e($det1->earnings); ?>">
                        </div>
                   </div> 
              </div>
			
	
                                <!-- Credit Card -->
                                <div class="snip1276" style="border: 1px solid #00a8ff;">
                                    <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Basic Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">5% After 24Hrs</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                        <li><i class="ion-checkmark"> </i>Minimun: $50</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: $1999</li>
                                        <li><i class="ion-checkmark"> </i>10% Referral Bonus</li>
                                        
                                        </ul>
                                        <div class="plan-select"><a data-name="BASIC" data-min="50" data-max="1999" data-profit="5" data-validity="1" class="btn-choose">Join Now</a></div>
                                    </div>
                                     <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Business Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">15% After 7Days</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                        <li><i class="ion-checkmark"> </i>Minimun: $2000</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: $4999</li>
                                        <li><i class="ion-checkmark"> </i>10% Referral Bonus</li>
                                        </ul>
                                        <div class="plan-select"><a data-name="BUSINESS" data-min="2000" data-max="4999" data-profit="15" data-validity="7" class="btn-choose">Join Now</a></div>
                                    </div>
                                    <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Company Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">30% After 10Days</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                      <li><i class="ion-checkmark"> </i>Minimun: $5000</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: $9999</li>
                                        <li><i class="ion-checkmark"> </i>10% Referral Bonus</li>
                                        </ul>
                                        <div class="plan-select"><a data-name="COMPANY" data-min="5000" data-max="9999" data-profit="30" data-validity="10" class="btn-choose">Join Now</a></div>
                                    </div>
                                    <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Expert Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">50% After 30Days</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                         <li><i class="ion-checkmark"> </i>Minimun: $10000</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: unlimited</li>
                                        <li><i class="ion-checkmark"> </i>10% Referral Bonus</li>
                                        </ul>
                                        <div class="plan-select"><a data-name="EXPERT" data-min="10000" data-max="999999999999999999" data-profit="50" data-validity="30" class="btn-choose">Join Now</a></div>
                                    </div>
                                </div>



		</div><!--.container-fluid-->
	</div><!--.page-content-->


	<script src="<?php echo e(asset('js/lib/jquery/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap-sweetalert/sweetalert.min.js')); ?>"></script>
    <script type="text/javascript">
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
                    
        });

		
		  function checkBalance()
		  {
           var amt = parseFloat($('#usd').val());
           var earn = parseFloat($('#earnings').val());
		   var type = $("input[type='radio'][name='crypto']:checked").val();
           var crypt;
           if(amt == 0)
           {
                swal({
					title: "Oops!",
					text: "Invalid Amount, Enter a valid Amount",
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonClass: "btn-default",
					cancelButtonClass: "btn-warning",
					confirmButtonText: "Warning",
					closeOnConfirm: false
				});
                return false;
           }
           else if(amt > earn)
           {
               swal({
					title: "Oops!",
					text: "Error, Insufficient Balance",
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonClass: "btn-default",
					cancelButtonClass: "btn-warning",
					confirmButtonText: "Warning",
					closeOnConfirm: false
				});
                return false;
           }
           else
           {
                $('#wait').show();
                 setTimeout(function(){
                $('#wait').hide();
                },10000);

				
                return true;
                
           }
            
         }


		 $('.btn-done').on('click',function(e) { 
			    e.preventDefault();         
                window.location.href = '<?php echo e(route('finalizeDeposit')); ?>'  
        })
	


	</script>	
	<script src="<?php echo e(asset('js/lib/popper/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/tether/tether.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

	<script type="text/javascript" src="<?php echo e(asset('js/lib/jqueryui/jquery-ui.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/lib/lobipanel/lobipanel.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/lib/match-height/jquery.matchHeight.min.js')); ?>"></script>
	
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>