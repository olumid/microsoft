<!DOCTYPE html>

<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

    <!-- META -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />    
    <meta name="description" content="" />
    
    <!-- FAVICONS ICON -->
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
    
    <!-- PAGE TITLE HERE -->
    <title>About</title>
    
    <!-- MOBILE SPECIFIC -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- BOOTSTRAP STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- FONTAWESOME STYLE SHEET -->
    
    <link rel="stylesheet" href="vendors/font-awesome/css/font-awesome.min.css">
    <!-- FLATICON STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/flaticon.min.css">
    <!-- ANIMATE STYLE SHEET --> 
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <!-- OWL CAROUSEL STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <!-- BOOTSTRAP SELECT BOX STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <!-- MAGNIFIC POPUP STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.min.css">
    <!-- LOADER STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/loader.min.css">    
    <!-- MAIN STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- THEME COLOR CHANGE STYLE SHEET -->
    <link rel="stylesheet" class="skin" type="text/css" href="css/skin/skin-1.css">
    <!-- CUSTOM  STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/custom.css">
   

    
    <!-- GOOGLE FONTS -->
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,300italic,400italic,500,500italic,700,700italic,900italic,900' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,800italic,800,700italic' rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Crete+Round:400,400i&amp;subset=latin-ext" rel="stylesheet">
    
 
</head>

<body>
 
    <div class="page-wraper">
        	
        <!-- HEADER START -->
    
<header class="site-header header-style-3 topbar-transparent">
        
            
            
            <div class="sticky-header main-bar-wraper">
                <div class="main-bar">
                    <div class="container"><a href="./">
                            <div style="background-image:url(img/new/log6.png); width:200px; background-position:left; background-size:contain; background-repeat:no-repeat" class="logo-header mostion">
                            </div>   
                        </a>
                            <!-- NAV Toggle Button -->
                            <button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            
                           
                            <!-- ETRA Nav -->
                            
                             
                            <!-- SITE Search -->
                            
                            <!-- MAIN Vav -->
                            <div class="header-nav navbar-collapse collapse ">
                              <ul class=" nav navbar-nav">
                                <li>
                                    <a href="./">TRADING<i></i></a>
                                       
                                </li>
                                
                                
                                 <li>
                                    <a href="./market">MARKET<i></i></a>
                                       
                                </li>
                              
                                
                                <li>
                                    <a href="./login">LOGIN<i></i></a>
                                       
                                </li>
                                
                                  <li>
                                    <a href="./register">REGISTER<i></i></a>
                                       
                                </li>
                            
                               
                              <li>
                                    <a href="./why">WHY US<i></i></a>
                                       
                              </li>
                              <li>
                                    <a href="./about">ABOUT US<i></i></a>
                                       
                              </li>
                              
                             <li>
                                    <a href="./contact">SUPPORT<i></i></a>
                                       
                              </li>
                              <li>
                                    <a href="./faq">FAQ<i></i></a>
                                       
                              </li>
                                
                                <li>
                                  
                                </li>
                            </ul>
                        </div>
        
                    </div>
                </div>
            </div>
            
        </header>        <div style="width:100%; background-color:#000;height:150px"></div>
      
      
  
      
        <div class="page-content">
            
            <!-- INNER PAGE BANNER -->
            <div class="wt-bnr-inr overlay-wraper" style="background-image:url(images/banner/about-us.jpg);">
                <div class="overlay-main bg-black opacity-07"></div>
                <div class="container">
                
                    <div class="wt-bnr-inr-entry">
                        <h1 class="text-white">About CoinFinancePro Company</h1>
                    </div>
                </div>
            </div>
            <!-- INNER PAGE BANNER END --> 
                
       
      
                 <section class="sec-padding">
 
    <div class="container">
    
    <div class="row">  
  
          <div class="clearfix"></div>
          <p>
         <div style="margin-top:50px; margin-bottom:50px" class="row text-left">
      
            <div id="google_translate_element"></div>

        
        <div style="padding:10px" class="col-md-5">
        <h2 style=" border-bottom:solid 1px #00CC00; padding-bottom:20px;padding:10px" class="dancingscript  text-primary font-weight-8 margin-bottom-2">ABOUT US</h2>
        
       
          <p style="color:#000;padding:10px" class="bfont margin-bottom7"> CoinFinancePro is the most secure investment platform established to make it easier, faster & most secure for anyone interested in stock,forex and bitcoin investment

            CoinFinancePro is designed to give High gain return to investors thereby limiting investor’s risk due to fatal loss.

We have 4 active plans which pays in Hours weekly as the case may be, Our margin returns are high and also the best all over london.

Our user-friendly interface, available on our website and social media platforms, lets you buy,see progress and activities on each user account . We ensure the utmost security by maintaining good risk management strategy and processing every transaction semi-manually. Our quick earnings on low transaction fees and fast trading engine guarantees a seamless trading experience.
Founded in 2018, by a professional trader from Oxford Univesrsity in United Kingdom. The CoinFinancePro team is comprised of leading experts in Computer Science, Investment Security and Finance, and we are registered and regulated in the UK. We are currently headquartered in England, with subsidiaries in major countries worldwide, as we actively strive to expand globally.
</p>
    
       
      
        </div>
        
        <div class="col-md-7" style="background-image:url(images/abt.png); background-position:right; height:400px; background-repeat:no-repeat">
    
        </div>
        
      </div>
            
            
          </p>
          
          <center>

<script src="../cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script></center>
          
          
            
             <div class="col-md-12" style="width:100%; margin-top:-20px; z-index:1000; height:200px; overflow:hidden">
             <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>

  <script type="text/javascript" src="../s3.tradingview.com/external-embedding/embed-widget-forex-cross-rates.js" async>
  {
  "width": 1200,
  "height": 400,
  "currencies": [
    "EUR",
    "USD",
    "JPY",
    "GBP",
    "CHF",
    "AUD",
    "CAD",
    "NZD",
    "CNY"
  ],
  "isTransparent": true,
  "colorTheme": "dark",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
             
             </div>
      
      <div style="border:solid 1px #2D2D2D; height:500px; background-color:#181818" class="col-md-12">
      
      </div>
      
      
      
          <div class="col-md-12">
            <p><div><strong><h1>WHAT WE DO BEST</h1> </div>
<br>


<br>
A CFD, or Contract for Difference, is AlphaFx type of financial instrument that allows you to trade on the price movements of stocks, crypto currency regardless of whether prices are rising or falling. The key advantage of a CFD is the opportunity to speculate on the price movements of an asset (upwards or downwards) without actually owning the underlying asset.
</p> 
<br><br>
 <center>  <a href="contact.html" class="but-stbutton-9 text-small  margin-left-2 uppercase"> &nbsp; &nbsp;DO YOU NEED HELP&nbsp;&nbsp; <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a></center>
 </div>
  <!--end item-->

  </div>
    
    
    
      
    
    
    
    
    
    
    
    
    
    
    
      <div class="row">
  <br><br>
  <div class="clearfix"></div>

 <div class="col-md-6" style=" padding:15px; margin-top:30px; margin-bottom:100px; overflow:hidden; height:550px">
<div class="text-box padding-3 section-dark" style="background-color:#F0F0F0; padding-left:0px; margin-right:0px">
<center><div class="col-md-12"> <h4 style=" font-size:25px; font-weight:lighter; line-height:20px; color:#333333">Platforms Designed for  forex trading</h4></div>
<p style="font-size:15px"> Your Trading algorithm account gives you access to our full suite of platform for investment and cashout .
CHECKOUT OUR PLATFORMS</p></center>
<br/><center>

 
   <center>  <a style="background-color:#0C0;color:#FFF;font-weight:bolder; border-radius:8px" href="./register" class="m-b15 site-button m-t15"  >OPEN AN ACCOUNT&nbsp;&nbsp;&nbsp;<i class="fa fa-play"></i></a></center></p>
</center>
<p>
 

<p><img src="images/meta.png" alt="" width="535" height="358" align="left" class="img-responsive"/>
</p>
<div class="clearfix"></div>


</div>
  </div>

 
 <!-- end item-->
 
 <div class="col-md-6" style=" padding:15px; margin-top:30px; margin-bottom:100px; overflow:hidden; height:550px">
<div class="text-box padding-3 section-dark" style="background-color:#F0F0F0; padding-left:0px; margin-right:0px">
<center><div class="col-md-12"> <h4 style=" font-size:25px; font-weight:lighter; line-height:20px; color:#333333">Platforms Designed for  forex trading</h4></div>
<p style="font-size:15px"> We have tools installed in your dashboard that does the trade for you, all you do is to earn profit
CHECKOUT OUR PLATFORMS</p></center>
<br/><center>

 
   <a class="btn btn-medium btn-cyan btn-anim-4 uppercase xround-7" href="#">
  <span>Animation 4</span> 
  <i>Animation 4</i></a></p>
</center>
<p>
 

<p><img src="images/meta2.png" alt="" width="532" height="360" align="left" class="img-responsive"/>
</p>
<div class="clearfix"></div>


</div>
  </div>
 <!-- end item-->

  
  </div>
    </div>
    
    <div class="container">
                   
                    <!-- IMAGE CAROUSEL START -->
                    <div class="section-content">
                        <div class="owl-carousel home-logo-carousel">
                        
                        	<!-- COLUMNS 1 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w1.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 2 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w2.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 3 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w3.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 4 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w4.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 5 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w5.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 6 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w6.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 7 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w1.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 8 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w2.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 9 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w3.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 10 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w4.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 11 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w5.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 12 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w6.png" alt=""></a>
                                    </div>
                                </div>
                            </div>                        
                        
                        </div>
                    </div>
                    <!-- IMAGE CAROUSEL START -->
        </div>

</section>
       
            
            <!-- OUR TEAM MEMBER SECTION START -->
            <div class="section-full text-center wt-our-team bg-gray p-t80 p-b50">
                
              <div class="container">
                
                	<!-- TITTLE START -->
                    <div class="section-head text-center">
                        <h2 class="text-uppercase">About Us</h2>
                        
                  
                     
                    </div>
                    <!-- TITLE END -->
                    
                    
                
                </div>
            </div>
            <!-- OUR TEAM MEMBER SECTION END -->
                    
        </div>
        <!-- CONTENT END -->
        
        <!-- FOOTER START -->
        <div> 

<footer class="site-footer bg-no-repeat bg-full-height bg-center"  style="padding:0px; margin:0px;background-image:url(images/background/footer-bg.jpg);">
            <!-- FOOTER BLOCKES START -->  
            <div class="footer-top overlay-wraper">
                <div class="overlay-main bg-black opacity-05"></div>
                <div class="container">
                    <div class="row">
                        <!-- ABOUT COMPANY -->
                        <div style="padding-right:20px" class="col-md-3 col-sm-6">  
                            <div class="widget widget_about">
                                <h4 class="widget-title text-white">About Company</h4>
                          <a href="./">
                            <div style="background-image:url(img/new/log6.png); width:200px; background-position:left; background-size:contain; background-repeat:no-repeat" class="logo-header mostion">
                            </div>   
                        </a>
                                <p style="color:#FFFFFF">CoinFinancePro is designed to give direct return to investors thereby limiting investor’s risk due to fatal loss.
                              </p>  
                            </div>
                            
                            
                            
                                <div class="logo-footer clearfix p-b15">
                                    <a href="http://www.forex.com/"><img src="images/british.png" width="221" height="95" alt=""/></a>
                                </div>
                                <p style="color:#FFFFFF"><strong style="font-weight:bold">Forex.com</strong> Trusted and Ofiicial forex broker. 
                              </p>  
                       
                            
                        </div> 
                        <!-- RESENT POST -->
                        <div class="col-md-3 col-sm-6">
                            <div class="widget recent-posts-entry-date">
                                <h4 class="widget-title text-white">Supporters</h4>
                                <div class="widget-post-bx">
                                 <span style="color:#FFF">Company House U.K <small style="color:#999">Office of the official register of company in North Ireland, Scotland,England and Wales</small></span>
                                    <a style="margin-bottom:20px" href="https://beta.companieshouse.gov.uk/company/11568582/officers"><img src="images/companyhousel.png" width="250" height="130" alt=""/></a>
                                    <div style="margin-top:30px" class="bdr-light-blue widget-post clearfix  bdr-b-1 m-b10 p-b10">
                                                     <span style="color:#FFF">Paxful <small style="color:#999">Trusted Online Bitcoin Exchang Market</small></span>
                                       <a href="https://paxful.com/"><img src="images/paxful.png" width="250" height="130"  alt=""/></a>
                                        
                                    </div>
                                    
                              </div>
                            </div>
                        </div>      
                        <!-- USEFUL LINKS -->
                        <div class="col-md-3 col-sm-6">
                            <div class="widget widget_services">
                                <h4 class="widget-title text-white">Useful links</h4>
                                <ul>
                                    <li><a href="about.html">About</a></li>
                                    <li><a href="faq.html">FAQ</a></li>
                                    <li><a href="team.html">Our Team</a></li>
                                    <li><a href="terms.html">Terms</a></li>
                                    <li><a href="contact%20us.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- NEWSLETTER -->
                        <div class="col-md-3 col-sm-6">
                        <div style="width:300px; height:270px; background-image:url(img/tv.html); background-position:center; background-repeat:no-repeat">
                            
                           <center>
 <div style="width:98%; padding-top:24px; overflow:hidden;height:240px">
 <iframe width="255" height="168" src="https://www.youtube.com/embed/kubGCSj5y3k?autoplay=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
 
 </div>
                            
</center>
                            
                             </div>
                            <div class="widget widget_newsletter">
                                <h4 class="widget-title text-white">Newsletter</h4>
                                <div class="newsletter-bx">
                                    <form role="search" method="post">
                                        <div class="input-group">
                                        <input name="news-letter" class="form-control" placeholder="ENTER YOUR EMAIL" type="text">
                                        <span class="input-group-btn">
                                            <button type="submit" class="site-button"><i class="fa fa-paper-plane-o"></i></button>
                                        </span>
                                    </div>
                                     </form>
                                </div>
                            </div>
                            <!-- SOCIAL LINKS -->
                            <div class="widget widget_social_inks">
                                <h4 class="widget-title text-white">Social Links</h4>
                                <ul class="social-icons social-square social-darkest">
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-facebook"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-twitter"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-linkedin"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-rss"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-youtube"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-instagram"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
              </div>
            </div>
            <!-- FOOTER COPYRIGHT --></footer></div>
        <!-- FOOTER END -->
        
        <!-- BUTTON TOP START -->
        <button class="scroltop"><span class=" iconmoon-house relative" id="btn-vibrate"></span>Top</button>

        <!-- MODAL  LOGIN -->
        <div id="Login-form" class="modal fade " role="dialog">
          <div class="modal-dialog modal-sm">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-white">Login Your Account</h4>
              </div>
              <div class="modal-body p-a30">
                <form id="log-form">
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <input class="form-control" placeholder="Enter Username" type="text">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input class="form-control" placeholder="Enter email" type="email">
                        </div>
                    </div>
                    <button type="button" class="site-button-secondry text-uppercase btn-block m-b10">Submit</button>
                    <span class="font-12">Don't have an account? <a href="javascript:;" class="text-primary">Register Here</a></span>
                </form>
              </div>
              <div class="modal-footer text-center">
                <div class="text-center"><img src="images/logo.png" alt=""></div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- MODAL  REGISTER -->
        <div id="Register-form" class="modal fade " role="dialog">
          <div class="modal-dialog modal-sm">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-white">Register here</h4>
              </div>
              <div class="modal-body p-a30">
                <form id="reg-form">
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <input class="form-control" placeholder="Enter Username" type="text">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input class="form-control" placeholder="Enter email" type="email">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input class="form-control" placeholder="Enter Password" type="email">
                        </div>
                    </div>
                    <button type="button" class="site-button-secondry text-uppercase btn-block m-b10">Submit</button>
                    <span class="font-12">Already Have an Account? <a href="javascript:;" class="text-primary">Login</a></span>
                </form>
              </div>
              <div class="modal-footer text-center">
                <div class="text-center"><img src="images/logo.png" alt=""></div>
              </div>
            </div>
          </div>
        </div> 
            
    </div>
    
<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript">
        (function(){var gtConstEvalStartTime = new Date();/*

    Copyright The Closure Library Authors.
    SPDX-License-Identifier: Apache-2.0
    */
    var h=this||self,l=/^[\w+/_-]+[=]{0,2}$/,m=null;function n(a){return(a=a.querySelector&&a.querySelector("script[nonce]"))&&(a=a.nonce||a.getAttribute("nonce"))&&l.test(a)?a:""}function p(a,b){function c(){}c.prototype=b.prototype;a.i=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.h=function(g,f,k){for(var e=Array(arguments.length-2),d=2;d<arguments.length;d++)e[d-2]=arguments[d];return b.prototype[f].apply(g,e)}}function q(a){return a};function r(a){if(Error.captureStackTrace)Error.captureStackTrace(this,r);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))}p(r,Error);r.prototype.name="CustomError";function u(a,b){a=a.split("%s");for(var c="",g=a.length-1,f=0;f<g;f++)c+=a[f]+(f<b.length?b[f]:"%s");r.call(this,c+a[g])}p(u,r);u.prototype.name="AssertionError";function v(a,b){throw new u("Failure"+(a?": "+a:""),Array.prototype.slice.call(arguments,1));};var w;function x(a,b){this.g=b===y?a:""}x.prototype.toString=function(){return this.g+""};var y={};function z(a){var b=document.getElementsByTagName("head")[0];b||(b=document.body.parentNode.appendChild(document.createElement("head")));b.appendChild(a)}
    function _loadJs(a){var b=document;var c="SCRIPT";"application/xhtml+xml"===b.contentType&&(c=c.toLowerCase());c=b.createElement(c);c.type="text/javascript";c.charset="UTF-8";if(void 0===w){b=null;var g=h.trustedTypes;if(g&&g.createPolicy){try{b=g.createPolicy("goog#html",{createHTML:q,createScript:q,createScriptURL:q})}catch(t){h.console&&h.console.error(t.message)}w=b}else w=b}a=(b=w)?b.createScriptURL(a):a;a=new x(a,y);a:{try{var f=c&&c.ownerDocument,k=f&&(f.defaultView||f.parentWindow);k=k||h;
    if(k.Element&&k.Location){var e=k;break a}}catch(t){}e=null}if(e&&"undefined"!=typeof e.HTMLScriptElement&&(!c||!(c instanceof e.HTMLScriptElement)&&(c instanceof e.Location||c instanceof e.Element))){e=typeof c;if("object"==e&&null!=c||"function"==e)try{var d=c.constructor.displayName||c.constructor.name||Object.prototype.toString.call(c)}catch(t){d="<object could not be stringified>"}else d=void 0===c?"undefined":null===c?"null":typeof c;v("Argument is not a %s (or a non-Element, non-Location mock); got: %s",
    "HTMLScriptElement",d)}a instanceof x&&a.constructor===x?d=a.g:(d=typeof a,v("expected object of type TrustedResourceUrl, got '"+a+"' of type "+("object"!=d?d:a?Array.isArray(a)?"array":d:"null")),d="type_error:TrustedResourceUrl");c.src=d;(d=c.ownerDocument&&c.ownerDocument.defaultView)&&d!=h?d=n(d.document):(null===m&&(m=n(h.document)),d=m);d&&c.setAttribute("nonce",d);z(c)}
    function _loadCss(a){var b=document.createElement("link");b.type="text/css";b.rel="stylesheet";b.charset="UTF-8";b.href=a;z(b)}function _isNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)if(!(b=b[a[c]]))return!1;return!0}function _setupNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)b.hasOwnProperty?b.hasOwnProperty(a[c])?b=b[a[c]]:b=b[a[c]]={}:b=b[a[c]]||(b[a[c]]={});return b}
    window.addEventListener&&"undefined"==typeof document.readyState&&window.addEventListener("DOMContentLoaded",function(){document.readyState="complete"},!1);
    if (_isNS('google.translate.Element')){return}(function(){var c=_setupNS('google.translate._const');c._cest = gtConstEvalStartTime;gtConstEvalStartTime = undefined;c._cl='en';c._cuc='googleTranslateElementInit';c._cac='';c._cam='';c._ctkk='449410.1855493327';var h='translate.googleapis.com';var s=(true?'https':window.location.protocol=='https:'?'https':'http')+'://';var b=s+h;c._pah=h;c._pas=s;c._pbi=b+'/translate_static/img/te_bk.gif';c._pci=b+'/translate_static/img/te_ctrl3.gif';c._pli=b+'/translate_static/img/loading.gif';c._plla=h+'/translate_a/l';c._pmi=b+'/translate_static/img/mini_google.png';c._ps=b+'/translate_static/css/translateelement.css';c._puh='translate.google.com';_loadCss(c._ps);_loadJs(b+'/translate_static/js/element/main.js');})();})();
</script>
<!-- JAVASCRIPT  FILES ========================================= --> 
<script   src="js/jquery-1.12.4.min.js"></script><!-- JQUERY.MIN JS -->
<script   src="js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->

<script   src="js/bootstrap-select.min.js"></script><!-- FORM JS -->
<script   src="js/jquery.bootstrap-touchspin.min.js"></script><!-- FORM JS -->

<script   src="js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->

<script   src="js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script   src="js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script   src="js/waypoints-sticky.min.js"></script><!-- COUNTERUP JS -->

<script  src="js/isotope.pkgd.min.js"></script><!-- MASONRY  -->

<script   src="js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->

<script   src="js/stellar.min.js"></script><!-- PARALLAX BG IMAGE   --> 
<script   src="js/scrolla.min.js"></script><!-- ON SCROLL CONTENT ANIMTE   --> 

<script   src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script   src="js/shortcode.js"></script><!-- SHORTCODE FUCTIONS  -->

<script  src="js/jquery.bgscroll.js"></script><!-- BACKGROUND SCROLL -->
<script  src="js/tickerNews.min.js"></script><!-- TICKERNEWS-->







</body>


</html>
