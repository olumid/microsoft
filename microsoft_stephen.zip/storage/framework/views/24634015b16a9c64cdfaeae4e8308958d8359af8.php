<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="<?php echo e(asset('img/logo/logo4.png')); ?>" rel="icon">
  <title>Vanguards Invest</title>
  <link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('css/ruang-admin.min.css')); ?>" rel="stylesheet">
</head>

<body id="page-top">
  <div id="wrapper">
    <!-- Sidebar -->
    <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard1')); ?>">
        <div class="sidebar-brand-icon">
          <img src="<?php echo e(asset('img/logo/logo5.png')); ?>">
        </div>
        <div class="sidebar-brand-text mx-3"></div>
      </a>
      <hr class="sidebar-divider my-0">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard1')); ?>">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
      
       <li class="nav-item active">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseForm" aria-expanded="true"
          aria-controls="collapseForm">
          <i class="fas fa-fw fa-user"></i>
          <span>My Profile</span>
        </a>
        <div id="collapseForm" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('profile')); ?>">Update Account</a>
            <a class="collapse-item" href="<?php echo e(route('password')); ?>">Update Password</a>
            <a class="collapse-item" href="<?php echo e(route('walletDetails')); ?>">Update Wallet</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTable" aria-expanded="true"
          aria-controls="collapseTable">
          <i class="fas fa-fw fa-credit-card"></i>
          <span>Withdraw</span>
        </a>
        <div id="collapseTable" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('otpPage')); ?>">Withdraw</a>
            <a class="collapse-item" href="<?php echo e(route('withdrawHistory')); ?>">History</a>
          </div>
        </div>
      </li>
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePage" aria-expanded="true"
          aria-controls="collapsePage">
          <i class="fas fa-fw fa-credit-card"></i>
          <span>Deposit</span>
        </a>
        <div id="collapsePage" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('depositRequest')); ?>">Deposit</a>
            <a class="collapse-item" href="<?php echo e(route('depositHistory')); ?>">History</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBootstrap" aria-expanded="true"
          aria-controls="collapseBootstrap">
          <i class="fas fa-fw fa-credit-card"></i>
          <span>Investment</span>
        </a>
        <div id="collapseBootstrap" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('investment')); ?>">Invest</a>
            <a class="collapse-item" href="<?php echo e(route('investmentHistory')); ?>">History</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('loan')); ?>">
          <i class="far fa-fw fa-window-maximize"></i>
          <span>Loan</span>
        </a>
        
      </li>
       <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('earnings')); ?>">
          <i class="far fa-fw fa-window-maximize"></i>
          <span>My Earnings</span>
        </a>
        
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('showDownlines')); ?>">
          <i class="fas fa-fw fa-palette"></i>
          <span>My Downlines</span>
        </a>
        
      </li>
     
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('logout')); ?>">
          <i class="fas fa-fw fa-user"></i>
          <span>Logout</span>
        </a>
      </li>
     
    </ul>
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <!-- TopBar -->
        <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top">
          <button id="sidebarToggleTop" class="btn btn-link rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">
                <form class="navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-1 small" placeholder="What do you want to look for?"
                      aria-label="Search" aria-describedby="basic-addon2" style="border-color: #3f51b5;">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>
            
           
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img class="img-profile rounded-circle" src="<?php echo e(asset('img/boy.png')); ?>" style="max-width: 60px">
                <span class="ml-2 d-none d-lg-inline text-white small"><?php echo e(Auth::user()->name); ?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="javascript:void(0);" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
        </nav>
        <!-- Topbar -->

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
                  
          <div class="row mb-3">
             
              <div class="col-md-6">

                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="mb-0">PASSWORD MODIFICATION</h4>
                                    </div>
                                        <?php if(Session::has('success1')): ?>
                                        <div id="info" style="font-size:15px;" class="alert alert-success alert-dismissible fade show" role="alert">
                                            <strong><?php echo e(Session::get('success1')); ?></strong>
                                            <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </a>
                                        </div>
                                        <?php endif; ?>
                                        <?php if($errors->any()): ?>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div style="margin-left:19px; margin-right:19px;" class="alert alert-danger" style="font-size:15px;">
                                                    <i class=""></i><?php echo e($error); ?>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <?php if(Request::get('errorMessage') !== null): ?>
                                            <p style='padding:15px;' class='bg-danger'><?php echo e(Request::get('errorMessage')); ?></p>
                                        <?php endif; ?>
                                        <?php if(Request::get('success') !== null): ?>
                                            <p style='padding:15px;' class='bg-success'><?php echo e(Request::get('success')); ?></p>
                                        <?php endif; ?>
                                    <div class="card-body">
                                        <form  action="<?php echo e(route('updateUserPassword')); ?>" class="needs-validation" novalidate=""  method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <div class="mb-3">
                                                <label for="username">Current Password</label>
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text">@</span>
                                                    </div>
                                                    <input type="password" class="form-control" name="current_password" required="">
                                                    <div class="invalid-feedback" style="width: 100%;">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="email">New Password <span class="text-muted"></span></label>
                                                <input type="password" class="form-control" name="password">
                                                <div class="invalid-feedback">
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label for="address">Confirm Password</label>
                                                <input type="password" class="form-control" name="password_confirmation" required="">
                                                <div class="invalid-feedback">
                                                </div>
                                            </div>


                                            <button class="btn btn-primary btn-lg btn-block" id="update-pass" type="submit">
                                            <i class="fa fa-check-circle fa-lg"></i>&nbsp;UPDATE
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
            
          </div>
          <!--Row-->

         
        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>VANGUARDS INVEST &copy; 2017 All Right Reserved
              <b><a href="#" target="_blank"></a></b>
            </span>
          </div>
        </div>
      </footer>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/ruang-admin.min.js')); ?>"></script>
   
</body>

</html>