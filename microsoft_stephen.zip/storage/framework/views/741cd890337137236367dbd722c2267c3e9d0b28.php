<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->

  <link rel="stylesheet" href="account/css/style1.css">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- endinject -->
 <link href="<?php echo e(asset('img/logo/logo6.png')); ?>" rel="icon">
  <!-- PAGE TITLE HERE -->
    <title>Register</title>
<!--Start of Tawk.to Script-->

<!--End of Tawk.to Script-->

</head>

<body>
    <style> #hide{display:none;}</style>

  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-stretch auth auth-img-bg">
        <div class="row flex-grow">
          <div class="col-lg-6 d-flex align-items-center justify-content-center">
            <div class="auth-form-transparent text-left p-3">
            <div id="google_translate_element"></div>
              <div class="brand-logo">
                  <strong style="color:goldenrod; padding-top:20px;">CRYPTOTRUST.COM</strong>
              </div>
              <h4>New here?</h4>
              <h6 class="font-weight-light">Join us today! It takes only few steps</h6>
            <form class="pt-3" action="<?php echo e(route('addAccount')); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="rfnumber" value="1429359" readonly="true" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password">
              <input type="text" id="hide" name="subject"  value="Thanks for joining us" class="form-control form-control-lg border-left-0">

                <div class="form-group <?php echo e($errors->has('fullname') ?  'has-error' : ''); ?>">
                  <label>Full Name</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-user-circle text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="fullname" class="form-control form-control-lg border-left-0" placeholder="First Name">
                  </div>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('fullname')); ?></p>
                </div>
                
                <div class="form-group <?php echo e($errors->has('email') ?  'has-error' : ''); ?>">
                  <label>Email</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-address-card-o text-primary"></i>
                      </span>
                    </div>
                    <input type="email" name="email" class="form-control form-control-lg border-left-0" placeholder="Email">
                  </div>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('email')); ?></p>
                </div>
                <div class="form-group <?php echo e($errors->has('username') ?  'has-error' : ''); ?>">
                  <label>USER ID</label>
                  <div class="input-group" style="margin-bottom:10px;">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-user-secret text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="username" class="form-control form-control-lg border-left-0" placeholder="USER ID">
                  </div>
                  <span>minimum of 6 characters required. space not allowed</span>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('username')); ?></p>
                </div>
               
                <div class="form-group <?php echo e($errors->has('password') ?  'has-error' : ''); ?>">
                  <label>Password</label>
                  <div class="input-group" style="margin-bottom:10px;">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-low-vision text-primary"></i>
                      </span>
                    </div>
                    <input type="password"  name="password" class="form-control form-control-lg border-left-0" placeholder="Password">                        
                  </div>
                  <span>Minimum of 8 characters required with at least 1 of each: upper case, lower case and numeric character</span>
                 <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('password')); ?></p>
                </div>
                <div class="form-group">
                  <label>Confirm Password</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-low-vision text-primary"></i>
                      </span>
                    </div>
                    <input type="password"  name="password_confirmation" class="form-control form-control-lg border-left-0" id="" placeholder="Confirm Password">                        
                  </div>
                </div>
                <div class="form-group <?php echo e($errors->has('country') ?  'has-error' : ''); ?>">
                  <label>Country</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-country-square text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="country" class="form-control form-control-lg border-left-0" placeholder="Phone Number">
                  </div>
                </div>
                <div class="form-group">
                  <label>Phone Number(optional)</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-phone-square text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="phone" class="form-control form-control-lg border-left-0" placeholder="Phone Number">
                  </div>
                </div>
                <?php if(Session::has('referrer')): ?>  
                 <div class="form-group">
                  <label>Referral ID(optional)</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="text-primary"></i>
                      </span>
                    </div>
                    <input readonly type="text" value="<?php echo e(Session::get('referrer')); ?>" name="referral_id" class="form-control form-control-lg border-left-0" placeholder="YFLM813A">
                  </div>
                 </div>
                <?php else: ?>
                <div class="form-group">
                  <label>Referral ID(optional)</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="referral_id" class="form-control form-control-lg border-left-0" placeholder="YFLM813A">
                  </div>
                 </div>
                <?php endif; ?>
                <div class="form-group <?php echo e($errors->has('security_question') ?  'has-error' : ''); ?>">
                  <label>Security Question</label>
                  <div class="input-group">
                   
                    <select name="security_question" class="form-control form-control-lg border-left-0">
                      <option value="0">Security Question</option>
                      <option value="What was your childhood nickname?">What was your childhood nickname?</option>
                      <option value="What is the name of your favourite childhood friend?">What is the name of your favourite childhood friend?</option>
                      <option value="What street did you live in in third Grade?">What street did you live in in third Grade?</option>
                      <option value="What schood did you attend for sixth grade?">What schood did you attend for sixth grade?</option>
                      <option value="What is your maternal grandmother's maiden name?">What is your maternal grandmother's maiden name?</option>
                  </select>
                  </div>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"> <p style="color: red;"><?php echo e($errors->first('security_question')); ?></p>
                </div>
                <div class="form-group <?php echo e($errors->has('answer') ?  'has-error' : ''); ?>">
                  <label>Answer</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-question-circle text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="answer" class="form-control form-control-lg border-left-0" placeholder="Answer">
                  </div>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"> <p style="color: red;"><?php echo e($errors->first('answer')); ?></p>
                </div>
                <div style="margin-left: 5%" class="mb-4 <?php echo e($errors->has('terms') ?  'has-error' : ''); ?>">
                  <div class="form-check">
                    <label class=" text-muted">
                      <input type="checkbox" class="form-check-input" checked="checked" name="terms">
                      I agree to all Terms & Conditions
                    </label>
                  </div>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"> <p style="color: red;"><?php echo e($errors->first('terms')); ?></p>
                </div>
                <div class="mt-3">
                  <button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn"  type="submit" name="submit">SIGN UP</button>
                </div>
                <div class="text-center mt-4 font-weight-light">
                  Already have an account? <a href="./login" class="text-primary">Login</a>
                </div>
              </form>
            </div>
          </div>
          <div class="col-lg-6 register-half-bg d-flex flex-row">
            <p class="text-white font-weight-medium text-center flex-grow align-self-end">CRYPTOTRUST.COM &copy; 2017 All Right Reserved.</p>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
    <!-- container-scroller -->
  <!-- plugins:js -->
<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript">
        (function(){var gtConstEvalStartTime = new Date();/*

    Copyright The Closure Library Authors.
    SPDX-License-Identifier: Apache-2.0
    */
    var h=this||self,l=/^[\w+/_-]+[=]{0,2}$/,m=null;function n(a){return(a=a.querySelector&&a.querySelector("script[nonce]"))&&(a=a.nonce||a.getAttribute("nonce"))&&l.test(a)?a:""}function p(a,b){function c(){}c.prototype=b.prototype;a.i=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.h=function(g,f,k){for(var e=Array(arguments.length-2),d=2;d<arguments.length;d++)e[d-2]=arguments[d];return b.prototype[f].apply(g,e)}}function q(a){return a};function r(a){if(Error.captureStackTrace)Error.captureStackTrace(this,r);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))}p(r,Error);r.prototype.name="CustomError";function u(a,b){a=a.split("%s");for(var c="",g=a.length-1,f=0;f<g;f++)c+=a[f]+(f<b.length?b[f]:"%s");r.call(this,c+a[g])}p(u,r);u.prototype.name="AssertionError";function v(a,b){throw new u("Failure"+(a?": "+a:""),Array.prototype.slice.call(arguments,1));};var w;function x(a,b){this.g=b===y?a:""}x.prototype.toString=function(){return this.g+""};var y={};function z(a){var b=document.getElementsByTagName("head")[0];b||(b=document.body.parentNode.appendChild(document.createElement("head")));b.appendChild(a)}
    function _loadJs(a){var b=document;var c="SCRIPT";"application/xhtml+xml"===b.contentType&&(c=c.toLowerCase());c=b.createElement(c);c.type="text/javascript";c.charset="UTF-8";if(void 0===w){b=null;var g=h.trustedTypes;if(g&&g.createPolicy){try{b=g.createPolicy("goog#html",{createHTML:q,createScript:q,createScriptURL:q})}catch(t){h.console&&h.console.error(t.message)}w=b}else w=b}a=(b=w)?b.createScriptURL(a):a;a=new x(a,y);a:{try{var f=c&&c.ownerDocument,k=f&&(f.defaultView||f.parentWindow);k=k||h;
    if(k.Element&&k.Location){var e=k;break a}}catch(t){}e=null}if(e&&"undefined"!=typeof e.HTMLScriptElement&&(!c||!(c instanceof e.HTMLScriptElement)&&(c instanceof e.Location||c instanceof e.Element))){e=typeof c;if("object"==e&&null!=c||"function"==e)try{var d=c.constructor.displayName||c.constructor.name||Object.prototype.toString.call(c)}catch(t){d="<object could not be stringified>"}else d=void 0===c?"undefined":null===c?"null":typeof c;v("Argument is not a %s (or a non-Element, non-Location mock); got: %s",
    "HTMLScriptElement",d)}a instanceof x&&a.constructor===x?d=a.g:(d=typeof a,v("expected object of type TrustedResourceUrl, got '"+a+"' of type "+("object"!=d?d:a?Array.isArray(a)?"array":d:"null")),d="type_error:TrustedResourceUrl");c.src=d;(d=c.ownerDocument&&c.ownerDocument.defaultView)&&d!=h?d=n(d.document):(null===m&&(m=n(h.document)),d=m);d&&c.setAttribute("nonce",d);z(c)}
    function _loadCss(a){var b=document.createElement("link");b.type="text/css";b.rel="stylesheet";b.charset="UTF-8";b.href=a;z(b)}function _isNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)if(!(b=b[a[c]]))return!1;return!0}function _setupNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)b.hasOwnProperty?b.hasOwnProperty(a[c])?b=b[a[c]]:b=b[a[c]]={}:b=b[a[c]]||(b[a[c]]={});return b}
    window.addEventListener&&"undefined"==typeof document.readyState&&window.addEventListener("DOMContentLoaded",function(){document.readyState="complete"},!1);
    if (_isNS('google.translate.Element')){return}(function(){var c=_setupNS('google.translate._const');c._cest = gtConstEvalStartTime;gtConstEvalStartTime = undefined;c._cl='en';c._cuc='googleTranslateElementInit';c._cac='';c._cam='';c._ctkk='449410.1855493327';var h='translate.googleapis.com';var s=(true?'https':window.location.protocol=='https:'?'https':'http')+'://';var b=s+h;c._pah=h;c._pas=s;c._pbi=b+'/translate_static/img/te_bk.gif';c._pci=b+'/translate_static/img/te_ctrl3.gif';c._pli=b+'/translate_static/img/loading.gif';c._plla=h+'/translate_a/l';c._pmi=b+'/translate_static/img/mini_google.png';c._ps=b+'/translate_static/css/translateelement.css';c._puh='translate.google.com';_loadCss(c._ps);_loadJs(b+'/translate_static/js/element/main.js');})();})();
</script>
</body>

</html>
