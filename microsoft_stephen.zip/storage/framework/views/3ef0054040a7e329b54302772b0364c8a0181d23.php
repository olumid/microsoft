<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="theme-color" content="#33363f">
<meta property="og:locale" content="en_US" />
<meta property="og:site_name" content="Coinfinancepro" />
<meta property="og:title" content="Online Investment Platform With 24/7 Support | Coinfinancepro" />

<link href="{{asset('img/new/android-icon-48x48.png')}}" rel="icon">
<title>Online Crypto investment Platform with 24/7 Support | Coinfinancepro</title>
<link rel="stylesheet" href="public/css/style1.css">
<link rel="stylesheet" href="public/css/scale.css">
<link rel="stylesheet" type="text/css" href="public/vendor/DataTables/datatables.css" />
<link rel="stylesheet" href="public/vendor/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="public/vendor/fontawesome/css/all.css">
<scrip src="public/vendor/jquery/jquery.js"></scrip>
<script type="text/javascript" src="public/vendor/DataTables/datatables.js"></script>
<script src="public/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<script src="public/vendor/fontawesome/js/all.js"></script>
</head>
<body>
<div id="custom-loader" class="">
<div id="app-loader-bg">
<div id="app-loader"></div>
</div>
</div>
<div class="app-header-pages">
<nav id="sticky-nav" class="navbar navbar-expand-md navbar-light fixed-header p-0">
<div class="container">
<a class="navbar-brand" href="https://Coinfinancepro.trade/en-us">
<img src="https://Coinfinancepro.trade/public/img/logo/oraimo-dark.png" alt="" width="" height="40">
</a>
<span class="navbar-text">
<button onclick="location.href='./sign-up'" class=" btn btn-success">Open account</button>
</span>
</div>
</nav>
</div>
<div class="page-container">
<div class="container mb-5">
<h1 class="my-dark my-montserrat my-300 my-gradient mb-5">Anti-Money Laundering Policy</h1>
<strong>Introduction</strong>
<p class="my-montserrat my-dark">Coinfinancepro is wholly committed to the fight against money laundering. As part of our commitment to combat and eliminate money laundering, we have implemented an educational program for all personnel to complete during their initial training. This program focuses on the fundamentals of Anti-Money Laundering (AML) and our internal Compliance Procedures.</p>
<p class="my-montserrat my-dark">Having successfully completed the internal program, all clients are required to read, acknowledge and act in accordance with Coinfinancepro’s “Anti-Money Laundering & Compliance Procedures Manual.</p>
<strong>Definition</strong>
<p class="my-montserrat my-dark">Money laundering is the term used for the concealment of illegally obtained money, typically by means of transfers involving foreign banks and legitimate financial institutions.</p>
<strong>Principles</strong>
<p class="my-montserrat my-dark">The key principles of the “Anti-Money Laundering Statement” are that:</p>
<ol>
<li>
<p class="my-montserrat my-dark">Coinfinancepro will maintain a written document of AML policy and procedures and a system of internal controls to ensure ongoing AML compliance by a designated person(s) and to take appropriate action, once suspicious activity is detected.</P>
</li>
<li>
<p class="my-montserrat my-dark">Coinfinancepro will comply with applicable anti-money laundering & terrorist financing laws and regulations wherever possible.</p>
</li>
<li>
<p class="my-montserrat my-dark">Coinfinancepro’s anti-money laundering policies apply to all business units and departments.</p>
</li>
<li>
<p class="my-montserrat my-dark">Protect Coinfinancepro from money laundering & terrorist financing.</p>
</li>
<li>
<p class="my-montserrat my-dark">All identified suspicious activities must be reported to the extent of all applicable foreign and domestic laws.</p>
</li>
<li>
<p class="my-montserrat my-dark">All the Client’s related documents will be preserved for a period that will not be less than five (5) years or in accordance with law requirements.</p>
</li>
<li>
<p class="my-montserrat my-dark">Coinfinancepro will cooperate fully with law enforcement and regulatory agencies to the extent that it can do so under all applicable laws in the event that there is cause to believe that a breach in AML procedures has occurred.</p>
</li>
<li>
<p class="my-montserrat my-dark">Coinfinancepro commits to no withdrawal being actioned from ANY Client account without full and satisfactory ‘know your customer’ or ‘compliance and due diligence’ checks being carried out. This means that any documentation required must be supplied in order to proceed with the return of funds to the Client.</p>
</li>
<li>
<p class="my-montserrat my-dark">Funds will always be returned to the initial source of funding. In simple terms if you have deposited via a wire transfer the funds will be returned via wire transfer; if you have used a Visa card, funds will be returned to the Visa card. At no point will Coinfinancepro deviate from this.</p>
</li>
</ol>
<p class="my-montserrat my-dark">Should you have any further questions regarding the Anti-Money Laundering policy, email our support team or contact us via our online chat for further clarification or assistance.</p>
<div class="mt-5">
<button onclick="print()" class="btn btn-secondary btn-lg"><i class="fad fa-share"></i> Print Document</button>
</div>
</div>
</div>
<div class="container">
<div class="cta-block p-5">
<h1 class="my-dark my-montserrat my-300 text-center">Trade with confidence. Trade with Coinfinancepro.</h1>
<p class="my-dark my-montserrat text-center mb-4">Join thousands of people who choose to trade with us, enjoying over 100 instruments including 24/7 trading of Digital Assets.</p>
<center class="mb-3">
 <div class="col-12 col-md-6">
<button onclick="location.href='./sign-up'" class="btn btn-primary">Open an account</button>
</div>
</center>
</div>
</div>
<div class="footer-block">
<div class="container">
<div class="row">
<div class="col-6 col-md-4 mb-3 mb-md-0">
<div class="foot-header">Company</div>
<div class="foot-body">
<a href="./about" class="foot">About Us</a>
<a href="tel:+1(260) 488 6441" class="foot"><b>Phone:</b> +1(260) 488 6441</a>
<a href="https://maps.google.com/?q=Irvington, Carlisle CA6 4NW, United Kingdom" class="foot"><b>UK Address:</b> Irvington, Carlisle CA6 4NW, United Kingdom</a>
<a href="https://maps.google.com/?q=9030 Metropolitan Ave, Queens, NY 11374, United States" class="foot"><b>US Address:</b> 9030 Metropolitan Ave, Queens, NY 11374, United States</a>
</div>
</div>

<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Trading</div>
<div class="foot-body">
<a href="./sign-up" class="foot">Open Live Account</a>
<a href="./sign-up" class="foot">Instruments</a>

<a href="./sign-up" class="foot">Market Analysis</a>
</div>
</div>
<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Funding</div>
<div class="foot-body">
<a href="./sign-up" class="foot">Funding Methods</a>
<a href="./sign-up" class="foot">Clients Protection</a>
</div>
</div>
<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Legal</div>
<div class="foot-body">
<a href="./aml-policy" class="foot">AML Policy</a>
<a href="./cookie-policy" class="foot">Cookie Policy</a>
<a href="./privacy-policy" class="foot">Privacy Policy</a>
<a href="./risk-disclosure" class="foot">Risk Disclosure</a>
<a href="./terms" class="foot">Terms & Conditions</a>
</div>
</div>
</div>
<div class="footer-sub mb-4 mt-5">
<p><strong>Risk Warning:</strong> CFD and Spot Forex trading both come with a high degree of risk. You must be prepared to sustain a total loss of any funds deposited with us, as well as any additional losses, charges, or other costs we incur in recovering any payment from you. Given the possibility of losing more than your entire investment, speculation in certain investments should only be conducted with risk capital funds that if lost will not significantly affect your personal or institution’s financial well-being. Before deciding to trade the products offered by us, you should carefully consider your objectives, financial situation, needs and level of experience. You should also be aware of all the risks associated with trading on margin. Please read our <a href="./risk-disclosure">Risk Disclosure document</a></p>
</div>
<div class="footer-sub mb-2">
<p>© Copyright 2019 All Rights Reserved. Coinfinancepro Ltd, 8 Copthall, Roseau Valley 00152, The Commonwealth of Dominica. <br>
This website is not directed at any jurisdiction and is not intended for any use that would be contrary to local law or regulation.</p>
</div>
<div class="text-center mt-5">
<img src="https://www.eaglefx.com/images/logos_payments-1.png.webp" alt="">
</div>
<div class="text-center mt-4">
<p class="footer-credit">© 2019 Coinfinancepro - ALL RIGHTS RESERVED.</p>
</div>
<div class="text-center mt-4">
<center>
<div class="d-flex col-5 col-lg-3">
<div class=""><img src="public/img/award001.png" width="80%" alt=""></div>
<div class=""><img src="public/img/award002.png" width="80%" alt=""></div>
<div class=""><img src="public/img/award003.png" width="80%" alt=""></div>
</div>
</center>
</div>
</div>
</div>
<script src="public/js/app.js"></script>


    </script>

</body>
</html>
