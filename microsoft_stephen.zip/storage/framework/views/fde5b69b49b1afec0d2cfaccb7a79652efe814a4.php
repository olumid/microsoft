 <?php if(count($user)> 0): ?>
                                <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                                    <thead class="text-primary" style="font-size:18px; font-weight:bold;">
                                        <tr>
                                            <th>S/N</th>
                                            <th>Username</th>
                                            <th>FullName</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Usd Balance</th>
                                            <th>Total Deposit</th>
                                            <th>Total Withdraw</th>
                                            <th>Earning</th>
                                            <th>Investment</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Credit Score</th>
                                            <th>Loan</th>
                                            <th>Action</th>
                                            <th>Action</th>

                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key+1); ?></td>
                                            <td><?php echo e($list->username); ?></td>
                                            <td><?php echo e($list->fullname); ?></td>
                                            <td><?php echo e($list->email); ?></td>
                                            <td><?php echo e($list->phone); ?></td>
                                            <td>$<?php echo e($list->balance); ?></td>
                                            <td>$<?php echo e($list->deposit); ?></td>
                                            <td>$<?php echo e($list->withdraw); ?></td>
                                            <td>$<?php echo e($list->earnings); ?></td>
                                            <?php if($list->current == ''): ?>
                                            <td>No Investment</td>
                                            <?php else: ?>
                                            <td><?php echo e($list->current); ?></td>
                                            <?php endif; ?>
                                            
                                            <td>$<?php echo e($list->amount); ?></td>
                                            <?php if($list->status == ''): ?>
                                            <td>Null</td>
                                            <?php else: ?>
                                            <td><?php echo e($list->status); ?></td>
                                            <?php endif; ?>
                                            <td><?php echo e($list->credit); ?></td>
                                            <td>$<?php echo e($list->loan); ?></td>
                                             <td>
                                                  <button class="btn btn-success btn-xs btn-editAcct" data-ids="<?php echo e($list->ids); ?>" data-balance="<?php echo e($list->balance); ?>" data-deposit="<?php echo e($list->deposit); ?>" data-loan="<?php echo e($list->loan); ?>" data-withdraw="<?php echo e($list->withdraw); ?>" data-deposit="<?php echo e($list->deposit); ?>" data-earnings="<?php echo e($list->earnings); ?>"><i class="fa fa-edit"></i>Update Acct</button>  
                                            </td>
                                            <td>
                                                  <button class="btn btn-primary btn-xs btn-editCredit" data-ids="<?php echo e($list->ids); ?>" data-credit="<?php echo e($list->credit); ?>"><i class="fa fa-edit"></i>Credit Score</button>                                                   
                                            </td>
                                           <td>
                                                  <button class="btn btn-primary btn-xs btn-editPassword" data-ids="<?php echo e($list->uid); ?>"><i class="fa fa-edit"></i>Change Password</button>                                                   
                                            </td>
                                           
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php endif; ?> 