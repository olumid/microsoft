 <?php if(count($user)> 0): ?>
                                <table class="table align-items-center table-flush table-hover" id="dataTableHover">
                                    <thead class="text-primary" style="font-size:18px; font-weight:bold;">
                                        <tr>
                                            <th style="color: white;">S/N</th>
                                            <th style="color: white;">Username</th>
                                            <th style="color: white;">FullName</th>
                                            <th style="color: white;">Email</th>
                                            <th style="color: white;">Phone</th>
                                            <th style="color: white;">Loan Status</th>
                                            <th style="color: white;">Action</th>
                                            <th style="color: white;">Action</th> 
                                            <th style="color: white;">Action</th>   
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key+1); ?></td>
                                            <td><?php echo e($list->username); ?></td>
                                            <td><?php echo e($list->fullname); ?></td>
                                            <td><?php echo e($list->email); ?></td>
                                            <td><?php echo e($list->phone); ?></td>
                                            <?php if($list->loan > 0): ?>
                                            <td>Can Borrow </td>
                                            <?php else: ?>
                                            <td>Can't Borrow </td>
                                            <?php endif; ?>
                                            <td>
                                                  <button class="btn btn-primary btn-xs btn-editPassword" data-ids="<?php echo e($list->uid); ?>"><i class="fa fa-edit"></i>Change Password</button>                                                   
                                            </td>
                                            <td>
												<a href="<?php echo e(route('viewWallets',$list->uid)); ?>" class="btn btn-warning btn-sm btn-view" ><i class="fa fa-check-square"></i> Manage Wallets</a>
											</td>
                                            <?php if($list->loan > 0): ?>
                                                <td>
													<a href="<?php echo e(route('dontAllowBorrow',$list->uid)); ?>" class="btn btn-danger btn-sm btn-stop"><i class="fa fa-spinner"></i> Dis-allow Borrow</a>                                                   
												</td>
											<?php else: ?>
												<td>
													<a href="<?php echo e(route('allowBorrow',$list->uid)); ?>" class="btn btn-success btn-sm btn-stop"><i class="fa fa-spinner"></i>Allow Borrow</a>                                                   
												</td>
											<?php endif; ?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php endif; ?> 