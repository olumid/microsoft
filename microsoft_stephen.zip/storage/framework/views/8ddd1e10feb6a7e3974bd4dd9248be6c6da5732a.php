
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Coin Finance Pro -- Referral System </title>
    <!-- Favicon icon -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/chartist/css/chartist.min.css')); ?>">
    <link href="<?php echo e(asset('vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap-sweetalert/sweetalert.css')); ?>">
    <link href="<?php echo e(asset('css/style11.css')); ?>" rel="stylesheet">
	<style>
		@import  url(https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&family=Titillium+Web:wght@400;700&display=swap);
		select{
			font-size: 20px;
			font-weight: bolder;
			
		}
	</style>
	
</head>
<body style="font-family: 'Titillium Web'; color:white">

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="<?php echo e(route('dashboard1')); ?>" class="brand-logo">
               <img src="<?php echo e(asset('img/new/log.png')); ?>" alt="">
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		
		<!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="dashboard_bar">
                                
                            </div>

                        <ul class="navbar-nav header-right">
							
							
							
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <img src="images/profile/pic1.jpg" width="20" alt=""/>
									<div class="header-info">
										<span><?php echo e(Auth::user()->name); ?></span>
									</div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a href="./app-profile.html" class="dropdown-item ai-icon">
                                        <svg id="icon-user1" xmlns="http://www.w3.org/2000/svg" class="text-primary" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                        <span class="ml-2">Profile </span>
                                    </a>
                                    <a href="./email-inbox.html" class="dropdown-item ai-icon">
                                        <svg id="icon-inbox" xmlns="http://www.w3.org/2000/svg" class="text-success" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                                        <span class="ml-2">Inbox </span>
                                    </a>
                                    <a href="./page-login.html" class="dropdown-item ai-icon">
                                        <svg id="icon-logout" xmlns="http://www.w3.org/2000/svg" class="text-danger" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                                        <span class="ml-2">Logout </span>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('dashboard1')); ?>" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        

                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('manageWallet')); ?>">
						<i class="flaticon-381-television"></i>
							<span class="nav-text">Wallets</span>
						</a>
                       
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('investment')); ?>">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">Packages</span>
						</a>
                        
                    </li>
                   
                    <li><a href="<?php echo e(route('password')); ?>" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Update Password</span>
						</a>
					</li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('withdrawRequest')); ?>" aria-expanded="false">
							<i class="flaticon-381-notepad"></i>
							<span class="nav-text">Withdraw</span>
						</a>
                       
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('transactionAll')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Transactions</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('depositHistory')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Orders</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('showDownlines')); ?>" aria-expanded="false">
							<i class="flaticon-381-heart"></i>
							<span class="nav-text">Referral</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('logout')); ?>" aria-expanded="false">
							<i class="flaticon-381-exit"></i>
							<span class="nav-text">Logout</span>
						</a> 
                    </li>
                    
                </ul>
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                
                <!-- row -->
				<div class="row">
	
									
									<div class="col-lg-3">
										<div class="card border coin-holding-card border-primary">
											<div class="card-body bg-primary rounded">
												<div class="d-flex align-items-center">
													
													<div>
														<h4 class="font-w500 text-white title mb-0">Referrals</h4>
														
													</div>
												</div>
												<div class="d-flex flex-wrap mt-4 align-items-center">	
													<div class="d-flex align-items-center mr-auto pr-3 mb-2">
														
														<h4 class="font-w500 text-white amount mb-0"><?php echo e(count($downline)); ?></h4>
													</div>
													<div class="mb-2">
														<svg width="14" height="8" viewBox="0 0 14 8" fill="none" xmlns="http://www.w3.org/2000/svg">
															<path d="M0.707108 6.06712C0.0771426 6.69709 0.523309 7.77423 1.41421 7.77423L12.3601 7.77423C13.251 7.77423 13.6972 6.69709 13.0672 6.06712L7.59426 0.594186C7.20373 0.203662 6.57057 0.203662 6.18005 0.594186L0.707108 6.06712Z" fill="#61C277"/>
														</svg>
														<span class="text-white fs-14"></span>
													</div>
												</div>	
											</div>
											
										</div>
									</div>
									<div class="col-lg-3">
										<div class="card border coin-holding-card border-primary">
											<div class="card-body bg-primary rounded">
												<div class="d-flex align-items-center">
													
													<div>
														<h4 class="font-w500 text-white title mb-0">Bonus</h4>
														
													</div>
												</div>
												<div class="d-flex flex-wrap mt-4 align-items-center">	
													<div class="d-flex align-items-center mr-auto pr-3 mb-2">
														
														<h4 class="font-w500 text-white amount mb-0">0</h4>
													</div>
													<div class="mb-2">
														<svg width="14" height="8" viewBox="0 0 14 8" fill="none" xmlns="http://www.w3.org/2000/svg">
															<path d="M0.707108 6.06712C0.0771426 6.69709 0.523309 7.77423 1.41421 7.77423L12.3601 7.77423C13.251 7.77423 13.6972 6.69709 13.0672 6.06712L7.59426 0.594186C7.20373 0.203662 6.57057 0.203662 6.18005 0.594186L0.707108 6.06712Z" fill="#61C277"/>
														</svg>
														<span class="text-white fs-14"></span>
													</div>
												</div>	
											</div>
											
										</div>
									</div>
				</div>
                <div class="row">
				    <div class="col-lg-5"> 
                        <div class="">
                           
                            <div class="card-body">
							<div class="form-group">
								<label for="amount">Referral Link </label>
                                <input type="text" class="form-control" name="address" id="address" value="http://localhost/iq/public/register?ref=<?php echo e(Auth::user()->username); ?>" readonly>
                            </div>
                            <label id="l1" for="" style="display:none; color:white;">Copied!!</label>
							<button type="button" class="btn btn-lg btn-warning btn-block btn-dep" onclick="copyToClipboard()">
								<i class="fa fa-copy fa-lg"></i>&nbsp;
								<span id="dep">Copy</span>
							</button>	  
                            </div>
                        </div>
                    </div>
					
                    <div class="col-lg-10">
                        <div class="card">
                            <div class="card-header">
                                <h4 style="font-size: 29px;" class="card-title">Referrals</h4>
                            </div>
                            <div class="card-body">

                                <div class="table-responsive">
                                  <?php if(count($downline)> 0): ?>
                                    <table class="table table-responsive-md">
                                        <thead>
                                            <tr>
                                                
                                                <th><strong>S/N</strong></th>
                                                <th><strong>Username</strong></th>
                                                <th><strong>Email</strong></th>
                                                
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $downline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <tr>
                                                  <td><?php echo e($key+1); ?></td>
                                                  <td><?php echo e($list->name); ?></td>
                                                  <td><?php echo e($list->email); ?></td>
                                                
                                              </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
                                        </tbody>
                                    </table>
                                   <?php else: ?>
                                        <p style="color: #fff; font-size: 25px; font-weight: bold; margin-top: 30px; text-align: center">Error! No Entry Found, Try Again  </p>
                                    <?php endif; ?>
                  
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright ©  <a href="#" target="_blank"></a> 2021</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

	</div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->

	<script src="<?php echo e(asset('j/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap-sweetalert/sweetalert.min.js')); ?>"></script>
	<script type="text/javascript">
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
                    
        });

		function copyToClipboard(){
            $('#address').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l1').show()
           setTimeout(function(){
              $('#l1').hide();
            },3000)
        }

	</script>	

    <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	
	<!-- Chart piety plugin files -->
    <script src="<?php echo e(asset('vendor/peity/jquery.peity.min.js')); ?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo e(asset('vendor/apexchart/apexchart.js')); ?>"></script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo e(asset('js/dashboard/dashboard-1.js')); ?>"></script>
	
	<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/deznav-init.js')); ?>"></script>

	

</body>
</html>