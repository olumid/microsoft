<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="<?php echo e(asset('img/logo/logo4.png')); ?>" rel="icon">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Vanguards Invest</title>
  <link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('css/ruang-admin.min.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('assets/css/style4.css')); ?>">
</head>

<body id="page-top">
  <div id="wrapper">
    <!-- Sidebar -->
    <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard1')); ?>">
        <div class="sidebar-brand-icon">
          <img src="<?php echo e(asset('img/logo/logo5.png')); ?>">
        </div>
        <div class="sidebar-brand-text mx-3"></div>
      </a>
      <hr class="sidebar-divider my-0">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard1')); ?>">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
      
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseForm" aria-expanded="true"
          aria-controls="collapseForm">
          <i class="fas fa-fw fa-user"></i>
          <span>My Profile</span>
        </a>
        <div id="collapseForm" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('profile')); ?>">Update Account</a>
            <a class="collapse-item" href="<?php echo e(route('password')); ?>">Update Password</a>
            <a class="collapse-item" href="<?php echo e(route('walletDetails')); ?>">Update Wallet</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTable" aria-expanded="true"
          aria-controls="collapseTable">
          <i class="fas fa-fw fa-credit-card"></i>
          <span>Withdraw</span>
        </a>
        <div id="collapseTable" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('otpPage')); ?>">Withdraw</a>
            <a class="collapse-item" href="<?php echo e(route('withdrawHistory')); ?>">History</a>
          </div>
        </div>
      </li>
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePage" aria-expanded="true"
          aria-controls="collapsePage">
          <i class="fas fa-fw fa-credit-card"></i>
          <span>Deposit</span>
        </a>
        <div id="collapsePage" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('depositRequest')); ?>">Deposit</a>
            <a class="collapse-item" href="<?php echo e(route('depositHistory')); ?>">History</a>
          </div>
        </div>
      </li>
      <li class="nav-item active">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBootstrap" aria-expanded="true"
          aria-controls="collapseBootstrap">
          <i class="fas fa-fw fa-credit-card"></i>
          <span>Investment</span>
        </a>
        <div id="collapseBootstrap" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('investment')); ?>">Invest</a>
            <a class="collapse-item" href="<?php echo e(route('investmentHistory')); ?>">History</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('loan')); ?>">
          <i class="far fa-fw fa-window-maximize"></i>
          <span>Loan</span>
        </a>
        
      </li>
       <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('earnings')); ?>">
          <i class="far fa-fw fa-window-maximize"></i>
          <span>My Earnings</span>
        </a>
        
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('showDownlines')); ?>">
          <i class="fas fa-fw fa-palette"></i>
          <span>My Downlines</span>
        </a>
        
      </li>
     
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('logout')); ?>">
          <i class="fas fa-fw fa-user"></i>
          <span>Logout</span>
        </a>
      </li>
     
    </ul>
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <!-- TopBar -->
        <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top">
          <button id="sidebarToggleTop" class="btn btn-link rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">
                <form class="navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-1 small" placeholder="What do you want to look for?"
                      aria-label="Search" aria-describedby="basic-addon2" style="border-color: #3f51b5;">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>
            
           
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img class="img-profile rounded-circle" src="<?php echo e(asset('img/boy.png')); ?>" style="max-width: 60px">
                <span class="ml-2 d-none d-lg-inline text-white small"><?php echo e(Auth::user()->name); ?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="javascript:void(0);" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
        </nav>
        <!-- Topbar -->

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
                  
          <div class="row mb-3">
                                 
              <div class="col-xl-4 col-lg-7">
                        <div class="card">
                            <div class="card-body">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-wallet text-primary border-primary"></i></div>
                                    <div class="stat-content dib">
                                        <div class="stat-heading text-primary" style="font-size:20px; font-weight:bold;">Total Balance</div>
                                        <div class="stat-digit" style="font-size:25px;">$<?php echo e($det1->usd_balance); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-xl-3 col-lg-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-wallet text-primary border-primary"></i></div>
                                    <div class="stat-content dib">
                                        <div class="stat-heading text-primary" style="font-size:20px; font-weight:bold;">Earning</div>
                                        <div class="stat-digit" style="font-size:25px;">$<?php echo e($det1->earnings); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-5 col-lg-9">
                        <div class="card">
                            <div class="card-body">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-wallet text-primary border-primary"></i></div>
                                    <div class="stat-content dib">
                                        <div class="stat-heading text-primary" style="font-size:20px; font-weight:bold;">Current Investment</div>
                                        <?php if($det1->invested_amount > 0): ?>
                                        <div class="stat-digit" style="font-size:25px;"><?php echo e($det1->current_investment); ?> PLAN :- $<?php echo e($det1->invested_amount); ?></div>
                                        <?php else: ?>
                                        <div class="stat-digit" style="font-size:25px;">0</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                 
                    <div class="col-lg-12" style="margin-top:10px;">
                        <div class="card">
                            <input type="hidden" id="balance"  name="balance" value="<?php echo e($det1->usd_balance); ?>">
                             <input type="hidden" id="ids"  name="ids" value="<?php echo e($det1->user_id); ?>">
                             <input type="hidden" id="investor_emails"  name="investor_emails" value="<?php echo e(Auth::user()->email); ?>">
                             <input type="hidden" id="investment_status"  name="investment_status" value="<?php echo e($det1->investment_status); ?>">
                            <div class="card-body">
                                <!-- Credit Card -->
                                <div class="snip1276">
                                    <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Basic Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">5% After 24Hrs</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                        <li><i class="ion-checkmark"> </i>Minimun: $50</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: $1999</li>
                                        <li><i class="ion-checkmark"> </i>10% Referral Bonus</li>
                                        
                                        </ul>
                                        <div class="plan-select"><a data-name="BASIC" data-min="50" data-max="1999" data-profit="5" data-validity="1" class="btn-choose">Join Now</a></div>
                                    </div>
                                     <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Business Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">15% After 7Days</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                        <li><i class="ion-checkmark"> </i>Minimun: $2000</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: $4999</li>
                                        <li><i class="ion-checkmark"> </i>10% Referral Bonus</li>
                                        </ul>
                                        <div class="plan-select"><a data-name="BUSINESS" data-min="2000" data-max="4999" data-profit="15" data-validity="7" class="btn-choose">Join Now</a></div>
                                    </div>
                                    <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Company Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">30% After 10Days</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                      <li><i class="ion-checkmark"> </i>Minimun: $5000</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: $9999</li>
                                        <li><i class="ion-checkmark"> </i>10% Referral Bonus</li>
                                        </ul>
                                        <div class="plan-select"><a data-name="COMPANY" data-min="5000" data-max="9999" data-profit="30" data-validity="10" class="btn-choose">Join Now</a></div>
                                    </div>
                                    <div class="plan">
                                        <header>
                                        <h4 class="plan-title">
                                            Expert Plan
                                        </h4>
                                        <div class="plan-cost"><span class="plan-price">50% After 30Days</span><span class="plan-type"></span></div>
                                        </header>
                                        <ul class="plan-features" style="font-size:18px; font-weight:bold;">
                                         <li><i class="ion-checkmark"> </i>Minimun: $10000</li>
                                        <li><i class="ion-checkmark"> </i>Maximum: unlimited</li>
                                        <li><i class="ion-checkmark"> </i>10% Referral Bonus</li>
                                        </ul>
                                        <div class="plan-select"><a data-name="EXPERT" data-min="10000" data-max="999999999999999999" data-profit="50" data-validity="30" class="btn-choose">Join Now</a></div>
                                    </div>
                                </div>

                            </div>
                        </div> <!-- .card -->
                    </div>  

          </div>
          <!--Row-->

         
        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <span>VANGUARDS INVEST &copy; 2017 All Right Reserved
              <b><a href="#" target="_blank"></a></b>
            </span>
          </div>
        </div>
      </footer>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>
  <?php echo $__env->make('user.modal.selectPlan', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
  <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script type="text/javascript">
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
            
        
        });

         //=============invoke select plan Modal
        $('.btn-choose').on('click',function(e) {
            e.preventDefault();
            $('#max').val($(this).data('max'));
            $('#min').val($(this).data('min'));
            $('#profit').val($(this).data('profit'));
            $('#validity').val($(this).data('validity'));
            $('#name').val($(this).data('name'));
            $('#investor_id').val(parseInt($('#ids').val()));
            $('#investor_email').val($('#investor_emails').val());
            var title = document.getElementById('title')
            title.innerHTML = '*'+ $(this).data('name') + ' PLAN *';
           $('#form_selectPlan').modal('show');
        });


        $('.btn-selectPlan').on('click',async function(e) {
            e.preventDefault();
            var amount = $('#amount').val();
            var min = parseInt($('#min').val());
            var max = parseInt($('#max').val());
            var amounts = parseInt($('#amount').val());
            var name = $('#name').val();
            var status = $('#investment_status').val();
                $('#wait_tag').hide();
                $('#invalid_tag').hide();
                $('#max_tag').hide();
                $('#min_tag').hide();
                

            if(amount == 0 || amount=='')
            {
                
                $('#wait_tag').show();
                await sleep(2000);
                $('#wait_tag').hide();
                $('#invalid_tag').show();
               
            }
            else if(status == 'Processing')
            {
                $('#wait_tag').show();
                await sleep(2000);
                $('#wait_tag').hide();
                $('#status_tag').show();    
            }
            else if(amounts < min)
            {
                var show_min = document.getElementById('show_min')
                show_min.innerHTML = 'Error!, The mininum amount allowed for ' + name + ' PLAN is $' +min;
               $('#wait_tag').show();
                await sleep(2000);
                $('#wait_tag').hide();
                $('#min_tag').show();
                
            }
            else if(amounts > max)
            {
                var show_max= document.getElementById('show_max')
                show_max.innerHTML = 'Error!, The maximum amount allowed for ' + name + ' PLAN is $' +max;
               $('#wait_tag').show();
                await sleep(2000);
                $('#wait_tag').hide();
                $('#max_tag').show();
                
            }
            else
            {
                var data = $('#selectPlan').serialize();
                console.log(data);
                $('#wait_tag').show();
                    await sleep(2000);
                    $('#wait_tag').hide();
                $.post("<?php echo e(route('saveInvestment')); ?>", data, function(data) {
                    $('#form_selectPlan').modal('hide');
                        window.location.href = '<?php echo e(route('investment1')); ?>'  

                })
            }

            /*var data = $('#editPlan').serialize();
            $.post("<?php echo e(route('updatePlan')); ?>", data, function(data) {
                showPlan();
            })
            $('#form_editPlan').modal('hide');
            $('#wait1').show()
            setTimeout(function(){
                $('#wait1').hide()
                        },4000)*/
        })
        function sleep(ms) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }
    
        </script>
    
  <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/ruang-admin.min.js')); ?>"></script>
   
   
</body>

</html>