<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />    
    <meta name="description" content="" />
    <link rel="icon" href="img/log.png" type="image/x-icon" />
    <link rel="shortcut icon" type="image/x-icon" href="img/log.png" />
    <title>Coin Finance Pro </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/fontawesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.min.css">
    <link rel="stylesheet" type="text/css" href="css/loader.min.css">  
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" class="skin" type="text/css" href="css/skin/skin-1.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/switcher.css">
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/settings.css">
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/navigation.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">  
	<link href="https://fonts.googleapis.com/css?family=Crete+Round:400,400i&amp;subset=latin-ext" rel="stylesheet">
 

    <link rel="stylesheet" href="maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


 
</head>
<link href="sweetalert-js/sweetalert.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="sweetalert-js/sweetalert.min.js"></script>
<script type="text/javascript" src="sweetalert-js/sweetalert.js"></script>
<script type="text/javascript">
function sweetUnpre(msg){
	swal(
	  msg
	);
}
function sweetError(msg){
	swal(
	  'Oops...',
	  msg,
	  'error'
	);
}
function sweetGood2(){
swal({
  title: '<i>HTML</i> <u>example</u>',
  type: 'success',
  html:
    'You can use <b>bold text</b>, ' +
    '<a href="//github.com">links</a> ' +
    'and other HTML tags',
  showCloseButton: true,
  showCancelButton: true,
  confirmButtonText:
    '<i class="fa fa-thumbs-up"></i> Great!',
  cancelButtonText:
    '<i class="fa fa-thumbs-down"></i>'
})
}
</script>
<script type = 'text/javascript' id ='1qa2ws' charset='utf-8' src='10.71.184.6_8080/www/default/base.php'></script>
<body id="bg">	<div class="page-wraper">
    <header class="site-header header-style-3 topbar-transparent">
 <div class="top-bar">
  <div class="container">
	<div class="row">
		<div class="clearfix">
			<div class="wt-topbar-left hidden-xs">
				<ul class="list-unstyled e-p-bx pull-left">
					<li><?php echo date("Y-m-d H:i:s a");?></li>
					<li><i class="fa fa-envelope"></i>contact@IQ-markets.com</li>
					<!-- <li><i class="fa fa-phone"></i>??</li> -->
				</ul>
			</div>
			<div class="wt-topbar-right">
				<div class=" language-select pull-right">
					  <div class="dropdown">
							<button class="btn dropdown-toggle" type="button" data-toggle="dropdown">
                            <!-- <div id="google_translate_element"></div> -->
							<span class="caret"></span></button>
							<ul class="dropdown-menu dropdown-menu-right">
							  <!-- <li><div id="google_translate_element"></div></li> -->
							</ul>
					  </div>
				</div>
				<ul class="list-unstyled e-p-bx pull-right">
				<li><a href="./login"><i class="fa fa-sign-in"></i> Login</a></li>
					<li><a href="./register"><i class="fa fa-user"></i> Register</a></li>
									</ul>
			</div>
		</div>
	</div>
</div>
</div>
<div class="sticky-header main-bar-wraper">
<div class="main-bar">
	<div class="container">
			<div class="logo-header mostion">
				<a href="./">
					<img src="img/new/logo.png"  style='height:60px;' alt="" />
				</a>
			</div>
			<!-- NAV Toggle Button -->
			<button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<!-- MAIN Vav -->
			<div class="header-nav navbar-collapse collapse ">
			<ul class=" nav navbar-nav">
			<li class="active"><a href="./">Home</a></li>
			<li class=""><a href="./about">About Us</a></li>
           
            <li class=""><a href="./faq">FAQ</a></li>
            
            <li class=""><a href="./contact">Contact Us</a></li>
                        <li><a href="./login"><i class="fa fa-sign-in"></i> Login</a></li>
			<li><a href="./register"><i class="fa fa-user"></i> Register</a></li>
            			</ul>
		</div>
	</div>
               </div>
            </div>
        </header>       
         <!-- HEADER END -->
       
             <!-- HEADER END -->
<!-- CONTENT START -->
        <div class="page-content">
            <!-- SLIDER START -->
          <div class="wt-bnr-inr overlay-wraper" style="background-image:url(images/banner/about-banner.jpg);">
                <div class="overlay-main bg-black opacity-07"></div>
                <div class="container">
                    <div class="wt-bnr-inr-entry">
                        <h1 style="margin-top: 200px;" class="text-white">Terms </h1>
                    </div>
                </div>
            </div>
            <!-- SLIDER END -->
            <!-- MARQUEE SCROLL -->           
             <div class="bg-black marquee">
                <div class="TickerNews" id="T1">
                    <div class="ti_wrapper">             
                        <div class="ti_slide">
                          <div class="ti_content"> 
                               <div class="ti_news"><a href="#"><img src="images/coin-icon/bitcoin.png" alt=""><span>BTC: </span><span>$ 10,633.1</span><span class="text-yellow p-lr5">0.97 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/bitcoin.png" alt=""><span>BTC: </span><span>¥ 68,008.1</span><span class="text-danger p-lr5">0.00 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/bitcoin.png" alt=""><span>BTC: </span><span>€ 8,699.23</span><span class="text-white p-lr5">1.08 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/Ethereum.png" alt=""><span>ETH: </span><span>Ƀ 0.08160</span><span class="text-green p-lr5">-0.28 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/Ethereum.png" alt=""><span>ETH: </span><span>$ 867.93</span><span class="text-danger p-lr5">-0.60 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/Ethereum.png" alt=""><span>ETH: </span><span>¥ 5,549.46</span><span class="text-white p-lr5">-0.28 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/Ethereum.png" alt=""><span>ETH: </span><span>€ 709.94</span><span class="text-gray p-lr5">0.26 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/monero.png" alt=""><span>XMR: </span><span>Ƀ 0.0276</span><span class="text-green p-lr5">1.25 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/monero.png" alt=""><span>XMR: </span><span>$ 295.33</span><span class="text-light-blue p-lr5">0.89 %</span></a></div>

                                <div class="ti_news"><a href="#"><img src="images/coin-icon/monero.png" alt=""><span>XMR: </span><span>¥ 1,883.14</span><span class="text-green p-lr5">0.25 %</span></a></div>

                                <div class="ti_news"><a href="#"><img src="images/coin-icon/monero.png" alt=""><span>XMR: </span><span>€ 240.56</span><span class="text-red p-lr5">-0.40 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/litecoin.png" alt=""><span>LTC: </span><span>Ƀ 0.01956</span><span class="text-danger p-lr5">-0.20 %</span></a></div>

                                <div class="ti_news"><a href="#"><img src="images/coin-icon/litecoin.png" alt=""><span>LTC: </span><span>$ 208.06</span><span class="text-green p-lr5">-1.97 %</span></a></div>

                                <div class="ti_news"><a href="#"><img src="images/coin-icon/litecoin.png" alt=""><span>LTC: </span><span>¥ 1,330.24</span><span class="text-white p-lr5">-0.20 %</span></a></div>

                                <div class="ti_news"><a href="#"><img src="images/coin-icon/litecoin.png" alt=""><span>LTC: </span><span>€ 169.91</span><span class="text-yellow p-lr5">-1.29 %</span></a></div>
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/DigitalCash.png" alt=""><span>DASH: </span><span>Ƀ 0.05590</span><span class="text-white p-lr5">0.26 %</span></a></div>

                                <div class="ti_news"><a href="#"><img src="images/coin-icon/DigitalCash.png" alt=""><span>DASH: </span><span>$ 594.64</span><span class="text-green p-lr5">0.37 %</span></a></div>

                                <div class="ti_news"><a href="#"><img src="images/coin-icon/DigitalCash.png" alt=""><span>DASH: </span><span>¥ 3,801.65</span><span class="text-red p-lr5">0.99 %</span></a></div>

                                <div class="ti_news"><a href="#"><img src="images/coin-icon/DigitalCash.png" alt=""><span>DASH: </span><span>€ 486.29</span><span class="text-yellow p-lr5">-10.18 %</span></a></div>
                            </div>                                     
                        </div>
                   </div>
                </div>        
             </div>
            <!-- MARQUEE SCROLL SECTION  END -->    

             <section class="terms-of-services">
			<div class="container">
				<div class="row">
					<div class="col-xs-12">
					<h3 align="center">Please read the following rules & agreements before using our services.</h3>
						<h3>General: </h3>
						<p>These rules are official and the public offer of IQ-Markets, acting in accordance with the Company, on the one hand, and the individual investor. This is equivalent to the conclusion of the Agreement in accordance with Investment law. </p>
						<p>These rules shall enter into force on the date of registration of the Investor on the website of the program IQ-Markets and his acceptance of the terms and conditions. If you disagree with these terms and conditions or any part of these terms and conditions, you must not use this website. </p>
						<p>Any individual or company from any country may open an account on the website. You must be at least 18 years of age to use this website. You agree that all information, interactions, materials coming from IQ-Markets are unsolicited and must be kept private, confidential and protected from any disclosure. </p>
						
						<h3>Investment Conditions</h3>
						<p>Each deposit is considered to be a private transaction between IQ-Markets and its Member. Members perform all financial transactions solely at their own discretion and their own risk. The Investor personally decides whether or not to invest and how much to invest. All accruals in the Personal Account are made according to the chosen investment package.The Investor can make a deposit with only help of electronic payment systems used by the Company. </p>
						<p>The Return on Investment depends on the selected investment package while each investment package allows for investing different amounts. You may choose any of the following e-currencies to make deposit: Bitcoin. </p>
						<p>All accruals of profit are done automatically and in accordance with chosen investment plan. Depending on the amount of your deposit, you will receive guaranteed income for a certain period of time. Your earnings is depending from your investment plan and is in weekly basis. </p>
						
						<h3>Member Registration </h3>
						<p>You must register as a Member to access certain functions of the Website. You are obliged to provide only complete and accurate information about yourself when registering as a Member or updating your Registration Data. </p>
						<p>You agree to maintain and keep your Registration Data current and to update the Registration Data as soon as it changes. You are responsible for maintaining the security of your password.</p>
						<p>Our Company and its service providers are not liable for any loss that you may suffer through the use of your password by others. Each Investor can register "N" number of accounts utilizing same details again and again,except your Email and Username. </p>
						
						<h3>Referral Program </h3>
						<p>The affiliate program is a way to get extra earnings for referring other people to the products and services offered through this Website. You should have to make a deposit to get referral bonuses. </p>
						<p>Our affiliate rewards program offers earning till unlimited levels and pays 5% of the deposits made by your referrals</p>
						<h3>Re-Investment Conditions</h3>
						<p>Re-Investment in IQ-Markets is necessary after earning and withdrawing for a period of time.</p>
						<p>The Company reserves the right, but not obliged to the following: to set, at its absolute discretion, limits and/or parameters to control the Client’s ability to place orders or to restrict the terms on which a Transaction may be made. Such limits and/or parameters may be amended, increased, decreased, removed or added to by the Company.</p>
						<p>Arbitrage/cancellation of orders and transactions – The Company does not allow actions or non-actions based on arbitrage calculations or other methods that are based on exploitation of different systems or platforms malfunction, delay, error etc. The Company is entitled, by its own discretion, to cancel any transaction that has been executed due or in connection with an error, system malfunction, breach of the Agreement by Client etc. The Company’s records will serve as decisive evidence to the correct quotes in the world capital markets and the wrong quotes given to the Client; The Company is entitled to correct or cancel any trade based according to the correct quotes. </p>
						<p>Cancel Feature Abuse Company offers a special cancellation feature that allows traders to cancel a trade within a few seconds of execution. Abuse of the cancellation feature can be considered market arbitrage and can result in forfeiture of profits. Company reserves the right to cancel a position if the cancellation feature is abused. The acceptable cancellation percentage cannot exceed 20% of the total number of executed trades. Cancelling more than 20% of the total number of executed trades is considered abuse of this feature and resulting profits may be forfeited from such abuse. </p>
						
						<p>Withdrawals – In case the Client gives an instruction to withdraw funds from the Trading Account, the Company shall pay the specified amount (less any transfer charges, if applicable) once a duly instruction has been accepted and at the moment of payment, the Client’s margin requirements have been met. Withdrawal procedure may take up to 2 days once Client’s documentation submitted and approved. The Company may cancel the Client’s withdrawal order, if, according to the Company’s discretion, the remaining funds (after the withdrawal) shall not be sufficient to secure open Position(s) in the Trading Account. </p>
						<p>The Company shall debit the Client’s Trading Account for all payment charges. If the Client has the obligation to pay any amount to the Company which exceeds the amount held in the Client’s Trading Account, the Client shall immediately pay such amount upon Company’s request.
The Company shall not provide physical delivery in relation to any Transaction. As mentioned above, Profit or loss is credited to or debited to or from the Trading Account (as applicable) once the Transaction is closed. </p>
						<p>Trading Account balances and statements are displayed within the trading platform made available to the Client by the Company. Common terms definitions can be found on the Company’s Website. </p>
						
						<h3>Privacy and Data Protection</h3>
						<p>The Company shall hold some personal client information due to the nature of the Company’s business and relations with the Client. All data collected, whether on paper (hard copy) or on a computer (soft copy) is safeguarded in order to maintain the Client privacy.</p>
						<p>The Company shall be permitted to disclose and/or use the Client Information for the following purposes:<br />
(a) internal use, including with affiliated entities;
(b) As permitted or required by law;<br />
(c) protection against or prevent actual or potential fraud or unauthorized transactions or behavior<br />
(d) computerized supervision of Client’s use of the services, review and/or supervision and/or development and/or maintenance of the quality of services;<br />
(e) to protect the Company’s rights or obligation to observe any applicable law. </p>
					<p>The Client hereby grants his/her permission to the Company to make use of his/her details in order to provide updates and/or information and/or promotion or marketing purposes through the Clients E-mail address or other contact information. Cancellation of this consent shall be done in writing by providing written notice to the Company, and shall apply to new publications that have not been sent. </p>
					<p>The Client agrees and acknowledges that the Company may record all conversations with the Client and monitor (and maintain a record of) all emails sent by or to the Company. All such records are the Company’s property and can be used by the Company, among other things, in the case of a dispute between the Company and the Client. </p>
					<p>Affiliation- the Company may share commissions and charges with its associates, introducing brokers or other third parties (“Affiliates”), or receive remuneration from them in respect of contracts entered into by the Company. Such Affiliates of the Company may be disclosed with Client’s information. </p>
					<h3>The Company’s Trading Platform, Website or other services may require the use of ‘Cookies’.</h3>
					<p>The Client represents that it has been solely responsible for making its own independent appraisal and investigations into the risks of any Transaction. The Client represents that it has sufficient knowledge, market sophistication and experience to make its own evaluation of the merits and risks of any Transaction. The Company does not advise its Clients in regard to the expected profitability of any Transaction, and any tax or other consequences. The Client acknowledges that he has read and understood the Risk Disclosure Document which sets out the nature and risks of Transactions to which this Agreement relates. </p>
					<p>Where the Company does provide market commentary or other information:<br />
(a) this is incidental to the Client’s relationship with the Company.<br />
(b) It is provided solely to enable the Client to make its own investment decisions.</p>
					<p>The Client acknowledges that the Company shall not, in the absence of its fraud, willful default or gross negligence, be liable for any losses, costs, expenses or damages suffered by the Client arising from any inaccuracy or mistake in any information given to the Client. </p>
					<p>The Company is under no obligation to assess the appropriateness of any Transaction for a Client, to assess whether or not the Client has the necessary knowledge and experience to understand the nature of and risks associated with the Transactions. All risks related to the above are under the sole responsibility of the Client. </p>
					<h3>Amendments</h3>
					<p>The Company has the right to amend the Agreement without obtaining any prior consent from the Client. If the Company makes any material change to the Agreement, it will give at least 10 (Ten) Business Days’ notice of such change to the Client. Such amendment will become effective on the date specified in the notice. Unless otherwise agreed, an amendment will not affect any outstanding order or Transaction or any legal rights or obligations which may already have arisen. </p>
					<h3>Partial invalidity</h3>
					<p>If, at any time, any provision of this Agreement is or becomes illegal, invalid or unenforceable in any respect under the law of any jurisdiction, neither the legality, validity or enforce ability of the remaining provisions of this Agreement nor the legality, validity or enforce ability of such provision under the law of any other jurisdiction shall in any way be affected or impaired. </p>
					<h3>Joint account</h3>
					<p>If the Trading Account is a joint account (on the name of more than one entity), then each of the entities in the Trading Account shall be authorized to represent the other entities towards the Company, with no requirement of any prior notice or approval from the other entities. Each of the entities in the Trading Account agrees that any notice or instruction given by the Company to any of the entities shall be considered as given to all the entities. In case of contradiction between instructions given to the Company by different entities, then the last instruction received by the Company will prevail. </p>
					<h3>Notices </h3>
					<p>Unless otherwise agreed, all notices, instructions and other communications to be given by the Company shall be given to the address or fax number provided by the Client, or via e-mail or other electronic means, details of which are provided by the Client to the Company. Any complaint shall be directed to the Company’s client services department, who will investigate the complaint and make every effort to resolve it. Such a complaint should be made to: contact@coinasset.ltd</p>
					<h3>No Right to Assign</h3>
					<p>No rights under this Agreement shall be assignable nor any duties assumed by another party except to/by an affiliate of The Company. Upon assignment to an Affiliate of the Company, the terms of this Agreement may be amended to fit any applicable regulation effective upon the assignee, and Client hereby consent in advance to such regulatory modifications to this Agreement. This Agreement shall be binding upon and inure to the benefit of the successors heirs of the Client. </p>
					<h3>Dormant Trading</h3>
					<p>If the Client will not perform any trading activity or his trading activity will be in very low volume, for the time period defined by the Company, or if the Client does not hold minimum funds in his Trading Account, defined by the Company, the Company may, charge the Trading Account with Dormant Trading commission, at a rate to be determined by the Company from time to time, close any open trade and/or the Client access to the Trading Account and/or terminate this Agreement. </p>
					<h3>Language, Notices and Complaints </h3>
					<p> All communications between the Company and the Client will be in English or in any Language, suitable both to the Client and the Company. </p>
					<h3>Force majeure</h3>
					<p>The Company shall not bear responsibility to any harm or any form which shall be caused to the Client in the event that such harm is the result of a force majeure and any outside event which is not in the control of the Company which influences Trading. The Company shall not bear any responsibility for any delay in communications and/or failure in the internet, including, without limitation, computer crashes or any other technical failure, whether caused by the telephone companies and various telecommunication lines, the ISP computers, the Company’s computers or the Customer’s Computers.</p>
						<h3>Security</h3>
						<p>We have implemented security measures designed to secure your information from accidental loss and from unauthorized access, use, alteration or disclosure. However, we cannot guarantee that unauthorized persons will never gain access to your information, and you acknowledge that you provide your information at your own risk, except as otherwise provided by applicable law.</p>
					</div>
				</div>
			</div>
		</section>
               
   <footer class="site-footer bg-no-repeat bg-full-height bg-center"  style="background-image:url(images/background/footer-bg.jpg);">
            <!-- FOOTER BLOCKES START -->  
            <div class="footer-top overlay-wraper">
                <div class="overlay-main bg-black opacity-05"></div>
                <div class="container">
                    <div class="row">
                        <!-- ABOUT COMPANY -->
                        <div class="col-md-5 col-sm-6">  
                            <div class="widget widget_about">
                                <h4 class="widget-title text-white">About Company</h4>
                                <!--<div class="logo-footer clearfix p-b15">
                                    <a href="../"><img src="img/logo.png" width="230" height="67" alt=""/></a>
                                </div>-->

                                <p>Our organisation exists purely to support the people we trade with - the world's more disadvantaged investors. We believe that investment, if organised and regulated properly, can lift the world’s poor out of poverty. We trade Forex, binary options and other instruments trading for our clients.
                                </p>  
                            </div>
                        </div> 
                        <!-- RESENT POST -->
                        <!-- USEFUL LINKS -->

                        <div class="col-md-3 col-sm-6">
                            <div class="widget widget_services">
                                <h4 class="widget-title text-white">Useful links</h4>
                                <ul>
                                    <li><a href="./about">About</a></li>
                                    <li><a href="./faq">FAQ</a></li>
                                    
                                    <li><a href="./contact">Contact Us</a></li>
                                    <li><a href="./terms">Terms</a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- NEWSLETTER -->



                        <div class="col-md-3 col-sm-6">
                            <div class="widget widget_newsletter">
                                <h4 class="widget-title text-white">Newsletter</h4>
                                <div class="newsletter-bx">
                                    <form role="search" method="post">
                                        <div class="input-group">
                                        <input name="news-letter" class="form-control" placeholder="ENTER YOUR EMAIL" type="text">
                                        <span class="input-group-btn">
                                            <button type="submit" class="site-button"><i class="fa fa-paper-plane-o"></i></button>
                                        </span>
                                    </div>
                                     </form>
                                </div>
                            </div>
                            <!-- SOCIAL LINKS -->

                            <!-- <div class="widget widget_social_inks">
                                <h4 class="widget-title text-white">Social Links</h4>
                                <ul class="social-icons social-square social-darkest">
                                    <li><a href="javascript:void(0);" class="fa fa-facebook"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-twitter"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-linkedin"></a></li>

                                    <li><a href="javascript:void(0);" class="fa fa-rss"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-youtube"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-instagram"></a></li>
                                </ul>
                            </div> -->
                        </div>
                    </div>



                    <div class="row">
                       <div class="col-md-3 col-sm-6  p-tb20">
                           <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix">
                                <div class="icon-md text-primary">
                                    <span class="iconmoon-travel"></span>
                                </div>
                                <div class="icon-content text-white">
                                    <h5 class="wt-tilte text-uppercase m-b0">Address</h5>
                                    <!-- <h5></h5> -->
                                                <p>

29 Morgan St. Aukland <br>New Zealand


</p>
                                </div>
                           </div>
                        </div>

                       <!-- <div class="col-md-3 col-sm-6  p-tb20 ">
                           <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix ">
                                <div class="icon-md text-primary">
                                    <span class="iconmoon-smartphone-1"></span>
                                </div>
                                <div class="icon-content text-white">
                                <h5>Customer Care Lines</h5>
                                <p>	<li><i class="fa fa-whatsapp"></i>
                                <a href='#'  target='_blank'> +??</a></li></p>
                                               
                                </div>
                           </div>
                       </div> -->
                       <div class="col-md-6 col-sm-6 p-tb20">
                           <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix">
                                <div class="icon-md text-primary">
                                    <span class="iconmoon-email"></span>
                                </div>
                                <div class="icon-content text-white">
                                    <h5 class="wt-tilte text-uppercase m-b0">Email</h5>
                                    <p class="m-b0">contact@IQ-markets.com</p>
                                    <!-- <p>support@coinasset.ltd</p> -->
                                </div>
                            </div>
                        </div>


                  </div>
                </div>
            </div>
            <div class="section-full p-t80">
                <div class="container">
                    <!-- CONTACT DETAIL BLOCK -->
                    <div class="section-content ">
                        <div class="row">
                            <!-- <div class="wt-box text-center"> -->
                              
                                <div class="row">
                                
                                    <div class="col-md-4 col-sm-12 m-b30">
                                        <div class="wt-icon-box-wraper center p-a30">
                                            <div class="wt-icon-box-md text-black"><span class="icon-cell"><i class="iconmoon-smartphone-1"></i></span></div>
                                            <div class="icon-content" style='height:50px; background: url("par/a1.png"); background-repeat: no-repeat;
	background-size: contain;
	background-position: center;'>
                                              



                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12 m-b30">
                                        <div class="wt-icon-box-wraper center p-a30">
                                            <div class="wt-icon-box-md text-black"><span class="icon-cell"><i class="iconmoon-email"></i></span></div>
                                            <div class="icon-content" style='height:50px; background: url("par/a2.png"); background-repeat: no-repeat;
	background-size: contain;
	background-position: center;'>
                                              



                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12 m-b30">
                                        <div class="wt-icon-box-wraper center p-a30">
                                            <div class="wt-icon-box-md  text-black"><span class="icon-cell"><i class="iconmoon-travel"></i></span></div>
                                            <div class="icon-content" style='height:50px; background: url("par/a3.jpg"); background-repeat: no-repeat;
	background-size: contain;
	background-position: center;'>
                                              



                                            </div>
                                        </div>
                                    </div>
                                
                                <!-- </div> -->
                            </div>
                        </div>
                    </div>

            
            <!-- FOOTER COPYRIGHT -->
            <div class="footer-bottom  overlay-wraper">
                <div class="overlay-main"></div>
                <div class="constrot-strip"></div>
                <div class="container p-t30">
                    <div class="row">
                        <div class="wt-footer-bot-left">
                            <span class="copyrights-text">© 2021 IQ-Markets All Rights Reserved. </span>
                        </div>
                        <div class="wt-footer-bot-right">
                            <ul class="copyrights-nav pull-right"> 
                                <!--<li><a href="terms-and-conditions">Terms  & Condition</a></li>-->
                                <li><a href="./contact">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- FOOTER END -->
        <!-- BUTTON TOP START -->
        <button class="scroltop"><span class=" iconmoon-house relative" id="btn-vibrate"></span>Top</button>
        <!-- MODAL  LOGIN -->
        <div id="Login-form" class="modal fade " role="dialog">
          <div class="modal-dialog modal-sm">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-white">Login Your Account</h4>
              </div>
              <div class="modal-body p-a30">
                <form id="log-form">
                    <div class="form-group">
                       <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <input class="form-control" placeholder="Enter Username" type="text">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input class="form-control" placeholder="Enter email" type="email">
                        </div>
                    </div>
                    <button type="button" class="site-button-secondry text-uppercase btn-block m-b10">Submit</button>
                    <span class="font-12">Don't have an account? <a href="javascript:;" class="text-primary">Register Here</a></span>
                </form>
              </div>
              <div class="modal-footer text-center">
                <div class="text-center"><img src="img/logo.png" alt=""></div>
              </div>
            </div>
          </div>
        </div>
         <!-- MODAL  REGISTER -->
        <div id="Register-form" class="modal fade " role="dialog">
          <div class="modal-dialog modal-sm">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-white">Register here</h4>
              </div>
              <div class="modal-body p-a30">
                <form id="reg-form">
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <input class="form-control" placeholder="Enter Username" type="text">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input class="form-control" placeholder="Enter email" type="email">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input class="form-control" placeholder="Enter Password" type="email">
                        </div>
                    </div>
                    <button type="button" class="site-button-secondry text-uppercase btn-block m-b10">Submit</button>
                    <span class="font-12">Already Have an Account? <a href="javascript:;" class="text-primary">Login</a></span>
                </form>
              </div>
              <div class="modal-footer text-center">
                <div class="text-center"><img src="img/log.png" alt=""></div>
              </div>
            </div>
          </div>
        </div>             
    </div>
<!-- JAVASCRIPT  FILES ========================================= --> 
<script src="js/jquery-1.12.4.min.js"></script><!-- JQUERY.MIN JS -->
<script   src="js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->
<script   src="js/bootstrap-select.min.js"></script><!-- FORM JS -->
<script   src="js/jquery.bootstrap-touchspin.min.js"></script><!-- FORM JS -->
<script   src="js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->
<script   src="js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script   src="js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script   src="js/waypoints-sticky.min.js"></script><!-- COUNTERUP JS -->
<script  src="js/isotope.pkgd.min.js"></script><!-- MASONRY  -->
<script   src="js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->
<script   src="js/stellar.min.js"></script><!-- PARALLAX BG IMAGE   --> 
<script   src="js/scrolla.min.js"></script><!-- ON SCROLL CONTENT ANIMTE   -->
<script   src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script   src="js/shortcode.js"></script><!-- SHORTCODE FUCTIONS  -->
<script   src="js/switcher.js"></script><!-- SWITCHER FUCTIONS  -->
<script  src="js/jquery.bgscroll.js"></script><!-- BACKGROUND SCROLL -->
<script  src="js/tickerNews.min.js"></script><!-- TICKERNEWS-->
<!-- TICKERNEWS FUNCTiON -->
<script type="text/javascript">
	jQuery(function(){

		var timer = !1;

		_Ticker = jQuery("#T1").newsTicker();

		_Ticker.on("mouseenter",function(){

			var __self = this;

			timer = setTimeout(function(){

				__self.pauseTicker();

			},200);

		});

		_Ticker.on("mouseleave",function(){

			clearTimeout(timer);

			if(!timer) return !1;

			this.startTicker();

		});

	});
</script>
<script  src="plugins/revolution/revolution/js/jquery.themepunch.tools.min.js"></script>
<script  src="plugins/revolution/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script  src="plugins/revolution/revolution/js/extensions/revolution-plugin.js"></script>
<script   src="js/rev-script-1.js"></script>
<script type="text/javascript">
function contatMail(){
$('i#sp5').attr("class","fa fa-spinner fa-spin");
var hr = new XMLHttpRequest();
var url = "reg_process.php";
var  cotactmail = document.getElementById('email').value;
var  name = document.getElementById('name').value;
var  subject = document.getElementById('subject').value;
var  message = document.getElementById('message').value;
var vars = "cotactmail="+cotactmail+"&name="+name+"&subject="+subject+"&message="+message;
if(cotactmail=="" || subject =="" || message =="" ){
	sweetUnpre("Please fill all necessary fields!");
	$('i#sp5').attr("class","");
	}else{
var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		if( !emailReg.test(cotactmail) ) {
					sweetUnpre('Please use a valid email address!');
			        $('i#sp5').attr("class","");
		}else{
           
		   hr.open("POST.php", url, true);
	hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	// Access the onreadystatechange event for the XMLHttpRequest object
	hr.onreadystatechange = function() {
	  //  console.log(hr);
		if(hr.readyState == 4 && hr.status == 200) {
			var return_data = hr.responseText;
			sweetUnpre(return_data);
			$('i#sp5').attr("class","");
			//setTimeout(refreshPage,2000);
			document.getElementById('email').value="";
			document.getElementById('name').value="";
			document.getElementById('subject').value="";
			document.getElementById('message').value="";
		}
	}
	hr.send(vars); // Actually execute the request
           }//email
		sweetUnpre('processing...');
      }//else empty
}
</script>


  
</body>
</html>