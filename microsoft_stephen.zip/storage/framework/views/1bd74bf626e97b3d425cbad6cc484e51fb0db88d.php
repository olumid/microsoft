<div id="form_editWithdraw" class="modal fade"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Udate Withdraw</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <div class="modal-body">
                <form action="#" class="form-horizontal" id="editWithdraw" method="POST">
                     <input type="text"  name="withdraw_id" id="withdraw_id">
                    <div class="form-group">
                        <label class="control-label col-md-4" >Type</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="type" id="type">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="control-label col-md-4">Amount($)</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="amount" id="amount">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Status</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="status" id="status">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Date</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="date" id="date">
                        </div>
                    </div>
                   
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-secondary " data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-update" id="btn-editWithdraw">Save</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>