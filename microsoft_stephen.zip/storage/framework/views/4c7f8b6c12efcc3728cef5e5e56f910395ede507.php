<div id="add_plan" class="modal fade"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add New Package</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <div class="modal-body">
                <form action="#" class="form-horizontal" id="addPlan" method="POST">

                    <div class="form-group">
                        <label class="control-label col-md-4" >Title</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="plan_name">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Min Deposit($)</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="min_deposit">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Max Deposit($)</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="max_deposit">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Profit %</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="profit">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Duration (Days)</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="duration">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-secondary " data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-addPlan" id="btn-addPlan">Save</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>