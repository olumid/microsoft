
<!DOCTYPE html>
<html lang="en">

<head>
<title>Globalfxcoin - Best trading platform - Login</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- plugins:css -->
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="account/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="account/images/favicon.png" />
 </head>

<body>
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-stretch auth auth-img-bg">
        <div class="row flex-grow">
          <div class="col-lg-6 d-flex align-items-center justify-content-center">
            <div class="auth-form-transparent text-left p-3">
              <div class="brand-logo">
                <strong style="color:goldenrod; padding-top:20px;">CREDITINVEST.UK</strong>   
               </div>
              <h4><?php echo e($error); ?></h4>
              
                <form class="pt-3" method="POST" action="<?php echo e(route('logins')); ?>">
                 <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label for="exampleInputEmail">USER ID</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-user-circle text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="name"  class="form-control form-control-lg border-left-0" placeholder="USER ID">
                  </div>
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword">Password</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-low-vision text-primary"></i>
                      </span>
                    </div>
                    <input type="password" name=password class="form-control form-control-lg border-left-0" placeholder="Password">                        
                  </div>
                </div>
                 <?php if(Session::has('msg')): ?>   
                 <div  style="color:red; margin-top:10px; margin-left:60px; padding:8px;">
                   <span class="fa fa-exclamation-circle" style="margin-left:8px;"></span><?php echo e(Session::get('msg')); ?> 
                   
                 </div>
                              
                <?php endif; ?>
                <div class="my-2 d-flex justify-content-between align-items-center">
                  <div class="form-check">
                    <label class="form-check-label text-muted">
                      <input type="checkbox" class="form-check-input">
                      Keep me signed in
                    </label>
                  </div>
                  <a href="reset-password" class="auth-link text-black">Forgot password?</a>
                </div>
                <div class="my-3">
                  <button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn" type="submit" name="login">LOGIN</button>
                </div>
                <div class="mb-2 d-flex">
                  <button type="button" class="btn btn-facebook auth-form-btn flex-grow mr-1">
                    <i class="mdi mdi-facebook mr-2"></i>Facebook
                  </button>
                  <button type="button" class="btn btn-google auth-form-btn flex-grow ml-1">
                    <i class="mdi mdi-google mr-2"></i>Google
                  </button>
                </div>
                <div class="text-center mt-4 font-weight-light">
                  Don't have an account? <a href="register" class="text-primary">Create</a>
                </div>
              </form>
            </div>
          </div>
          <div class="col-lg-6 login-half-bg d-flex flex-row">
            <p class="text-white font-weight-medium text-center flex-grow align-self-end">Copyright &copy; 2020  All rights reserved.</p>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
    <!-- container-scroller -->
  <!-- plugins:js -->

  
</body>

</html>
