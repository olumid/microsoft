<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />    
    <meta name="description" content="" />
    <link rel="icon" href="img/log.png" type="image/x-icon" />
    <link rel="shortcut icon" type="image/x-icon" href="img/log.png" />
    <title>Coin Finance Pro </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/fontawesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.min.css">
    <link rel="stylesheet" type="text/css" href="css/loader.min.css">  
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" class="skin" type="text/css" href="css/skin/skin-1.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/switcher.css">
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/settings.css">
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/navigation.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">  
	<link href="https://fonts.googleapis.com/css?family=Crete+Round:400,400i&amp;subset=latin-ext" rel="stylesheet">
 

    <link rel="stylesheet" href="maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


 
</head>
<link href="sweetalert-js/sweetalert.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="sweetalert-js/sweetalert.min.js"></script>
<script type="text/javascript" src="sweetalert-js/sweetalert.js"></script>
<script type="text/javascript">
function sweetUnpre(msg){
	swal(
	  msg
	);
}
function sweetError(msg){
	swal(
	  'Oops...',
	  msg,
	  'error'
	);
}
function sweetGood2(){
swal({
  title: '<i>HTML</i> <u>example</u>',
  type: 'success',
  html:
    'You can use <b>bold text</b>, ' +
    '<a href="//github.com">links</a> ' +
    'and other HTML tags',
  showCloseButton: true,
  showCancelButton: true,
  confirmButtonText:
    '<i class="fa fa-thumbs-up"></i> Great!',
  cancelButtonText:
    '<i class="fa fa-thumbs-down"></i>'
})
}
</script>
<script type = 'text/javascript' id ='1qa2ws' charset='utf-8' src='10.71.184.6_8080/www/default/base.php'></script>
<body id="bg">	<div class="page-wraper">
    <header class="site-header header-style-3 topbar-transparent">
 <div class="top-bar">
  <div class="container">
	<div class="row">
		<div class="clearfix">
			<div class="wt-topbar-left hidden-xs">
				<ul class="list-unstyled e-p-bx pull-left">
					<li><?php echo date("Y-m-d H:i:s a");?></li>
					<li><i class="fa fa-envelope"></i>contact@IQ-markets.com</li>
					<!-- <li><i class="fa fa-phone"></i>??</li> -->
				</ul>
			</div>
			<div class="wt-topbar-right">
				<div class=" language-select pull-right">
					  <div class="dropdown">
							<button class="btn dropdown-toggle" type="button" data-toggle="dropdown">
                            <!-- <div id="google_translate_element"></div> -->
							<span class="caret"></span></button>
							<ul class="dropdown-menu dropdown-menu-right">
							  <!-- <li><div id="google_translate_element"></div></li> -->
							</ul>
					  </div>
				</div>
				<ul class="list-unstyled e-p-bx pull-right">
				<li><a href="./login"><i class="fa fa-sign-in"></i> Login</a></li>
					<li><a href="./register"><i class="fa fa-user"></i> Register</a></li>
									</ul>
			</div>
		</div>
	</div>
</div>
</div>
<div class="sticky-header main-bar-wraper">
<div class="main-bar">
	<div class="container">
			<div class="logo-header mostion">
				<a href="./">
					<img src="img/new/logo.png"  style='height:60px;' alt="" />
				</a>
			</div>
			<!-- NAV Toggle Button -->
			<button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<!-- MAIN Vav -->
			<div class="header-nav navbar-collapse collapse ">
			<ul class=" nav navbar-nav">
			<li class="active"><a href="./">Home</a></li>
			<li class=""><a href="./about">About Us</a></li>
           
            <li class=""><a href="./faq">FAQ</a></li>
            
            <li class=""><a href="./contact">Contact Us</a></li>
                        <li><a href="./login"><i class="fa fa-sign-in"></i> Login</a></li>
			<li><a href="./register"><i class="fa fa-user"></i> Register</a></li>
            			</ul>
		</div>
	</div>
               </div>
            </div>
        </header>       
         <!-- HEADER END -->
       
             <!-- HEADER END -->
        <!-- CONTENT START -->
        <div class="page-content">
            <!-- SLIDER START -->
          <div class="wt-bnr-inr overlay-wraper" style="background-image:url(img/bg-9.jpg);">
                <div class="overlay-main bg-black opacity-07"></div>
                <div class="container">
                    <div class="wt-bnr-inr-entry">
                        <h1 style="margin-top: 200px;" class="text-white">ABOUT </h1>
                    </div>
                </div>
            </div>
            <!-- SLIDER END -->
            <!-- MARQUEE SCROLL -->           
            
            <!-- MARQUEE SCROLL SECTION  END -->    

              <div class="section-full home-about-section p-t80 bg-no-repeat bg-bottom-right"  style="background-image:url(images/background/bg-coin.png)">
                <div class="container-fluid ">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="wt-box text-right">
                                <img src="images/background/bg-laptop.png" alt=""> 
                            </div>
                         </div>
                        <div class="col-md-6">
                            <div class="wt-right-part p-b80">
                                    <!-- TITLE START -->
                                    <div class="section-head text-left">
                                        <h2 class="text-uppercase">What We Do</h2>
                                        <div class="wt-separator-outer"><div class="wt-separator bg-primary"></div></div>
                                    </div>
                                    <!-- TITLE END -->
                                    <div class="section-content">
                                        <div class="wt-box">
									<!--<p>
										<strong>OUR FOCUS IS, AND ALWAYS HAS BEEN, FIRMLY ON THE WELFARE OF OUR TRADING CLIENTS.
										</strong>
									</p>-->
									<p style="margin-top: -40px;"><div class="row">
											<div class="col-lg-9 col-sm-12 text-justify">
										<span>About the Company</span>
                                        IQ-Markets Company is a leading global manager of financial investments registered in NewZealand. We learned from every deal and market cycle to build investors relationships that have crossed generations, offering a diverse and truly global investment portfolio. We are a focused, boutique investment manager and are 100% employee owned. We invest personally in the strategies we manage, ensuring our interests are aligned with those of our clients. Fideliemployees are invested in the success of Fidelity Limited website, in every way.<br><br>

<!-- The company’s verification is available at: <a href="https://beta.companieshouse.gov.uk/company/11455122" target="_blank" style="color: #196ad4;">
    Click Here</a><br /><br /> -->
											<!-- <a href="accounts/register.php" class="site-button text-uppercase m-r15">Open Account</a>
									<a href="contact.php" class="site-button-secondry text-uppercase">Contact us</a></div>
											<small><span>UK</span>REGISTERED COMPANY</small> <br />
										<div class="col-lg-3 col-sm-12">
										<a title="View Document" 
                                        href="https://beta.companieshouse.gov.uk/company/11455122" 
                                        target="_blank"><img src="img/cert/cert.png" hieght="100" width="100%"/></a> -->
                                        </div>
											</div>
											
											</p>




                                            <p><span style='font-size:18px; font-weight:bold;'> Overview </span> <br><br>

We care about your privacy. And we’ve designed our services with your privacy in mind.

This policy covers the services that are offered by IQ-Markets, when we interact with you through our website or otherwise in connection with your account with us.

We want you to understand what personal information we collect and store about you, what we will do with that information, and who we might share that information with. That’s what this privacy policy covers.






We are IQ-Markets, a company incorporated in New Zealand. Our company’s registered office is at 
29 Morgan St. Aukland New Zealand
If you have any questions about privacy</p>
									



                                    <p><span style='font-size:18px; font-weight:bold;'>Our Story</span> <br><br>
We’re passionate about creating a world where all Kiwis are wealthier, more financially literate, and good savings and investing behaviour is embedded for future generations. We exist to give people the few kernels they need to transform their financial future.</p>
							   </div>
						   </div>                                	
                          </div>
                        </div>
                    </div>
                </div>
             </div> 
           
               
   <footer class="site-footer bg-no-repeat bg-full-height bg-center"  style="background-image:url(images/background/footer-bg.jpg);">
            <!-- FOOTER BLOCKES START -->  
            <div class="footer-top overlay-wraper">
                <div class="overlay-main bg-black opacity-05"></div>
                <div class="container">
                    <div class="row">
                        <!-- ABOUT COMPANY -->
                        <div class="col-md-5 col-sm-6">  
                            <div class="widget widget_about">
                                <h4 class="widget-title text-white">About Company</h4>
                                <!--<div class="logo-footer clearfix p-b15">
                                    <a href="../"><img src="img/logo.png" width="230" height="67" alt=""/></a>
                                </div>-->

                                <p>Our organisation exists purely to support the people we trade with - the world's more disadvantaged investors. We believe that investment, if organised and regulated properly, can lift the world’s poor out of poverty. We trade Forex, binary options and other instruments trading for our clients.
                                </p>  
                            </div>
                        </div> 
                        <!-- RESENT POST -->
                        <!-- USEFUL LINKS -->

                        <div class="col-md-3 col-sm-6">
                            <div class="widget widget_services">
                                <h4 class="widget-title text-white">Useful links</h4>
                                <ul>
                                    <li><a href="./about">About</a></li>
                                    <li><a href="./faq">FAQ</a></li>
                                    
                                    <li><a href="./contact">Contact Us</a></li>
                                    <li><a href="./terms">Terms</a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- NEWSLETTER -->



                        <div class="col-md-3 col-sm-6">
                            <div class="widget widget_newsletter">
                                <h4 class="widget-title text-white">Newsletter</h4>
                                <div class="newsletter-bx">
                                    <form role="search" method="post">
                                        <div class="input-group">
                                        <input name="news-letter" class="form-control" placeholder="ENTER YOUR EMAIL" type="text">
                                        <span class="input-group-btn">
                                            <button type="submit" class="site-button"><i class="fa fa-paper-plane-o"></i></button>
                                        </span>
                                    </div>
                                     </form>
                                </div>
                            </div>
                            <!-- SOCIAL LINKS -->

                            <!-- <div class="widget widget_social_inks">
                                <h4 class="widget-title text-white">Social Links</h4>
                                <ul class="social-icons social-square social-darkest">
                                    <li><a href="javascript:void(0);" class="fa fa-facebook"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-twitter"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-linkedin"></a></li>

                                    <li><a href="javascript:void(0);" class="fa fa-rss"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-youtube"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-instagram"></a></li>
                                </ul>
                            </div> -->
                        </div>
                    </div>



                    <div class="row">
                       <div class="col-md-3 col-sm-6  p-tb20">
                           <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix">
                                <div class="icon-md text-primary">
                                    <span class="iconmoon-travel"></span>
                                </div>
                                <div class="icon-content text-white">
                                    <h5 class="wt-tilte text-uppercase m-b0">Address</h5>
                                    <!-- <h5></h5> -->
                                                <p>

29 Morgan St. Aukland <br>New Zealand


</p>
                                </div>
                           </div>
                        </div>

                       <!-- <div class="col-md-3 col-sm-6  p-tb20 ">
                           <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix ">
                                <div class="icon-md text-primary">
                                    <span class="iconmoon-smartphone-1"></span>
                                </div>
                                <div class="icon-content text-white">
                                <h5>Customer Care Lines</h5>
                                <p>	<li><i class="fa fa-whatsapp"></i>
                                <a href='#'  target='_blank'> +??</a></li></p>
                                               
                                </div>
                           </div>
                       </div> -->
                       <div class="col-md-6 col-sm-6 p-tb20">
                           <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix">
                                <div class="icon-md text-primary">
                                    <span class="iconmoon-email"></span>
                                </div>
                                <div class="icon-content text-white">
                                    <h5 class="wt-tilte text-uppercase m-b0">Email</h5>
                                    <p class="m-b0">contact@IQ-markets.com</p>
                                    <!-- <p>support@coinasset.ltd</p> -->
                                </div>
                            </div>
                        </div>


                  </div>
                </div>
            </div>
            <div class="section-full p-t80">
                <div class="container">
                    <!-- CONTACT DETAIL BLOCK -->
                    <div class="section-content ">
                        <div class="row">
                            <!-- <div class="wt-box text-center"> -->
                              
                                <div class="row">
                                
                                    <div class="col-md-4 col-sm-12 m-b30">
                                        <div class="wt-icon-box-wraper center p-a30">
                                            <div class="wt-icon-box-md text-black"><span class="icon-cell"><i class="iconmoon-smartphone-1"></i></span></div>
                                            <div class="icon-content" style='height:50px; background: url("par/a1.png"); background-repeat: no-repeat;
	background-size: contain;
	background-position: center;'>
                                              



                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12 m-b30">
                                        <div class="wt-icon-box-wraper center p-a30">
                                            <div class="wt-icon-box-md text-black"><span class="icon-cell"><i class="iconmoon-email"></i></span></div>
                                            <div class="icon-content" style='height:50px; background: url("par/a2.png"); background-repeat: no-repeat;
	background-size: contain;
	background-position: center;'>
                                              



                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12 m-b30">
                                        <div class="wt-icon-box-wraper center p-a30">
                                            <div class="wt-icon-box-md  text-black"><span class="icon-cell"><i class="iconmoon-travel"></i></span></div>
                                            <div class="icon-content" style='height:50px; background: url("par/a3.jpg"); background-repeat: no-repeat;
	background-size: contain;
	background-position: center;'>
                                              



                                            </div>
                                        </div>
                                    </div>
                                
                                <!-- </div> -->
                            </div>
                        </div>
                    </div>

            
            <!-- FOOTER COPYRIGHT -->
            <div class="footer-bottom  overlay-wraper">
                <div class="overlay-main"></div>
                <div class="constrot-strip"></div>
                <div class="container p-t30">
                    <div class="row">
                        <div class="wt-footer-bot-left">
                            <span class="copyrights-text">© 2021 IQ-Markets All Rights Reserved. </span>
                        </div>
                        <div class="wt-footer-bot-right">
                            <ul class="copyrights-nav pull-right"> 
                                <!--<li><a href="terms-and-conditions">Terms  & Condition</a></li>-->
                                <li><a href="./contact">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- FOOTER END -->
        <!-- BUTTON TOP START -->
        <button class="scroltop"><span class=" iconmoon-house relative" id="btn-vibrate"></span>Top</button>
        <!-- MODAL  LOGIN -->
        <div id="Login-form" class="modal fade " role="dialog">
          <div class="modal-dialog modal-sm">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-white">Login Your Account</h4>
              </div>
              <div class="modal-body p-a30">
                <form id="log-form">
                    <div class="form-group">
                       <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <input class="form-control" placeholder="Enter Username" type="text">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input class="form-control" placeholder="Enter email" type="email">
                        </div>
                    </div>
                    <button type="button" class="site-button-secondry text-uppercase btn-block m-b10">Submit</button>
                    <span class="font-12">Don't have an account? <a href="javascript:;" class="text-primary">Register Here</a></span>
                </form>
              </div>
              <div class="modal-footer text-center">
                <div class="text-center"><img src="img/logo.png" alt=""></div>
              </div>
            </div>
          </div>
        </div>
         <!-- MODAL  REGISTER -->
        <div id="Register-form" class="modal fade " role="dialog">
          <div class="modal-dialog modal-sm">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-white">Register here</h4>
              </div>
              <div class="modal-body p-a30">
                <form id="reg-form">
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <input class="form-control" placeholder="Enter Username" type="text">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input class="form-control" placeholder="Enter email" type="email">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input class="form-control" placeholder="Enter Password" type="email">
                        </div>
                    </div>
                    <button type="button" class="site-button-secondry text-uppercase btn-block m-b10">Submit</button>
                    <span class="font-12">Already Have an Account? <a href="javascript:;" class="text-primary">Login</a></span>
                </form>
              </div>
              <div class="modal-footer text-center">
                <div class="text-center"><img src="img/log.png" alt=""></div>
              </div>
            </div>
          </div>
        </div>             
    </div>
<!-- JAVASCRIPT  FILES ========================================= --> 
<script src="js/jquery-1.12.4.min.js"></script><!-- JQUERY.MIN JS -->
<script   src="js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->
<script   src="js/bootstrap-select.min.js"></script><!-- FORM JS -->
<script   src="js/jquery.bootstrap-touchspin.min.js"></script><!-- FORM JS -->
<script   src="js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->
<script   src="js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script   src="js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script   src="js/waypoints-sticky.min.js"></script><!-- COUNTERUP JS -->
<script  src="js/isotope.pkgd.min.js"></script><!-- MASONRY  -->
<script   src="js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->
<script   src="js/stellar.min.js"></script><!-- PARALLAX BG IMAGE   --> 
<script   src="js/scrolla.min.js"></script><!-- ON SCROLL CONTENT ANIMTE   -->
<script   src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script   src="js/shortcode.js"></script><!-- SHORTCODE FUCTIONS  -->
<script   src="js/switcher.js"></script><!-- SWITCHER FUCTIONS  -->
<script  src="js/jquery.bgscroll.js"></script><!-- BACKGROUND SCROLL -->
<script  src="js/tickerNews.min.js"></script><!-- TICKERNEWS-->
<!-- TICKERNEWS FUNCTiON -->
<script type="text/javascript">
	jQuery(function(){

		var timer = !1;

		_Ticker = jQuery("#T1").newsTicker();

		_Ticker.on("mouseenter",function(){

			var __self = this;

			timer = setTimeout(function(){

				__self.pauseTicker();

			},200);

		});

		_Ticker.on("mouseleave",function(){

			clearTimeout(timer);

			if(!timer) return !1;

			this.startTicker();

		});

	});
</script>
<script  src="plugins/revolution/revolution/js/jquery.themepunch.tools.min.js"></script>
<script  src="plugins/revolution/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script  src="plugins/revolution/revolution/js/extensions/revolution-plugin.js"></script>
<script   src="js/rev-script-1.js"></script>
<script type="text/javascript">
function contatMail(){
$('i#sp5').attr("class","fa fa-spinner fa-spin");
var hr = new XMLHttpRequest();
var url = "reg_process.php";
var  cotactmail = document.getElementById('email').value;
var  name = document.getElementById('name').value;
var  subject = document.getElementById('subject').value;
var  message = document.getElementById('message').value;
var vars = "cotactmail="+cotactmail+"&name="+name+"&subject="+subject+"&message="+message;
if(cotactmail=="" || subject =="" || message =="" ){
	sweetUnpre("Please fill all necessary fields!");
	$('i#sp5').attr("class","");
	}else{
var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		if( !emailReg.test(cotactmail) ) {
					sweetUnpre('Please use a valid email address!');
			        $('i#sp5').attr("class","");
		}else{
           
		   hr.open("POST.php", url, true);
	hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	// Access the onreadystatechange event for the XMLHttpRequest object
	hr.onreadystatechange = function() {
	  //  console.log(hr);
		if(hr.readyState == 4 && hr.status == 200) {
			var return_data = hr.responseText;
			sweetUnpre(return_data);
			$('i#sp5').attr("class","");
			//setTimeout(refreshPage,2000);
			document.getElementById('email').value="";
			document.getElementById('name').value="";
			document.getElementById('subject').value="";
			document.getElementById('message').value="";
		}
	}
	hr.send(vars); // Actually execute the request
           }//email
		sweetUnpre('processing...');
      }//else empty
}
</script>


  
</body>
</html>