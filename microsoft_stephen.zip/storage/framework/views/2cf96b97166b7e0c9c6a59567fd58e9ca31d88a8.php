<div id="updateTron" class="modal fade"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Update BTC Wallet</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <div class="modal-body">
                <form action="#" class="form-horizontal" id="addService">

                    <div class="form-group">
                        <label class="control-label col-md-4" >Tron Address</label>
                        <div class="col-md-8">
                            <input type="text"  class="form-control select2" name="bitcoin_address">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Tron Value</label>
                        <div class="col-md-8">
                            <input type="text"  class="form-control select2" name="service_name">
                        </div>
                    </div>
                    
                     <div class="form-group">
                          <div class="fileinput fileinput-new" data-provides="fileinput">
                              <div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 200px; height: 130px;"></div>
                          <div>
						  <span class="btn btn-default btn-file">
						  <span class="fileinput-new btn btn-primary">Select Qr </span>
						  <span class="fileinput-exists btn btn-primary">
							Change </span>
						  <input type="file" name="bicoin_qr" accept="image/jpeg,image/x-png,image/png,image/jpg" id="photo">
						  </span>
                          <a href="#" class="btn btn-danger fileinput-exists" data-dismiss="fileinput">Remove </a>
                         </div>
                          
                    </div>
                    
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-secondary " data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-addService" id="btn-addservice">Save</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>