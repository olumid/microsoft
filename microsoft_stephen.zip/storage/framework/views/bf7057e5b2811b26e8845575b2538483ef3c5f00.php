
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Welcome to Credit Invest</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/themify-icons/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
   

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    
</head>

<body>
    <!-- Left Panel -->

   <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo"></a>
                <a class="navbar-brand hidden" href="./"><img src="<?php echo e(asset('images/logo2.png')); ?>" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.html"> <i class="menu-icon fa fa-home"></i>Home</a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-user"></i>My Profile</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-user"></i><a href="maps-gmap.html">Update Account</a></li>
                            <li><i class="menu-icon fa fa-lock"></i><a href="maps-vector.html">Security</a></li>
                            <li><i class="menu-icon fa fa-cogs"></i><a href="maps-gmap.html">Wallet Details</a></li>
                            <li><i class="menu-icon fa fa-group"></i><a href="maps-vector.html">Verify Account</a></li>
                        </ul>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-th-list"></i>Withdrawal</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-th-list"></i>Deposit</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-list"></i>Transaction Log</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-suitcase"></i>Investment Packages</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-suitcase"></i>Loan</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-users"></i>My Downlines</a>
                    </li>
                     <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-users"></i>Credit Score</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('logout')); ?>"> <i class="menu-icon fa fa-dashboard"></i>Logout</a>
                    </li>
                    
                   
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
           <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        <button class="search-trigger"><i class="fa fa-search"></i></button>
                        <div class="form-inline">
                            <form class="search-form">
                                <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                                <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                            </form>
                        </div>

                        
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="<?php echo e(asset('images/admin.jpg')); ?>" alt="User Avatar">
                        </a>

                       
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a class="dropdown-toggle" href="#" data-toggle="dropdown"  id="language" aria-haspopup="true" aria-expanded="true">
                            <i class="flag-icon flag-icon-us"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="language">
                            <div class="dropdown-item">
                                <span class="flag-icon flag-icon-fr"></span>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-es"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-us"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-it"></i>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </header><!-- /header -->
        

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">

                    <div class="col-md-9">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title text-primary" style="font-size:18px; font-weight:bold;">Downlines</strong>
                            </div>
                            <div class="card-body">
                                <?php if(count($downline)> 0): ?>
                                    <table class="table table-striped table-bordered">
                                        <thead class="text-success" style="font-size:18px; font-weight:bold;">
                                            <tr>
                                                <th><i class="fa fa-list-ol"></i> S/N</th>
                                                <th><i class="fa fa-btc"></i> username</th>
                                                <th><i class="fa fa-money"></i> Email</th>
                                                
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $downline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                <td><?php echo e($list->name); ?></td>
                                                <td><?php echo e($list->email); ?></td>
                                               
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                    </table>

                                    <?php else: ?>
                                        <p style="color: orangered; font-size: 25px; font-weight: bold; margin-top: 30px; text-align: center">Error! No Entry Found, Try Again  </p>
                                    <?php endif; ?>
                            </div>
                        </div>
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->

    </div><!-- /#right-panel -->

    <!-- Right Panel -->


       <script src="<?php echo e(asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/popper.js/dist/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>



</body>

</html>