<!-- Modal -->
<div class="modal fade " id="form_deletePlan" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content note note-danger" style="padding: 20px">

            <div class="row" style="padding: 10px">
                <div class="col-sm-10">

                    <input type="hidden"  name="plans" id="plans" >
                    <h5 style="text-align: center; font-size: 20px">Are you sure you want to get rid of this package ?</h5>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" >NO</button>
                <button type="button" class="btn btn-danger del">YES</button>
            </div>

        </div>
    </div>
</div>

