<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 
  <link href="<?php echo e(asset('img/logo/logo4.png')); ?>" rel="icon">
  <title>Vanguards Invest</title>
  <link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('css/ruang-admin.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('vendors/bootstrap-fileinput/bootstrap-fileinput.css')); ?>" rel="stylesheet">
</head>

<body id="page-top">
  <div id="wrapper">
    <!-- Sidebar -->
     <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard')); ?>">
        <div class="sidebar-brand-icon">
          <img src="<?php echo e(asset('img/logo/logo5.png')); ?>">
        </div>
        <div class="sidebar-brand-text mx-3"></div>
      </a>
      <hr class="sidebar-divider my-0">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
      
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseForm" aria-expanded="true"
          aria-controls="collapseForm">
          <i class="fas fa-fw fa-user"></i>
          <span>Security</span>
        </a>
        <div id="collapseForm" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            
            <a class="collapse-item" href="<?php echo e(route('walletDetails1')); ?>">Wallet Details</a>
            <a class="collapse-item" href="<?php echo e(route('verifyInvestor')); ?>">Verify Account</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('manageUser')); ?>">
          <i class="far fa-fw fa-window-maximize"></i>
          <span>Manage Users</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('depositAll')); ?>">
          <i class="far fa-fw fa-window-maximize"></i>
          <span>Deposit Requests</span>
        </a>
      </li>
       <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('withdrawAll')); ?>">
          <i class="far fa-fw fa-window-maximize"></i>
          <span>Withdrawal Requests</span>
        </a>
        
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('investmentAll')); ?>">
          <i class="fas fa-fw fa-palette"></i>
          <span>View Investments</span>
        </a>
        
      </li>
      
       <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('managePlan')); ?>">
          <i class="fas fa-fw fa-palette"></i>
          <span>Manage Loans</span>
        </a>
        
      </li>

      </li>
       <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('sendMail')); ?>">
          <i class="fas fa-fw fa-palette"></i>
          <span>Send Mail</span>
        </a>
        
      </li>
     
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('logout')); ?>">
          <i class="fas fa-fw fa-user"></i>
          <span>Logout</span>
        </a>
      </li>
     
    </ul>
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <!-- TopBar -->
        <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top">
        

          <button id="sidebarToggleTop" class="btn btn-link rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
           <div id="google_translate_element"></div>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">
                <form class="navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-1 small" placeholder="What do you want to look for?"
                      aria-label="Search" aria-describedby="basic-addon2" style="border-color: #3f51b5;">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>
            
           
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img class="img-profile rounded-circle" src="<?php echo e(asset('img/boy.png')); ?>" style="max-width: 60px">
                <span class="ml-2 d-none d-lg-inline text-white small"><?php echo e(Auth::user()->name); ?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="javascript:void(0);" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
        </nav>
        <!-- Topbar -->

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">

          <div class="row mb-3">
                <div class="col-lg-7">
                        <div class="card">
                            <?php if(Session::has('message1')): ?>   
                                <div id="info" style="font-size:13px; font-size:15px; margin:2%" class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong><?php echo e(Session::get('message1')); ?></strong>
                                    <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </a>
                                </div>
                            <?php endif; ?>
                            <div class="card-body">
                                <div class="custom-tab">

                                    <nav>
                                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                            <a class="nav-item nav-link active" id="custom-nav-home-tab" data-toggle="tab" href="#custom-nav-home" role="tab" aria-controls="custom-nav-home" aria-selected="true">BTC</a>
                                            <a class="nav-item nav-link" id="custom-nav-eth-tab" data-toggle="tab" href="#custom-nav-eth" role="tab" aria-controls="custom-nav-eth" aria-selected="false">ETH</a>
                                            <a class="nav-item nav-link" id="custom-nav-ltc-tab" data-toggle="tab" href="#custom-nav-ltc" role="tab" aria-controls="custom-nav-ltc" aria-selected="false">LTC</a>
                                             <a class="nav-item nav-link" id="custom-nav-tron-tab" data-toggle="tab" href="#custom-nav-tron" role="tab" aria-controls="custom-nav-tron" aria-selected="false">TRON</a>
                                            <a class="nav-item nav-link" id="custom-nav-xrp-tab" data-toggle="tab" href="#custom-nav-xrp" role="tab" aria-controls="custom-nav-xrp" aria-selected="false">XRP</a>
                                        </div>
                                    </nav>
                                    <div class="tab-content pl-3 pt-2" id="nav-tabContent">
                                        <div class="tab-pane fade show active" id="custom-nav-home" role="tabpanel" aria-labelledby="custom-nav-home-tab">
                                            <div style="margin-top: 10%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                 <img src="qr/<?php echo e($det->bitcoin_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 30%;">
                                                 <h5 style=" margin-left: 34%; margin-top:10px;">BTC Address:</h5><br>
                                                 <h5 style="margin-top: -15px;"><?php echo e($det->bitcoin_address); ?></h5>
                                            </div>
                                            <button id="update_btc" class="btn btn-primary" data-qr="<?php echo e($det->bitcoin_qr); ?>" data-values="<?php echo e($det->bitcoin_value / 100000000); ?>"  data-address="<?php echo e($det->bitcoin_address); ?>">Update</button>
                                        </div>
                                        <div class="tab-pane fade" id="custom-nav-eth" role="tabpanel" aria-labelledby="custom-nav-eth-tab">
                                            <div style="margin-top: 10%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                 <img src="qr/<?php echo e($det->etherium_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 30%;">
                                                 <h5 style=" margin-left: 34%; margin-top:10px;">ETH Address:</h5><br>
                                                 <h5 style="margin-top: -15px;text-allign:centre; "><?php echo e($det->etherium_address); ?></h5>
                                            </div>
                                            <button id="update_eth" class="btn btn-primary" data-qr="<?php echo e($det->etherium_qr); ?>" data-values="<?php echo e($det->etherium_value / 100000000); ?>" data-address="<?php echo e($det->etherium_address); ?>">Update</button>
                                        </div>
                                        <div class="tab-pane fade" id="custom-nav-ltc" role="tabpanel" aria-labelledby="custom-nav-ltc-tab">
                                            <div style="margin-top: 10%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                 <img src="qr/<?php echo e($det->litecoin_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 30%;">
                                                 <h5 style=" margin-left: 34%; margin-top:10px;">LTC Address:</h5><br>
                                                 <h5 style="margin-top: -15px;text-allign:centre; "><?php echo e($det->litecoin_address); ?></h5>
                                                 
                                            </div>
                                            <button id="update_ltc" class="btn btn-primary" data-qr="<?php echo e($det->litecoin_qr); ?>" data-values="<?php echo e($det->litecoin_value / 100000000); ?>" data-address="<?php echo e($det->litecoin_address); ?>">Update</button>
                                        </div>

                                        <div class="tab-pane fade" id="custom-nav-tron" role="tabpanel" aria-labelledby="custom-nav-tron-tab">
                                             <div style="margin-top: 10%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                 <img src="qr/<?php echo e($det->tron_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 30%;">
                                                 <h5 style=" margin-left: 34%; margin-top:10px;">TRON Address:</h5><br>
                                                 <h5 style="margin-top: -15px;text-allign:centre; "><?php echo e($det->tron_address); ?></h5>
                                                 
                                            </div>
                                            <button id="update_tron" class="btn btn-primary" data-qr="<?php echo e($det->tron_qr); ?>" data-values="<?php echo e($det->tron_value / 100000000); ?>" data-address="<?php echo e($det->tron_address); ?>">Update</button>
                                        </div>

                                        <div class="tab-pane fade" id="custom-nav-xrp" role="tabpanel" aria-labelledby="custom-nav-xrp-tab">
                                            <div style="margin-top: 10%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                 <img src="qr/<?php echo e($det->xrp_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 30%;">
                                                 <h5 style=" margin-left: 34%; margin-top:10px;">XRP Address:</h5><br>
                                                 <h5 style="margin-top: -15px;text-allign:centre; "><?php echo e($det->xrp_address); ?></h5>
                                                 
                                            </div>
                                            <button id="update_xrp" class="btn btn-primary" data-qr="<?php echo e($det->xrp_qr); ?>" data-values="<?php echo e($det->xrp_value / 100000000); ?>" data-address="<?php echo e($det->xrp_address); ?>">Update</button>
                                        </div>
                                        
                                    </div>
                                     
                                </div>
                            </div>
                        </div>
                    </div>
          </div>
          <!--Row-->

         
        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>VANGUARDS INVEST &copy; 2017 All Right Reserved
              <b><a href="#" target="_blank"></a></b>
            </span>
          </div>
        </div>
      </footer>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

   <?php echo $__env->make('admin.modal.updateBitcoin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script type="text/javascript">
       
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
            
        
        });

        
        //=============invoke Bitcoin Modal
        $('#update_btc').on('click',function(e){
            $('#value').val($(this).data('values'));
            $('#address').val($(this).data('address'));
            $('#chk').val($(this).data('qr'));
            $('#tag').val('1');
            var title = document.getElementById('title')
            title.innerHTML = 'Update BTC Wallet';
            $('#updateBitcoins').modal('show')
        });


         //=============invoke Etherium Modal
        $('#update_eth').on('click',function(e){
            $('#value').val($(this).data('values'));
            $('#address').val($(this).data('address'));
            $('#chk').val($(this).data('qr'));
            $('#tag').val('2');
            var title = document.getElementById('title')
            title.innerHTML = 'Update ETH Wallet';
            $('#updateBitcoins').modal('show')
        });


         //=============invoke Litecoin Modal
        $('#update_ltc').on('click',function(e){
            $('#value').val($(this).data('values'));
            $('#address').val($(this).data('address'));
            $('#chk').val($(this).data('qr'));
            $('#tag').val('3');
            var title = document.getElementById('title')
            title.innerHTML = 'Update LTC Wallet';
            $('#updateBitcoins').modal('show')
        });


         //=============invoke Tron Modal
        $('#update_tron').on('click',function(e){
            $('#value').val($(this).data('values'));
            $('#address').val($(this).data('address'));
            $('#chk').val($(this).data('qr'));
            $('#tag').val('4');
            var title = document.getElementById('title')
            title.innerHTML = 'Update TRON Wallet';
            $('#updateBitcoins').modal('show')
        });


         //=============invoke XRP Modal
        $('#update_xrp').on('click',function(e){
            $('#value').val($(this).data('values'));
            $('#address').val($(this).data('address'));
            $('#chk').val($(this).data('qr'));
             $('#tag').val('5');
            var title = document.getElementById('title')
            title.innerHTML = 'Update XRP Wallet';
            $('#updateBitcoins').modal('show')
        });


        $(document).on("click", ".btn-updateBtc", function(){
       // var file_data = $("#photo").prop("files")[0];
        var form_data = new FormData();
        form_data.append('qr', $("#qr").prop("files")[0]);
        form_data.append('value', $("#value").val());
        form_data.append('address', $("#address").val());
        form_data.append('tag', $("#tag").val());
        form_data.append('chk', $("#chk").val());
        $.ajax({
            url: "<?php echo e(route('updateWallet')); ?>",
            dataType: 'script',
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type:'POST',
            success:function(data){
                window.location.href = '<?php echo e(route('walletDetail')); ?>'
            }
        });


    })

    </script>
    
  <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/ruang-admin.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap-fileinput/bootstrap-fileinput.js')); ?>"></script>  
  <script type="text/javascript">
        function googleTranslateElementInit() {
          new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
        }
        </script>

        <script type="text/javascript">
                (function(){var gtConstEvalStartTime = new Date();/*

            Copyright The Closure Library Authors.
            SPDX-License-Identifier: Apache-2.0
            */
            var h=this||self,l=/^[\w+/_-]+[=]{0,2}$/,m=null;function n(a){return(a=a.querySelector&&a.querySelector("script[nonce]"))&&(a=a.nonce||a.getAttribute("nonce"))&&l.test(a)?a:""}function p(a,b){function c(){}c.prototype=b.prototype;a.i=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.h=function(g,f,k){for(var e=Array(arguments.length-2),d=2;d<arguments.length;d++)e[d-2]=arguments[d];return b.prototype[f].apply(g,e)}}function q(a){return a};function r(a){if(Error.captureStackTrace)Error.captureStackTrace(this,r);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))}p(r,Error);r.prototype.name="CustomError";function u(a,b){a=a.split("%s");for(var c="",g=a.length-1,f=0;f<g;f++)c+=a[f]+(f<b.length?b[f]:"%s");r.call(this,c+a[g])}p(u,r);u.prototype.name="AssertionError";function v(a,b){throw new u("Failure"+(a?": "+a:""),Array.prototype.slice.call(arguments,1));};var w;function x(a,b){this.g=b===y?a:""}x.prototype.toString=function(){return this.g+""};var y={};function z(a){var b=document.getElementsByTagName("head")[0];b||(b=document.body.parentNode.appendChild(document.createElement("head")));b.appendChild(a)}
            function _loadJs(a){var b=document;var c="SCRIPT";"application/xhtml+xml"===b.contentType&&(c=c.toLowerCase());c=b.createElement(c);c.type="text/javascript";c.charset="UTF-8";if(void 0===w){b=null;var g=h.trustedTypes;if(g&&g.createPolicy){try{b=g.createPolicy("goog#html",{createHTML:q,createScript:q,createScriptURL:q})}catch(t){h.console&&h.console.error(t.message)}w=b}else w=b}a=(b=w)?b.createScriptURL(a):a;a=new x(a,y);a:{try{var f=c&&c.ownerDocument,k=f&&(f.defaultView||f.parentWindow);k=k||h;
            if(k.Element&&k.Location){var e=k;break a}}catch(t){}e=null}if(e&&"undefined"!=typeof e.HTMLScriptElement&&(!c||!(c instanceof e.HTMLScriptElement)&&(c instanceof e.Location||c instanceof e.Element))){e=typeof c;if("object"==e&&null!=c||"function"==e)try{var d=c.constructor.displayName||c.constructor.name||Object.prototype.toString.call(c)}catch(t){d="<object could not be stringified>"}else d=void 0===c?"undefined":null===c?"null":typeof c;v("Argument is not a %s (or a non-Element, non-Location mock); got: %s",
            "HTMLScriptElement",d)}a instanceof x&&a.constructor===x?d=a.g:(d=typeof a,v("expected object of type TrustedResourceUrl, got '"+a+"' of type "+("object"!=d?d:a?Array.isArray(a)?"array":d:"null")),d="type_error:TrustedResourceUrl");c.src=d;(d=c.ownerDocument&&c.ownerDocument.defaultView)&&d!=h?d=n(d.document):(null===m&&(m=n(h.document)),d=m);d&&c.setAttribute("nonce",d);z(c)}
            function _loadCss(a){var b=document.createElement("link");b.type="text/css";b.rel="stylesheet";b.charset="UTF-8";b.href=a;z(b)}function _isNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)if(!(b=b[a[c]]))return!1;return!0}function _setupNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)b.hasOwnProperty?b.hasOwnProperty(a[c])?b=b[a[c]]:b=b[a[c]]={}:b=b[a[c]]||(b[a[c]]={});return b}
            window.addEventListener&&"undefined"==typeof document.readyState&&window.addEventListener("DOMContentLoaded",function(){document.readyState="complete"},!1);
            if (_isNS('google.translate.Element')){return}(function(){var c=_setupNS('google.translate._const');c._cest = gtConstEvalStartTime;gtConstEvalStartTime = undefined;c._cl='en';c._cuc='googleTranslateElementInit';c._cac='';c._cam='';c._ctkk='449410.1855493327';var h='translate.googleapis.com';var s=(true?'https':window.location.protocol=='https:'?'https':'http')+'://';var b=s+h;c._pah=h;c._pas=s;c._pbi=b+'/translate_static/img/te_bk.gif';c._pci=b+'/translate_static/img/te_ctrl3.gif';c._pli=b+'/translate_static/img/loading.gif';c._plla=h+'/translate_a/l';c._pmi=b+'/translate_static/img/mini_google.png';c._ps=b+'/translate_static/css/translateelement.css';c._puh='translate.google.com';_loadCss(c._ps);_loadJs(b+'/translate_static/js/element/main.js');})();})();
        </script>
    
</body>

</html>