<!DOCTYPE html>
<html>
  <head>

     <title> Read this</title>
  </head>

  <body>

  <h2> <b style="font-size: 45px;"><?php echo e(Auth::user()->name); ?></b> you have no right to use this method</h2>
  </body>
</html>