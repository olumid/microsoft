<div id="form_selectPlan" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="border-color: #f5f4f1 transparent transparent transparent;">
                <h3 class="modal-title" id="title" style="color: hsl(59, 69%, 49%);"></h3>
                
            </div>
            <div class="modal-body" style="background-color: #e6e6e6; border: 5px solid #faf9f9;">
                <div id="invalid_tag" style="font-family: roboto; font-size:15px; margin:3px; display:none;" class="alert alert-danger">
                     <strong>Invalid Amount. Please, Enter a valid Amount</strong>             
                </div>
                <div id="error_tag" style="font-family: roboto; font-size:15px; margin:3px; display:none;" class="alert alert-danger fade show" role="alert">
                    <strong>Error!, Insufficient balance</strong>                  
                </div>
                <div id="wait_tag" style="font-family: roboto; font-size:15px; margin:3px; display:none;" class="alert alert-success fade show" role="alert">
                     <strong>Please wait.........</strong>                     
                </div>
                <div id="status_tag" style="color: red; font-family: roboto; font-size:19px; margin:3px; display:none;" class="alert alert-default fade show" role="alert">
                     <strong>Oops, sorry you cannot have more than one investment at a time!</strong>                     
                </div>
               
                <div id="max_tag" style="color: red; font-family: roboto; font-size:19px; margin:3px; display:none;" class="alert alert-default fade show" role="alert">
                     <strong id="show_max"></strong>                     
                </div>
                <div id="min_tag" style="color: red; font-family: roboto; font-size:19px; margin:3px; display:none;" class="alert alert-default fade show" role="alert">
                     <strong  id="show_min"></strong>                     
                </div>
                <input type="hidden" id="max"  class="form-control select2" name="max">
                <input type="hidden" id="min"  class="form-control select2" name="min">
                <form action="#" class="form-horizontal" id="selectPlan" method="post">
                    <div class="form-group">
                       
                        <div class="col-md-8">
                             <input type="hidden" id="name"  class="form-control select2" name="plan_name">
                             <input type="hidden" id="profit"  class="form-control select2" name="plan_rate">
                             <input type="hidden" id="validity"  class="form-control select2" name="plan_validity">
                             <input type="hidden" id="investor_id"  class="form-control select2" name="investor_id">
                             <input type="hidden" id="investor_email"  class="form-control select2" name="investor_email">
                        
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-10">Enter Amount($) Below.</label>
                        <div class="col-md-8">
                            <input type="number" id="amount"  class="form-control select2" name="amount" value="0">
                            <input type="hidden" id="invest_status"  class="form-control select2" name="investment_status" value="Processing">
                            <input type="hidden" id="counter"  class="form-control select2" name="counter" value="0">
                            <small style="color: red; font-size:18px;" class="form-text">Note:- only numbers allowed</small>
                        </div>
                    </div>                                                        
                    <div class="modal-footer  col-md-10" style="margin-top:20px;">
                        <button type="submit" class="btn btn-secondary " data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-selectPlan" id="btn-selectPlan">Save</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>