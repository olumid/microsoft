
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />




	<!-- META -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />    
    <meta name="description" content="" />
    
    <!-- FAVICONS ICON -->
    <link rel="icon" href="images/favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
    
    <!-- PAGE TITLE HERE -->
    <title>Market</title>
    
    <!-- MOBILE SPECIFIC -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
  <!-- PAYOUT PROGRESS BAR CSS -->
 

<link rel="stylesheet" href="payout/main.html">


    
    <!-- [if lt IE 9]>
        <script src="js/html5shiv.min.js"></script>
        <script src="js/respond.min.js"></script>
	<![endif] -->
    
    
    
    <!-- BOOTSTRAP STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- FONTAWESOME STYLE SHEET -->
    
    <link rel="stylesheet" href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- FLATICON STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/flaticon.min.css">
    <!-- ANIMATE STYLE SHEET --> 
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <!-- OWL CAROUSEL STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <!-- BOOTSTRAP SELECT BOX STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <!-- MAGNIFIC POPUP STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.min.css">
    <!-- LOADER STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/loader.min.css">    
    <!-- MAIN STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- THEME COLOR CHANGE STYLE SHEET -->
    <link rel="stylesheet" class="skin" type="text/css" href="css/skin/skin-1.css">
    <!-- CUSTOM  STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/custom.css">
   

    
    <!-- REVOLUTION SLIDER CSS -->
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/settings.css">
    <!-- REVOLUTION NAVIGATION STYLE -->
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/navigation.css">
    
    <!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">  
	<link href="https://fonts.googleapis.com/css?family=Crete+Round:400,400i&amp;subset=latin-ext" rel="stylesheet">
  
 
<style type="text/css">
#apDiv1 {
	position:absolute;
	left:1px;
	top:3155px;
	width:445px;
	height:294px;
	z-index:100000;
	font-size: 0.9em;
	color: #FFF;
	background-color: #903;
	text-align: center;
	display:none;
}

.alink{
	color:#0C3;
	
	
}
</style>
</head>

<body>

       <div style="width:100%; height:140px; background-color:#070707">
    
<header class="site-header header-style-3 topbar-transparent">
        
            
            
            <div class="sticky-header main-bar-wraper">
                <div class="main-bar">
                    <div class="container">
                        <a href="./">
                            <div style="background-image:url(img/new/log6.png); width:200px; background-position:left; background-size:contain; background-repeat:no-repeat" class="logo-header mostion">
                            </div>   
                        </a>
                            
                            <!-- NAV Toggle Button -->
                            <button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            
                           
                            <!-- ETRA Nav -->
                            
                             
                            <!-- SITE Search -->
                            
                            <!-- MAIN Vav -->
                            <div class="header-nav navbar-collapse collapse ">
                             <ul class=" nav navbar-nav">
                                <li>
                                    <a href="./">TRADING<i></i></a>
                                       
                                </li>
                                
                                
                                 <li>
                                    <a href="./market">MARKET<i></i></a>
                                       
                                </li>
                              
                                
                                <li>
                                    <a href="./login">LOGIN<i></i></a>
                                       
                                </li>
                                
                                  <li>
                                    <a href="./register">REGISTER<i></i></a>
                                       
                                </li>
                            
                               
                              <li>
                                    <a href="./why">WHY US<i></i></a>
                                       
                              </li>
                              <li>
                                    <a href="./about">ABOUT US<i></i></a>
                                       
                              </li>
                              
                             <li>
                                    <a href="./contact">SUPPORT<i></i></a>
                                       
                              </li>
                              <li>
                                    <a href="./faq">FAQ<i></i></a>
                                       
                              </li>
                                
                                <li>
                                  
                                </li>
                            </ul>
                        </div>
        
                    </div>
                </div>
            </div>
            
        </header>       
        

       
       
       </div> 
        <!-- CONTENT START -->
        <div class="page-content">
        
            <!-- SLIDER START -->
            <div class="main-slider style-two default-banner">
           		<div class="tp-banner-container">
                    <div class="tp-banner" >
                        <!-- START REVOLUTION SLIDER 5.4.1 -->
                        <div id="rev_slider_1014_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="typewriter-effect" data-source="gallery">
                           <div id="rev_slider_1014_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.1">
                                <ul>
                                    <!-- SLIDE 1 -->	
                                    
                                    
                                    <!-- SLIDE 2 -->
                                    <li data-index="rs-1001" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="images/main-slider/slider2/slide1.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                    <!-- MAIN IMAGE -->
                                    <img src="images/main-slider/slider2/slide1b.jpg"  alt=""  data-bgposition="center bottom" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina/>
                                    <!-- LAYERS -->
                                    
                                    <!-- LAYER NR. 1 [ for overlay ] -->
                                    <div class="tp-caption tp-shape tp-shapewrapper " 
                                    id="slide-101-layer-1" 
                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                    data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                                    data-width="full"
                                    data-height="full"
                                    data-whitespace="nowrap"
                                    data-type="shape" 
                                    data-basealign="slide" 
                                    data-responsive_offset="off" 
                                    data-responsive="off"
                                    data-frames='[
                                    {"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                    style="z-index: 12;background-color:rgba(0, 0, 0, 0.3);border-color:rgba(0, 0, 0, 0);border-width:0px;"> 
                                    </div>
                                    
                                    <!-- LAYER NR. 2 [ for title ] -->
                                    <div class="tp-caption   tp-resizeme" 
                                    id="slide-101-layer-2" 
                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
                                    data-y="['top','top','top','top']" data-voffset="['308','308','308','308']"  
                                    data-fontsize="['60','60','60','60']"
                                    data-lineheight="['110','110','110','110']"
                                    data-width="['6','6','6','6']"
                                    data-height="['110,'110','110','110']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                
                                    data-type="text" 
                                    data-responsive_offset="on" 
                                    data-frames='[
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                
                                    style="z-index: 13; 
                                    white-space: normal;                                                                    
                                    ">
                                    
                                    <div class="bg-primary">&nbsp;</div>
                                    
                                    </div>
                                                                    
                                    <!-- LAYER NR. 3 [ for title ] -->
                                    <div class="tp-caption   tp-resizeme" 
                                    id="slide-101-layer-3" 
                                    data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" 
                                    data-y="['top','top','top','top']" data-voffset="['300','300','300','300']"  
                                    data-fontsize="['55','55','55','45']"
                                    data-lineheight="['60','60','60','65']"
                                    data-width="['700','700','700','700']"
                                    data-height="['none','none','none','none']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                
                                    data-type="text" 
                                    data-responsive_offset="on" 
                                    data-frames='[
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                
                                    style="z-index: 13; 
                                    white-space: normal; 
                                    font-weight: 700;
                                    color: rgb(75, 57, 65);
                                    border-width:0px;">
                                    
                                    <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase; ">
                                    	<span class="text-white" style="padding-right:10px;">LONDON BEST</span><span class="text-primary"></span>
                                    </div>
                                    
                                    </div>
                                    
                                    <!-- LAYER NR. 4 [ for title ] -->
                                    <div class="tp-caption   tp-resizeme" 
                                    id="slide-101-layer-4" 
                                    data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" 
                                    data-y="['top','top','top','top']" data-voffset="['360','360','360','360']"  
                                    data-fontsize="['53','53','53','45']"
                                    data-lineheight="['70','70','70','70']"
                                    data-width="['700','700','700','700']"
                                    data-height="['none','none','none','none']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                
                                    data-type="text" 
                                    data-responsive_offset="on" 
                                    data-frames='[
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1000,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                
                                    style="z-index: 13; 
                                    white-space: normal; 
                                    font-weight: 700;
                                    border-width:0px;">
                                    <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase ;">
                                   		<span class="text-primary" style="padding-right:10px; text-shadow:1px 1px 4px #FF9900;color:#CCCCCC">TRADING CENTER </span><span class="text-white"></span>
                                    </div>
                                    
                                    </div>
                                
                                    <!-- LAYER NR. 5 [ for paragraph] -->
                                    <div class="tp-caption  tp-resizeme" 
                                    id="slide-101-layer-5" 
                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 
                                    data-y="['top','top','top','top']" data-voffset="['440','440','440','440']"  
                                    data-fontsize="['16','16','16','30']"
                                    data-lineheight="['30','30','30','40']"
                                    data-width="['600','600','600','600']"
                                    data-height="['none','none','none','none']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                
                                    data-type="text" 
                                    data-responsive_offset="on"
                                    data-frames='[
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1500,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                
                                    style="z-index: 13; 
                                    font-weight: 500; 
                                    color:#fff;
                                    border-width:0px;">
                                   </div>
                                
                                    <!-- LAYER NR. 6 [ for see all service botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-6"						
                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 
                                    data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  
                                    data-lineheight="['none','none','none','none']"
                                    data-width="['300','300','300','300']"
                                    data-height="['none','none','none','none']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                    
                                    data-type="text" 
                                    data-responsive_offset="on"
                                    data-frames='[ 
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                    style="z-index:13; text-transform:uppercase;">
                                          
                                    </div>
                                    
                                    <!-- LAYER NR. 7 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-7"						
                                    data-x="['left','left','left','left']" data-hoffset="['220','220','220','320']" 
                                    data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  
                                    data-lineheight="['none','none','none','none']"
                                    data-width="['300','300','300','300']"
                                    data-height="['none','none','none','none']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                    
                                    data-type="text" 
                                    data-responsive_offset="on"
                                    data-frames='[ 
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                    style="z-index:13;
                                    text-transform:uppercase;
                                    font-weight:500;
                                    ">
                                    
                                     
                                   
                                    </div>
                                    
                                    <!-- LAYER NR. 8 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-8"						
                                    data-x="['right','right','right','right']" data-hoffset="['-100','-100','-100','-100']" 
                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-650','-650','-650','-650']"
                                    
                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},
                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
                                    
                                    style="z-index: 13;">
                                    <img src="images/main-slider/slider2/earth2.png" alt="" class="spin-city">
                                    </div>
                                    
                                     <!-- LAYER NR. 9 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-9"						
                                    data-x="['right','right','right','right']" data-hoffset="['-300','-100','-100','-100']" 
                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-200','-200','-200','-200']"
                                    
                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},
                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
                                    
                                    style="z-index: 13;">
                                    <img src="images/main-slider/slider2/earth2-shadow.png" alt="">
                                    </div>  
                                                                     
                                    <!-- LAYER NR. 10 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-10"
                                    
                                    data-x="['right','right','right','right']" data-hoffset="['200','200','200','200']" 
                                    data-y="['top','bottom','bottom','bottom']" data-voffset="['150','150','150','150']"
                                    
                                    data-height="none"
                                    data-whitespace="nowrap"
                         
                                    data-type="image" 
                                    data-responsive_offset="on" 
                        
                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},
                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                                                  
                                    style="z-index: 16;">
                                    <img src="images/main-slider/slider2/rocketxx.html" alt="" class="floating">
                                    </div> 
                                                                         
                                    <!-- LAYER NR. 11 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-11"
                                    
                                    data-x="['right','right','right','right']" data-hoffset="['278','278','278','278']" 
                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['180','100','100','100']"
                                    
                                    data-height="none"
                                    data-whitespace="nowrap"
                         
                                    data-type="image" 
                                    data-responsive_offset="on" 
                        
                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":4000,"ease":"Power3.easeOut"},
                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                                                  
                                    style="z-index: 15;">
                                    <img src="images/main-slider/slider2/firexx.html" alt="" class="floating">
                                    </div>
                                    
                                    <!-- LAYER NR. 12 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-12"
                                    
                                    data-x="['right','right','right','right']" data-hoffset="['100','100','100','100']" 
                                    data-y="['top','bottom','bottom','bottom']" data-voffset="['0','0','0','0']"
                                    data-lineheight="['none','none','none','none']"
                                    data-width="['500','500','500','500']"
                                    data-height="['none','none','none','none']"                                    
                                    data-whitespace="nowrap"
                                    data-type="image" 
                                    data-responsive_offset="on" 
                        
                                     data-frames='[ 
                                    {"from":"y:0px(R);opacity:0;","speed":2000,"to":"o:1;","delay":4000,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                                                  
                                    style="z-index: 12;">
                                    <div class="coin-slide bg-full-width bg-repeat-y coin-slide-rotate" style="background-image:url(images/main-slider/slider2/coin-sky.png);height:100vh;">
                                    <div class="coin-slide bg-full-width bg-repeat-y coin-slide-rotate" style="background-image:url(images/main-slider/slider2/coin-sky2.png);height:70vh;"></div>
                                    
                                    </div>
                                    </div>    
                                                                                                   
                                  </li>

                                    <!-- SLIDE  3 -->
                                    
                                     <!-- SLIDE  3  li tag goes here -->                               
                                </ul>
                                	
                           </div>
                        </div>
                        <!-- END REVOLUTION SLIDER -->
                    </div>
            	</div>
            </div>
            <!-- SLIDER END -->

            
                      
            <!-- OUR VALUE SECTION START --><!-- OUR VALUE SECTION  END -->
            
         
            
            
            
            
            
            
            <div style="width:100%">
            
            <div style="width: 100%; height:62px; background-color: #FFFFFF; overflow:hidden; box-sizing: border-box; border: 1px solid #56667F; border-radius: 4px; text-align: right; line-height:14px; block-size:62px; font-size: 12px; box-sizing:content-box; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #56667F;padding:1px;padding: 0px; margin: 0px;"><div style="height:40px;"><iframe src="https://widget.coinlib.io/widget?type=horizontal_v2&amp;theme=light&amp;pref_coin_id=1505&amp;invert_hover=" width="100%" height="36" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;"></iframe></div></div>
            
            
            </div>
           
           
          <div style="background-color:#F8F8F8" class="section-full p-t80 p-b50">
                <div class="container">
                
                  
                    <div class="row">
                     <div id="google_translate_element"></div>
                    <div class="col-md-6 col-sm-6">
                        	<img src="images/market.jpg" alt="investor" width="465" height="802" />
                    </div>
                        
                    
                    
                        <div class="col-md-6 col-sm-6">
                            <div class="section-head text-left">
                                <h2 style="font-weight:bolder" class="text-uppercase">Stock market rallies: what you need to know</h2>
                          </div>
                             
                                <p style="font-size:20px; font-weight:lighter; line-height:20px; color:#000000">


A bull market rally is considered the default type of market rally. It occurs when prices are rising and there is optimism this trend will continue for a long time.

The duration or strength of a rally will vary depending on how many sellers enter the market and how quickly they take back control. Understanding the different types of bull market is vital if you want to identify how long each rally will last. There are a lot of terms used to describe bull markets, but these are the most common:


<br />

<div style="width:100%; height:250px; overflow:hidden"><!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/EURUSD/?exchange=FX" rel="noopener" target="_blank"><span class="blue-text">EURUSD Rates</span></a> by TradingView</div>
  <script type="text/javascript" src="../s3.tradingview.com/external-embedding/embed-widget-mini-symbol-overview.js" async>
  {
  "symbol": "FX:EURUSD",
  "width": 350,
  "height": 220,
  "locale": "en",
  "dateRange": "12M",
  "colorTheme": "light",
  "trendLineColor": "#37a6ef",
  "underLineColor": "#E3F2FD",
  "isTransparent": true,
  "autosize": false,
  "largeChartUrl": ""
}
  </script>
</div>
<!-- TradingView Widget END --> </div> </p>


 <small style="font-size:10px; font-weight:lighter; color:#A8A8A8">
                              
You can invest in 4 types of investment options with AlphaFX: Top Trader Portfolios which comprise the best performing and most sustainable traders on our platform, and Market Portfolios that bundle together CFD stocks, commodities or ETFs under one chosen market strategy.

CopyPortfolios aim to help investors minimise long-term risk, promote opportunities for growth, by taking copy trading to the next level and creating diversified investments.
  </small>
                                <div>
                                	
                                </div>
                      </div>
                  </div>
                        
                    </div>
                </div> 
           
           
           
           
           
           
            
            <div class="section-full home-about-section p-t80 bg-no-repeat bg-bottom-right"  style=" background-color:#EFEFEF">
                <div class="container-fluid ">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="wt-box text-right animate" data-animate="pulse" data-duration="2.0s" data-delay="0.2s" data-offset="100">
                                <img src="images/unnamed.gif" alt=""> 
                            </div>
                      </div>
                        <div class="col-md-6">
                            <div class="wt-right-part p-b80">
                                    <!-- TITLE START -->
                                    <div class="section-head text-left">
                                      
                                                  <h2 style="font-weight:bolder" class="text-uppercase">Stock Trading with CoinFinancePro</h2>
                                       
                                    <!-- TITLE END -->
                                    <div class="section-content">
                                        <div style="text-align:justify" class="wt-box">
                                           
                                           <span style="font-family:Kozuka Gothic Pro; color:#000; font-weight:lighter; font-size:16px">  Trading stocks with Globafxcoin grant investors access to the markets, where investors trade on the price movements on shares of a corporation that is trading in the equity market.
                                            CoinFinancePro has access to direct liquidity forex pricing, with real-time data straight from the two largest stock exchanges in the world, NYSE and NASDAQ.

</span>
                                            
                                              <ul class="list-chevron-circle orange ">
                                        <li>Earn up to 15% with with your investment capital back to your bitcoin wallet address or any other receiving address you provide
</li>
                        <li>Get guidance and priority support from your dedicated Market Strategist
No bank fees for wires</li>
                        
                          <li>Get unlimited access to Access to exclusive events and product previews</li>
                            <li>Enjoy instant execution, making sure you get efficient price execution in the markets.</li>
                                	</ul>
                                            <a href="./about" style="margin:10px; font-weight:bold; background-color:#FF9900; color:#FFFFFF; padding:15px; border-radius:9px">&nbsp;Read more&nbsp;</a>
                                            
                                        </div>
                                    </div>                                	
                                </div>
                        </div>
                    </div>
                </div>
             </div>
         
            
            
            
      <div class="section-full  p-t80 p-b80 bg-gray" style=" padding-top:200px; padding-bottom:100px; background-image:url(images/bg.png); background-repeat:repeat-y" >
            	
          
          
        <!-- TITLE START-->
                    <div class="section-head text-center">
                    
                           <h2 style="font-weight:bolder; color:#FFF" class="text-uppercase">Our tools, your advantage</h2>	
                     
                    <!-- TITLE END-->
                    <div class="section-content no-col-gap">
                        <div class="row">
                               
                            <!-- COLUMNS 1 -->
                            <div style=" padding:30px; margin-bottom:30px" class="col-md-3 col-sm-3 step-number-block">
                               
                               <center> <h4 style="color:#FFFFFF">Choose from a full range of simple and complex order types with superior execution and reliability.</h4>
                            </center>
                            </div>
                            <!-- COLUMNS 2 -->
                        <div style=" padding:30px; margin-bottom:30px" class="col-md-3 col-sm-3 step-number-block">
   
                               <center> <h4 style="color:#FFFFFF">Use our customizable drawing tools and indicators, and trade directly from the charts. </h4>
                            </center>
                            </div>
                            <!-- COLUMNS 3 -->
                                <div style=" padding:30px; margin-bottom:30px" class="col-md-3 col-sm-3 step-number-block">
                             
                               <center> <h4 style="color:#FFFFFF">Never miss an opportunity with integrated analysis, news and trade ideas</h4>
                           </center>
                            </div>
                           <div style=" padding:30px; margin-bottom:30px" class="col-md-3 col-sm-3 step-number-block">
                             
                               <center> <h4 style="color:#FFFFFF">Spot opportunities, trade and manage your positions from a full suite of mobile and tablet apps.</h4>
                          </center>
                            </div>
                        </div>
                       
                    </div>
                
                </div>
          </div>
           
            

          <!-- ABOUT COMPANY SECTION START -->           
             
            <!-- ABOUT COMPANY SECTION  END --> 
            
            <!-- WHY CHOOSE US SECTION START  -->
            
            <!-- WHY CHOOSE US SECTION END -->                      
    
                       
          <!-- SECTION CONTENT START -->
            <div class="row clearfix">
            
                <div style="background-color:#1C222C; margin-bottom:50px; display:none" class="col-lg-12">
                
              
                  <div class="col-lg-1"></div>  <div class="col-lg-10"><div class="card">
                        <div class="header">
                    
                            <center><h1 style="color:#F60; font-family:impact; font-size:5em">Client payout</h1></center>
                        <center><div class="icon-content">
                                        <div class="font-26 font-weight-800 text-black m-b5"><span style="color:#FFFFFF" class="counter">1500</span><b><span style="color:#CCC">+</span></b></div>
                                        <span>TRANSFER IN PROGRESS</span>
                                    </div></center>   
                        </div>
                    <div class="section-content no-col-gap; col-sm-12"><div class="body">
                      
                         <div class="table-responsive table_middel">
                            <table class="table m-b-0">
                                <thead class="thead-dark">
                                    <tr style="color:#FFF; background-color:#333">
                                      
                                        <th width="7%" style="color:#FFF; background-color:#333">Photo</th>
                                        <th width="11%" style="color:#FFF; background-color:#333; text-align:center">Names</th>
                             <th width="9%" style="color:#FFF; background-color:#333; text-align:center">Plan</th>
                        <th width="13%" style="color:#FFF; background-color:#333; text-align:center"> Date</th>
                        <th width="13%" style="color:#FFF; background-color:#333; text-align:center">Amount</th>
                        <th width="18%" style="color:#FFF; background-color:#333; text-align:center">Random countdown</th><th width="11%" style="color:#FFF; background-color:#333; text-align:center">Progress</th>
                        <th width="18%" style="color:#FFF; background-color:#333; text-align:center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    
                                                                        <tr>
                                        
                                        <td><div style="border-radius:10px; height:50px; width:50px; border:solid 1px #FFFFFF; border-radius:50px; background-image:url(admin/payout/.jpg); background-position:center; background-size:contain"></div></td>
                                        <td style="padding-top:20px; text-align:center"><span class="text-info"></span></td>
                                        <td style="padding-top:20px; text-align:center"></td>
                                        <td style="padding-top:20px; text-align:center"></td>
                                        <td style="padding-top:20px; text-align:center"></td>
                                        <td style="padding-top:20px; text-align:center"><span class="badge badge-warning"> <div class="counter font-15" style="font-weight:lighter"><span style="font-size:0.4em"><small style="font-size:0.5em"></small></span></div></span></td>
                                        <td style="padding-top:27px; text-align:center"><div class="progress progress-xs">
                                          <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width:40%; border-radius:9px"> <span class="sr-only">% Complete</span> </div><center> <div style="padding:7px">100%</div></center>
                                          </div>
                                        </td>
                                        <td style="padding-top:20px; text-align:center"><span class="badge badge-success"></span></td>
                                      </tr>


<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript">
        (function(){var gtConstEvalStartTime = new Date();/*

    Copyright The Closure Library Authors.
    SPDX-License-Identifier: Apache-2.0
    */
    var h=this||self,l=/^[\w+/_-]+[=]{0,2}$/,m=null;function n(a){return(a=a.querySelector&&a.querySelector("script[nonce]"))&&(a=a.nonce||a.getAttribute("nonce"))&&l.test(a)?a:""}function p(a,b){function c(){}c.prototype=b.prototype;a.i=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.h=function(g,f,k){for(var e=Array(arguments.length-2),d=2;d<arguments.length;d++)e[d-2]=arguments[d];return b.prototype[f].apply(g,e)}}function q(a){return a};function r(a){if(Error.captureStackTrace)Error.captureStackTrace(this,r);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))}p(r,Error);r.prototype.name="CustomError";function u(a,b){a=a.split("%s");for(var c="",g=a.length-1,f=0;f<g;f++)c+=a[f]+(f<b.length?b[f]:"%s");r.call(this,c+a[g])}p(u,r);u.prototype.name="AssertionError";function v(a,b){throw new u("Failure"+(a?": "+a:""),Array.prototype.slice.call(arguments,1));};var w;function x(a,b){this.g=b===y?a:""}x.prototype.toString=function(){return this.g+""};var y={};function z(a){var b=document.getElementsByTagName("head")[0];b||(b=document.body.parentNode.appendChild(document.createElement("head")));b.appendChild(a)}
    function _loadJs(a){var b=document;var c="SCRIPT";"application/xhtml+xml"===b.contentType&&(c=c.toLowerCase());c=b.createElement(c);c.type="text/javascript";c.charset="UTF-8";if(void 0===w){b=null;var g=h.trustedTypes;if(g&&g.createPolicy){try{b=g.createPolicy("goog#html",{createHTML:q,createScript:q,createScriptURL:q})}catch(t){h.console&&h.console.error(t.message)}w=b}else w=b}a=(b=w)?b.createScriptURL(a):a;a=new x(a,y);a:{try{var f=c&&c.ownerDocument,k=f&&(f.defaultView||f.parentWindow);k=k||h;
    if(k.Element&&k.Location){var e=k;break a}}catch(t){}e=null}if(e&&"undefined"!=typeof e.HTMLScriptElement&&(!c||!(c instanceof e.HTMLScriptElement)&&(c instanceof e.Location||c instanceof e.Element))){e=typeof c;if("object"==e&&null!=c||"function"==e)try{var d=c.constructor.displayName||c.constructor.name||Object.prototype.toString.call(c)}catch(t){d="<object could not be stringified>"}else d=void 0===c?"undefined":null===c?"null":typeof c;v("Argument is not a %s (or a non-Element, non-Location mock); got: %s",
    "HTMLScriptElement",d)}a instanceof x&&a.constructor===x?d=a.g:(d=typeof a,v("expected object of type TrustedResourceUrl, got '"+a+"' of type "+("object"!=d?d:a?Array.isArray(a)?"array":d:"null")),d="type_error:TrustedResourceUrl");c.src=d;(d=c.ownerDocument&&c.ownerDocument.defaultView)&&d!=h?d=n(d.document):(null===m&&(m=n(h.document)),d=m);d&&c.setAttribute("nonce",d);z(c)}
    function _loadCss(a){var b=document.createElement("link");b.type="text/css";b.rel="stylesheet";b.charset="UTF-8";b.href=a;z(b)}function _isNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)if(!(b=b[a[c]]))return!1;return!0}function _setupNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)b.hasOwnProperty?b.hasOwnProperty(a[c])?b=b[a[c]]:b=b[a[c]]={}:b=b[a[c]]||(b[a[c]]={});return b}
    window.addEventListener&&"undefined"==typeof document.readyState&&window.addEventListener("DOMContentLoaded",function(){document.readyState="complete"},!1);
    if (_isNS('google.translate.Element')){return}(function(){var c=_setupNS('google.translate._const');c._cest = gtConstEvalStartTime;gtConstEvalStartTime = undefined;c._cl='en';c._cuc='googleTranslateElementInit';c._cac='';c._cam='';c._ctkk='449410.1855493327';var h='translate.googleapis.com';var s=(true?'https':window.location.protocol=='https:'?'https':'http')+'://';var b=s+h;c._pah=h;c._pas=s;c._pbi=b+'/translate_static/img/te_bk.gif';c._pci=b+'/translate_static/img/te_ctrl3.gif';c._pli=b+'/translate_static/img/loading.gif';c._plla=h+'/translate_a/l';c._pmi=b+'/translate_static/img/mini_google.png';c._ps=b+'/translate_static/css/translateelement.css';c._puh='translate.google.com';_loadCss(c._ps);_loadJs(b+'/translate_static/js/element/main.js');})();})();
</script>
<script src="js/jquery-1.12.4.min.js"></script><!-- JQUERY.MIN JS -->
<script   src="js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->

<script   src="js/bootstrap-select.min.js"></script><!-- FORM JS -->
<script   src="js/jquery.bootstrap-touchspin.min.js"></script><!-- FORM JS -->

<script   src="js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->

<script   src="js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script   src="js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script   src="js/waypoints-sticky.min.js"></script><!-- COUNTERUP JS -->

<script  src="js/isotope.pkgd.min.js"></script><!-- MASONRY  -->

<script   src="js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->

<script   src="js/stellar.min.js"></script><!-- PARALLAX BG IMAGE   --> 
<script   src="js/scrolla.min.js"></script><!-- ON SCROLL CONTENT ANIMTE   -->

<script   src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script   src="js/shortcode.js"></script><!-- SHORTCODE FUCTIONS  -->

<script  src="js/jquery.bgscroll.js"></script><!-- BACKGROUND SCROLL -->
<script  src="js/tickerNews.min.js"></script><!-- TICKERNEWS-->
<!-- TICKERNEWS FUNCTiON -->
<script type="text/javascript">
	jQuery(function(){
		var timer = !1;
		_Ticker = jQuery("#T1").newsTicker();
		_Ticker.on("mouseenter",function(){
			var __self = this;
			timer = setTimeout(function(){
				__self.pauseTicker();
			},200);
		});
		_Ticker.on("mouseleave",function(){
			clearTimeout(timer);
			if(!timer) return !1;
			this.startTicker();
		});
	});
</script>
<!-- REVOLUTION JS FILES -->

<script  src="plugins/revolution/revolution/js/jquery.themepunch.tools.min.js"></script>
<script  src="plugins/revolution/revolution/js/jquery.themepunch.revolution.min.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->	
<script  src="plugins/revolution/revolution/js/extensions/revolution-plugin.js"></script>

<!-- REVOLUTION SLIDER FUNCTION  ===== -->
<script   src="js/rev-script-1.js"></script>






    <script src="j/jquery.appear.js"></script>
    <script src="j/swiper/swiper.min.js"></script>
    <script src="j/swiperanimation/SwiperAnimation.min.js"></script>
    <script src="j/counter/jquery.countTo.js"></script>
    <script src="j/owl-carousel/owl.carousel.min.js"></script>
    <script src="j/jarallax/jarallax.min.js"></script>
    <script src="j/jarallax/jarallax-video.min.js"></script>
    <script src="j/magnific-popup/jquery.magnific-popup.min.js"></script>


    <script src="js/jquery-2.2.4.min.html"></script>
    <script src="js/common_scripts.html"></script>
    <script src="js/main.js"></script>
	<script src="assets/validate.html"></script>
</body>


</html>                                      