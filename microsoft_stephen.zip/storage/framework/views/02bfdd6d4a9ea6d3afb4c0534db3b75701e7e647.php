<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Coin Finance - Transaction </title>
    <!-- Favicon icon -->
      <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('img/new/android-icon-48x48.png')); ?>">
 	  
    <link href="<?php echo e(asset('vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
	  <link href="<?php echo e(asset('vendor/datatables/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
	  <link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
	  
    <link href="<?php echo e(asset('css/style11.css')); ?>" rel="stylesheet">
	 
	
<style>
		@import  url(https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&family=Titillium+Web:wght@400;700&display=swap);
		select{
			font-size: 20px;
			font-weight: bolder;
			
		}
	</style>
	
</head>
<body style="font-family: 'Titillium Web'; color:white">

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="<?php echo e(route('dashboard1')); ?>" class="brand-logo"  style="margin-right: 40%;">
               <img src="<?php echo e(asset('img/new/log1.png')); ?>" alt="" style="margin-left: 100px;">
            </a>
            <div class="nav-control" style="margin-left: 150px;">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		
		<!--**********************************
            Header start
        ***********************************-->
      <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            <div class="dashboard_bar">
                                
                            </div>
                        </div>
                        <ul class="navbar-nav header-right">
							
							
							
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <img src="<?php echo e(asset('avatar/'.Auth::user()->avatar)); ?>" width="20" alt=""/>
									<div class="header-info">
										<span><?php echo e(Auth::user()->name); ?></span>
									</div>
                                </a> 
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
         <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('dashboard1')); ?>" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        

                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('manageWallet')); ?>">
						<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Profile</span>
						</a>
                       
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('investment')); ?>">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">Packages</span>
						</a>
                        
                    </li>
                      <li><a class="has-arrow ai-icon" href="<?php echo e(route('transactionAll')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Transactions</span>
						</a> 
                    </li>
                   
                     <li><a class="has-arrow ai-icon" href="<?php echo e(route('nft')); ?>" aria-expanded="false">
							<i class="flaticon-381-layer-1"></i>
							<span class="nav-text">Market Place</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('loan')); ?>" aria-expanded="false">
							<i class="flaticon-381-heart"></i>
							<span class="nav-text">Loan</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('logout')); ?>" aria-expanded="false">
							<i class="flaticon-381-exit"></i>
							<span class="nav-text">Logout</span>
						</a> 
                    </li>
                   
                </ul>
                    
			</div>
                   
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="d-flex align-items-center flex-wrap mb-3">
					
				
				</div>
				<div class="row">
                                        <?php if(Session::has('msg')): ?>   
                                            <div id="info" style="font-size:13px;" class="alert alert-success alert-dismissible fade show" role="alert">
                                                <strong><?php echo e(Session::get('msg')); ?></strong>
                                                <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </a>
                                            </div>
                                        <?php endif; ?>	
					<div class="col-xl-12">
						<div class="table-responsive table-hover fs-14">
            <?php if(count($transaction)> 0): ?>
              
                <table class="table display mb-4 dataTablesCard short-one  card-table text-black" id="example5">
                  <thead>
                    <tr>
                      <th>
                        
                      </th>
                      <th>Transaction ID</th>
                      <th>Date</th>
                      <th>Coin</th>
                      <th>Amount</th>
                      <th>Status</th>
                      
                    </tr>
                  </thead>
                  <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tbody>
                  
                    <tr>
                      <?php if($list->operation == 'Withdraw'): ?>
                      <td class="pr-0">
                        <span class="bg-success ic-icon">
                          <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M7.99954 10.4687L21.1821 23.6513C21.7435 24.2127 22.6537 24.2127 23.2151 23.6513C23.7765 23.0899 23.7765 22.1798 23.2151 21.6184L10.0325 8.43582L13.4612 8.4441L13.4612 8.44409C14.2551 8.44598 14.9002 7.80394 14.9021 7.01004C14.904 6.21593 14.2617 5.57098 13.468 5.56905L13.4668 6.06905L13.468 5.56905L6.55703 5.55234L6.54969 5.55232L6.54737 5.55239C5.75771 5.55578 5.11953 6.19662 5.11616 6.98358L5.1161 6.98585L5.11612 6.99333L5.13282 13.9043L5.13282 13.9043C5.13475 14.6982 5.77979 15.3403 6.57378 15.3384C7.36769 15.3365 8.00975 14.6914 8.00787 13.8975L8.00787 13.8975L7.99954 10.4687Z" fill="white" stroke="white"/>
                          </svg>
                        </span>
                      </td>
                      <?php else: ?>
                      <td class="pr-0">
                        <span class="bg-danger ic-icon">
                          <svg width="29" height="29" viewBox="0 0 29 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M20.7529 19.1563L7.5703 5.97367C7.00891 5.41228 6.09876 5.41228 5.53737 5.97367C4.97598 6.53505 4.97598 7.44521 5.53737 8.0066L18.72 21.1892L15.2913 21.1809L15.2912 21.1809C14.4973 21.179 13.8522 21.8211 13.8503 22.615C13.8484 23.4091 14.4907 24.054 15.2844 24.056L15.2856 23.556L15.2844 24.056L22.1954 24.0727L22.2028 24.0727L22.2051 24.0726C22.9947 24.0692 23.6329 23.4284 23.6363 22.6414L23.6363 22.6391L23.6363 22.6317L23.6196 15.7207L23.6196 15.7207C23.6177 14.9268 22.9727 14.2847 22.1787 14.2866C21.3847 14.2885 20.7427 14.9336 20.7446 15.7275L20.7446 15.7275L20.7529 19.1563Z" fill="white" stroke="white"/>
                          </svg>
                        </span>
									  	</td>
                      <?php endif; ?>
                      <td><?php echo e($list->transaction_id); ?></td>
                      <td><?php echo e($list->created_at); ?></td>
                      <td class="wspace-no">
                        
                        <span class="text-black"><?php echo e($list->transaction_type); ?></span>
                      </td>
                      <td>
                        <span class="text-black font-w600">$<?php echo e($list->amount); ?></span>
                      </td>
                      <?php if($list->transaction_status == 'Pending'): ?>
                      <td>
                        <a class="btn-link text-warning"><?php echo e($list->transaction_status); ?></a>
                      </td> 
                      <?php else: ?>
                        <td>
                        <a class="btn-link text-success"><?php echo e($list->transaction_status); ?></a>
                      </td> 
                      <?php endif; ?>
                    </tr>
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                  
                    
                  </tbody>
                </table>
               
            <?php else: ?>
                <p style="color: orangered; font-size: 25px; font-weight: bold; margin-top: 30px; text-align: center">Error! No Entry Found, Try Again  </p>
            <?php endif; ?>  
						</div>	
					</div>
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
         <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    

  <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>	
	<script src="<?php echo e(asset('vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
	
  <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
	<script src=" <?php echo e(asset('js/dezz.js')); ?>"></script>

	<script>
		(function($) {
			var table = $('#example5').DataTable({
				searching: false,
				paging:true,
				select: false,
				//info: false,         
				lengthChange:false 
				
			});
			$('#example5 tbody').on('click', 'tr', function () {
				var data = table.row( this ).data();
				
			});
		})(jQuery);
	</script>
</body>
</html>