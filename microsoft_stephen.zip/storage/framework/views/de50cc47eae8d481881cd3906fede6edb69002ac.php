<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content=" TradeMinePay is the best and modern platform to invest in cryptocurrencies!">
    <meta name="keywords" content="Crypto, investments, TradeMinePay">
    <meta name="author" content="TradeMinePay">

    <!-- Page Title -->
    <title>Trade Mine Pay</title>

    <!-- Favicon Icon -->
    <link href="<?php echo e(asset('images/favicon.ico')); ?>" rel="stylesheet">
    <!-- Icon fonts -->
    <link href="<?php echo e(asset('css/css-themify-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-flaticon.css')); ?>" rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('css/css-bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Plugins for this template -->
    <link href="<?php echo e(asset('css/css-font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-owl.theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-slick-theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-owl.transitions.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-jquery.fancybox.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-odometer-theme-default.css')); ?>" rel="stylesheet"><!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/css-style.css')); ?>" rel="stylesheet">

    </head>
    <body>

    <!-- start of page-wrapper -->
    <div class="page-wrapper">

        <!-- start of preloader -->
        <div class="preloader">
            <div class="sk-fading-circle">
                <div class="sk-circle1 sk-circle"></div>
                <div class="sk-circle2 sk-circle"></div>
                <div class="sk-circle3 sk-circle"></div>
                <div class="sk-circle4 sk-circle"></div>
                <div class="sk-circle5 sk-circle"></div>
                <div class="sk-circle6 sk-circle"></div>
                <div class="sk-circle7 sk-circle"></div>
                <div class="sk-circle8 sk-circle"></div>
                <div class="sk-circle9 sk-circle"></div>
                <div class="sk-circle10 sk-circle"></div>
                <div class="sk-circle11 sk-circle"></div>
                <div class="sk-circle12 sk-circle"></div>
            </div>
        </div>
        <!-- end of preloader -->

        <!-- Start of header -->
        <header id="header" class="site-header header-style-1"><nav class="navigation navbar navbar-default"><div class="container">
                    <div class="navbar-header">
                        <button type="button" class="open-btn">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="/">

                            <a class="navbar-brand" href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('images/image2-logo.png')); ?>" alt></a>
                         </a>

                    </div>
                    <div id="navbar" class="navbar-collapse collapse navbar-right navigation-holder">
                        <button class="close-navbar"><i class="ti-close"></i></button>
                        <ul class="nav navbar-nav">

                            <li><a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                            <li><a href="<?php echo e(route('terms')); ?>">Terms of Services</a></li>
                            <li><a href="<?php echo e(route('get-login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('get-register')); ?>">Register</a></li>

                        </ul></div><!-- end of nav-collapse -->




                </div><!-- end of container -->
            </nav>
            </header><!-- end of header --><!-- start of hero slider -->

        <section class="hero hero-slider-wrapper hero-style-1"><div class="hero-slider">

                <div class="slide">
                    <img src="images/slider-slide-1.jpg" alt class="slider-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col col-lg-10 col-lg-offset-1 col-md-8 col-md-offset-2 col-sm-12 slide-caption">
                                <div class="">
                                    <h1>Have you invested with the main</h1>
                                </div>
                                <div class="slide-subtitle">
                                    <h3>cryptocoins?</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="slide">
                    <img src="images/slider-slide-3.jpg" alt class="slider-bg">
                    <div class="container">
                        <div class="row">
                            <div class="col col-lg-6 col-sm-8 slide-caption">
                                <div class="slide-title">
                                    <h2>TradeMinePay <br><samp>Investment </samp>Client based</h2>
                                </div>
                                <div class="slide-subtitle">
                                    <p>We are working on multicurrency markets<br> with all benefits of Forex trading, <br>Profit Guaranteed</p>
                                </div>
                                <div class="btns">
                                    <a href="#" class="theme-btn-1">Invest Now</a>
                                </div>
                                <div class="slider-pic">
                                    <img src="images/slider/img-1.png" alt>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="slide">
                    <img src="images/slider-slide-2.jpg" alt class="slider-bg"><div class="container">
                        <div class="row">
                            <div class="col col-lg-6 col-sm-8 slide-caption">
                                <div class="slide-title">
                                    <h2>Invest In Bitcoin <br>easy steps for <span>trading</span></h2>
                                </div>

                                <div class="slide-subtitle">
                                    <p>Using our software and powerful servers, we make arbitrage <br>transactions within 1 exchange <br>almost in real-time</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <!-- end of hero slider -->
        <!-- TradingView Widget BEGIN -->
        <div class="tradingview-widget-container">
            <div class="tradingview-widget-container__widget"></div>
            <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com" rel="noopener" target="_blank"><span class="blue-text">Ticker Tape</span></a> by TradingView</div>
            <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
                {
                    "symbols": [
                    {
                        "proName": "FOREXCOM:SPXUSD",
                        "title": "S&P 500"
                    },
                    {
                        "proName": "FOREXCOM:NSXUSD",
                        "title": "Nasdaq 100"
                    },
                    {
                        "proName": "FX_IDC:EURUSD",
                        "title": "EUR/USD"
                    },
                    {
                        "proName": "BITSTAMP:BTCUSD",
                        "title": "BTC/USD"
                    },
                    {
                        "proName": "BITSTAMP:ETHUSD",
                        "title": "ETH/USD"
                    }
                ],
                        "colorTheme": "light",
                        "isTransparent": false,
                        "displayMode": "adaptive",
                        "locale": "en"
                }
            </script>
        </div>
        <!-- TradingView Widget END -->

        <section class="chart_section padding"><div class="container">
                <div class="section_heading sh_big align-center mb-60">
                    <h5>what you need to know</h5>
                    <h2>About us</h2>
                    <p>We believe there is great potential in today’s wide range of investment alternatives – and we recognize a corresponding increase in complexity as well.<br> That’s why TradeMinePay Services provides institutional-quality portfolio options for individual investors; we believe that individuals who invest in today’s dynamic marketplace deserve a disciplined, systematic strategy to manage risk and return.
                        <br>We use an institutional approach to building portfolios for individuals. <br>You gain access to carefully selected institutional money managers and a process designed to help you to more systematically diversify your holdings.
                        <br>We help you select a portfolio that closely matches both your financial objectives and your level of risk tolerance. <br>Then we systematically monitor risk and return on an ongoing basis.
                        Diversification does not ensure a profit or guarantee against a loss.</p>
                </div><!-- /Section Heading -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="chart_content">
                            <!-- TradingView Widget BEGIN -->
                            <div class="tradingview-widget-container">
                                <div id="tradingview_b9480"></div>
                                <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/AAPL/" rel="noopener" target="_blank"><span class="blue-text">Apple</span></a>, <a href="https://www.tradingview.com/symbols/GOOGL/" rel="noopener" target="_blank"><span class="blue-text">Google</span></a> <span class="blue-text">and</span> <a href="https://www.tradingview.com/symbols/MSFT/" rel="noopener" target="_blank"><span class="blue-text">Microsoft Quotes</span></a> by TradingView</div>
                                <script type="text/javascript" src="https://s3.tradingview.com/tv.js"></script>
                                <script type="text/javascript">
                                    new TradingView.MediumWidget(
                                            {
                                                "symbols": [
                                                    [
                                                        "Apple",
                                                        "AAPL"
                                                    ],
                                                    [
                                                        "Google",
                                                        "GOOGL"
                                                    ],
                                                    [
                                                        "Microsoft",
                                                        "MSFT"
                                                    ],
                                                    [
                                                        "BTC|12m"
                                                    ],
                                                    [
                                                        "BITBAY:BTCUSD|12m"
                                                    ]
                                                ],
                                                "chartOnly": false,
                                                "width": "1000",
                                                "height": "400",
                                                "locale": "en",
                                                "colorTheme": "light",
                                                "gridLineColor": "#F0F3FA",
                                                "trendLineColor": "#2196F3",
                                                "fontColor": "#787B86",
                                                "underLineColor": "#E3F2FD",
                                                "isTransparent": false,
                                                "autosize": false,
                                                "container_id": "tradingview_b9480"
                                            }
                                    );
                                </script>
                            </div>
                            <!-- TradingView Widget END -->
                            <div class="chart_feature chart_feature-bg ">
                                <i class="flaticon-bitcoin-8"></i>
                                <h4>Our Value</h4>
                                <p>What we value the most in TradeMinePay is our experience, professionalism and proven reliable strategies. We introduce innovations to the area of currency trading, fine-tuning and bringing them to perfection!</p>
                            </div>
                            <div class="chart_feature right-align">
                                <i class="flaticon-bitcoin-4"></i>
                                <h4>Why us</h4>
                                <p>We carefully selects only the most promising and high-yielding activities to add to our portfolio such as cryptocurrency trading. We diversify risks in the most competent manner and use global trends to our advantage.</p>
                            </div>
                        </div>
                    </div>
                </div>
        </section><!-- end of Chart section --><!-- start of Service Section --><section class="service_section padding"><div class="container">
                <div class="section_heading align-center mb-50">
                    <h5>Our services</h5>
                    <h2>Why Choose <span>TradeMinePay</span></h2>
                    <p>crpto platform features more than 60 different cryptocurrencies including the well-known bitcoin, Ethereum,</p>
                </div><!-- /Section Heading -->
                <div class="row">
                    <div class="col-md-4 col-sm-6">
                        <div class="service_content">
                            <h4><i class="flaticon-bitcoin-7"></i> <span>Safe &amp; Secure</span></h4>
                            <p>Our team consists of highly qualified specialists</p>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6">
                        <div class="service_content">
                            <h4><i class="flaticon-keyword"></i> <span>Payment</span></h4>
                            <p>Prompt payment on accrued profits.</p>
                        </div>
                    </div>

                    <div class="col-md-4 col-sm-6">
                        <div class="service_content">
                            <h4><i class="flaticon-bitcoin-7"></i> <span>Profit</span></h4>
                            <p>Gauranteed profit with minimized rist</p>
                        </div>
                    </div>

                </div>
            </div>
        </section><!-- end of Service Section --><!-- start of fun-fact section --><section class="fun-fact-section"><div class="container">
                <div class="row">
                    <div class="col-md-5 col-sm-12">
                        <div class="section_heading res-767-center">
                            <h2>Our investors with <span>TradeMinePay </span></h2>
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-12">
                        <div class="funfact-grids">
                            <div class="grid">
                                <div>
                                    <h3><span class="odometer" data-count="3000">48</span>+</h3>
                                </div>
                                <p>Members</p>
                            </div>
                            <div class="grid">
                                <div>
                                    <h3><span class="odometer" data-count="2750">9</span>+</h3>
                                </div>
                                <p>Investments</p>
                            </div>
                            <div class="grid">
                                <div>
                                    <h3><span class="odometer" data-count="2000">0</span>+</h3>
                                </div>
                                <p>Deposits</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section><!-- end of fun-fact section --><!-- start of currency section -->
        <section class="currency_section padding"><div class="container">
                <div class="section_heading align-center mb-60">
                    <h5>Our Price</h5>
                    <h2>OUR <span>PLANS</span></h2>
                    <p>Yes, there is! This is the so-called 'Fibonacci pivot strategy'.<br>This strategy is based on the famous Fibonacci sequence which is extremely popular among professional currency traders.</p>
                </div><!-- /Section Heading -->
                <div class="row">
                    <div class="row pricing_lists">
                        <div class="col-lg-4">
                            <div class="pricing_wrapper pricing_active">
                                <div class="pricing_top">
                                    <i class="flaticon-bitcoin-1"></i>
                                </div>
                                <div class="pricing_box">
                                    <div class="pricing_head">
                                        <h3>Plan C Investment</h3>
                                        <h2>Min: $1000.00</h2>
                                        <h4>Max: $2000.00</h2>
                                    </div>
                                    <h1 class="pricing_mid">Return: 6.00%</h1>
                                    <p>Duration: 34</p>
                                    <div class="pricing_footer">
                                        <a href="<?php echo e(route('get-login')); ?>"class="button_1">Invest Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="pricing_wrapper pricing_active">
                                <div class="pricing_top">
                                    <i class="flaticon-bitcoin-1"></i>
                                </div>
                                <div class="pricing_box">
                                    <div class="pricing_head">
                                        <h3>Plan B Investment</h3>
                                        <h2>Min: $500.00</h2>
                                        <h4>Max: $1000.00</h2>
                                    </div>
                                    <h1 class="pricing_mid">Return: 4.00%</h1>
                                    <p>Duration: 20</p>
                                    <div class="pricing_footer">
                                        <a href="<?php echo e(route('get-login')); ?>" class="button_1">Invest Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="pricing_wrapper pricing_active">
                                <div class="pricing_top">
                                    <i class="flaticon-bitcoin-1"></i>
                                </div>
                                <div class="pricing_box">
                                    <div class="pricing_head">
                                        <h3>Plan A Investment</h3>
                                        <h2>Min: $50.00</h2>
                                        <h4>Max: $500.00</h2>
                                    </div>
                                    <h1 class="pricing_mid">Return: 3.00%</h1>
                                    <p>Duration: 24</p>
                                    <div class="pricing_footer">
                                        <a href="<?php echo e(route('get-login')); ?>" class="button_1">Invest Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="pricing_wrapper pricing_active">
                                <div class="pricing_top">
                                    <i class="flaticon-bitcoin-1"></i>
                                </div>
                                <div class="pricing_box">
                                    <div class="pricing_head">
                                        <h3>Plan D Investment</h3>
                                        <h2>Min: $2000.00</h2>
                                        <h4>Max: $3000.00</h2>
                                    </div>
                                    <h1 class="pricing_mid">Return: 8.00%</h1>
                                    <p>Duration: 48</p>
                                    <div class="pricing_footer">
                                        <a href="<?php echo e(route('get-login')); ?>" class="button_1">Invest Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="pricing_wrapper pricing_active">
                                <div class="pricing_top">
                                    <i class="flaticon-bitcoin-1"></i>
                                </div>
                                <div class="pricing_box">
                                    <div class="pricing_head">
                                        <h3>VIP INVESTMENT</h3>
                                        <h2>Min: $4000.00</h2>
                                        <h4>Max: $5000.00</h2>
                                    </div>
                                    <h1 class="pricing_mid">Return: 15.00%</h1>
                                    <p>Duration: 50</p>
                                    <div class="pricing_footer">
                                        <a href="<?php echo e(route('get-login')); ?>" class="button_1">Invest Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="pricing_wrapper pricing_active">
                                <div class="pricing_top">
                                    <i class="flaticon-bitcoin-1"></i>
                                </div>
                                <div class="pricing_box">
                                    <div class="pricing_head">
                                        <h3>HOURLY VIP INVESTMENT</h3>
                                        <h2>Min: $5000.00</h2>
                                        <h4>Max: $6000.00</h2>
                                    </div>
                                    <h1 class="pricing_mid">Return: 5.00%</h1>
                                    <p>Duration: 5</p>
                                    <div class="pricing_footer">
                                        <a href="<?php echo e(route('get-login')); ?>" class="button_1">Invest Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="pricing_wrapper pricing_active">
                                <div class="pricing_top">
                                    <i class="flaticon-bitcoin-1"></i>
                                </div>
                                <div class="pricing_box">
                                    <div class="pricing_head">
                                        <h3>HOURLY VIP INVESTMENT</h3>
                                        <h2>Min: $6000.00</h2>
                                        <h4>Max: $10000.00</h2>
                                    </div>
                                    <h1 class="pricing_mid">Return: 6.00%</h1>
                                    <p>Duration: 5</p>
                                    <div class="pricing_footer">
                                        <a href="<?php echo e(route('get-login')); ?>" class="button_1">Invest Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="pricing_wrapper pricing_active">
                                <div class="pricing_top">
                                    <i class="flaticon-bitcoin-1"></i>
                                </div>
                                <div class="pricing_box">
                                    <div class="pricing_head">
                                        <h3>HOURLY VIP INVESTMENT</h3>
                                        <h2>Min: $10000.00</h2>
                                        <h4>Max: $1000000.00</h2>
                                    </div>
                                    <h1 class="pricing_mid">Return: 10.00%</h1>
                                    <p>Duration: 12</p>
                                    <div class="pricing_footer">
                                        <a href="<?php echo e(route('get-login')); ?>" class="button_1">Invest Now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </section>
        <!-- end of currency section -->

        <!-- start projects section -->
        <!-- end of projects section --><!-- start of process section --><section class="process_section bg-grey padding"><div class="container">
                <div class="section_heading align-center mb-20">
                    <h5>Frequently Asked Questions</h5>
                    <h2>FAQS</h2>
                    <p>Below our Frequently Asked Question<br>Faq</p>
                </div><!-- /Section Heading -->
                <div class="row">

                    <div class="row">
                        <div class="col col-xs-12">
                            <div class="faq-section">
                                <div class="panel-group faq-accordion theme-accordion-s1" id="accordion">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse-1" aria-expanded="true">IS TRADEMINEPAY A REGISTERED COMPANY??</a>
                                        </div>
                                        <div id="collapse-1" class="panel-collapse collapse in">
                                            <div class="panel-body">
                                                <p>Yes, it is a registered Company and supporting documents can be provided upon request.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse-2">Can I use multiple accounts?</a>
                                        </div>
                                        <div id="collapse-2" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                <p>No, it's forbidden. Only one account is allowed per person. Please don't violate this rule. If we find that one user has more than one account or more than one account with the same IP, all such accounts will be blocked and the entire funds will be frozen.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse-3">What is the minimum and maximum amount can be entrusted to the company?</a>
                                        </div>
                                        <div id="collapse-3" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                <p>the minimum amount is $20 and the maximum amount cannot exceed $150000.</p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse-4">What fee should I pay for withdrawal of funds?</a>
                                        </div>
                                        <div id="collapse-4" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                <p>The company does not charge a fee for withdrawals. You get exactly same amount that you have requested. However, you have to keep in mind that a fee might be charged by the payment system for conducting transactions.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        </section>
        <!-- end of process section -->
        <!-- start of team section -->
        <section class="team_section padding"><div class="container">
                <div class="section_heading align-center mb-60">

                    <h2>CUSTOMER <span>CARE</span></h2>
                </div><!-- /Section Heading -->
                <div class="row">

                    <div class="col-md-4 col-sm-6">
                        <div class="team_member">
                            <img src="images/team-team-3.jpg" alt="team"><div class="overlay">
                                <h4>Dill Waser</h4>
                                <p>Support Specialist</p>
                                <ul class="team_social"><li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                                    <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                </ul></div>
                        </div>
                    </div>
                </div>
            </div>
        </section><!-- end of team section -->





        <!-- start of callback section -->
        <section class="callback_section">
            <!-- start of footer section --><footer class="footer_section"><div class="container">
                    <div class="row widget_wrapper">
                        <div class="col-lg-3 col-sm-6 col-xs-12 sm-padding">
                           <p> TradeMinePay is the best and modern platform to invest in cryptocurrencies!</p>
                            <ul class="footer_social"><li class="fstitle">Follow Us <span>:</span></li>
                                <li><a href="https://facebook.com"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://twitter.com"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://telegram.com"><i class="fa fa-telegram"></i></a></li>
                            </ul></div>

                        <div class="col-lg-3 col-sm-6 col-xs-12 sm-padding">
                        <h4>Contact us</h4>
                            <ul class="widget_info"><li>
                                    <p class="text-color">Address :</p>
                                    <p>Krakowskie Prezedmiescie 20/21 00-071 Warshaw, Poland</p>
                                </li>
                                <li>
                                    <p class="text-color">Call Us :</p>
                                    <p>(481) 778-110-86</p>
                                </li>
                                <li>
                                    <p class="text-color">Email:</p>
                                    <p>info@trademinepay</p>
                                </li>
                            </ul></div>

                        <div class="col-lg-3 col-sm-6 col-xs-12 sm-padding">
                            <h4>Quick Links</h4>
                            <ul class="widget_info">
                                <li><a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                                <li><a href="<?php echo e(route('terms')); ?>">Terms of Services</a></li>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="row">
                        <div class="copyright">TradeMinePay © 2010 All Right Reserved</div>
                    </div>
                </div>
            </footer><!-- end of footer section--></div>
    <!-- end of page-wrapper -->



    <!-- All JavaScript files
    ================================================== -->
    <script src="<?php echo e(asset('js/js-jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/js-bootstrap.min.js')); ?>"></script>
      <!-- Plugins for this template -->
    <script src="<?php echo e(asset('js/js-jquery-plugin-collection.js')); ?>"></script>
    <!-- Custom script for this template -->
    <script src="<?php echo e(asset('js/js-script.js')); ?>"></script>
        <!--Start of Tawk.to Script-->
    <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
            var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
            s1.async=true;
            s1.src='https://embed.tawk.to/5edbdd159e5f69442290084c/default';
            s1.charset='UTF-8';
            s1.setAttribute('crossorigin','*');
            s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
    <!--End of Tawk.to Script-->
    </body></html>
