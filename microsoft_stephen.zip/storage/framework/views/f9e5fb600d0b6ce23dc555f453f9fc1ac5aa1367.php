
<!DOCTYPE html>
<html>
<head lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>StartUI - Premium Bootstrap 4 Admin Dashboard Template</title>

	<link href="img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144">
	<link href="img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114">
	<link href="img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72">
	<link href="img/favicon.57x57.png" rel="apple-touch-icon" type="image/png">
	<link href="img/favicon.png" rel="icon" type="image/png">
	<link href="img/favicon.ico" rel="shortcut icon">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap-sweetalert/sweetalert.css')); ?>">
 	<link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/sweet-alert-animations.min.css"')); ?>>
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/lobipanel/lobipanel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/lobipanel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/jqueryui/jquery-ui.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/separate/pages/widgets.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
</head>
<body class="with-side-menu control-panel control-panel-compact">

	<header class="site-header">
	    <div class="container-fluid">
	        <a href="#" class="site-logo">
	            <img class="hidden-md-down" src="<?php echo e(asset('img/logo-2.png')); ?>" alt="">
	            <img class="hidden-lg-down" src="<?php echo e(asset('img/logo-2-mob.png')); ?>" alt="">
	        </a>
	
	        <button id="show-hide-sidebar-toggle" class="show-hide-sidebar">
	            <span>toggle menu</span>
	        </button>
	
	        <button class="hamburger hamburger--htla">
	            <span>toggle menu</span>
	        </button>
	        <div class="site-header-content">
	            <div class="site-header-content-in">
	                <div class="site-header-shown">
	               
	                   
	
	                </div><!--.site-header-shown-->
	
	                <div class="mobile-menu-right-overlay"></div>
	                <div class="site-header-collapsed">
	                    <div class="site-header-collapsed-in">
	                        
	                       
	                    </div><!--.site-header-collapsed-in-->
	                </div><!--.site-header-collapsed-->
	            </div><!--site-header-content-in-->
	        </div><!--.site-header-content-->
	    </div><!--.container-fluid-->
	</header><!--.site-header-->

	<div class="mobile-menu-left-overlay"></div>
	<nav class="side-menu">
	    <ul class="side-menu-list">
	        <li class="grey with-sub">
	            <span>
	                <i class="font-icon font-icon-dashboard"></i>
	                <span class="lbl">Dashboard</span>
	            </span>
	            <ul>
	                <li><a href="index.html"><span class="lbl">Default</span><span class="label label-custom label-pill label-danger">new</span></a></li>
	              
	     
	            </ul>
	        </li>
	         <li class="blue with-sub">
	            <span>
	                <i class="font-icon font-icon-user"></i>
	                <span class="lbl">Profile</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Version 1</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">Version 2</span></a></li>
					<li><a href="profile-2.html"><span class="lbl">Version 2</span></a></li>
	            </ul>
	        </li>
			<li class="pink-red with-sub">
	            <span>
	                <i class="font-icon font-icon-case-2"></i>
	                <span class="lbl">Deposit</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Deposit</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
			<li class="blue with-sub">
	            <span>
	                <i class="font-icon font-icon-zigzag"></i>
	                <span class="lbl">Invest</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Invest</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
			<li class="pink-red with-sub">
	            <span>
	                <i class="font-icon font-icon-case-2"></i>
	                <span class="lbl">Withdraw</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Withdraw</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
	        
	        
	        <li class="blue-dirty">
	            <a href="tables.html">
	                <span class="glyphicon glyphicon-th"></span>
	                <span class="lbl">My Earnings</span>
	            </a>
	        </li>
	        <li class="magenta with-sub">
	            <a href="tables.html">
	                <span class="glyphicon glyphicon-list-alt"></span>
	                <span class="lbl">My Downlines</span>
	            </a>
	        </li>
	        <li class="green with-sub">
	             <a href="tables.html">
	                <i class="font-icon glyphicon glyphicon-log-out"></i>
	                <span class="lbl">Logout</span>
	            </a>
	            
	        </li>
	   
	        
	    </ul>
	
	</nav><!--.side-menu-->

<div class="page-content">
		<div class="container-fluid">
			
			<section class="card col-md-6 blue" style=" border: 1px solid #00a8ff">
				<div class="card-block">
					<div class="row m-t-lg">
						<div class="col-md-12">
                  <h5 style='color:#000e2e; font-family: Georgia, serif;'> Fund Wallet</h5> <br>
				 		   <?php if(Session::has('msg')): ?>   
                                <div id="info" style="font-family: roboto; font-size:15px; margin-bottom:30px;" class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong><?php echo e(Session::get('msg')); ?></strong>
                                    <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </a>
                                </div>
                             <?php endif; ?>
                    
                  <div style="margin-top: -20px;" class="alert alert-info alert-no-border alert-close alert-dismissible fade show" role="alert">                 
							    Enter an amount in USD you wish to deposit to your investment account. You'll be redirect to 
                                 make payment via your choice of Cryto available below.
				  </div>
                 <form action="#" class="form-horizontal" id="selectPlan" method="post">
					<div class="form-group" style="margin-top: 40px;">
						<div class="col-12 col-md-12">
						<label id="l5" for="" style="margin-bottom: -10px;">Enter Amount</label>
							<input type="hidden" name="tag" value="XRP">
							<input type="hidden" name="tab" value="5">
							<input id="usd" style="margin-top:20px; border: 1px solid #00a8ff;" required="" type="number" name="usd" placeholder=" Enter Amount in USD" class="form-control" 
							>
						</div>
					</div>
					<div class="col-md-12">
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-2" value="btc" checked>
						
						<label for="radio-2">Deposit Via Bitcoin </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-1" value="eth">
							<label for="radio-1">Deposit Via Ethereum </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-3" value="bch">
							<label for="radio-3">Deposit Via Bitcoin Cash </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-4" value="tron">
							<label for="radio-4">Deposit Via Tron </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-5" value="ltc">
							<label for="radio-5">Deposit Via Litecoin </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-6" value="usdt">
							<label for="radio-6">Deposit Via Tether(USDT) </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-7" value="doge">
							<label for="radio-7">Deposit Via Doge Coin </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-8" value="bnc">
							<label for="radio-8">Deposit Via Binance Coin </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-9" value="xrp">
							<label for="radio-9">Deposit Via Ripple </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-10" value="ada">
							<label for="radio-10">Deposit Via Cardano </label>
						</div>
						<input type="hidden" id="etherium_address" name="etherium_address" value="<?php echo e($det->etherium_address); ?>" />
						<input type="hidden" id="e_qr" value="qr/<?php echo e($det->etherium_qr); ?>" />
						<input type="hidden" id="tron_address" name="tron_address" value="<?php echo e($det->tron_address); ?>" />
						<input type="hidden" id="tr_qr" value="qr/<?php echo e($det->tron_qr); ?>" />
						<input type="hidden" id="xrp_address" name="xrp_address" value="<?php echo e($det->xrp_address); ?>" />
						<input type="hidden" id="x_qr" value="qr/<?php echo e($det->xrp_qr); ?>" />
						<input type="hidden" id="tether_address" name="tether_address" value="<?php echo e($det->tether_address); ?>" />
						<input type="hidden" id="t_qr" value="qr/<?php echo e($det->tether_qr); ?>" />
						<input type="hidden" id="bitcoinC_address" name="bitcoinC_address" value="<?php echo e($det->bitcoinC_address); ?>" />
						<input type="hidden" id="bch_qr" value="qr/<?php echo e($det->bitcoinC_qr); ?>" />
						<input type="hidden" id="binanceC_address" name="binanceC_address" value="<?php echo e($det->binanceC_address); ?>" />
						<input type="hidden" id="bnb_qr" value="qr/<?php echo e($det->binanceC_qr); ?>" />
						<input type="hidden" id="doge_address" name="doge_address" value="<?php echo e($det->doge_address); ?>" />
						<input type="hidden" id="d_qr" value="qr/<?php echo e($det->doge_qr); ?>" />
						<input type="hidden" id="cardano_address" name="cardano_address" value="<?php echo e($det->cardano_address); ?>" />
						<input type="hidden" id="c_qr" value="qr/<?php echo e($det->cardano_qr); ?>" />
						<input type="hidden" id="bitcoin_address" name="bitcoin_address" value="<?php echo e($det->bitcoin_address); ?>" />
						<input type="hidden" id="b_qr" value="qr/<?php echo e($det->bitcoin_qr); ?>" />
						<input type="hidden" id="litecoin_address" name="litecoin_address" value="<?php echo e($det->litecoin_address); ?>" />
						<input type="hidden" id="l_qr" value="qr/<?php echo e($det->litecoin_qr); ?>" />
					</div>

					
					<div>
                        <button id="payment-button" type="submit" class="btn btn-lg btn-primary btn-block btn-dep">
                        <i class="fa fa-check-circle fa-lg"></i>&nbsp;
                         <span id="dep">Deposit</span>
                    </div>
				 </form>
					</div><!--.row-->
				</div>
			</section>
		</div><!--.container-fluid-->
	</div><!--.page-content-->

	
	<?php echo $__env->make('user.modal.confirmDeposit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<script src="<?php echo e(asset('js/lib/jquery/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap-sweetalert/sweetalert.min.js')); ?>"></script>
    <script type="text/javascript">
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
                    
        });

		$('.btn-dep').on('click',function(e) {
            e.preventDefault();
			var type = $("input[type='radio'][name='crypto']:checked").val();
            var crypt;
			var val = parseInt($('#usd').val());
			if( val < 1 || $('#usd').val() == ''){
				swal({
					title: "Oops!",
					text: "Wrong value, Enter a valid Amount",
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonClass: "btn-default",
					cancelButtonClass: "btn-warning",
					confirmButtonText: "Warning",
					closeOnConfirm: false
				});
			}
			else
			{
				 if(type == 'btc')
				{
					  $('#address1').val($('#bitcoin_address').val());
					  $('#amount').val(val);
					  $('#types').val('BTC');
					  var data = $('#deposits').serialize();
					 $.post("<?php echo e(route('saveDeposit')); ?>", data, function(data) {
						console.log(data);
						document.getElementById('tag2').innerHTML = data;
					 });
					 crypt = $('#bitcoin_address').val();
					 var pict = $('#b_qr').val();
					 console.log(crypt + ' ' + pict);
					 var tag = document.getElementById('tag');
					 tag.innerHTML = 'FUND WITH BITCOIN';
					 $('#tag1').val('Transfer exactly $'+$('#usd').val()+' worth of BTC to '+crypt);
					  $('#link4').val(crypt);
					 

					$(".modal-body #pict").attr("src", pict);
					$('#form_confirmDeposit').modal('show');					
				}
				else if(type == 'eth')
				{
					$('#address1').val($('#etherium_address').val());
					  $('#amount').val(val);
					  $('#types').val('ETH');
					  var data = $('#deposits').serialize();
					 $.post("<?php echo e(route('saveDeposit')); ?>", data, function(data) {
						console.log(data);
						document.getElementById('tag2').innerHTML = data;
					 });
					 crypt = $('#etherium_address').val();
					 var pict = $('#e_qr').val();
					 console.log(crypt + ' ' + pict);
					 var tag = document.getElementById('tag');
					 tag.innerHTML = 'FUND WITH ETHERIUM';
					 $('#tag1').val('Transfer exactly $'+$('#usd').val()+' worth of ETH to '+crypt);
					  $('#link4').val(crypt);
					 
					$(".modal-body #pict").attr("src", pict);
					$('#form_confirmDeposit').modal('show');
				}
				else if(type == 'ltc')
				{
					$('#address1').val($('#litecoin_address').val());
					  $('#amount').val(val);
					  $('#types').val('LTC');
					  var data = $('#deposits').serialize();
					 $.post("<?php echo e(route('saveDeposit')); ?>", data, function(data) {
						console.log(data);
						document.getElementById('tag2').innerHTML = data;
					 });
					 crypt = $('#litecoin_address').val();
					 var pict = $('#l_qr').val();
					 console.log(crypt + ' ' + pict);
					 var tag = document.getElementById('tag');
					 tag.innerHTML = 'FUND WITH LITECOIN';
					 $('#tag1').val('Transfer exactly $'+$('#usd').val()+' worth of LTC to '+crypt);
					  $('#link4').val(crypt);
					 
					$(".modal-body #pict").attr("src", pict);
					$('#form_confirmDeposit').modal('show');
				}
				else if(type == 'usdt')
				{
					$('#address1').val($('#tether_address').val());
					  $('#amount').val(val);
					  $('#types').val('USDT');
					  var data = $('#deposits').serialize();
					 $.post("<?php echo e(route('saveDeposit')); ?>", data, function(data) {
						console.log(data);
						document.getElementById('tag2').innerHTML = data;
					 });
					 crypt = $('#tether_address').val();
					 var pict = $('#t_qr').val();
					 console.log(crypt + ' ' + pict);
					 var tag = document.getElementById('tag');
					 tag.innerHTML = 'FUND WITH TETHER';
					 $('#tag1').val('Transfer exactly $'+$('#usd').val()+' worth of USDT to '+crypt);
					  $('#link4').val(crypt);
					 
					$(".modal-body #pict").attr("src", pict);
					$('#form_confirmDeposit').modal('show');
				}
				else if(type == 'bnc')
				{
					$('#address1').val($('#tether_address').val());
					  $('#amount').val(val);
					  $('#types').val('USDT');
					  var data = $('#deposits').serialize();
					 $.post("<?php echo e(route('saveDeposit')); ?>", data, function(data) {
						console.log(data);
						document.getElementById('tag2').innerHTML = data;
					 });
					 crypt = $('#tether_address').val();
					 var pict = $('#t_qr').val();
					 console.log(crypt + ' ' + pict);
					 var tag = document.getElementById('tag');
					 tag.innerHTML = 'FUND WITH TETHER';
					 $('#tag1').val('Transfer exactly $'+$('#usd').val()+' worth of USDT to '+crypt);
					  $('#link4').val(crypt);
					 
					$(".modal-body #pict").attr("src", pict);
					$('#form_confirmDeposit').modal('show');
				}
				else if(type == 'bch')
				{
					$('#address1').val($('#bitcoinC_address').val());
					  $('#amount').val(val);
					  $('#types').val('BTC');
					  var data = $('#deposits').serialize();
					 $.post("<?php echo e(route('saveDeposit')); ?>", data, function(data) {
						console.log(data);
						document.getElementById('tag2').innerHTML = data;
					 });
					 crypt = $('#bitcoinC_address').val();
					 var pict = $('#bch_qr').val();
					 console.log(crypt + ' ' + pict);
					 var tag = document.getElementById('tag');
					 tag.innerHTML = 'FUND WITH BITCOIN CASH';
					 $('#tag1').val('Transfer exactly $'+$('#usd').val()+' worth of BCH to '+crypt);
					  $('#link4').val(crypt);
					 
					$(".modal-body #pict").attr("src", pict);
					$('#form_confirmDeposit').modal('show');
				}
				else if(type == 'doge')
				{
					$('#address1').val($('#doge_address').val());
					  $('#amount').val(val);
					  $('#types').val('DOGE');
					  var data = $('#deposits').serialize();
					 $.post("<?php echo e(route('saveDeposit')); ?>", data, function(data) {
						console.log(data);
						document.getElementById('tag2').innerHTML = data;
					 });
					 crypt = $('#doge_address').val();
					 var pict = $('#d_qr').val();
					 console.log(crypt + ' ' + pict);
					 var tag = document.getElementById('tag');
					 tag.innerHTML = 'FUND WITH DOGE';
					 $('#tag1').val('Transfer exactly $'+$('#usd').val()+' worth of DOGE to '+crypt);
					  $('#link4').val(crypt);
					 
					$(".modal-body #pict").attr("src", pict);
					$('#form_confirmDeposit').modal('show');
				}
				else if(type == 'ada')
				{
					$('#address1').val($('#cardano_address').val());
					  $('#amount').val(val);
					  $('#types').val('ADA');
					  var data = $('#deposits').serialize();
					 $.post("<?php echo e(route('saveDeposit')); ?>", data, function(data) {
						console.log(data);
						document.getElementById('tag2').innerHTML = data;
					 });
					 crypt = $('#cardano_address').val();
					 var pict = $('#c_qr').val();
					 console.log(crypt + ' ' + pict);
					 var tag = document.getElementById('tag');
					 tag.innerHTML = 'FUND WITH CARDANO';
					 $('#tag1').val('Transfer exactly $'+$('#usd').val()+' worth of ADA to '+crypt);
					  $('#link4').val(crypt);
					 
					$(".modal-body #pict").attr("src", pict);
					$('#form_confirmDeposit').modal('show');
				}
				else if(type == 'tron')
				{
					$('#address1').val($('#tron_address').val());
					  $('#amount').val(val);
					  $('#types').val('TRON');
					  var data = $('#deposits').serialize();
					 $.post("<?php echo e(route('saveDeposit')); ?>", data, function(data) {
						console.log(data);
						document.getElementById('tag2').innerHTML = data;
					 });
					 crypt = $('#tron_address').val();
					 var pict = $('#tr_qr').val();
					 console.log(crypt + ' ' + pict);
					 var tag = document.getElementById('tag');
					 tag.innerHTML = 'FUND WITH TRON';
					 $('#tag1').val('Transfer exactly $'+$('#usd').val()+' worth of TRON to '+crypt);
					  $('#link4').val(crypt);
					 
					$(".modal-body #pict").attr("src", pict);
					$('#form_confirmDeposit').modal('show');
				}
				else if(type == 'xrp')
				{
					$('#address1').val($('#xrp_address').val());
					  $('#amount').val(val);
					  $('#types').val('RIPPLE');
					  var data = $('#deposits').serialize();
					 $.post("<?php echo e(route('saveDeposit')); ?>", data, function(data) {
						console.log(data);
						document.getElementById('tag2').innerHTML = data;
					 });
					 crypt = $('#xrp_address').val();
					 var pict = $('#x_qr').val();
					 console.log(crypt + ' ' + pict);
					 var tag = document.getElementById('tag');
					 tag.innerHTML = 'FUND WITH RIPPLE';
					 $('#tag1').val('Transfer exactly $'+$('#usd').val()+' worth of XRP to '+crypt);
					  $('#link4').val(crypt);
					 
					$(".modal-body #pict").attr("src", pict);
					$('#form_confirmDeposit').modal('show');
				}
			}
           //$('#form_selectPlan').modal('show');
        });

		 $('.btn-done').on('click',function(e) { 
			    e.preventDefault();         
                window.location.href = '<?php echo e(route('finalizeDeposit')); ?>'  
        })
		
		function copyToClipboard3(){
            $('#link4').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l4').show()
           setTimeout(function(){
              $('#l4').hide();
            },3000)
        }


	</script>	
	<script src="<?php echo e(asset('js/lib/popper/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/tether/tether.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

	<script type="text/javascript" src="<?php echo e(asset('js/lib/jqueryui/jquery-ui.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/lib/lobipanel/lobipanel.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/lib/match-height/jquery.matchHeight.min.js')); ?>"></script>
	
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>