
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Coin Finance Pro -- Wallets </title>
    <!-- Favicon icon -->
     <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('img/new/android-icon-48x48.png')); ?>">
	<link href="<?php echo e(asset('vendor/jqvmap/css/jqvmap.min.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/chartist/css/chartist.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
    <link href="<?php echo e(asset('vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style11.css')); ?>" rel="stylesheet">
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
         <div class="nav-header">
            <a href="<?php echo e(route('dashboard1')); ?>" class="brand-logo"  style="margin-right: 40%;">
               <img src="<?php echo e(asset('img/new/log1.png')); ?>" alt="" style="margin-left: 40px;">
            </a>
            <div class="nav-control" style="margin-left: 150px;">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--*****************************
            Nav header end
        ***********************************-->
		
		
		
		<!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            <div class="dashboard_bar">
                               
                            </div>
                        </div>

                        <ul class="navbar-nav header-right">
							
							
							
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <img src="<?php echo e(asset('avatar/'.Auth::user()->avatar)); ?>" width="20" alt=""/>
									<div class="header-info">
										<span><?php echo e(Auth::user()->name); ?></span>
									</div>
                                </a>
                                
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('dashboard1')); ?>" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        

                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('manageWallet')); ?>">
						<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Profile</span>
						</a>
                       
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('investment')); ?>">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">Packages</span>
						</a>
                        
                    </li>
                      <li><a class="has-arrow ai-icon" href="<?php echo e(route('transactionAll')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Transactions</span>
						</a> 
                    </li>
                   
                     <li><a class="has-arrow ai-icon" href="<?php echo e(route('nft')); ?>" aria-expanded="false">
							<i class="flaticon-381-layer-1"></i>
							<span class="nav-text">Market Place</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('loan')); ?>" aria-expanded="false">
							<i class="flaticon-381-heart"></i>
							<span class="nav-text">Loan</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('logout')); ?>" aria-expanded="false">
							<i class="flaticon-381-exit"></i>
							<span class="nav-text">Logout</span>
						</a> 
                    </li>
                   
                </ul>
                    
			</div>
                   
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
         <div class="content-body" style='background:linear-gradient(rgba(0,0,0,0.2),rgba(0,0,0,0.4)), url("<?php echo e(asset('img/new/logo5.png')); ?>");
	'>
            <!-- row -->
          <div class="container-fluid">
                <div class="row">
                    <?php if(Session::has('msg')): ?>   
                        <div id="info" style="font-size:13px; margin-left:20px; margin-right:20px; margin-bottom:20px;" class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong style="padding: 20px;"><?php echo e(Session::get('msg')); ?></strong>
                                <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </a>
                        </div>
                    <?php endif; ?>	
                </div>
				<div class="row">
                  
					<div class="col-xl-5 col-xxl-6">
						<div class="card">
							<div class="card-header pb-0 border-0">
								<h5 class="mb-0 text-black fs-20">My Profile</h5>
								
							</div>
							<div class="card-body">
								<div class="text-center">
									<img src="<?php echo e(asset('avatar/'.Auth::user()->avatar)); ?>" alt= "" class="rounded ds-img-profile">
									<h4 class="fs-26 mt-sm-3 mt-2 mb-sm-3 mb-0 font-w600 text-black"><?php echo e(Auth::user()->name); ?></h4>	
									<p class="mb-0 text-black ">Join on  <?php echo e(Auth::user()->created_at->format('Y-m-d')); ?></p>
									<a href="<?php echo e(route('profile')); ?>" class="btn btn-rounded btn-outline-primary mt-sm-4 mt-2"><i class="fa fa-pencil scale5 mr-3"></i>Edit prorfile</a>
                                    <a href="<?php echo e(route('kyc')); ?>" class="btn btn-rounded btn-outline-primary mt-sm-4 mt-2"><i class="fa fa-pencil scale5 mr-3"></i>Upload Kyc</a>
                                     <a href="<?php echo e(route('password')); ?>" class="btn btn-rounded btn-outline-primary mt-sm-4 mt-2"><i class="fa fa-pencil scale5 mr-3"></i>Change Password</a>
                                </div>
								
							</div>
						</div>
					</div>
					
					
					
				</div>
            </div>
        </div>
		             
                </div>


        <!--**********************************
            Content body end
        ***********************************-->
				

        <!--**********************************
            Footer start
        ***********************************-->
       
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->


	</div>
  

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
	

    <script src="<?php echo e(asset('j/jquery-3.2.1.min.js')); ?>"></script>	
	<script type="text/javascript">
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });

			  //=============invoke select plan Modal
			$('.btn-edit').on('click',function(e) {
				e.preventDefault();
				$('#wallet_name1').val($(this).data('name'));
				$('#wallet_id1').val($(this).data('id'));
				
			$('#editModal').modal('show');
			});

			
                    
        });
	</script>		
    <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	
	<!-- Chart piety plugin files -->
    <script src="<?php echo e(asset('vendor/peity/jquery.peity.min.js')); ?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo e(asset('vendor/apexchart/apexchart.js')); ?>"></script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo e(asset('js/dashboard/my-wallet.js')); ?>"></script>
	
	<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
	<script src=" <?php echo e(asset('js/dezz.js')); ?>"></script>
	
    
	<script>
		jQuery('.cards-slider').owlCarousel({
			loop:false,
			margin:30,
			nav:true,
            rtl:(getUrlParams('dir') == 'rtl')?true:false,
			autoWidth:true,
            //rtl:true,
			dots: false,
			navText: ['', ''],
		});	
	</script>
</body>
</html>