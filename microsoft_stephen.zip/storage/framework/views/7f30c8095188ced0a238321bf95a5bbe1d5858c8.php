<div id="form_editPlan" class="modal fade"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modify Package</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
           <div class="modal-body">
                <form action="#" class="form-horizontal" id="editPlan" method="POST">
                    <input type="hidden"  name="plan_id" id="plan_id" >
                    <div class="form-group">
                        <label class="control-label col-md-4" >Title</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="plan_name" id="plan_name">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Min Deposit($)</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="min_deposit" id="min_deposit">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Max Deposit($)</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="max_deposit" id="max_deposit">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Profit %</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="profit" id="profit">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-secondary " data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-update">Save</button>
                    </div>
                </form>
            </div>


        </div>
    </div>
</div>