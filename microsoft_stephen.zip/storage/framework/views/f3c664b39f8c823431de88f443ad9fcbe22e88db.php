
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>




<link href="https://fonts.googleapis.com/css2?family=Thasadith&amp;display=swap" rel="stylesheet">

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />




	<!-- META -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />    
    <meta name="description" content="" />
    
    <!-- FAVICONS ICON -->
    <link href="<?php echo e(asset('img/logo/logo6.png')); ?>" rel="icon">
    
    <!-- PAGE TITLE HERE -->
    <title>Home</title>
    
    <!-- MOBILE SPECIFIC -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
  <!-- PAYOUT PROGRESS BAR CSS -->
 

<link rel="stylesheet" href="payout/main.html">


    
    <!-- [if lt IE 9]>
        <script src="js/html5shiv.min.js"></script>
        <script src="js/respond.min.js"></script>
	<![endif] -->
    
    
    
    <!-- BOOTSTRAP STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- FONTAWESOME STYLE SHEET -->
    <link rel="stylesheet" href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>">
    <!-- FLATICON STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/flaticon.min.css">
    <!-- ANIMATE STYLE SHEET --> 
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <!-- OWL CAROUSEL STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <!-- BOOTSTRAP SELECT BOX STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <!-- MAGNIFIC POPUP STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.min.css">
    <!-- LOADER STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/loader.min.css">    
    <!-- MAIN STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- THEME COLOR CHANGE STYLE SHEET -->
    <link rel="stylesheet" class="skin" type="text/css" href="css/skin/skin-1.css">
    <!-- CUSTOM  STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/custom.css">
   

    
    <!-- REVOLUTION SLIDER CSS -->
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/settings.css">
    <!-- REVOLUTION NAVIGATION STYLE -->
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/navigation.css">
    
    <!-- GOOGLE FONTS -->
	
 
<style type="text/css">
#apDiv1 {
	position:absolute;
	left:1px;
	top:3155px;
	width:445px;
	height:294px;
	z-index:100000;
	font-size: 0.9em;
	color: #FFF;
	background-color: #903;
	text-align: center;
	display:none;
}


.text {

   font-family: 'Thasadith', sans-serif;
	font-size:19px;
	color:#FFFFFF;
	padding:0;
	margin:0; 
	overflow-x: hidden;
} 





.title {

   font-family:sans-serif;
	font-size:40px;
	font-weight:bolder;
 
	color:#000;

}






 


a {
  color: #ec5598;
  outline: 0 none;
  text-decoration:none;
}

a:hover,
a:focus {
  text-decoration:none;
  outline: 0 none;
}

a:active,
a:hover,
a:focus{
  color: #333333;
}

p a {
	color:#333333;
}


.ml9 {
  position: relative;
  font-weight: 200;
  font-size: 4em;
}

.ml9 .text-wrapper {
  position: relative;
  display: inline-block;
  padding-top: 0.2em;
  padding-right: 0.05em;
  padding-bottom: 0.1em;
  overflow: hidden;
}

.ml9 .letter {
  transform-origin: 50% 100%;
  display: inline-block;
  line-height: 1em;
}



</style>
</head>

<body style="background-color:#060f47;">
 
 

<header class="site-header header-style-3 topbar-transparent" style="background-color:#060f47;">
        
            
            
            <div class="sticky-header main-bar-wraper" style="background-color:#060f47; color:white;">
                <div class="main-bar">
                    <div class="container">
                         <a href="./">
                            <div style="background-image:url(img/new/log6.png); width:200px; background-position:left; background-size:contain; background-repeat:no-repeat" class="logo-header mostion">
                            </div>   
                        </a>
                            
                            <!-- NAV Toggle Button -->
                            <button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            
                           
                            <!-- ETRA Nav -->
                            
                             
                            <!-- SITE Search -->
                            
                            <!-- MAIN Vav -->
                            <div class="header-nav navbar-collapse collapse ">
                            <ul class=" nav navbar-nav">
                                <li>
                                    <a href="./">TRADING<i></i></a>
                                       
                                </li>
                                
                                
                                 <li>
                                    <a href="./market">MARKET<i></i></a>
                                       
                                </li>
                              
                                
                                <li>
                                    <a href="./login">LOGIN<i></i></a>
                                       
                                </li>
                                
                                  <li>
                                    <a href="./register">REGISTER<i></i></a>
                                       
                                </li>
                            
                               
                              <li>
                                    <a href="./why">WHY US<i></i></a>
                                       
                              </li>
                              <li>
                                    <a href="./about">ABOUT US<i></i></a>
                                       
                              </li>
                              
                             <li>
                                    <a href="./contact">SUPPORT<i></i></a>
                                       
                              </li>
                              <li>
                                    <a href="./f">FAQ<i></i></a>
                                       
                              </li>
                                
                                <li>
                                  
                                </li>
                            </ul>
                        </div>
        
                    </div>
                </div>
            </div>
            
        </header>	
       	
       
        <div class="page-content">
        
        
        <div style=" height:300px; width:100%; border:solid 10px #000000; background-color:#000; overflow:hidden">
        
        
        
        
        
        <div  class="main-slider style-two default-banner">
           		<div class="tp-banner-container">
                    <div class="tp-banner" >
                        <!-- START REVOLUTION SLIDER 5.4.1 -->
                        <div id="rev_slider_1014_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="typewriter-effect" data-source="gallery">
                           <div id="rev_slider_1014_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.1">
                                <ul>
                                    <!-- SLIDE 1 -->	
                                    
                                    
                                    <!-- SLIDE 2 -->
                                    <li data-index="rs-1001" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="images/main-slider/slider2/slide1.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                    <!-- MAIN IMAGE -->
                                    <img src="images/main-slider/slider2/slide1b.jpg"  alt=""  data-bgposition="center bottom" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina/>
                                    <!-- LAYERS -->
                                    
                                    <!-- LAYER NR. 1 [ for overlay ] -->
                                    <div class="tp-caption tp-shape tp-shapewrapper " 
                                    id="slide-101-layer-1" 
                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                    data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 
                                    data-width="full"
                                    data-height="full"
                                    data-whitespace="nowrap"
                                    data-type="shape" 
                                    data-basealign="slide" 
                                    data-responsive_offset="off" 
                                    data-responsive="off"
                                    data-frames='[
                                    {"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                    style="z-index: 12;background-color:rgba(0, 0, 0, 0.3);border-color:rgba(0, 0, 0, 0);border-width:0px;"> 
                                    </div>
                                    
                                    <!-- LAYER NR. 2 [ for title ] -->
                                    <div class="tp-caption   tp-resizeme" 
                                    id="slide-101-layer-2" 
                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
                                    data-y="['top','top','top','top']" data-voffset="['308','308','308','308']"  
                                    data-fontsize="['60','60','60','60']"
                                    data-lineheight="['110','110','110','110']"
                                    data-width="['6','6','6','6']"
                                    data-height="['110,'110','110','110']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                
                                    data-type="text" 
                                    data-responsive_offset="on" 
                                    data-frames='[
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                
                                    style="z-index: 13; 
                                    white-space: normal;                                                                    
                                    ">
                                    
                                    <div class="bg-primary">&nbsp;</div>
                                    
                                    </div>
                                                                    
                                    <!-- LAYER NR. 3 [ for title ] -->
                                    <div class="tp-caption   tp-resizeme" 
                                    id="slide-101-layer-3" 
                                    data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" 
                                    data-y="['top','top','top','top']" data-voffset="['300','300','300','300']"  
                                    data-fontsize="['55','55','55','45']"
                                    data-lineheight="['60','60','60','65']"
                                    data-width="['700','700','700','700']"
                                    data-height="['none','none','none','none']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                
                                    data-type="text" 
                                    data-responsive_offset="on" 
                                    data-frames='[
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                
                                    style="z-index: 13; 
                                    white-space: normal; 
                                    font-weight: 700;
                                    color: rgb(75, 57, 65);
                                    border-width:0px;">
                                    
                                    <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase; ">
                                    	<span class="text-white" style="padding-right:10px;">LONDON BEST</span><span class="text-primary"></span>
                                    </div>
                                    
                                    </div>
                                    
                                    <!-- LAYER NR. 4 [ for title ] -->
                                    <div class="tp-caption   tp-resizeme" 
                                    id="slide-101-layer-4" 
                                    data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" 
                                    data-y="['top','top','top','top']" data-voffset="['360','360','360','360']"  
                                    data-fontsize="['53','53','53','45']"
                                    data-lineheight="['70','70','70','70']"
                                    data-width="['700','700','700','700']"
                                    data-height="['none','none','none','none']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                
                                    data-type="text" 
                                    data-responsive_offset="on" 
                                    data-frames='[
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1000,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                
                                    style="z-index: 13; 
                                    white-space: normal; 
                                    font-weight: 700;
                                    border-width:0px;">
                                    <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase ;">
                                   		<span class="text-primary" style="padding-right:10px; text-shadow:1px 1px 4px #FF9900;color:#CCCCCC">TRADING CENTER </span><span class="text-white"></span>
                                    </div>
                                    
                                    </div>
                                
                                    <!-- LAYER NR. 5 [ for paragraph] -->
                                    <div class="tp-caption  tp-resizeme" 
                                    id="slide-101-layer-5" 
                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 
                                    data-y="['top','top','top','top']" data-voffset="['440','440','440','440']"  
                                    data-fontsize="['16','16','16','30']"
                                    data-lineheight="['30','30','30','40']"
                                    data-width="['600','600','600','600']"
                                    data-height="['none','none','none','none']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                
                                    data-type="text" 
                                    data-responsive_offset="on"
                                    data-frames='[
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1500,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                
                                    style="z-index: 13; 
                                    font-weight: 500; 
                                    color:#fff;
                                    border-width:0px;">
                                   </div>
                                
                                    <!-- LAYER NR. 6 [ for see all service botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-6"						
                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 
                                    data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  
                                    data-lineheight="['none','none','none','none']"
                                    data-width="['300','300','300','300']"
                                    data-height="['none','none','none','none']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                    
                                    data-type="text" 
                                    data-responsive_offset="on"
                                    data-frames='[ 
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                    style="z-index:13; text-transform:uppercase;">
                                          
                                    </div>
                                    
                                    <!-- LAYER NR. 7 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-7"						
                                    data-x="['left','left','left','left']" data-hoffset="['220','220','220','320']" 
                                    data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  
                                    data-lineheight="['none','none','none','none']"
                                    data-width="['300','300','300','300']"
                                    data-height="['none','none','none','none']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                    
                                    data-type="text" 
                                    data-responsive_offset="on"
                                    data-frames='[ 
                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                    style="z-index:13;
                                    text-transform:uppercase;
                                    font-weight:500;
                                    ">
                                    
                                     
                                   
                                    </div>
                                    
                                    <!-- LAYER NR. 8 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-8"						
                                    data-x="['right','right','right','right']" data-hoffset="['-100','-100','-100','-100']" 
                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-650','-650','-650','-650']"
                                    
                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},
                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
                                    
                                    style="z-index: 13;">
                                    <img src="images/main-slider/slider2/earth2.png" alt="" class="spin-city">
                                    </div>
                                    
                                     <!-- LAYER NR. 9 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-9"						
                                    data-x="['right','right','right','right']" data-hoffset="['-300','-100','-100','-100']" 
                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-200','-200','-200','-200']"
                                    
                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},
                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
                                    
                                    style="z-index: 13;">
                                    <img src="images/main-slider/slider2/earth2-shadow.png" alt="">
                                    </div>  
                                                                     
                                    <!-- LAYER NR. 10 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-10"
                                    
                                    data-x="['right','right','right','right']" data-hoffset="['200','200','200','200']" 
                                    data-y="['top','bottom','bottom','bottom']" data-voffset="['150','150','150','150']"
                                    
                                    data-height="none"
                                    data-whitespace="nowrap"
                         
                                    data-type="image" 
                                    data-responsive_offset="on" 
                        
                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},
                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                                                  
                                    style="z-index: 16;">
                                    <img src="images/main-slider/slider2/rocketxx.html" alt="" class="floating">
                                    </div> 
                                                                         
                                    <!-- LAYER NR. 11 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-11"
                                    
                                    data-x="['right','right','right','right']" data-hoffset="['278','278','278','278']" 
                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['180','100','100','100']"
                                    
                                    data-height="none"
                                    data-whitespace="nowrap"
                         
                                    data-type="image" 
                                    data-responsive_offset="on" 
                        
                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":4000,"ease":"Power3.easeOut"},
                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                                                  
                                    style="z-index: 15;">
                                    <img src="images/main-slider/slider2/firexx.html" alt="" class="floating">
                                    </div>
                                    
                                    <!-- LAYER NR. 12 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-101-layer-12"
                                    
                                    data-x="['right','right','right','right']" data-hoffset="['100','100','100','100']" 
                                    data-y="['top','bottom','bottom','bottom']" data-voffset="['0','0','0','0']"
                                    data-lineheight="['none','none','none','none']"
                                    data-width="['500','500','500','500']"
                                    data-height="['none','none','none','none']"                                    
                                    data-whitespace="nowrap"
                                    data-type="image" 
                                    data-responsive_offset="on" 
                        
                                     data-frames='[ 
                                    {"from":"y:0px(R);opacity:0;","speed":2000,"to":"o:1;","delay":4000,"ease":"Power4.easeOut"},
                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}
                                    ]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    
                                                                  
                                    style="z-index: 12;">
                                    <div class="coin-slide bg-full-width bg-repeat-y coin-slide-rotate" style="background-image:url(images/main-slider/slider2/coin-sky.png);height:100vh;">
                                    <div class="coin-slide bg-full-width bg-repeat-y coin-slide-rotate" style="background-image:url(images/main-slider/slider2/coin-sky2.png);height:70vh;"></div>
                                    
                                    </div>
                                    </div>    
                                                                                                   
                                  </li>

                                    <!-- SLIDE  3 -->
                                    
                                     <!-- SLIDE  3  li tag goes here -->                               
                                </ul>
                                	
                           </div>
                        </div>
                        <!-- END REVOLUTION SLIDER -->
                    </div>
            	</div>
          </div>
        
        
        </div>
        
            <!-- SLIDER START -->
          

            <!-- MARQUEE SCROLL -->           
             
            <!-- MARQUEE SCROLL SECTION  END -->    
                      
               
     <div class="page-wraper" style="background-color:#060f47; color:white;">
	                           
            <div style="background-color:#060f47" class="bg-gray-light p-tb05">
                <div class="container">
                    <ul class="wt-breadcrumb breadcrumb-style-2">
                        <div class="col-sm-9"> <h3 style="color:#FFFFFF; font-weight:100">NEW TO <strong style="color:goldenrod">CoinFinancePro.com</strong> ?</h3></div>
                           <div class="col-sm-3"><center><a style="background-color:#0C0;color:#FFF;font-weight:bolder; border-radius:8px" href="account/register" class="m-b15 site-button m-t15"  >REGISTER HERE&nbsp;&nbsp;&nbsp;<i class="fa fa-play"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center> </div>
                    </ul>
                </div>
            </div>
            <!-- BREADCRUMB ROW END -->
             
      
                              
            <!-- BREADCRUMB ROW -->                            
      
            <!-- ABOUT COMPANY SECTION START -->
            <div style="background-color:#FF700; margin-top:40px; padding-bottom:40px; color:#FFF" class="section-full p-t40">
                <div class="container">
                    <div class="row">
                    
                      <div style="margin-bottom:40px" class="col-md-6 col-sm-6">
                      <img src="images/light.gif" width="500" height="288" alt="tradding" /></div>
                    
                    
                    
                        <div class="col-md-6 col-sm-6" >
                            <div class="section-head text-left"  data-animate="fadeInDown" data-duration="1.0s" data-delay="0.1s" data-offset="100">
                             
                                <h1 class="title" style="color:#FFF">Trade with Global Market Leaders in Crypto Currency </h1>
                                
                                <h3 style="color:#CCCCCC">Explore the Benefits</h3>
                               
                              <ul  style="color:#FFF; font-weight:bold" class="list-arrow-circle green">
                               
                                
                                    <li class="text">
                                
                               Trade the world’s currency markets along with the most popular share, index and commodity CFDs 
                            
                                </li>
                                 <hr />
                                    <li class="text">
                               Our suite of powerful trading platforms was designed to meet the demanding needs of currency traders 
                               
                                </li>
                                 <hr />
                                
                               <li class="text">
                                
                               Discover your trading personality and make profits straight to your bitcoin wallet
                               
                                </li>
                                 <hr />

                                  <h3 class="title" style="color:#FFF">Special Features</h3>
                                
                                   <h3 style="color:#CCCCCC">We are RLS capable</h3>
                                 <li class="text">
                                
                                   Representative Appointments  based on merit                               
                                </li>
                                 <hr />
                                 <li class="text">
                                
                                   Leaderboard for every 5 - 10 referrals & a 35% commission is served to the leader of the team                             
                                </li>
                                 <hr />
                                  <li class="text">
                                
                                   Smart contract are initiated for business and company plan investors to boost their ROI for a period of time                            
                                </li>
                                 <hr />
                                 <span style="float:left">
                                 <a style="background-color:#093; color:#FFF; font-weight:bolder; border-radius:8px; font-family: 'Thasadith', sans-serif;font-size:19px;color:#FFFFFF;" href="./register" class="m-b15 site-button m-r15" ><strong>OPEN ACCOUNT</strong></a>
                                 
                                 </span>
                                   <span style="float:left">
                                 <a style="background-color:# F60; color:#FFF; font-weight:bolder; border-radius:8px; font-family: 'Thasadith', sans-serif;font-size:19px;color:#FFFFFF;" href="./register" class="m-b15 site-button m-r15" ><strong>TRY A DEMO ACCOUNT</strong></a>
                                 
                                 </span>
                                
                                 
                                </ul>
                                
                              
                            
                            </div>
                        </div>
                      
                    </div>
                </div>
                
                
                
                
                
            </div> 
            
            
            
       <div style="padding-top:0px; height:50px; overflow:hidden; background-color:#060f47; padding-bottom:50px;">
            
            <div class="container">
          <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>

  <script type="text/javascript" src="../s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
  {
  "symbols": [
    {
      "proName": "FOREXCOM:SPXUSD",
      "title": "S&P 500"
    },
    {
      "proName": "FOREXCOM:NSXUSD",
      "title": "Nasdaq 100"
    },
    {
      "proName": "FX_IDC:EURUSD",
      "title": "EUR/USD"
    },
    {
      "proName": "BITSTAMP:BTCUSD",
      "title": "BTC/USD"
    },
    {
      "proName": "BITSTAMP:ETHUSD",
      "title": "ETH/USD"
    }
  ],
  "showSymbolLogo": true,
  "colorTheme": "light",
  "isTransparent": true,
  "displayMode": "compact",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
            </div>
          </div>       
            
            
            
            
            
      
      
      
      
      
      
      
      <div>
                <div class="container">
                   
                    <!-- IMAGE CAROUSEL START -->
                    <div class="section-content">
                        <div class="owl-carousel home-logo-carousel">
                         <!-- COLUMNS 11 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                   
                                        <a href="#"><img src="images/what%20we%20do/crypto.jpg" alt=""></a>
                                   
                                </div>
                            </div>
                            
                             <div class="item">
                                <div class="ow-client-logo">
                                   
                                        <a href="#"><img src="images/what%20we%20do/1.jpg" alt=""></a>
                                   
                                </div>
                            </div>
                            
                            
                             <div class="item">
                                <div class="ow-client-logo">
                                   
                                        <a href="#"><img src="images/what%20we%20do/2.jpg" alt=""></a>
                                   
                                </div>
                            </div>
  
                             <div class="item">
                                <div class="ow-client-logo">
                                   
                                        <a href="#"><img src="images/what%20we%20do/4.jpg" alt=""></a>
                                   
                                </div>
                            </div>                            
                            
                            
                             <div class="item">
                                <div class="ow-client-logo">
                                   
                                        <a href="#"><img src="images/what%20we%20do/3.jpg" alt=""></a>
                                   
                                </div>
                            </div>
                            
                            <!-- COLUMNS 12 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                 
                                        <a href="#"><img src="images/what%20we%20do/binary_trading.jpg" alt=""></a>
                                   
                                </div>
                            </div>                        
                        
                        </div>
                    </div>
                    <!-- IMAGE CAROUSEL START -->
                </div>
            
          </div>
      
      
      <div class="section-head text-center">
                    <p></p> <p></p>
                    <h2 style="font-weight:lighter;color:white; font-family:sans-serif; font-size:40px">How to start trading with us</h2>	
                     
                    <!-- TITLE END-->
                    <div style="background-image:url(images/house.png); background-position:top; background-repeat:repeat-y" class="section-content no-col-gap">
                        <div class="row">
                               
                            <!-- COLUMNS 1 -->
                            <div style=" padding:30px; margin-bottom:30px" class="col-md-4 col-sm-4 step-number-block">
                                <div style="width:100%; height:205px; background-image:url(images/icon/registration.png); background-position:center; background-repeat:no-repeat"></div>
                               <center> <h4 style="color:#FFF">Register and Login to your dashboard</h4>
                              <div style=" color:#FFF; text-align:left; padding:10px;color:#666666"></div></center>
                            </div>
                            <!-- COLUMNS 2 -->
                        <div style=" padding:30px; margin-bottom:30px" class="col-md-4 col-sm-4 step-number-block">
                                <div style="width:100%; height:205px; background-image:url(images/icon/wallet.png); background-position:center; background-repeat:no-repeat"></div>
                               <center> <h4 style="color:#FFF">At your dashboard, Click on make new investment and select your desired choice of plan from the plans dropdown</h4>
                              <div style=" color:#FFF; text-align:left; padding:10px;color:#666666">

</div></center>
                          </div>
                            <!-- COLUMNS 3 -->
                                <div style=" padding:30px; margin-bottom:30px" class="col-md-4 col-sm-4 step-number-block">
                                <div style="width:100%; height:205px; background-image:url(images/icon/dashboard.png); background-position:center; background-repeat:no-repeat"></div>
                               <center> <h4 style="color:#FFF">Make the exact deposit you pledged into the company auto generated BTC wallet and blockchain technology will automatically confirm you if it detects any payment</h4>
                   <div style=" color:#FFF; text-align:left; padding:10px;color:#666666">.</div></center>
                            </div>
                             <div class="col-md-2 col-sm-2 step-number-block"></div>
                        </div>
                        <center>        
                          <p><a href="registration.html"class="site-button" style=" margin-top:10px;max-width:300px; font-weight:bolder; font-size:2em; border-radius:10px; min-width:190px">REGISTER HERE</a></p>
                          <p>&nbsp;</p>
                        </center>
                    </div>
                    
                    
                    
                      <div class="section-head text-center">
                      
                      <div class="container">
                      
                        <div style="height:400px; overflow:hidden" class="row">
                      
                  <div style="height:560px; background-color: #1D2330; overflow:hidden; box-sizing: border-box; border: 1px solid #282E3B; border-radius: 4px; text-align: right; line-height:14px; font-size: 12px; font-feature-settings: normal; text-size-adjust: 100%; box-shadow: inset 0 -20px 0 0 #262B38;padding:1px;padding: 0px; margin: 0px; width: 100%;"><div style="height:540px; padding:0px; margin:0px; width: 100%;"><iframe src="https://widget.coinlib.io/widget?type=chart&amp;theme=dark&amp;coin_id=859&amp;pref_coin_id=1505" width="100%" height="536px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0" style="border:0;margin:0;padding:0;line-height:14px;"></iframe></div><div style="color: #626B7F; line-height: 14px; font-weight: 400; font-size: 11px; box-sizing: border-box; padding: 2px 6px; width: 100%; font-family: Verdana, Tahoma, Arial, sans-serif;"><a href="https://coinlib.io/" target="_blank" style="font-weight: 500; color: #626B7F; text-decoration:none; font-size:11px">Cryptocurrency Prices</a>&nbsp;by Coinlib</div></div>    
                      
                      
                      
                      </div>
                      
                      	<div class="row">
                            
                            	<div class="col-md-3 col-sm-3  col-xs-6 col-xs-100pc">
                                	<div class="wt-media m-b30">
                                        <img src="https://www.larive.com/wp-content/uploads/2017/11/Want-Want-Group-in-Jinan.jpg" alt="" class="img-responsive"/>
                                    </div>
                                </div>
                                
                                
                                
                                
                                
                                
                                
                                
                                <div class="col-md-3 col-sm-3  col-xs-6 col-xs-100pc">
                                	<div class="wt-media m-b30">
                                        <img src="https://roscongress.org/upload/resize_cache/iblock/251/360_239_1/pu0a0101.jpg" alt="" class="img-responsive"/>
                                    </div>
                                </div>
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                <div class="col-md-3 col-sm-3  col-xs-6 col-xs-100pc">
                                	<div class="wt-media m-b30">
                                        <img src="images/fx3.jpg" alt="" class="img-responsive"/>
                                    </div>
                                </div>
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                
                                <div class="col-md-3 col-sm-3  col-xs-6 col-xs-100pc">
                                	<div class="wt-media m-b30">
                                        <img src="https://themarketperiodical.com/wp-content/uploads/2020/10/bitcoin-3090250_1280-350x250.jpg" alt="" class="img-responsive"/>
                                    </div>
                                </div>
                                
                                </div> 
                      
                      </div>
                      
                      
                      </div>
                
          </div>
      
      
      <section class="sec-padding">
 
    <div class="container">
    
    <div class="row">  
  
          <div class="clearfix"></div>
          <p>
         <div style="margin-top:50px; margin-bottom:50px" class="row text-left">
      


        
        <div style="padding:10px" class="col-md-5">
        <h2 style=" border-bottom:solid 1px #00CC00; padding-bottom:20px;padding:10px" class="dancingscript  text-primary font-weight-8 margin-bottom-2">US Dollar Price Action Setups: EUR/USD, GBP/USD, AUD/USD</h2>
        
        <h4 style="color:rgb(255, 255, 255); padding:10px" class="font-weight-4 line-height-2 margin-bottom-3">We believe that every company, every organization, every trader and every investor must have access to the widest array of markets, the most asset classes</h4>
          <p style="color:rgb(253, 253, 253);padding:10px" class="bfont margin-bottom7"> the most liquidity, the most products and services, the most expertise, and the most advanced tools and technologies in order to seize their market opportunities and thrive.</p>
      <center>  <a style="background-color:#0C0;color:#FFF;font-weight:bolder; border-radius:8px" href="./register" class="m-b15 site-button m-t15"  >OPEN AN ACCOUNT&nbsp;&nbsp;&nbsp;<i class="fa fa-play"></i></a></center>
       <div style="width:100%" class="widget widget_gallery mfp-gallery">
                                        <h4 class="widget-title" style="color:goldenrod">Our tools, your advantage</h4>
                                                                              
                                    </div>
      
        </div>
        
        <div class="col-md-7" style="background-image:url(images/pltv.png); background-position:right; height:400px; background-repeat:no-repeat">
    
        </div>
        
      </div>
            
            
          </p>
          


<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script></center>
          
          
            
             <div class="col-md-12" style="width:100%; margin-top:-20px; z-index:1000; height:200px; overflow:hidden">
             <!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>

  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-forex-cross-rates.js" async>
  {
  "width": 1200,
  "height": 400,
  "currencies": [
    "EUR",
    "USD",
    "JPY",
    "GBP",
    "CHF",
    "AUD",
    "CAD",
    "NZD",
    "CNY"
  ],
  "isTransparent": true,
  "colorTheme": "dark",
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END -->
             
             </div>
      
      <div style=" overflow:hidden; height:400px; background-color:#000" class="col-md-12">
                 
  <div style="background-color:#030303; height:60px; z-index:1000000; margin-top:50px; width:100%"></div>                  
                   
            
             <video style="width:100%; z-index:200; margin-top:-250px; height:700px"  loop autoplay controls muted class="html-video" poster="images/maintenance-bg.html">
                <source type="video/mp4" src="video/3d.mp4">
                
      </video>
           
           
                    
                    
                    
      </div>
      
      
      
          <div class="col-md-12">
            <p><div><strong style="color:goldenrod;"><h1 style="color:goldenrod;">CDF TRADING</h1> WITH CoinFinancePro.com  </strong> </div>
              <br>

              <!-- TradingView Widget BEGIN -->
              <div class="tradingview-widget-container">
                <div class="tradingview-widget-container__widget"></div>
                <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com" rel="noopener" target="_blank"><span class="blue-text">Ticker Tape</span></a> by TradingView</div>
                <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
                {
                "symbols": [
                  {
                    "proName": "FOREXCOM:SPXUSD",
                    "title": "S&P 500"
                  },
                  {
                    "proName": "FOREXCOM:NSXUSD",
                    "title": "Nasdaq 100"
                  },
                  {
                    "proName": "FX_IDC:EURUSD",
                    "title": "EUR/USD"
                  },
                  {
                    "proName": "BITSTAMP:BTCUSD",
                    "title": "BTC/USD"
                  },
                  {
                    "proName": "BITSTAMP:ETHUSD",
                    "title": "ETH/USD"
                  }
                ],
                "colorTheme": "light",
                "isTransparent": true,
                "displayMode": "compact",
                "locale": "en"
              }
                </script>
              </div>
              <!-- TradingView Widget END -->
              <br>
              <div id="google_translate_element"></div>
              <br>
A CFD, or Contract for Difference, is CoinFinancePro.com  type of financial instrument that allows you to trade on the price movements of stocks, crypto currency regardless of whether prices are rising or falling. The key advantage of a CFD is the opportunity to speculate on the price movements of an asset (upwards or downwards) without actually owning the underlying asset.
</p> 
<br><br>
 <center>  <a href="./contact" class="but-stbutton-9 text-small  margin-left-2 uppercase"> &nbsp; &nbsp;DO YOU NEED HELP&nbsp;&nbsp; <i class="fa fa-long-arrow-right" aria-hidden="true"></i></a></center>
 </div>
  <!--end item-->

  </div>
    
    
    
      
    
    
      <div class="row">
  <br><br>
  <div class="clearfix"></div>

 <div class="col-md-6" style=" padding:15px; margin-top:30px; margin-bottom:100px; overflow:hidden; height:550px">
<div class="text-box padding-3 section-dark" style="background-color:#F0F0F0; padding-left:0px; margin-right:0px">
<center><div class="col-md-12"> <h4 style=" font-size:25px; font-weight:lighter; line-height:20px; color:#333333">Platforms Designed for  forex trading</h4></div>
<p style="font-size:15px"> Your Trading algorithm account gives you access to our full suite of platform for investment and cashout .
CHECKOUT OUR PLATFORMS</p></center>
<br/><center>

 
   <center>  <a style="background-color:#0C0;color:#FFF;font-weight:bolder; border-radius:8px" href="./register" class="m-b15 site-button m-t15"  >OPEN AN ACCOUNT&nbsp;&nbsp;&nbsp;<i class="fa fa-play"></i></a></center></p>
</center>
<p>
 

<p><img src="images/meta.png" alt="" width="535" height="358" align="left" class="img-responsive"/>
</p>
<div class="clearfix"></div>


</div>
  </div>

 
 <!-- end item-->
 
 <div class="col-md-6" style=" padding:15px; margin-top:30px; margin-bottom:100px; overflow:hidden; height:550px">
<div class="text-box padding-3 section-dark" style="background-color:#F0F0F0; padding-left:0px; margin-right:0px">
<center><div class="col-md-12"> <h4 style=" font-size:25px; font-weight:lighter; line-height:20px; color:#333333">Platforms Designed for  forex trading</h4></div>
<p style="font-size:15px"> We have tools installed in your dashboard that does the trade for you, all you do is to earn profit
CHECKOUT OUR PLATFORMS</p></center>
<br/><center>

 
   <a class="btn btn-medium btn-cyan btn-anim-4 uppercase xround-7" href="#">
  <span>Animation 4</span> 
  <i>Animation 4</i></a></p>
</center>
<p>
 

<p><img src="images/meta2.png" alt="" width="532" height="360" align="left" class="img-responsive"/>
</p>
<div class="clearfix"></div>


</div>
  </div>
 <!-- end item-->

  
  </div>
    </div>
    
    <div class="container">
                   
                    <!-- IMAGE CAROUSEL START -->
                    <div class="section-content">
                        <div class="owl-carousel home-logo-carousel">
                        
                        	<!-- COLUMNS 1 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w1.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 2 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w2.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 3 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w3.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 4 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w4.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 5 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w5.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 6 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w6.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 7 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w1.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 8 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w2.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 9 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w3.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 10 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w4.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 11 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w5.png" alt=""></a>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 12 --> 
                            <div class="item">
                                <div class="ow-client-logo">
                                    <div class="client-logo wt-img-effect on-color">
                                        <a href="#"><img src="images/client-logo/w6.png" alt=""></a>
                                    </div>
                                </div>
                            </div>                        
                        
                        </div>
                    </div>
                    <!-- IMAGE CAROUSEL START -->
        </div>

</section>   
            
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 <div style="background-color:#FFF; overflow:hidden" class="section-full p-t80 p-b50">
                <div class="container">
                    <div class="row">
                    
                    <div class="col-md-6 col-sm-6">
                        	<img src="images/mobtrade.png" alt="investor" width="1000" height="862" />
                    </div>
                          
                          
                          
                          
                            
                 
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    
                    
                        <div class="col-md-6 col-sm-6">
                            <div class="section-head text-left">
                                <h2 style="font-family:sans-serif; font-weight:bolder" class="text-uppercase">INVESTORS EMPOWERMENT</h2>
                                </div>
                             
                                <p style="font-size:20px; font-weight:lighter; font-weight:lighter; line-height:20px; color:#000000">
<!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/symbols/NASDAQ-AAPL/" rel="noopener" target="_blank"><span class="blue-text">AAPL Fundamental Data</span></a> by TradingView</div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-financials.js" async>
  {
  "symbol": "NASDAQ:AAPL",
  "colorTheme": "light",
  "isTransparent": true,
  "largeChartUrl": "",
  "displayMode": "regular",
  "width": 480,
  "height": 830,
  "locale": "en"
}
  </script>
</div>
<!-- TradingView Widget END --> </p>


 <small style="font-size:10px; font-weight:lighter; color:#A8A8A8">
                              
You can invest in 4 types of investment options with GLOBAL FX: Top Trader Portfolios which comprise the best performing and most sustainable traders on our platform, and Market Portfolios that bundle together CFD stocks, commodities or ETFs under one chosen market strategy.

CopyPortfolios aim to help investors minimise long-term risk, promote opportunities for growth, by taking copy trading to the next level and creating diversified investments.
  </small>
                                <div>
                                	
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
            
            <div style="padding-top:50px; padding-bottom:50px; background-color:#003">
            
            <div class="container"><!-- IMAGES BOX WITH CONTENT DEMO-2 -->
         <div style="margin-bottom:40px">   <center><h2 style="color:#FFFFFF; margin-bottom:30px">INVESTMENT OPTIONS</h2>
            <span style="color:#FFFFFF; margin-bottom:50px">
          
          
Choose the world’s No.1 CFD provider1

With many years of trading and over 239,323,000 Offline clients around the globe, we’re the world’s No.1 CFD provider. Why trade cryptocurrencies with anyone else?
</span></center></div>
              <div class="clearfix"></div>
                    <div class="section-content">
                        <div class="row">
                                     
                          <div class="col-md-3 col-sm-3 m-b30 animate" data-animate="fadeInUp" data-duration="3.0s" data-delay="0.2s" data-offset="100">
                                <div class="wt-box">
                                    
                                    
                                    
                                  <div style="border-bottom-left-radius:20px; padding-bottom:20px; margin-top:-15px; border-bottom-right-radius:20px;background-size:100%; background-position:bottom; background-repeat:no-repeat" class="wt-info bg-white"><center><h2 style="color:#000">BASIC PLAN</h2></center>
                                    <div style="padding:0px; margin:0px; background-color:#FFF" class="wt-media">
                              <div style="height:15px"></div>      
                            <center>  <h4 style=" text-align:center;color:#F93;font-weight:bolder" class="wt-title m-t0"></h4>   </center>          
                                <div style=" width:100%; width:250px; padding:0px" class="btcwdgt-chart" bw-theme="light">
                            	<script>
								 (function(b,i,t,C,O,I,N) {
									  window.addEventListener('load',function() {
									  if(b.getElementById(C))return;
									  I=b.createElement(i),N=b.getElementsByTagName(i)[0];
									  I.src=t;I.id=C;N.parentNode.insertBefore(I, N);
									},false)
								  })(document,'script','../widgets.bitcoin.com/widget.js','btcwdgt');
								</script>
                            </div>                
                                
                                  </div> 
                     
                      
                     <p style="border-bottom:dotted 1px #CCCCCC">&nbsp;&nbsp;<i class="fa fa-sort-asc" style=" font-size:1.4em;; margin-right:10px;color:#33FF33"></i><strong style="font-weight:bold; color:#000000">Max Deposit&nbsp;</strong><span style="font-size:1.4em;color:#000000">&nbsp;&nbsp;$1999</span></p>
                      
                                    <p style="border-bottom:dotted 1px #CCCCCC; margin-top:-10px">&nbsp;&nbsp;<i class="fa fa-sort-desc" style=" font-size:1.4em;; margin-right:10px;color:#F00"></i><strong style="font-weight:bold; color:#000000">Min Deposit&nbsp;</strong><span style="font-size:1.4em;color:#000000">&nbsp;&nbsp;$50</span></p>
                                
                                
                                 <p style="border-bottom:dotted 1px #CCCCCC; margin-top:-10px">&nbsp;&nbsp;<i class="fa fa-line-chart" style=" font-size:1.4em;; margin-right:10px;color:#F00"></i><strong style="font-weight:bold; color:#000000">GAIN&nbsp;<br /></strong><span style="font-size:1.4em; text-align:center; margin:10px; font-weight:bolder;color:#F60">&nbsp;5% + CAPITAL IN <br /> &nbsp;&nbsp;&nbsp;&nbsp;24 HOURS</span></p>
                                
                                
                                          
                                          
                                    <p style=" margin-top:-20px;border-bottom:dotted 1px #CCCCCC">&nbsp;&nbsp;<i class="fa fa-group" style=" font-size:1.4em;; margin-right:10px;color:#33FF33"></i><strong style="font-weight:bold; color:#000000">Referral&nbsp;</strong><span style="font-size:1.4em;color:#000000">10%</span></p>
                  
                  
                  <center><span>
                                 <a style=" background-color:#00CC00;font-weight:bolder; margin-top:-10px; border-radius:8px"  href="./register"  class="m-b5 site-button m-r5" >Register </a>
                                 
                                 </span></center>                     
                              
                                  </div>
                                </div>
                          </div>
                          <div class="col-md-3 col-sm-3 m-b30 animate" data-animate="fadeInUp" data-duration="3.0s" data-delay="0.2s" data-offset="100">
                                <div class="wt-box">
                                    
                                    
                                    
                                  <div style="border-bottom-left-radius:20px; padding-bottom:20px; margin-top:-15px; border-bottom-right-radius:20px;background-size:100%; background-position:bottom; background-repeat:no-repeat" class="wt-info bg-white"><center>
                                    <h2 style="color:#000">BUSINESS PLAN</h2></center>
                                    <div style="padding:0px; margin:0px; background-color:#FFF" class="wt-media">
                              <div style="height:15px"></div>      
                            <center>  <h4 style=" text-align:center;color:#F93;font-weight:bolder" class="wt-title m-t0"></h4>   </center>          
                                <div style=" width:100%; width:250px; padding:0px" class="btcwdgt-chart" bw-theme="light">
                            	<script>
								 (function(b,i,t,C,O,I,N) {
									  window.addEventListener('load',function() {
									  if(b.getElementById(C))return;
									  I=b.createElement(i),N=b.getElementsByTagName(i)[0];
									  I.src=t;I.id=C;N.parentNode.insertBefore(I, N);
									},false)
								  })(document,'script','../widgets.bitcoin.com/widget.js','btcwdgt');
								</script>
                            </div>                
                                
                                  </div> 
                     
                      
                     <p style="border-bottom:dotted 1px #CCCCCC">&nbsp;&nbsp;<i class="fa fa-sort-asc" style=" font-size:1.4em;; margin-right:10px;color:#33FF33"></i><strong style="font-weight:bold; color:#000000">Max Deposit&nbsp;</strong><span style="font-size:1.4em;color:#000000">&nbsp;&nbsp;$4999</span></p>
                      
                                    <p style="border-bottom:dotted 1px #CCCCCC; margin-top:-10px">&nbsp;&nbsp;<i class="fa fa-sort-desc" style=" font-size:1.4em;; margin-right:10px;color:#F00"></i><strong style="font-weight:bold; color:#000000">Min Deposit&nbsp;</strong><span style="font-size:1.4em;color:#000000">&nbsp;&nbsp;$2000</span></p>
                                
                                
                                 <p style="border-bottom:dotted 1px #CCCCCC; margin-top:-10px">&nbsp;&nbsp;<i class="fa fa-line-chart" style=" font-size:1.4em;; margin-right:10px;color:#F00"></i><strong style="font-weight:bold; color:#000000">GAIN&nbsp;<br /></strong><span style="font-size:1.4em; text-align:center; margin:10px; font-weight:bolder;color:#F60">&nbsp;15% + CAPITAL IN <br /> &nbsp;&nbsp;&nbsp;&nbsp;7 DAYS</span></p>
                                
                                
                                          
                                          
                                    <p style=" margin-top:-20px;border-bottom:dotted 1px #CCCCCC">&nbsp;&nbsp;<i class="fa fa-group" style=" font-size:1.4em;; margin-right:10px;color:#33FF33"></i><strong style="font-weight:bold; color:#000000">Referral&nbsp;</strong><span style="font-size:1.4em;color:#000000">10%</span></p>
                  
                  
                  <center><span>
                                 <a style=" background-color:#00CC00;font-weight:bolder; margin-top:-10px; border-radius:8px"  href="./register"  class="m-b5 site-button m-r5" >Register </a>
                                 
                                 </span></center>                     
                              
                                  </div>
                                </div>
                          </div>
                           <div class="col-md-3 col-sm-3 m-b30 animate" data-animate="fadeInUp" data-duration="3.0s" data-delay="0.2s" data-offset="100">
                                <div class="wt-box">
                                    
                                    
                                    
                                  <div style="border-bottom-left-radius:20px; padding-bottom:20px; margin-top:-15px; border-bottom-right-radius:20px;background-size:100%; background-position:bottom; background-repeat:no-repeat" class="wt-info bg-white"><center><h2 style="color:#000">COMPANY PLAN</h2></center>
                                    <div style="padding:0px; margin:0px; background-color:#FFF" class="wt-media">
                              <div style="height:15px"></div>      
                            <center>  <h4 style=" text-align:center;color:#F93;font-weight:bolder" class="wt-title m-t0"></h4>   </center>          
                                <div style=" width:100%; width:250px; padding:0px" class="btcwdgt-chart" bw-theme="light">
                            	<script>
								 (function(b,i,t,C,O,I,N) {
									  window.addEventListener('load',function() {
									  if(b.getElementById(C))return;
									  I=b.createElement(i),N=b.getElementsByTagName(i)[0];
									  I.src=t;I.id=C;N.parentNode.insertBefore(I, N);
									},false)
								  })(document,'script','../widgets.bitcoin.com/widget.js','btcwdgt');
								</script>
                            </div>                
                                
                                  </div> 
                     
                      
                     <p style="border-bottom:dotted 1px #CCCCCC">&nbsp;&nbsp;<i class="fa fa-sort-asc" style=" font-size:1.4em;; margin-right:10px;color:#33FF33"></i><strong style="font-weight:bold; color:#000000">Max Deposit&nbsp;</strong><span style="font-size:1.4em;color:#000000">&nbsp;&nbsp;$9999</span></p>
                      
                                    <p style="border-bottom:dotted 1px #CCCCCC; margin-top:-10px">&nbsp;&nbsp;<i class="fa fa-sort-desc" style=" font-size:1.4em;; margin-right:10px;color:#F00"></i><strong style="font-weight:bold; color:#000000">Min Deposit&nbsp;</strong><span style="font-size:1.4em;color:#000000">&nbsp;&nbsp;$5000</span></p>
                                
                                
                                 <p style="border-bottom:dotted 1px #CCCCCC; margin-top:-10px">&nbsp;&nbsp;<i class="fa fa-line-chart" style=" font-size:1.4em;; margin-right:10px;color:#F00"></i><strong style="font-weight:bold; color:#000000">GAIN&nbsp;<br /></strong><span style="font-size:1.4em; text-align:center; margin:10px; font-weight:bolder;color:#F60">&nbsp;30% + CAPITAL IN <br /> &nbsp;&nbsp;&nbsp;&nbsp;10 DAYS</span></p>
                                
                                
                                          
                                          
                                    <p style=" margin-top:-20px;border-bottom:dotted 1px #CCCCCC">&nbsp;&nbsp;<i class="fa fa-group" style=" font-size:1.4em;; margin-right:10px;color:#33FF33"></i><strong style="font-weight:bold; color:#000000">Referral&nbsp;</strong><span style="font-size:1.4em;color:#000000">10%</span></p>
                  
                  
                  <center><span>
                                 <a style=" background-color:#00CC00;font-weight:bolder; margin-top:-10px; border-radius:8px"  href="./register"  class="m-b5 site-button m-r5" >Register </a>
                                 
                                 </span></center>                     
                              
                                  </div>
                                </div>
                          </div>
                            
                        <div class="col-md-3 col-sm-3 m-b30 animate" data-animate="fadeInUp" data-duration="3.0s" data-delay="0.2s" data-offset="100">
                                <div class="wt-box">
                                    
                                    
                                    
                                  <div style="border-bottom-left-radius:20px; padding-bottom:20px; margin-top:-15px; border-bottom-right-radius:20px;background-size:100%; background-position:bottom; background-repeat:no-repeat" class="wt-info bg-white"><center><h2 style="color:#000">EXPERT PLAN</h2></center>
                                    <div style="padding:0px; margin:0px; background-color:#FFF" class="wt-media">
                              <div style="height:15px"></div>      
                            <center>  <h4 style=" text-align:center;color:#F93;font-weight:bolder" class="wt-title m-t0"></h4>   </center>          
                                <div style=" width:100%; width:250px; padding:0px" class="btcwdgt-chart" bw-theme="light">
                            	<script>
								 (function(b,i,t,C,O,I,N) {
									  window.addEventListener('load',function() {
									  if(b.getElementById(C))return;
									  I=b.createElement(i),N=b.getElementsByTagName(i)[0];
									  I.src=t;I.id=C;N.parentNode.insertBefore(I, N);
									},false)
								  })(document,'script','../widgets.bitcoin.com/widget.js','btcwdgt');
								</script>
                            </div>                
                                
                                  </div> 
                     
                      
                     <p style="border-bottom:dotted 1px #CCCCCC">&nbsp;&nbsp;<i class="fa fa-sort-asc" style=" font-size:1.4em;; margin-right:10px;color:#33FF33"></i><strong style="font-weight:bold; color:#000000">Max Deposit&nbsp;</strong><span style="font-size:1.4em;color:#000000">&nbsp;&nbsp;UNLIMITED</span></p>
                      
                                    <p style="border-bottom:dotted 1px #CCCCCC; margin-top:-10px">&nbsp;&nbsp;<i class="fa fa-sort-desc" style=" font-size:1.4em;; margin-right:10px;color:#F00"></i><strong style="font-weight:bold; color:#000000">Min Deposit&nbsp;</strong><span style="font-size:1.4em;color:#000000">&nbsp;&nbsp;$10000</span></p>
                                
                                
                                 <p style="border-bottom:dotted 1px #CCCCCC; margin-top:-10px">&nbsp;&nbsp;<i class="fa fa-line-chart" style=" font-size:1.4em;; margin-right:10px;color:#F00"></i><strong style="font-weight:bold; color:#000000">GAIN&nbsp;<br /></strong><span style="font-size:1.4em; text-align:center; margin:10px; font-weight:bolder;color:#F60">&nbsp;60% + CAPITAL IN <br /> &nbsp;&nbsp;&nbsp;&nbsp;10 HOURS</span></p>
                                
                                
                                          
                                          
                                    <p style=" margin-top:-20px;border-bottom:dotted 1px #CCCCCC">&nbsp;&nbsp;<i class="fa fa-group" style=" font-size:1.4em;; margin-right:10px;color:#33FF33"></i><strong style="font-weight:bold; color:#000000">Referral&nbsp;</strong><span style="font-size:1.4em;color:#000000">10%</span></p>
                  
                  
                  <center><span>
                                 <a style=" background-color:#00CC00;font-weight:bolder; margin-top:-10px; border-radius:8px"  href="./register"  class="m-b5 site-button m-r5" >Register </a>
                                 
                                 </span></center>                     
                              
                                  </div>
                                </div>
                          </div>
                        
                        </div>
                  </div>
                
  </div>
            
            
            </div>
            
            
         
         
         
         <div class="section-full home-about-section p-t80 bg-no-repeat bg-bottom-right"  style=" background-color:#F0F0F0 ">
                <div class="container-fluid ">
                    <div class="row">
                       <div class="col-md-1">
                       </div>
                        <div class="col-md-6">
                            <div class="wt-box text-right">
                                <p>&nbsp;</p>
                                <p>&nbsp;</p>
                                <p>&nbsp;</p>
                                <p><img src="images/land.png" alt=""></p>
                            </div>
                      </div>
                        <div class="col-md-5">
                            <div class="wt-right-part p-b80">
                                    <!-- TITLE START -->
                                    <div class="section-head text-left">
                                        <span class="wt-title-subline font-16 text-gray-dark m-b15"></span>
                                        <h2 class="text-uppercase">Ways to trade cryptocurrencies with Us</h2>
                                        
                                    </div>
                                    <!-- TITLE END -->
                                    <div class="section-content">
                                        <div class="wt-box">
                                            <p>
                                                <strong style="color:rgb(0, 0, 0);">If you’re looking to get involved in the cryptocurrency sphere, one of the first steps to consider is whether you will buy the digital assets or speculate on their prices. Take a look at some of the benefits to trading CFDs on cryptocurrencies, and discover why it has become a popular alternative to buying coins outright.


                                                </strong>
                                            </p>
                                            <p style="color:rgb(0, 0, 0);">


You can trade cryptocurrencies with Us using CFDs. CFDs, or contract for difference, allow you to speculate on the price of cryptocurrencies without having to take ownership of the underlying assets. With CFDs you can trade over 17,000 markets on leverage through all our available platforms including web, mobile, and MT4.However you can register as an investor and we will do all the big work for you, then profit gets straight to you</p>
                                           
                                        </div>
                                    </div>                                	
                          </div>
                        </div>
                    </div>
                </div>
          </div>
           <section style="height:600px; overflow:hidden"  id="main-wrapper" class="oxyy-login-register bg-dark">
     
             <video style="width:100%;"  loop autoplay controls muted class="html-video" poster="images/maintenance-bg.html">
                <source type="video/mp4" src="video/video.mp4">
                
      </video>
           
      </section>
         
         
         <section class="sec-padding">
 
   
    
    
    <div class="container">
                   
                    <!-- IMAGE CAROUSEL START -->
                    <div class="section-content">
                        
                    </div>
                    <!-- IMAGE CAROUSEL START -->
           </div>

</section>  
         
         
<div class="container" style="margin-top:10px;">
                   
  <!-- IMAGE CAROUSEL START -->
  <div class="section-content">
    <center><img src="images/certificate1.png" width="100%"> 

  </div>
  <!-- IMAGE CAROUSEL START -->
</div>

</section>        
         
         
         
         
         
         

           
          <div class="section-full p-t80 p-b50">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <div class="section-head text-left">
                                <h2 class="text-uppercase" style="color:white;" > Market Overview </h2>
                                <p>

Market Overview Widget provides a quick glance at the latest market activity across various sectors. It works great for homepages, and it can be configured to take users to a page with a larger chart on your site. Set your own instrument lists and tabs to cover what you need, adjust the timeframe for the chart or even hide the chart completely. </p>
                                <div style="width:100%; height:600px; overflow:hidden">
                                
                               
                                    <!-- TradingView Widget BEGIN -->
    <div class="tradingview-widget-container">
      <div class="tradingview-widget-container__widget"></div>
      <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/markets/stocks-usa/" rel="noopener" target="_blank"><span class="blue-text">Stock Quotes</span></a> by TradingView</div>
      <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-market-overview.js" async>
      {
      "title": "Stocks",
      "tabs": [
        {
          "title": "Financial",
          "symbols": [
            {
              "s": "NYSE:JPM",
              "d": "Jpmorgan Chase & Co"
            },
            {
              "s": "NYSE:WFC",
              "d": "Wells Fargo Co New"
            },
            {
              "s": "NYSE:BAC",
              "d": "Bank Amer Corp"
            },
            {
              "s": "NYSE:HSBC",
              "d": "Hsbc Hldgs Plc"
            },
            {
              "s": "NYSE:C",
              "d": "Citigroup Inc"
            },
            {
              "s": "NYSE:MA",
              "d": "Mastercard Incorporated"
            }
          ]
        },
        {
          "title": "Technology",
          "symbols": [
            {
              "s": "NASDAQ:AAPL",
              "d": "Apple"
            },
            {
              "s": "NASDAQ:GOOGL",
              "d": "Google Inc"
            },
            {
              "s": "NASDAQ:MSFT",
              "d": "Microsoft Corp"
            },
            {
              "s": "NASDAQ:FB",
              "d": "Facebook Inc"
            },
            {
              "s": "NYSE:ORCL",
              "d": "Oracle Corp"
            },
            {
              "s": "NASDAQ:INTC",
              "d": "Intel Corp"
            }
          ]
        },
        {
          "title": "Services",
          "symbols": [
            {
              "s": "NASDAQ:AMZN",
              "d": "Amazon Com Inc"
            },
            {
              "s": "NYSE:BABA",
              "d": "Alibaba Group Hldg Ltd"
            },
            {
              "s": "NYSE:T",
              "d": "At&t Inc"
            },
            {
              "s": "NYSE:WMT",
              "d": "Wal-mart Stores Inc"
            },
            {
              "s": "NYSE:CHL",
              "d": "China Mobile Limited"
            },
            {
              "s": "NYSE:V",
              "d": "Visa Inc"
            }
          ]
        }
      ],
      "width": 400,
      "height": 660,
      "showChart": true,
      "locale": "en",
      "plotLineColorGrowing": "rgba(33, 150, 243, 1)",
      "plotLineColorFalling": "rgba(33, 150, 243, 1)",
      "belowLineFillColorGrowing": "rgba(33, 150, 243, 0.12)",
      "belowLineFillColorFalling": "rgba(33, 150, 243, 0.12)",
      "gridLineColor": "#F0F3FA",
      "scaleFontColor": "rgba(120, 123, 134, 1)",
      "showSymbolLogo": true,
      "symbolActiveColor": "rgba(33, 150, 243, 0.12)",
      "colorTheme": "light"
    }
      </script>
    </div>
    <!-- TradingView Widget END -->
                                

</div>
</div>
</div>

                        <div class="col-md-6 col-sm-6">
                        	<div class="row">





    <img src="images/c.png" alt="investor" width="1000" height="862" />
     
       <p style='padding:15px; margin-top:-190px; color:white; text-align:center; font-size:18px; font-family: Georgia, serif;' >Our Visa Debit Crypto Card are made available for free, to all our Company and Expert plan investors.</p>                     
                            </div>
                            
                        </div>
                    </div>
                </div>
          </div>
            
         

         
         
         <div style="background-image:url(images/bgtrend.jpg); background-position:top; background-repeat:repeat-y" class="section-content no-col-gap">
                        <div class="row">
                                <div style=" padding:30px; margin-bottom:30px" class="col-md-1 col-sm-1 step-number-block">
                                </div>
                            <!-- COLUMNS 1 -->
                          <div style=" padding:30px; margin-bottom:30px" class="col-md-10 col-sm-10 step-number-block">
                             
                                <h1 style="color:#FFF; text-align:center; font-size:50px; font-weight:bolder; line-height:50px">
                                Trade with confidence and benefit from</h1>
                              
                               <center>
                               
                                <h3 style="color:#FFF">1,250+ assets including Indices & Stocks</h3>
                              <div style=" color:#FFF; text-align:left; padding:10px;color:#666666"></div></center>
                            </div>
                            <!-- COLUMNS 2 -->
                            <!-- COLUMNS 3 -->
                                
                             <div class="col-md-2 col-sm-2 step-number-block"></div>
                        </div>
                        <center>        
                          <p><a href="./register"class="site-button" style=" margin-top:1px;max-width:300px; font-size:20px; border-radius:10px; min-width:250px">&nbsp;OPEN ACCOUNT HERE&nbsp;</a></p>
                          <p>&nbsp;</p>
                        </center>
                    </div>
         
         
         <div style="background-color:#F1F2F4" class="section-full p-t80 p-b50">
                <div class="container">
                    <div class="row">
                    
                    <div class="col-md-6 col-sm-6"><br />
                            <img src="images/gallery/thumb/man1.png" alt="investor" width="590" height="189" />
                           
                           
                           <br />  
                            
                            
                           <img src="images/gallery/thumb/man2.png" alt="investor" width="590" height="189" />
                           
                           
                           <br />
                           
                           <img src="images/gallery/thumb/man3.png" alt="investor" width="590" height="189" /> 
                            
                            </div>
                          
                          
                          
                          
                            
                 
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    
                    
                        <div class="col-md-6 col-sm-6">
                            <div class="section-head text-left">
                                <h2 class="text-uppercase">Social Trading revolution</h2>
                                </div>
                             
                                <p style="font-size:30px; font-weight:lighter; line-height:40px; color:#000000">
                              
Join the Social Trading revolution. Connect with other traders, discuss trading strategies, and use our patented CopyTrader™ technology to automatically copy their trading portfolio performance.  </p>
                                <div>
                                	
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
          </div>   
            
    

<footer class="site-footer bg-no-repeat bg-full-height bg-center"  style="padding:0px; margin:0px;background-image:url(images/background/footer-bg.jpg);">
            <!-- FOOTER BLOCKES START -->  
            <div class="footer-top overlay-wraper">
                <div class="overlay-main bg-black opacity-05"></div>
                <div class="container">
                    <div class="row">
                        <!-- ABOUT COMPANY -->
                        <div style="padding-right:20px" class="col-md-3 col-sm-6">  
                            <div class="widget widget_about">
                                <h4 class="widget-title text-white">About Company</h4>
                                <div class="logo-footer clearfix p-b15">
                                   <a href="./">
                            <div style="background-image:url(img/new/log6.png); width:200px; background-position:left; background-size:contain; background-repeat:no-repeat" class="logo-header mostion">
                            </div>   
                        </a>
                                </div>
                                <p style="color:#FFFFFF">CoinFinancePro.com  is designed to give direct return to investors thereby limiting investor’s risk due to fatal loss.
                              </p>  
                            </div>
                            
                            
                            
                                <div class="logo-footer clearfix p-b15">
                                    <a href="http://www.forex.com/"><img src="images/british.png" width="221" height="95" alt=""/></a>
                                </div>
                                <p style="color:#FFFFFF"><small style="font-weight:bold; font-size:11px;">Forex.com</small><br/> Trusted and Ofiicial forex broker. 
                              </p>  
                       
                            
                        </div> 
                        <br/><br/>
                        <!-- RESENT POST -->
                        <div class="col-md-3 col-sm-6">
                            <div class="widget recent-posts-entry-date">
                                <h4 class="widget-title text-white">Supporters</h4>
                                <div class="widget-post-bx">
                                 <span style="color:#FFF">Company House U.K <small style="color:#999">Office of the official register of company in North Ireland, Scotland,England and Wales</small></span>
                                    <a style="margin-bottom:20px" href="https://beta.companieshouse.gov.uk/company/11568582/officers"><img src="images/companyhousel.png" width="250" height="130" alt=""/></a>
                                    <div style="margin-top:30px" class="bdr-light-blue widget-post clearfix  bdr-b-1 m-b10 p-b10">
                                                     <span style="color:#FFF">Paxful <small style="color:#999">Trusted Online Bitcoin Exchang Market</small></span>
                                       <a href="https://paxful.com/"><img src="images/paxful.png" width="250" height="130"  alt=""/></a>
                                        
                                    </div>
                                    
                              </div>
                            </div>
                        </div>      
                        <!-- USEFUL LINKS -->
                        <div class="col-md-3 col-sm-6">
                            <div class="widget widget_services">
                                <h4 class="widget-title text-white">Useful links</h4>
                                <ul>
                                    <li><a href="about.html">About</a></li>
                                    <li><a href="faq.html">FAQ</a></li>
                                    <li><a href="team.html">Our Team</a></li>
                                    <li><a href="terms.html">Terms</a></li>
                                    <li><a href="contact%20us.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- NEWSLETTER -->
                        <div class="col-md-3 col-sm-6">
                        <div style="width:300px; height:270px; background-image:url(img/tv.html); background-position:center; background-repeat:no-repeat">
                            
                           <center>
 <div style="width:98%; padding-top:24px; overflow:hidden;height:240px">
 <iframe width="255" height="168" src="https://www.youtube.com/embed/kubGCSj5y3k?autoplay=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
 
 </div>
                            
</center>
                            
                             </div>
                            <div class="widget widget_newsletter">
                                <h4 class="widget-title text-white">Newsletter</h4>
                                <div class="newsletter-bx">
                                    <form role="search" method="post">
                                        <div class="input-group">
                                        <input name="news-letter" class="form-control" placeholder="ENTER YOUR EMAIL" type="text">
                                        <span class="input-group-btn">
                                            <button type="submit" class="site-button"><i class="fa fa-paper-plane-o"></i></button>
                                        </span>
                                    </div>
                                     </form>
                                </div>
                            </div>
                            <!-- SOCIAL LINKS -->
                            <div class="widget widget_social_inks">
                                <h4 class="widget-title text-white">Social Links</h4>
                                <ul class="social-icons social-square social-darkest">
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-facebook"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-twitter"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-linkedin"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-rss"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-youtube"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-instagram"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
              </div>
            </div>
            <!-- FOOTER COPYRIGHT --></footer>        
      </div>
        <!-- FOOTER END -->

        
        <!-- BUTTON TOP START -->
        <button class="scroltop"><span class=" iconmoon-house relative" id="btn-vibrate"></span>Top</button>

        <!-- MODAL  LOGIN -->
        <div id="Login-form" class="modal fade " role="dialog">
          <div class="modal-dialog modal-sm">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-white">Login Your Account</h4>
              </div>
              <div class="modal-body p-a30">
              <form id="form1" name="form1" method="POST">
              <div class="form-group">
   <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input name="username" id="username" class="form-control" placeholder="Enter Username" type="text">
                </div>
                </div>
     <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input class="form-control" placeholder="Enter Password" name="password" type="password">
                        </div>
                </div>
                  
    <p>
      <input class="site-button-secondry text-uppercase btn-block m-b10" type="submit" name="button" id="button" value="Submit" />
    </p>
  </form>
              
                    <span class="font-12">Don't have an account? <a href="#invest">Chose an Investment option</a></span>
              
              </div>
              <div style="background-color:#000019" class="modal-footer text-center">
                <div class="text-center"><strong style="color:goldenrod; padding-top:20px;">CoinFinancePro.com</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- MODAL  REGISTER -->
                     
                
</div>
 



<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript">
        (function(){var gtConstEvalStartTime = new Date();/*

    Copyright The Closure Library Authors.
    SPDX-License-Identifier: Apache-2.0
    */
    var h=this||self,l=/^[\w+/_-]+[=]{0,2}$/,m=null;function n(a){return(a=a.querySelector&&a.querySelector("script[nonce]"))&&(a=a.nonce||a.getAttribute("nonce"))&&l.test(a)?a:""}function p(a,b){function c(){}c.prototype=b.prototype;a.i=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.h=function(g,f,k){for(var e=Array(arguments.length-2),d=2;d<arguments.length;d++)e[d-2]=arguments[d];return b.prototype[f].apply(g,e)}}function q(a){return a};function r(a){if(Error.captureStackTrace)Error.captureStackTrace(this,r);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))}p(r,Error);r.prototype.name="CustomError";function u(a,b){a=a.split("%s");for(var c="",g=a.length-1,f=0;f<g;f++)c+=a[f]+(f<b.length?b[f]:"%s");r.call(this,c+a[g])}p(u,r);u.prototype.name="AssertionError";function v(a,b){throw new u("Failure"+(a?": "+a:""),Array.prototype.slice.call(arguments,1));};var w;function x(a,b){this.g=b===y?a:""}x.prototype.toString=function(){return this.g+""};var y={};function z(a){var b=document.getElementsByTagName("head")[0];b||(b=document.body.parentNode.appendChild(document.createElement("head")));b.appendChild(a)}
    function _loadJs(a){var b=document;var c="SCRIPT";"application/xhtml+xml"===b.contentType&&(c=c.toLowerCase());c=b.createElement(c);c.type="text/javascript";c.charset="UTF-8";if(void 0===w){b=null;var g=h.trustedTypes;if(g&&g.createPolicy){try{b=g.createPolicy("goog#html",{createHTML:q,createScript:q,createScriptURL:q})}catch(t){h.console&&h.console.error(t.message)}w=b}else w=b}a=(b=w)?b.createScriptURL(a):a;a=new x(a,y);a:{try{var f=c&&c.ownerDocument,k=f&&(f.defaultView||f.parentWindow);k=k||h;
    if(k.Element&&k.Location){var e=k;break a}}catch(t){}e=null}if(e&&"undefined"!=typeof e.HTMLScriptElement&&(!c||!(c instanceof e.HTMLScriptElement)&&(c instanceof e.Location||c instanceof e.Element))){e=typeof c;if("object"==e&&null!=c||"function"==e)try{var d=c.constructor.displayName||c.constructor.name||Object.prototype.toString.call(c)}catch(t){d="<object could not be stringified>"}else d=void 0===c?"undefined":null===c?"null":typeof c;v("Argument is not a %s (or a non-Element, non-Location mock); got: %s",
    "HTMLScriptElement",d)}a instanceof x&&a.constructor===x?d=a.g:(d=typeof a,v("expected object of type TrustedResourceUrl, got '"+a+"' of type "+("object"!=d?d:a?Array.isArray(a)?"array":d:"null")),d="type_error:TrustedResourceUrl");c.src=d;(d=c.ownerDocument&&c.ownerDocument.defaultView)&&d!=h?d=n(d.document):(null===m&&(m=n(h.document)),d=m);d&&c.setAttribute("nonce",d);z(c)}
    function _loadCss(a){var b=document.createElement("link");b.type="text/css";b.rel="stylesheet";b.charset="UTF-8";b.href=a;z(b)}function _isNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)if(!(b=b[a[c]]))return!1;return!0}function _setupNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)b.hasOwnProperty?b.hasOwnProperty(a[c])?b=b[a[c]]:b=b[a[c]]={}:b=b[a[c]]||(b[a[c]]={});return b}
    window.addEventListener&&"undefined"==typeof document.readyState&&window.addEventListener("DOMContentLoaded",function(){document.readyState="complete"},!1);
    if (_isNS('google.translate.Element')){return}(function(){var c=_setupNS('google.translate._const');c._cest = gtConstEvalStartTime;gtConstEvalStartTime = undefined;c._cl='en';c._cuc='googleTranslateElementInit';c._cac='';c._cam='';c._ctkk='449410.1855493327';var h='translate.googleapis.com';var s=(true?'https':window.location.protocol=='https:'?'https':'http')+'://';var b=s+h;c._pah=h;c._pas=s;c._pbi=b+'/translate_static/img/te_bk.gif';c._pci=b+'/translate_static/img/te_ctrl3.gif';c._pli=b+'/translate_static/img/loading.gif';c._plla=h+'/translate_a/l';c._pmi=b+'/translate_static/img/mini_google.png';c._ps=b+'/translate_static/css/translateelement.css';c._puh='translate.google.com';_loadCss(c._ps);_loadJs(b+'/translate_static/js/element/main.js');})();})();
</script>
<!-- JAVASCRIPT  FILES ========================================= --> 
<script src="js/jquery-1.12.4.min.js"></script><!-- JQUERY.MIN JS -->
<script   src="js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->

<script   src="js/bootstrap-select.min.js"></script><!-- FORM JS -->
<script   src="js/jquery.bootstrap-touchspin.min.js"></script><!-- FORM JS -->

<script   src="js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->

<script   src="js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script   src="js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script   src="js/waypoints-sticky.min.js"></script><!-- COUNTERUP JS -->

<script  src="js/isotope.pkgd.min.js"></script><!-- MASONRY  -->

<script   src="js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->

<script   src="js/stellar.min.js"></script><!-- PARALLAX BG IMAGE   --> 
<script   src="js/scrolla.min.js"></script><!-- ON SCROLL CONTENT ANIMTE   -->

<script   src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script   src="js/shortcode.js"></script><!-- SHORTCODE FUCTIONS  -->

<script  src="js/jquery.bgscroll.js"></script><!-- BACKGROUND SCROLL -->
<script  src="js/tickerNews.min.js"></script><!-- TICKERNEWS-->
<!-- TICKERNEWS FUNCTiON -->
<script type="text/javascript">
	jQuery(function(){
		var timer = !1;
		_Ticker = jQuery("#T1").newsTicker();
		_Ticker.on("mouseenter",function(){
			var __self = this;
			timer = setTimeout(function(){
				__self.pauseTicker();
			},200);
		});
		_Ticker.on("mouseleave",function(){
			clearTimeout(timer);
			if(!timer) return !1;
			this.startTicker();
		});
	});
</script>
<!-- REVOLUTION JS FILES -->

<script  src="plugins/revolution/revolution/js/jquery.themepunch.tools.min.js"></script>
<script  src="plugins/revolution/revolution/js/jquery.themepunch.revolution.min.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->	
<script  src="plugins/revolution/revolution/js/extensions/revolution-plugin.js"></script>

<!-- REVOLUTION SLIDER FUNCTION  ===== -->
<script   src="js/rev-script-1.js"></script>













<!-- JAVASCRIPT  FILES ========================================= --> 
<script src="js/jquery-1.12.4.min.js"></script><!-- JQUERY.MIN JS -->
<script   src="js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->

<script   src="js/bootstrap-select.min.js"></script><!-- FORM JS -->
<script   src="js/jquery.bootstrap-touchspin.min.js"></script><!-- FORM JS -->

<script   src="js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->

<script   src="js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script   src="js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script   src="js/waypoints-sticky.min.js"></script><!-- COUNTERUP JS -->

<script  src="js/isotope.pkgd.min.js"></script><!-- MASONRY  -->

<script   src="js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->

<script   src="js/stellar.min.js"></script><!-- PARALLAX BG IMAGE   --> 
<script   src="js/scrolla.min.js"></script><!-- ON SCROLL CONTENT ANIMTE   -->

<script   src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script   src="js/shortcode.js"></script><!-- SHORTCODE FUCTIONS  -->

<script  src="js/jquery.bgscroll.js"></script><!-- BACKGROUND SCROLL -->
<script  src="js/tickerNews.min.js"></script><!-- MARQUEE SCROLL -->
<!-- MARQUEE FUNCTiON -->
<script type="text/javascript">
	$(function(){
		var timer = !1;
		_Ticker = $("#T1").newsTicker();
		_Ticker.on("mouseenter",function(){
			var __self = this;
			timer = setTimeout(function(){
				__self.pauseTicker();
			},200);
		});
		_Ticker.on("mouseleave",function(){
			clearTimeout(timer);
			if(!timer) return !1;
			this.startTicker();
		});
	});
</script>
<!-- REVOLUTION JS FILES -->

 





<script src="js/jquery-1.12.4.min.js"></script><!-- JQUERY.MIN JS -->
<script   src="js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->

<script   src="js/bootstrap-select.min.js"></script><!-- FORM JS -->
<script   src="js/jquery.bootstrap-touchspin.min.js"></script><!-- FORM JS -->

<script   src="js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->

<script   src="js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script   src="js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script   src="js/waypoints-sticky.min.js"></script><!-- COUNTERUP JS -->

<script  src="js/isotope.pkgd.min.js"></script><!-- MASONRY  -->

<script   src="js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->

<script   src="js/stellar.min.js"></script><!-- PARALLAX BG IMAGE   --> 
<script   src="js/scrolla.min.js"></script><!-- ON SCROLL CONTENT ANIMTE   -->

<script   src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script   src="js/shortcode.js"></script><!-- SHORTCODE FUCTIONS  -->

<script  src="js/jquery.bgscroll.js"></script><!-- BACKGROUND SCROLL -->
<script  src="js/tickerNews.min.js"></script><!-- TICKERNEWS-->
<!-- TICKERNEWS FUNCTiON -->
<script type="text/javascript">
	jQuery(function(){
		var timer = !1;
		_Ticker = jQuery("#T1").newsTicker();
		_Ticker.on("mouseenter",function(){
			var __self = this;
			timer = setTimeout(function(){
				__self.pauseTicker();
			},200);
		});
		_Ticker.on("mouseleave",function(){
			clearTimeout(timer);
			if(!timer) return !1;
			this.startTicker();
		});
	});
</script>
<!-- REVOLUTION JS FILES -->

<script  src="plugins/revolution/revolution/js/jquery.themepunch.tools.min.js"></script>
<script  src="plugins/revolution/revolution/js/jquery.themepunch.revolution.min.js"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->	
<script  src="plugins/revolution/revolution/js/extensions/revolution-plugin.js"></script>

<!-- REVOLUTION SLIDER FUNCTION  ===== -->
<script   src="js/rev-script-1.js"></script>






    <script src="j/jquery.appear.js"></script>
    <script src="j/swiper/swiper.min.js"></script>
    <script src="j/swiperanimation/SwiperAnimation.min.js"></script>
    <script src="j/counter/jquery.countTo.js"></script>
    <script src="j/owl-carousel/owl.carousel.min.js"></script>
    <script src="j/jarallax/jarallax.min.js"></script>
    <script src="j/jarallax/jarallax-video.min.js"></script>
    <script src="j/magnific-popup/jquery.magnific-popup.min.js"></script>


    <script src="js/jquery-2.2.4.min.html"></script>
    <script src="js/common_scripts.html"></script>
    <script src="js/main.js"></script>
	<script src="assets/validate.html"></script>
</body>


</html>