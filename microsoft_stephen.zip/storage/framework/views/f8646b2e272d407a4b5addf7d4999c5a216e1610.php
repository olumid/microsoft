
<!doctype html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Coin Finance Pro</title>
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

   <link rel="icon" href="img/log.jpeg" type="image/x-icon">
    <!-- VENDOR CSS -->
    <link rel="stylesheet" href="ucss/bootstrap.min.css">
    <link rel="stylesheet" href="ucss/font-awesome.min.css">

    <!-- MAIN CSS -->
    <link rel="stylesheet" href="ucss/main.css">
    <link rel="stylesheet" href="ucss/color_skins.css">
    <style>
		@import  url(https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&family=Titillium+Web:wght@400;700&display=swap);
		select{
			font-size: 20px;
			font-weight: bolder;
			
		}
	</style>
</head>

<body class="theme-blush" style="font-family: 'Titillium Web';">
<!-- WRAPPER -->
<div id="wrapper" style='background:red;'>
    <div class="vertical-align-wrap" 
    style='background:linear-gradient(rgba(0,0,0,0.2),rgba(0,0,0,0.4)), url("img/log.jpg"); background-repeat: no-repeat;
	background-size: cover;
	background-position: center;'>
        <div class="vertical-align-middle auth-main">
            <div class="auth-box">
                <div class="top">
                <a href='./'>
                <img  src='img/new/logo.png' data-at2x='img/new/logo.png' width='100' alt='Logo' class='logo_mobile' />
                    <!-- <h3 style='color:red;'>Alvarium Block LTD</h3> -->

                </a>
               
                </div>
                <div class="card">
                        <div class="header">

         
        <p class="lead" style='color:#000e2e; font-size: 20px; font-weight: bold'>Create an account</p>
    </div>
    <div class="body" style="font-size:18px;">
         <form class="pt-3" action="<?php echo e(route('addAccount')); ?>" method="post">
              <?php echo e(csrf_field()); ?>


            <div class="form-group <?php echo e($errors->has('fullname') ?  'has-error' : ''); ?>">
                <label for="signup-firstname" class="control-label">FullName</label>
                <input type="text" name="fullname"  class="form-control " placeholder="Your first name" style='font-size:17px' value="<?php echo e(old('fullname')); ?>">            
                <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('fullname')); ?></p>
            </div>
           
            <div class="form-group <?php echo e($errors->has('email') ?  'has-error' : ''); ?>">
                <label for="signup-email" class="control-label">Email</label>
                <input type="email" name="email"  class="form-control " placeholder="Your email" style=' font-size: 17px' value="<?php echo e(old('email')); ?>">           
                <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('email')); ?></p>
            </div>
            

           <div class="form-group <?php echo e($errors->has('username') ?  'has-error' : ''); ?>">
                 <label>User ID</label>
                <input type="text" name="username" class="form-control" placeholder="Your User ID" style='font-size: 17px' value="<?php echo e(old('username')); ?>">
            
               <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('username')); ?></p>
            </div>
            

            <div class="form-group <?php echo e($errors->has('password') ?  'has-error' : ''); ?>">
                <label for="signup-password" class="control-label">Password</label>
                <input type="password" name="password" class="form-control "  placeholder="Password" style='font-size: 17px'  value="<?php echo e(old('password')); ?>">                                           
            </div>
             <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('password')); ?></p>
           
            <div class="form-group">
               <label for="signup-password" class="control-label">Confirm Password</label>
                <input type="password" name="password_confirmation" class="form-control "  placeholder="Confirm Password" style='  font-size: 17px'>                                           
            </div>
            
             <div class="form-group  <?php echo e($errors->has('country') ?  'has-error' : ''); ?>">
                <label for="signup-phone" class="control-label">Country</label>
                <input type="text" name="country" class="form-control " placeholder="Your Country" style='font-size: 17px'  value="<?php echo e(old('country')); ?>">
               <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('country')); ?></p
            </div>
           

            <?php if(Session::has('referrer')): ?>  
                 <div class="form-group">
                  <label>Referral ID(optional)</label>
                 
                    
                    <input readonly type="text" value="<?php echo e(Session::get('referrer')); ?>" name="referral_id" class="form-control form-control-lg border-left-0" placeholder="YFLM813A">
                 
                 </div>
                <?php else: ?>
                <div class="form-group">
                  <label>Referral ID(optional)</label>
                  
                    <input type="text" name="referral_id" class="form-control" placeholder="YFLM813A"  style='  font-size: 17px'>
                  </div>
                 
                <?php endif; ?>
                
           
            

           <input type="submit" name="register" value="REGISTER" style='background:#f0ad4e; border: none; color:white; padding:15px;'>
            
            <div class="bottom">
            <br>
            
                <span class="helper-text" style=''>Already have an account? <a href="./login">Login</a></span>
                <span><a href="./" style='color:#000e2e;'>www.IQ-Markets.com</a></span>
            </div>
        </form>

    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- END WRAPPER -->


<!--Start of Tawk.to Script-->

<!--End of Tawk.to Script-->

</body>
</html>