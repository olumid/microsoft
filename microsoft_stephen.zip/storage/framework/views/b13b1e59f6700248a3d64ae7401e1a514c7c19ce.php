<div id="form_editAcct" class="modal fade"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Udate Investor`s Account</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </a>
            </div>
            <div class="modal-body">
                <form action="#" class="form-horizontal" id="editAcct" method="POST">
                     <input type="hidden"  name="user_id" id="user_id">
                   
                    <div class="form-group">
                        <label class="control-label col-md-4" >Usd Balance($)</label>
                        <div class="col-md-8">
                            <input class="form-control select2" name="balance" id="balance">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Earnings($)</label>
                        <div class="col-md-8">
                            <input  class="form-control select2" name="earnings" id="earnings">
                        </div>
                    </div>
                   
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-secondary " data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary btn-update" id="btn-editAcct">Save</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>