<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="<?php echo e(asset('img/logo/logo4.png')); ?>" rel="icon">
  <title>Vanguards Invest</title>
  <link href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('css/ruang-admin.min.css')); ?>" rel="stylesheet">
</head>

<body id="page-top">
  <div id="wrapper">
    <!-- Sidebar -->
    <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard1')); ?>">
        <div class="sidebar-brand-icon">
          <img src="<?php echo e(asset('img/logo/logo5.png')); ?>">
        </div>
        <div class="sidebar-brand-text mx-3"></div>
      </a>
      <hr class="sidebar-divider my-0">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('dashboard1')); ?>">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
      
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseForm" aria-expanded="true"
          aria-controls="collapseForm">
          <i class="fas fa-fw fa-user"></i>
          <span>My Profile</span>
        </a>
        <div id="collapseForm" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('profile')); ?>">Update Account</a>
            <a class="collapse-item" href="<?php echo e(route('password')); ?>">Update Password</a>
            <a class="collapse-item" href="<?php echo e(route('walletDetails')); ?>">Update Wallet</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTable" aria-expanded="true"
          aria-controls="collapseTable">
          <i class="fas fa-fw fa-credit-card"></i>
          <span>Withdraw</span>
        </a>
        <div id="collapseTable" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('otpPage')); ?>">Withdraw</a>
            <a class="collapse-item" href="<?php echo e(route('withdrawHistory')); ?>">History</a>
          </div>
        </div>
      </li>
       <li class="nav-item active">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePage" aria-expanded="true"
          aria-controls="collapsePage">
          <i class="fas fa-fw fa-credit-card"></i>
          <span>Deposit</span>
        </a>
        <div id="collapsePage" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('depositRequest')); ?>">Deposit</a>
            <a class="collapse-item" href="<?php echo e(route('depositHistory')); ?>">History</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBootstrap" aria-expanded="true"
          aria-controls="collapseBootstrap">
          <i class="fas fa-fw fa-credit-card"></i>
          <span>Investment</span>
        </a>
        <div id="collapseBootstrap" class="collapse" aria-labelledby="headingTable" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <a class="collapse-item" href="<?php echo e(route('investment')); ?>">Invest</a>
            <a class="collapse-item" href="<?php echo e(route('investmentHistory')); ?>">History</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('loan')); ?>">
          <i class="far fa-fw fa-window-maximize"></i>
          <span>Loan</span>
        </a>
        
      </li>
       <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('earnings')); ?>">
          <i class="far fa-fw fa-window-maximize"></i>
          <span>My Earnings</span>
        </a>
        
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="<?php echo e(route('showDownlines')); ?>">
          <i class="fas fa-fw fa-palette"></i>
          <span>My Downlines</span>
        </a>
        
      </li>
     
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('logout')); ?>">
          <i class="fas fa-fw fa-user"></i>
          <span>Logout</span>
        </a>
      </li>
     
    </ul>
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content">
        <!-- TopBar -->
        <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top">
          <button id="sidebarToggleTop" class="btn btn-link rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">
                <form class="navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-1 small" placeholder="What do you want to look for?"
                      aria-label="Search" aria-describedby="basic-addon2" style="border-color: #3f51b5;">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>
            
           
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img class="img-profile rounded-circle" src="<?php echo e(asset('img/boy.png')); ?>" style="max-width: 60px">
                <span class="ml-2 d-none d-lg-inline text-white small"><?php echo e(Auth::user()->name); ?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="javascript:void(0);" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
        </nav>
        <!-- Topbar -->

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
               
          
          <div class="row mb-3">
             
              <div class="col-lg-6">
                        <div class="card">
                            
                            <div style="font-family: roboto; width:100%; padding:8px; font-weight:bold; font-size:20px; text-align: center; " class="btn  btn-primary">
                                *Select Deposit Mode Below.*                               
                            </div>
                             <?php if(Session::has('msg')): ?>   
                                <div id="info" style="font-family: roboto; font-size:15px; margin:25px" class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong><?php echo e(Session::get('msg')); ?></strong>
                                    <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </a>
                                </div>
                             <?php endif; ?>
                        
                            <div class="card-body">
                                <div class="custom-tab">
                                        
                                    <nav>
                                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                            <a class="nav-item nav-link active" id="custom-nav-home-tab" data-toggle="tab" href="#custom-nav-home" role="tab" aria-controls="custom-nav-home" aria-selected="true">BTC</a>
                                            <a class="nav-item nav-link" id="custom-nav-eth-tab" data-toggle="tab" href="#custom-nav-eth" role="tab" aria-controls="custom-nav-eth" aria-selected="false">ETH</a>
                                            <a class="nav-item nav-link" id="custom-nav-ltc-tab" data-toggle="tab" href="#custom-nav-ltc" role="tab" aria-controls="custom-nav-ltc" aria-selected="false">LTC</a>
                                             <a class="nav-item nav-link" id="custom-nav-tron-tab" data-toggle="tab" href="#custom-nav-tron" role="tab" aria-controls="custom-nav-tron" aria-selected="false">TRON</a>
                                            <a class="nav-item nav-link" id="custom-nav-xrp-tab" data-toggle="tab" href="#custom-nav-xrp" role="tab" aria-controls="custom-nav-xrp" aria-selected="false">XRP</a>
                                        </div>
                                    </nav>
                                    <div class="tab-content pl-3 pt-2" id="nav-tabContent">
                                        <div class="tab-pane fade show active" id="custom-nav-home" role="tabpanel" aria-labelledby="custom-nav-home-tab">
                                          <form action="<?php echo e(route('saveDeposit')); ?>" method="post" id="saveDeposit">
                                                <?php echo e(csrf_field()); ?>

                                                <div style="margin-top: 2%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                        <img src="qr/<?php echo e($det->bitcoin_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 10%;">
                                                        <h5 style="margin-bottom:-20px; margin-left: 2%; margin-top:10px; font-weight:bold;">Make Deposit to the Bitcoin Wallet below</h5><br>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" name="tag" value="BTC">
                                                            <input type="hidden" name="tab" value="1">
                                                            <input id="link1" name="address" style="background-color: #f3f0f0;" type="text"  placeholder="<?php echo e($det->bitcoin_address); ?>" value="<?php echo e($det->bitcoin_address); ?>" class="form-control link">
                                                            </div>
                                                        </div>
                                                        
                                                        <button type="button" style="margin-left: 3%; margin-top:6px; margin-bottom:40px;" class="btn btn-primary" onclick="copyToClipboard()">Copy Bitcoin Address</button>   
                                                        <label id="l1" for="" style="display:none;">Copied!!</label>                           
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                          
                                                            <input type="hidden" id="b_val" value="<?php echo e($det->bitcoin_value); ?>">
                                                            <input type="hidden"  name="crypto_value" id="crypto_value">
                                                            <input type="text"  id="btc_value" placeholder="Value in BTC is displayed here" disabled="" class="form-control"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9"><input id="usd" style="margin-top:20px;" required="" type="number" name="amount" placeholder="Enter Amount in USD" class="form-control"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9"><input name="transaction_id" style="background-color: #f3f0f0; margin-top:20px;" type="text" required="" placeholder="Paste the transferred BTC Transaction ID Here" class="form-control"></div>
                                                        </div>
                                                        <button type="submit" style="margin-left: 3%; margin-top:6px; margin-bottom:30px;" class="save btn btn-warning">Click Here To Deposit</button>
                                                    </div>
                                            
                                          </form>
                                            
                                        </div>
                                        <div class="tab-pane fade" id="custom-nav-eth" role="tabpanel" aria-labelledby="custom-nav-eth-tab">
                                             <form action="<?php echo e(route('saveDeposit')); ?>" method="post" id="saveDeposit">
                                                    <div style="margin-top: 2%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                        <img src="qr/<?php echo e($det->etherium_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 10%;">
                                                        <h5 style="margin-bottom:-20px; margin-left: 2%; margin-top:10px; font-weight:bold;">Make deposit to the Etherium Wallet below</h5><br>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" name="tag" value="ETH">
                                                            <input type="hidden" name="tab" value="2">
                                                            <input style="background-color: #f3f0f0;" type="text" name="address" id="link2"  placeholder="<?php echo e($det->etherium_address); ?>" value="<?php echo e($det->bitcoin_address); ?>" class="form-control link">
                                                            </div>
                                                        </div>
                                                        
                                                        <button type="button" style="margin-left: 3%; margin-top:6px; margin-bottom:40px;" class="btn btn-primary" onclick="copyToClipboard1()">Copy Etherium Address</button>
                                                        <label id="l2" for="" style="display:none;">Copied!!</label>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" id="e_val" value="<?php echo e($det->etherium_value); ?>">
                                                            <input type="hidden"  name="crypto_value" id="crypto_value1">
                                                            <input type="text" id="eth_value" name="disabled-input" placeholder="Value in ETH is displayed here" disabled="" class="form-control"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9"><input id="usd1" style="margin-top:20px;" required="" type="number" name="amount" placeholder=" Enter Amount in USD" class="form-control"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9"><input name="transaction_id" style="background-color: #f3f0f0; margin-top:20px;" required="" type="text" placeholder="Paste the transferred ETH Transaction ID Here" class="form-control"></div>
                                                        </div>
                                                        <button type="submit" style="margin-left: 3%; margin-top:6px; margin-bottom:30px;" class="save btn btn-warning">Click Here To Deposit</button>
                                                    </div>
                                             </form>
                                            
                                        </div>
                                        <div class="tab-pane fade" id="custom-nav-ltc" role="tabpanel" aria-labelledby="custom-nav-ltc-tab">
                                            <form action="<?php echo e(route('saveDeposit')); ?>" method="post" id="saveDeposit">
                                                    <div style="margin-top: 2%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                        <img src="qr/<?php echo e($det->litecoin_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 10%;">
                                                        <h5 style="margin-bottom:-20px; margin-left: 2%; margin-top:10px; font-weight:bold;">Make deposit to the Litecoin Wallet below</h5><br>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" name="tag" value="LTC">
                                                            <input type="hidden" name="tab" value="3">
                                                            <input style="background-color: #f3f0f0;" id="link3" name="address" type="text" placeholder="<?php echo e($det->bitcoin_address); ?>" value="<?php echo e($det->litecoin_address); ?>" class="form-control link">
                                                            </div>
                                                        </div>
                                                        
                                                        <button type="button" style="margin-left: 3%; margin-top:6px; margin-bottom:40px;" class="btn btn-primary" onclick="copyToClipboard2()">Copy Litecoin Address</button>
                                                        <label id="l3" for="" style="display:none;">Copied!!</label>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" id="l_val" value="<?php echo e($det->litecoin_value); ?>">
                                                            <input type="hidden"  name="crypto_value" id="crypto_value2">
                                                            <input type="text" id="ltc_value" name="disabled-input" placeholder="Value in LTC is displayed here" disabled="" class="form-control"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" name="tag" value="LTC">
                                                            <input id="usd2" style="margin-top:20px;" type="number" required="" name="amount" placeholder="Enter Amount in USD" class="form-control">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9"><input name="transaction_id" style="background-color: #f3f0f0; margin-top:20px;" required="" type="text" placeholder="Paste the Transferred LTC transaction ID Here" class="form-control"></div>
                                                        </div>
                                                        <button type="submit" style="margin-left: 3%; margin-top:6px; margin-bottom:30px;" class="save btn btn-warning">Click Here To Deposit</button>
                                                  
                                                    </div>
                                            </form>
                                           
                                        </div>

                                        <div class="tab-pane fade" id="custom-nav-tron" role="tabpanel" aria-labelledby="custom-nav-tron-tab">
                                            <form action="<?php echo e(route('saveDeposit')); ?>" method="post" id="saveDeposit">
                                                    <div style="margin-top: 2%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                        <img src="qr/<?php echo e($det->tron_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 10%;">
                                                        <h5 style="margin-bottom:-20px; margin-left: 2%; margin-top:10px; font-weight:bold;">Make deposit to the Tron Wallet below</h5><br>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">

                                                            <input id="link4" style="background-color: #f3f0f0;" name="address" type="text"  placeholder="<?php echo e($det->tron_address); ?>" value="<?php echo e($det->tron_address); ?>" class="form-control link">
                                                            </div>
                                                        </div>
                                                        
                                                        <button type="button" style="margin-left: 3%; margin-top:6px; margin-bottom:40px;" class="btn btn-primary" onclick="copyToClipboard3()">Copy Tron Address</button>
                                                        <label id="l4" for="" style="display:none;">Copied!!</label>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" id="t_val" value="<?php echo e($det->tron_value); ?>">
                                                            <input type="hidden"  name="crypto_value" id="crypto_value3">
                                                            <input type="text" id="tron_value" name="disabled-input" placeholder="Value in TRON is displayed here" disabled="" class="form-control"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" name="tag" value="TRON">
                                                            <input type="hidden" name="tab" value="4">
                                                            <input id="usd3" style="margin-top:20px;" type="number" name="amount" required="" placeholder=" Enter Amount in USD" class="form-control">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9"><input name="transaction_id" style="background-color: #f3f0f0; margin-top:20px;" required="" type="text" placeholder="Paste the transferred TRON Transaction ID Here" class="form-control"></div>
                                                        </div>
                                                        <button type="submit" style="margin-left: 3%; margin-top:6px; margin-bottom:30px;" class="save btn btn-warning">Click Here To Deposit</button>
                                                
                                                    </div>
                                            </form>
                                            
                                        </div>

                                        <div class="tab-pane fade" id="custom-nav-xrp" role="tabpanel" aria-labelledby="custom-nav-xrp-tab">
                                            <form action="<?php echo e(route('saveDeposit')); ?>" method="post" id="saveDeposit">
                                                    <div style="margin-top: 2%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                        <img src="qr/<?php echo e($det->xrp_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 10%;">
                                                        <h5 style="margin-bottom:-20px; margin-left: 2%; margin-top:10px; font-weight:bold;">Make deposit to the XRP Wallet below</h5><br>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input id="link5" style="background-color: #f3f0f0;" name="address" type="text" placeholder="<?php echo e($det->bitcoin_address); ?>" value="<?php echo e($det->xrp_address); ?>" class="form-control link">
                                                            </div>
                                                        </div>
                                                        
                                                        <button type="button" style="margin-left: 3%; margin-top:6px; margin-bottom:40px;" class="btn btn-primary" onclick="copyToClipboard4()">Copy Xrp Address</button>
                                                        <label id="l5" for="" style="display:none;">Copied!!</label>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" id="x_val" value="<?php echo e($det->xrp_value); ?>">
                                                            <input type="hidden"  name="crypto_value" id="crypto_value4">
                                                            <input type="text" id="xrp_value" name="disabled-input" placeholder="Value in XRP is displayed here" disabled="" class="form-control"></div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" name="tag" value="XRP">
                                                            <input type="hidden" name="tab" value="5">
                                                            <input id="usd4" style="margin-top:20px;" required="" type="number" name="amount" placeholder=" Enter Amount in USD" class="form-control">
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9"><input name="transaction_id" style="background-color: #f3f0f0; margin-top:20px;" required="" type="text" placeholder="Paste the transferred XRP Transaction ID" class="form-control"></div>
                                                        </div>
                                                        <button type="submit" style="margin-left: 3%; margin-top:6px; margin-bottom:30px;" class="save btn btn-warning">Click Here To Deposit</button>
                                                    </div>
                                            </form>
                                            
                                        </div>
                                        
                                    </div>
                                     
                                </div>
                            </div>
                        </div>
                    </div>
                     
          </div>
          <!--Row-->

         
        </div>
        <!---Container Fluid-->
      </div>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>VANGUARDS INVEST &copy; 2017 All Right Reserved
              <b><a href="#" target="_blank"></a></b>
            </span>
          </div>
        </div>
      </footer>
      <!-- Footer -->
    </div>
  </div>

  <!-- Scroll to top -->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script type="text/javascript">
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
            
        
        });

   
        //BTC calc
        $(document).on("change keyup", "#usd", function(){
            var fee = parseFloat($('#usd').val());
            var b_val = parseInt($('#b_val').val());
            var res = parseFloat($('#b_val').val()) / 100000000;
            $('#btc_value').val( fee * res);
            $('#crypto_value').val( fee * res);
        });

         //ETH calc
        $(document).on("change keyup", "#usd1", function(){
            var fee = parseFloat($('#usd1').val());
            var b_val = parseInt($('#e_val').val());
            var res = parseFloat($('#e_val').val()) / 100000000;
            $('#eth_value').val( fee * res);
            $('#crypto_value1').val( fee * res);
        });

         //LTC calc
        $(document).on("change keyup", "#usd2", function(){
            var fee = parseFloat($('#usd2').val());
            var b_val = parseInt($('#l_val').val());
            var res = parseFloat($('#l_val').val()) / 100000000;
            $('#ltc_value').val( fee * res);
            $('#crypto_value2').val( fee * res);
        });

         //TRON calc
        $(document).on("change keyup", "#usd3", function(){
            var fee = parseFloat($('#usd3').val());
            var b_val = parseInt($('#t_val').val());
            var res = parseFloat($('#t_val').val()) / 100000000;
            $('#tron_value').val( fee * res);
            $('#crypto_value3').val( fee * res);
         });

         //XRP calc
        $(document).on("change keyup", "#usd4", function(){
            var fee = parseFloat($('#usd4').val());
            var b_val = parseInt($('#x_val').val());
            var res = parseFloat($('#x_val').val()) / 100000000;
            $('#xrp_value').val( fee * res);
            $('#crypto_value4').val( fee * res);
        });

    

        // Clipboard
        function copyToClipboard(){
            $('#link1').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l1').show()
           setTimeout(function(){
              $('#l1').hide();
            },3000)
        }

        function copyToClipboard1(){
            $('#link2').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l2').show()
           setTimeout(function(){
              $('#l2').hide();
            },3000)
        }

        function copyToClipboard2(){
            $('#link3').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l3').show()
           setTimeout(function(){
              $('#l3').hide();
            },3000)
        }


        function copyToClipboard3(){
            $('#link4').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l4').show()
           setTimeout(function(){
              $('#l4').hide();
            },3000)
        }

        function copyToClipboard4(){
            $('#link5').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l5').show()
           setTimeout(function(){
              $('#l5').hide();
            },3000)
        }
    
    
        </script>
    
  <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
  <script src="<?php echo e(asset('js/ruang-admin.min.js')); ?>"></script>
   
</body>

</html>