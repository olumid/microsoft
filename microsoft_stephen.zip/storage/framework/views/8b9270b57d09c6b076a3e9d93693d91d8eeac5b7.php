<div id="form_confirmDeposit" class="modal fade"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tag" style="text-align: center"></h5>
                
            </div>
            <div class="modal-body">
                   <form action="#" class="form-horizontal" id="deposits" method="post>
                    <div class="col-12 col-md-9" style="margin-top: 30px;">
                        <img style=" width: 200px; height: 200px" id="pict" src="" alt="NULL"/><br/>
                       
                    </div>
                    <input type="hidden" name="amount" id="amount">
                    <input type="hidden" name="types" id="types">
                    <input type="hidden" name="address1" id="address1">
                    <div class="form-group">
                        <div class="col-12 col-md-12" style="margin-top: 10px;">
                            <textarea style="border: 2px solid white; font-weight: bold" readonly name="" id="tag1" cols="48" rows="3"></textarea>
                        </div>    
                    </div>    
                    
                     <div class="form-group">
                        <div class="col-12 col-md-12">
                            <input id="link4" style="background-color: #f3f0f0; margin-top:10px;" name="address" type="text" value="" class="form-control link">
                       <button type="button" style="margin-left: 3%; margin-top: 15px; margin-bottom:40px;" class="btn btn-primary" onclick="copyToClipboard3()">Copy To Clipboard</button>
                        <label id="l4" for="" style="color: green;display:none; float: right;  margin-top: 12px;">Copied!!</label>
                        </div>  
                     </div>
                                          

                     <div class="col-12 col-md-12" style="margin-top:-20px; ">
                        <label for="" style="font-size:17px; font-weight: bold;">Transactions ID : <span id="tag2"></span> </label>
                        <label for="" style="font-size:17px; margin-top: 17px;">Contact us with the Transaction ID for faster confirmation</label>
                     </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary btn-done" id="btn-editCredit">DONE</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>