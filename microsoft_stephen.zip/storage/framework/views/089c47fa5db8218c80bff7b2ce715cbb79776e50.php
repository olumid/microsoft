<?php if(count($plan)> 0): ?>
<table id="bootstrap-data-table-export" class="table table-striped table-bordered">
    <thead>
        <tr>
            <th><i class="fa fa-list-ol"></i> S/N</th>
            <th><i class="fa fa-btc"></i> Plan</th>
            <th><i class="fa fa-money"></i> Max Deposit</th>
            <th><i class="fa fa-money"></i> Min Deposit</th>
            <th><i class="fa fa-percent"></i> Profit</th>
            <th><i class="fa fa-percent"></i> Duration</th>
            <th>Action</th>
            <th>Action</th>

        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $plan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($key+1); ?></td>
            <td><?php echo e($list->plan_name); ?></td>
            <td><?php echo e($list->min_deposit); ?></td>
            <td><?php echo e($list->max_deposit); ?></td>
            <td><?php echo e($list->profit); ?></td>
            <td><?php echo e($list->duration); ?></td>
            <td>
                <button class="btn btn-success btn-xs btn-editPlan" data-id="<?php echo e($list->plan_id); ?>" data-name="<?php echo e($list->plan_name); ?>" data-max="<?php echo e($list->max_deposit); ?>" data-min="<?php echo e($list->min_deposit); ?>"  data-profit="<?php echo e($list->profit); ?>"><i class="fa fa-edit"></i> Edit</button>
            </td>
            <td>
                <button class="btn btn-danger btn-xs btn-deletePlan" data-id="<?php echo e($list->plan_id); ?>" data-name="<?php echo e($list->plan_name); ?>" data-max="<?php echo e($list->max_deposit); ?>" data-min="<?php echo e($list->min_deposit); ?>"  data-profit="<?php echo e($list->profit); ?>"><i class="fa fa-trash-o"></i> Delete</button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>

        <?php else: ?>
            <p style="color: orangered; font-size: 25px; font-weight: bold; margin-top: 30px; text-align: center">Error! No Entry Found, Try Again  </p>
        <?php endif; ?>


    <script src="<?php echo e(asset('vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('vendors/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/init-scripts/data-table/datatables-init.js')); ?>"></script>