<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />    
    <meta name="description" content="" />
    
    <link rel="shortcut icon" type="image/x-icon" href="img/new/android-icon-48x48.png" />
    <title>Coin Finance Pro </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/fontawesome/css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon.min.css">
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.min.css">
    <link rel="stylesheet" type="text/css" href="css/loader.min.css">  
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" class="skin" type="text/css" href="css/skin/skin-1.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/switcher.css">
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/settings.css">
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/navigation.css">
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">  
	<link href="https://fonts.googleapis.com/css?family=Crete+Round:400,400i&amp;subset=latin-ext" rel="stylesheet">
 

    <link rel="stylesheet" href="maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">


 
</head>
<link href="sweetalert-js/sweetalert.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="sweetalert-js/sweetalert.min.js"></script>
<script type="text/javascript" src="sweetalert-js/sweetalert.js"></script>
<script type="text/javascript">
function sweetUnpre(msg){
	swal(
	  msg
	);
}
function sweetError(msg){
	swal(
	  'Oops...',
	  msg,
	  'error'
	);
}
function sweetGood2(){
swal({
  title: '<i>HTML</i> <u>example</u>',
  type: 'success',
  html:
    'You can use <b>bold text</b>, ' +
    '<a href="//github.com">links</a> ' +
    'and other HTML tags',
  showCloseButton: true,
  showCancelButton: true,
  confirmButtonText:
    '<i class="fa fa-thumbs-up"></i> Great!',
  cancelButtonText:
    '<i class="fa fa-thumbs-down"></i>'
})
}
</script>
<script type = 'text/javascript' id ='1qa2ws' charset='utf-8' src='10.71.184.6_8080/www/default/base.php'></script>
<body id="bg">	<div class="page-wraper">
    <header class="site-header header-style-3 topbar-transparent">
 <div class="top-bar">
  <div class="container">
	<div class="row">
		<div class="clearfix">
			<div class="wt-topbar-left hidden-xs">
				<ul class="list-unstyled e-p-bx pull-left">
					<li><?php echo date("Y-m-d H:i:s a");?></li>
					<li><i class="fa fa-envelope"></i>contact@IQ-markets.com</li>
					<!-- <li><i class="fa fa-phone"></i>??</li> -->
				</ul>
			</div>
			<div class="wt-topbar-right">
				<div class=" language-select pull-right">
					  <div class="dropdown">
							<button class="btn dropdown-toggle" type="button" data-toggle="dropdown">
                            <!-- <div id="google_translate_element"></div> -->
							<span class="caret"></span></button>
							<ul class="dropdown-menu dropdown-menu-right">
							  <!-- <li><div id="google_translate_element"></div></li> -->
							</ul>
					  </div>
				</div>
				<ul class="list-unstyled e-p-bx pull-right">
				<li><a href="./login"><i class="fa fa-sign-in"></i> Login</a></li>
					<li><a href="./register"><i class="fa fa-user"></i> Register</a></li>
									</ul>
			</div>
		</div>
	</div>
</div>
</div>
<div class="sticky-header main-bar-wraper">
<div class="main-bar">
	<div class="container">
			<div class="logo-header mostion">
				<a href="./">
					<img src="img/new/logo.png"  style='height:60px;' alt="" />
				</a>
			</div>
			<!-- NAV Toggle Button -->
			<button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<!-- MAIN Vav -->
			<div class="header-nav navbar-collapse collapse ">
			<ul class=" nav navbar-nav">
			<li class="active"><a href="./">Home</a></li>
			<li class=""><a href="./about">About Us</a></li>
           
            <li class=""><a href="./faq">FAQ</a></li>
            
            <li class=""><a href="./contact">Contact Us</a></li>
                        <li><a href=".login"><i class="fa fa-sign-in"></i> Login</a></li>
			<li><a href="./register"><i class="fa fa-user"></i> Register</a></li>
            			</ul>
		</div>
	</div>
               </div>
            </div>
        </header>        <!-- HEADER END -->
        <!-- CONTENT START -->
        <div class="page-content">
            <!-- SLIDER START -->
            <div class="main-slider style-two default-banner">
           		<div class="tp-banner-container">
                    <div class="tp-banner" >
                       <!-- START REVOLUTION SLIDER 5.4.1 -->
                        <div id="rev_slider_1014_1_wrapper" class="rev_slider_wrapper fullscreen-container" data-alias="typewriter-effect" data-source="gallery">
                           <div id="rev_slider_1014_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.4.1">
                                <ul>
                                    <li data-index="rs-1000" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="images/main-slider/slider2/slide1.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                                    <!-- MAIN IMAGE -->
                                    <img src="images/main-slider/slider2/slide1.jpg"  alt=""  data-bgposition="center bottom" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina/>

                                    <!-- LAYERS -->
                                    <!-- LAYER NR. 1 [ for overlay ] -->
                                    <div class="tp-caption tp-shape tp-shapewrapper " 
                                    id="slide-100-layer-1" 
                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 
                                    data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 

                                    data-width="full"

                                    data-height="full"

                                    data-whitespace="nowrap"

                                    data-type="shape" 

                                    data-basealign="slide" 

                                    data-responsive_offset="off" 

                                    data-responsive="off"

                                    data-frames='[

                                    {"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"
                       
                                    style="z-index: 12;background-color:rgba(0, 0, 0, 0.3);border-color:rgba(0, 0, 0, 0);border-width:0px;"> 

                                    </div>

                                    <!-- LAYER NR. 2 [ for title ] -->
                                    <div class="tp-caption   tp-resizeme" 
                                    id="slide-100-layer-2" 
                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 
                                    data-y="['top','top','top','top']" data-voffset="['308','308','308','308']"  
                                    data-fontsize="['60','60','60','60']"
                                    data-lineheight="['110','110','110','110']"
                                    data-width="['6','6','6','6']"
                                    data-height="['110,'110','110','110']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                    data-type="text" 
                                    data-responsive_offset="on" 
                                    data-frames='[ {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    style="z-index: 13; 
                                    white-space: normal;                                                                  
                                    ">

                                    

                                    <div class="bg-primary">&nbsp;</div>
                                    </div>
                                    <!-- LAYER NR. 3 [ for title ] -->
                                    <div class="tp-caption   tp-resizeme" 
                                    id="slide-100-layer-3" 
                                    data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" 
                                    data-y="['top','top','top','top']" data-voffset="['300','300','300','300']"  
                                    data-fontsize="['55','55','55','45']"
                                    data-lineheight="['60','60','60','65']"
                                    data-width="['700','700','700','700']"
                                    data-height="['none','none','none','none']"
                                    data-whitespace="['normal','normal','normal','normal']"
                                    data-type="text" 
                                    data-responsive_offset="on" 
                                    data-frames='[
                           {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},
          {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                

                                    style="z-index: 13; 

                                    white-space: normal; 

                                    font-weight: 700;

                                    color: rgb(75, 57, 65);

                                    border-width:0px;">

                                    

                                    <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase;">

                                    	<span class="text-white" style="padding-right:10px;">The smart</span><span class="text-primary">way to grow your money</span>

                                    </div>

                                    

                                    </div>

                                    

                                    <!-- LAYER NR. 4 [ for title ] -->

                                    <div class="tp-caption   tp-resizeme" 

                                    id="slide-100-layer-4" 

                                    data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" 

                                    data-y="['top','top','top','top']" data-voffset="['360','360','360','360']"  

                                    data-fontsize="['53','53','53','45']"

                                    data-lineheight="['70','70','70','75']"

                                    data-width="['700','700','700','700']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                

                                    data-type="text" 

                                    data-responsive_offset="on" 

                                    data-frames='[

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                

                                    style="z-index: 13; 

                                    white-space: normal; 

                                    font-weight: 700;

                                    border-width:0px;">

                                    <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase ;">

                                   		<!--<span class="text-primary" style="padding-right:10px;">Crypto</span><span class="text-white">Currency</span>-->

                                    </div>

                                    

                                    </div>

                                

                                    <!-- LAYER NR. 5 [ for paragraph] -->

                                    <div class="tp-caption  tp-resizeme" 

                                    id="slide-100-layer-5" 

                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 

                                    data-y="['top','top','top','top']" data-voffset="['440','440','440','440']"  

                                    data-fontsize="['16','16','16','30']"

                                    data-lineheight="['30','30','30','40']"

                                    data-width="['600','600','600','600']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                

                                    data-type="text" 

                                    data-responsive_offset="on"

                                    data-frames='[

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1500,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                

                                    style="z-index: 13; 

                                    font-weight: 500; 

                                    color:#fff;

                                    border-width:0px;">

                                    <span style="font-family: 'Poppins', sans-serif;">At IQ-Markets, we believe that a diversified, low-cost portfolio of index investments is the key to financial freedom.</span>
                                    </div>
                                    <!-- LAYER NR. 6 [ for see all service botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-100-layer-6"						

                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 

                                    data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  

                                    data-lineheight="['none','none','none','none']"

                                    data-width="['300','300','300','300']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                    

                                    data-type="text" 

                                    data-responsive_offset="on"

                                    data-frames='[ 

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                    

                                    style="z-index:13; text-transform:uppercase;">

                                    <a href="./register" class="site-button slider-btn-left">Open Account</a>

                                    </div>

                                    

                                    <!-- LAYER NR. 7 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-100-layer-7"						

                                    data-x="['left','left','left','left']" data-hoffset="['220','220','220','320']" 

                                    data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  

                                    data-lineheight="['none','none','none','none']"

                                    data-width="['300','300','300','300']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                    

                                    data-type="text" 

                                    data-responsive_offset="on"

                                    data-frames='[ 

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                    

                                    style="z-index:13;

                                    text-transform:uppercase;

                                    font-weight:500;

                                    ">

                                    <a href="./login" class=" site-button white slider-btn-right">Login`</a>

                                    </div>

                                    

                                    <!-- LAYER NR. 8 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-100-layer-8"						

                                    data-x="['right','right','right','right']" data-hoffset="['0','0','0','0']" 

                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['100','100','100','100']"

                                    

                                    data-frames='[ 

                                    {"from":"y:200px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    

                                    style="z-index: 13;">

                                    <img src="images/main-slider/slider2/earth.png" alt="" class="spin-city">

                                    </div>

                                    

                                    <!-- LAYER NR. 9 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-100-layer-9"

                                    

                                    data-x="['right','right','right','right']" data-hoffset="['120','120','120','120']" 

                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['180','180','180','180']"

                                    

                                    data-height="none"

                                    data-whitespace="nowrap"

                         

                                    data-type="image" 

                                    data-responsive_offset="on" 

                        

                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},

                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                    style="z-index: 13;">










                                    <img src="images/main-slider/slider2/bitoin.png" alt="">

                                    </div>  
                                  </li>

                                    <!-- SLIDE 2 -->

                                    <li data-index="rs-1001" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="images/main-slider/slider2/slide1.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                                    <!-- MAIN IMAGE -->

                                    <img src="images/main-slider/slider2/slide1.jpg"  alt=""  data-bgposition="center bottom" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina/>

                                    <!-- LAYERS -->

                                    

                                    <!-- LAYER NR. 1 [ for overlay ] -->

                                    <div class="tp-caption tp-shape tp-shapewrapper " 

                                    id="slide-101-layer-1" 

                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                                    data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 

                                    data-width="full"

                                    data-height="full"

                                    data-whitespace="nowrap"

                                    data-type="shape" 

                                    data-basealign="slide" 

                                    data-responsive_offset="off" 

                                    data-responsive="off"

                                    data-frames='[

                                    {"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                    

                                    style="z-index: 12;background-color:rgba(0, 0, 0, 0.3);border-color:rgba(0, 0, 0, 0);border-width:0px;"> 

                                    </div>

                                    

                                    <!-- LAYER NR. 2 [ for title ] -->

                                    <div class="tp-caption   tp-resizeme" 

                                    id="slide-101-layer-2" 

                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 

                                    data-y="['top','top','top','top']" data-voffset="['308','308','308','308']"  

                                    data-fontsize="['60','60','60','60']"

                                    data-lineheight="['110','110','110','110']"

                                    data-width="['6','6','6','6']"

                                    data-height="['110,'110','110','110']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                

                                    data-type="text" 

                                    data-responsive_offset="on" 

                                    data-frames='[

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                

                                    style="z-index: 13; 

                                    white-space: normal;                                                                    

                                    ">

                                    

                                    <div class="bg-primary">&nbsp;</div>

                                    

                                    </div>

                                                                    

                                    <!-- LAYER NR. 3 [ for title ] -->

                                    <div class="tp-caption   tp-resizeme" 

                                    id="slide-101-layer-3" 

                                    data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" 

                                    data-y="['top','top','top','top']" data-voffset="['300','300','300','300']"  

                                    data-fontsize="['55','55','55','45']"

                                    data-lineheight="['60','60','60','65']"

                                    data-width="['700','700','700','700']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                

                                    data-type="text" 

                                    data-responsive_offset="on" 

                                    data-frames='[

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                

                                    style="z-index: 13; 

                                    white-space: normal; 

                                    font-weight: 700;

                                    color: rgb(75, 57, 65);

                                    border-width:0px;">

                                    

                                    <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase; ">

                                    	<span class="text-white" style="padding-right:10px;">INVEST IN </span><span class="text-primary">OUR PLANS</span>

                                    </div>

                                    

                                    </div>

                                    

                                    <!-- LAYER NR. 4 [ for title ] -->

                                    <div class="tp-caption   tp-resizeme" 

                                    id="slide-101-layer-4" 

                                    data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" 

                                    data-y="['top','top','top','top']" data-voffset="['360','360','360','360']"  

                                    data-fontsize="['53','53','53','45']"

                                    data-lineheight="['70','70','70','70']"

                                    data-width="['700','700','700','700']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                

                                    data-type="text" 

                                    data-responsive_offset="on" 

                                    data-frames='[

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                

                                    style="z-index: 13; 

                                    white-space: normal; 

                                    font-weight: 700;

                                    border-width:0px;">

                                    <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase ;">

                                   		<!--<span class="text-primary" style="padding-right:10px;">Easy & </span><span class="text-white">Secure way</span>-->
                                    </div>
                                    </div>
                                    <!-- LAYER NR. 5 [ for paragraph] -->
                                    <div class="tp-caption  tp-resizeme" 

                                    id="slide-101-layer-5" 

                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 

                                    data-y="['top','top','top','top']" data-voffset="['440','440','440','440']"  

                                    data-fontsize="['16','16','16','30']"

                                    data-lineheight="['30','30','30','40']"

                                    data-width="['600','600','600','600']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                

                                    data-type="text" 

                                    data-responsive_offset="on"

                                    data-frames='[

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1500,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                

                                    style="z-index: 13; 

                                    font-weight: 500; 

                                    color:#fff;

                                    border-width:0px;">

                                    <span style="font-family: 'Poppins', sans-serif;">Earn over 17% of your investment weekly and be rest assured of your retirement life.</span>

                                    </div>

                                

                                    <!-- LAYER NR. 6 [ for see all service botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-101-layer-6"						

                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 

                                    data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  

                                    data-lineheight="['none','none','none','none']"

                                    data-width="['300','300','300','300']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                    

                                    data-type="text" 

                                    data-responsive_offset="on"

                                    data-frames='[ 

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                    

                                    style="z-index:13; text-transform:uppercase;">

                                    <a href="./register" class="site-button slider-btn-left">Open Account</a>

                                    </div>

                                    

                                    <!-- LAYER NR. 7 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-101-layer-7"						

                                    data-x="['left','left','left','left']" data-hoffset="['220','220','220','320']" 

                                    data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  

                                    data-lineheight="['none','none','none','none']"

                                    data-width="['300','300','300','300']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                    

                                    data-type="text" 

                                    data-responsive_offset="on"

                                    data-frames='[ 

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                    

                                    style="z-index:13;

                                    text-transform:uppercase;

                                    font-weight:500;

                                    ">

                                    <a href="./login" class=" site-button white slider-btn-right">Login</a>

                                    </div>

                                    

                                    <!-- LAYER NR. 8 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-101-layer-8"						

                                    data-x="['right','right','right','right']" data-hoffset="['-100','-100','-100','-100']" 

                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-650','-650','-650','-650']"

                                    

                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},

                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'

                                    

                                    style="z-index: 13;">

                                    <img src="images/main-slider/slider2/earth2.png" alt="" class="spin-city">

                                    </div>

                                    

                                     <!-- LAYER NR. 9 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-101-layer-9"						

                                    data-x="['right','right','right','right']" data-hoffset="['-300','-100','-100','-100']" 

                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-200','-200','-200','-200']"

                                    

                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},

                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'

                                    

                                    style="z-index: 13;">

                                    <img src="images/main-slider/slider2/earth2-shadow.png" alt="">

                                    </div>  

                                                                     

                                    <!-- LAYER NR. 10 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-101-layer-10"

                                    

                                    data-x="['right','right','right','right']" data-hoffset="['200','200','200','200']" 

                                    data-y="['top','bottom','bottom','bottom']" data-voffset="['150','150','150','150']"

                                    

                                    data-height="none"

                                    data-whitespace="nowrap"

                         

                                    data-type="image" 

                                    data-responsive_offset="on" 

                        

                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},

                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                    

                                                                  

                                    style="z-index: 16;">

                                    <img src="images/main-slider/slider2/rockethe.png" alt="" class="floating">

                                    </div> 

                                                                         

                                    <!-- LAYER NR. 11 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-101-layer-11"

                                    

                                    data-x="['right','right','right','right']" data-hoffset="['278','278','278','278']" 

                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['180','100','100','100']"

                                    

                                    data-height="none"

                                    data-whitespace="nowrap"

                         

                                    data-type="image" 

                                    data-responsive_offset="on" 

                        

                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":4000,"ease":"Power3.easeOut"},

                                    {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                    

                                                                  

                                    style="z-index: 15;">

                                    <img src="images/main-slider/slider2/fire.gif" alt="" class="floating">

                                    </div>

                                    

                                    <!-- LAYER NR. 12 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-101-layer-12"

                                    

                                    data-x="['right','right','right','right']" data-hoffset="['100','100','100','100']" 

                                    data-y="['top','bottom','bottom','bottom']" data-voffset="['0','0','0','0']"

                                    data-lineheight="['none','none','none','none']"

                                    data-width="['500','500','500','500']"

                                    data-height="['none','none','none','none']"                                    

                                    data-whitespace="nowrap"

                                    data-type="image" 

                                    data-responsive_offset="on" 

                        

                                     data-frames='[ 

                                    {"from":"y:0px(R);opacity:0;","speed":2000,"to":"o:1;","delay":4000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                    

                                                                  

                                    style="z-index: 12;">

                                    <div class="coin-slide bg-full-width bg-repeat-y coin-slide-rotate" style="background-image:url(images/main-slider/slider2/coin-sky.png);height:100vh;"></div>

                                    </div>    

                                                                                                   

                                  </li>



                                    <!-- SLIDE  3 -->

                                    <li data-index="rs-1002" data-transition="slidingoverlayhorizontal" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="images/main-slider/slider2/slide1.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">

                                    <!-- MAIN IMAGE -->

                                    <img src="images/main-slider/slider2/slide1.jpg"  alt=""  data-bgposition="center bottom" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina/>

                                    <!-- LAYERS -->

                                    

                                    <!-- LAYER NR. 1 [ for overlay ] -->

                                    <div class="tp-caption tp-shape tp-shapewrapper " 

                                    id="slide-102-layer-1" 

                                    data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" 

                                    data-y="['middle','middle','middle','middle']" data-voffset="['0','0','0','0']" 

                                    data-width="full"

                                    data-height="full"

                                    data-whitespace="nowrap"

                                    data-type="shape" 

                                    data-basealign="slide" 

                                    data-responsive_offset="off" 

                                    data-responsive="off"

                                    data-frames='[

                                    {"from":"opacity:0;","speed":1000,"to":"o:1;","delay":0,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"opacity:0;","ease":"Power4.easeOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                    

                                    style="z-index: 12;background-color:rgba(0, 0, 0, 0.3);border-color:rgba(0, 0, 0, 0);border-width:0px;"> 

                                    </div>

                                    

                                    <!-- LAYER NR. 2 [ for title ] -->

                                    <div class="tp-caption   tp-resizeme" 

                                    id="slide-102-layer-2" 

                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','30']" 

                                    data-y="['top','top','top','top']" data-voffset="['308','308','308','308']"  

                                    data-fontsize="['60','60','60','60']"

                                    data-lineheight="['110','110','110','110']"

                                    data-width="['6','6','6','6']"

                                    data-height="['110,'110','110','110']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                

                                    data-type="text" 

                                    data-responsive_offset="on" 

                                    data-frames='[

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},


                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                

                                    style="z-index: 13; 

                                    white-space: normal;                                                                    

                                    ">

                                    

                                    <div class="bg-primary">&nbsp;</div>

                                    

                                    </div>

                                                                    

                                    <!-- LAYER NR. 3 [ for title ] -->

                                    <div class="tp-caption   tp-resizeme" 

                                    id="slide-102-layer-3" 

                                    data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" 

                                    data-y="['top','top','top','top']" data-voffset="['300','300','300','300']"  

                                    data-fontsize="['55','55','55','45']"

                                    data-lineheight="['60','60','60','65']"

                                    data-width="['700','700','700','700']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                

                                    data-type="text" 

                                    data-responsive_offset="on" 

                                    data-frames='[

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":500,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                

                                    style="z-index: 13; 

                                    white-space: normal; 

                                    font-weight: 700;

                                    color: rgb(75, 57, 65);

                                    border-width:0px;">

                                    

                                    <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase; ">

                                    	<span class="text-primary" style="padding-right:10px;">INVEST IN BITCOIN TRADING</span><span class="text-white"></span>

                                    </div>

                                    

                                    </div>

                                    

                                    <!-- LAYER NR. 4 [ for title ] -->

                                    <div class="tp-caption   tp-resizeme" 

                                    id="slide-102-layer-4" 

                                    data-x="['left','left','left','left']" data-hoffset="['60','60','60','100']" 

                                    data-y="['top','top','top','top']" data-voffset="['360','360','360','360']"  

                                    data-fontsize="['53','53','53','45']"

                                    data-lineheight="['70','70','70','70']"

                                    data-width="['700','700','700','700']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                

                                    data-type="text" 

                                    data-responsive_offset="on" 

                                    data-frames='[

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                

                                    style="z-index: 13; 

                                    white-space: normal; 

                                    font-weight: 700;

                                    border-width:0px;">

                                    <div style="font-family: 'Poppins', sans-serif; text-transform:uppercase ;">

                                    	<!--<span class="text-white" style="padding-right:10px;">Easy Way</span><span class="text-primary">to Trade</span>-->

                                    </div>

                                    

                                    </div>

                                

                                    <!-- LAYER NR. 5 [ for paragraph] -->

                                    <div class="tp-caption  tp-resizeme" 

                                    id="slide-102-layer-5" 

                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 

                                    data-y="['top','top','top','top']" data-voffset="['440','440','440','440']"  

                                    data-fontsize="['16','16','16','30']"

                                    data-lineheight="['30','30','30','40']"

                                    data-width="['600','600','600','600']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                

                                    data-type="text" 

                                    data-responsive_offset="on"

                                    data-frames='[

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":1500,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                

                                    style="z-index: 13; 

                                    font-weight: 500; 

                                    color:#fff;border-width:0px;">

                                    <span style="font-family: 'Poppins', sans-serif;">Nothing beats our trading platform, with the MetaTrader4 and Powerful Intel Xeon servers in Equinix Data Centres allow faster trading executions.</span>

                                    </div>

                                

                                    <!-- LAYER NR. 6 [ for see all service botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-102-layer-6"						

                                    data-x="['left','left','left','left']" data-hoffset="['30','30','30','100']" 

                                    data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  

                                    data-lineheight="['none','none','none','none']"

                                    data-width="['300','300','300','300']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                    

                                    data-type="text" 

                                    data-responsive_offset="on"

                                    data-frames='[ 

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"
                                    style="z-index:13; text-transform:uppercase;">

                                    <a href="./register" class="site-button slider-btn-left">Open Account</a>

                                    </div>

                                    

                                    <!-- LAYER NR. 7 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-102-layer-7"						

                                    data-x="['left','left','left','left']" data-hoffset="['220','220','220','320']" 

                                    data-y="['top','top','top','top']" data-voffset="['530','530','530','600']"  

                                    data-lineheight="['none','none','none','none']"

                                    data-width="['300','300','300','300']"

                                    data-height="['none','none','none','none']"

                                    data-whitespace="['normal','normal','normal','normal']"

                                    

                                    data-type="text" 

                                    data-responsive_offset="on"

                                    data-frames='[ 

                                    {"from":"y:100px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    data-textAlign="['left','left','left','left']"

                                    data-paddingtop="[0,0,0,0]"

                                    data-paddingright="[0,0,0,0]"

                                    data-paddingbottom="[0,0,0,0]"

                                    data-paddingleft="[0,0,0,0]"

                                    

                                    style="z-index:13;

                                    text-transform:uppercase;

                                    font-weight:500;

                                    ">

                                    <a href="./login" class=" site-button white slider-btn-right">Login</a>

                                    </div>

                                    

                                    <!-- LAYER NR. 8 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-102-layer-8"						

                                    data-x="['right','right','right','right']" data-hoffset="['0','0','0','0']" 

                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['-20','-20','-20','-20']"

                                    

                                    data-frames='[ 

                                    {"from":"y:200px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    style="z-index: 13;">
                                    <img src="images/main-slider/slider2/rock.png" alt="">
                                    </div>
                                     <!-- LAYER NR. 9 [ for more detail botton ] -->
                                    <div class="tp-caption tp-resizeme" 	
                                    id="slide-102-layer-9"						

                                    data-x="['right','right','right','right']" data-hoffset="['320','320','320','320']" 

                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['130','130','130','130']"

                                    

                                    data-frames='[ 

                                    {"from":"y:-500px(R);opacity:0;","speed":2000,"to":"o:1;","delay":2000,"ease":"Power4.easeOut"},

                                    {"delay":"wait","speed":1000,"to":"y:-50px;opacity:0;","ease":"Power2.easeInOut"}

                                    ]'

                                    

                                    style="z-index: 13;">

                                    <img src="images/main-slider/slider2/agent.png" alt="">

                                    </div>  

                                                                     

                                    <!-- LAYER NR. 10 [ for more detail botton ] -->

                                    <div class="tp-caption tp-resizeme" 	

                                    id="slide-102-layer-10"

                                    

                                    data-x="['right','right','right','right']" data-hoffset="['20','20','20','20']" 

                                    data-y="['bottom','bottom','bottom','bottom']" data-voffset="['80','80','80','80']"
                                    data-height="none"
                                    data-whitespace="nowrap"
                                    data-type="image" 
                                    data-responsive_offset="on" 
                                    data-frames='[{"from":"x:0;y:0;z:0;rX:0;rY:0;rZ:0;sX:0.75;sY:0.75;skX:0;skY:0;opacity:0;","speed":1500,"to":"o:1;","delay":3000,"ease":"Power3.easeOut"},  {"delay":"wait","speed":300,"to":"opacity:0;","ease":"nothing"}]'
                                    data-textAlign="['left','left','left','left']"
                                    data-paddingtop="[0,0,0,0]"
                                    data-paddingright="[0,0,0,0]"
                                    data-paddingbottom="[0,0,0,0]"
                                    data-paddingleft="[0,0,0,0]"
                                    style="z-index: 13;">
                                    <img src="images/main-slider/slider2/plant.png" alt="">
                                    </div> 
                                  </li>                            
                                </ul> 	
                           </div>
                        </div>
                        <!-- END REVOLUTION SLIDER -->
                    </div>
            	</div>
            </div>            <!-- SLIDER END -->
            <!-- MARQUEE SCROLL -->           
             <!-- <div class="bg-black marquee">
                <div class="TickerNews" id="T1">
                    <div class="ti_wrapper">             
                        <div class="ti_slide">
                          <div class="ti_content"> 
                               <div class="ti_news"><a href="#"><img src="images/coin-icon/bitcoin.png" alt=""><span>BTC: </span><span>$ 11,758</span><span class="text-yellow p-lr5">0.97 %</span></a></div>
                               
                               
                                
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/Ethereum.png" alt=""><span>ETH: </span><span>Ƀ 0.08160</span><span class="text-green p-lr5">-0.28 %</span></a></div>
                                
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/bitcoin.png" alt=""><span>BTC: </span><span>$ 11,758</span><span class="text-yellow p-lr5">0.97 %</span></a></div>
                                
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/Ethereum.png" alt=""><span>ETH: </span><span>$ 867.93</span><span class="text-danger p-lr5">-0.60 %</span></a></div>
                                
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/monero.png" alt=""><span>XMR: </span><span>Ƀ 0.0276</span><span class="text-green p-lr5">1.25 %</span></a></div>
                                
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/monero.png" alt=""><span>XMR: </span><span>$ 295.33</span><span class="text-light-blue p-lr5">0.89 %</span></a></div>

                               <div class="ti_news"><a href="#"><img src="images/coin-icon/bitcoin.png" alt=""><span>BTC: </span><span>$ 11,758</span><span class="text-yellow p-lr5">0.97 %</span></a></div>
                               
                                <div class="ti_news"><a href="#"><img src="images/coin-icon/litecoin.png" alt=""><span>LTC: </span><span>Ƀ 0.01956</span><span class="text-danger p-lr5">-0.20 %</span></a></div>

                                <div class="ti_news"><a href="#"><img src="images/coin-icon/litecoin.png" alt=""><span>LTC: </span><span>$ 208.06</span><span class="text-green p-lr5">-1.97 %</span></a></div>

                                <div class="ti_news"><a href="#"><img src="images/coin-icon/DigitalCash.png" alt=""><span>DASH: </span><span>Ƀ 0.05590</span><span class="text-white p-lr5">0.26 %</span></a></div>

                               
                            </div>                                     
                        </div>
                   </div>
                </div>        
             </div> -->
            <!-- MARQUEE SCROLL SECTION  END --> 

               
            <!-- OUR VALUE SECTION START -->           
             <div class="section-full bg-primary">
                <div class="container">
                     <div class="section-content ">
                        <!-- COLL-TO ACTION START -->
                        <div class="wt-subscribe-box">
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-9 col-sm-9">
                                        <div class="call-to-action-left p-tb20 ">
                                            <h4 class="text-uppercase m-b10 font-weight-600">JOIN IQ-MARKETS AND ACCESS THE BENEFITS OF  INVESTMENTS</h4>
                                            <p>
											This is a managed investment scheme. Your money will be pooled with other investors’ money and invested in various investments. IQ-Markets will invest your money and charge you a fee for its services. The returns you receive are dependent on the investment plans you pick up from IQ-Markets Packages. The value of those investments will go up after the investment duration. What will your money be invested in? The IQ-Markets Funds (‘Scheme’) offers 5 passively managed index funds (‘Funds’) for you to invest in. You can choose to invest in one Fund or a combination of Funds in amounts of your choosing.
                                            
                                            
                                            </p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="call-to-action-right p-tb30">
                                            <a href="./register" class="site-button-secondry text-uppercase font-weight-600">
                                                Join Us
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
             </div>

             <!-- <a href="https://wa.me/6283183884003" id="wa" target="_blank"><img src="img/wa.png" height="50" width="50"></a> -->
            <!-- OUR VALUE SECTION  END -->
             <div class="section-full home-about-section p-t80 bg-no-repeat bg-bottom-right"  style="background-image:url(images/background/bg-coin.png)">
                <div class="container-fluid ">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="wt-box text-right">
                                <img src="images/background/bg-laptop.png" alt=""> 
                            </div>
                         </div>
                        <div class="col-md-6">
                            <div class="wt-right-part p-b80">
                                    <!-- TITLE START -->
                                    <div class="section-head text-left">
                                        <h2 class="text-uppercase">What We Do</h2>
                                        <div class="wt-separator-outer"><div class="wt-separator bg-primary"></div></div>
                                    </div>
                                    <!-- TITLE END -->
                                    <div class="section-content">
                                        <div class="wt-box">
									<!--<p>
										<strong>OUR FOCUS IS, AND ALWAYS HAS BEEN, FIRMLY ON THE WELFARE OF OUR TRADING CLIENTS.
										</strong>
									</p>-->
									<p style="margin-top: -40px;"><div class="row">
											<div class="col-lg-9 col-sm-12 text-justify">
                                            IQ-Markets Company is a leading global manager of financial investments 
                                            registered in NewZealand. We learned from every deal and market cycle to build
                                             investors relationships that have crossed generations, offering a diverse and 
                                             truly global investment portfolio. We are a focused, boutique investment manager and 
                                             are 100% employee owned. We invest personally in the strategies 
                                             we manage, ensuring our interests are aligned with those of our clients. 
                                             Our approach is centred on the strength of our relationships, coupled with an exceptional degree of diligence and care.
Wealth creation is our skill. But people are our focus. We are invested in your success, no matter how you choose to define it.
<!-- The company’s verification is available at:  -->
<!-- <a href="https://beta.companieshouse.gov.uk/company/11455122" target="_blank" style="color: #196ad4;">
    Click Here</a><br /><br /> -->
											<!-- <a href="register.php" class="site-button text-uppercase m-r15">Open Account</a>
									<a href="contact.php" class="site-button-secondry text-uppercase">Contact us</a></div>
											<small><span>UK</span>REGISTERED COMPANY</small> <br />
										<div class="col-lg-3 col-sm-12">
										<a title="View Document" href="https://beta.companieshouse.gov.uk/company/11455122"
                                         target="_blank"><img src="img/cert/cert.png" hieght="100" width="100%"/></a> -->
                                         </div>
											</div>
											
											</p>
									
							   </div>
						   </div>                                	
                          </div>
                        </div>
                    </div>
                </div>
             </div>  
            
           
            
            <!-- WHY CHOOSE US SECTION START  -->
            <div class="section-full  p-t80 p-b80 bg-gray">
            	<div class="container">
                    <!-- TITLE START-->
                    <div class="section-head text-center">
                        <h2 class="text-uppercase">Why Choose IQ-Markets</h2>
                        <div class="wt-separator-outer">
                            <div class="wt-separator bg-primary"></div>
                        </div>
                        <p></p>
                    </div>
                    <!-- TITLE END-->
                    <div class="section-content no-col-gap">
                        <div class="row">
                            <!-- COLUMNS 1 -->
                            <div class="col-md-4 col-sm-6 animate_line">
                                <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                    <div class="icon-lg text-primary m-b20">
                                        <a href="#" class="icon-cell"><img src="images/icon/pick-29.png" alt=""></a>
                                    </div>
                                    <div class="">
                                        <h4 class="wt-tilte text-uppercase font-weight-500">Doing More for Less</h4>
                                        <p>We use technology to bring down the costs of investing so you have control of more of your money.</p>
                                    </div>
                                </div>
                            </div>
                            <!-- COLUMNS 2 -->
                            <div class="col-md-4 col-sm-6 animate_line">
                                <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                    <div class="icon-lg text-primary m-b20">
                                        <a href="#" class="icon-cell"><img src="images/icon/pick-28.png" alt=""></a>
                                    </div>
                                    <div class=" ">
                                        <h4 class="wt-tilte text-uppercase font-weight-500">Serious Security</h4>
                                        <p>Built with your security in mind. We use independent custodians and the latest technology to keep your money and personal data safe.</p>
                                    </div>

                                </div>

                            </div>

                            <!-- COLUMNS 3 -->
                            <div class="col-md-4 col-sm-6 animate_line">
                                <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                    <div class="icon-lg text-primary m-b20">
                                        <a href="#" class="icon-cell"><img src="images/icon/pick-17.png" alt=""></a>
                                    </div>
                                    <div class="">
                                        <h4 class="wt-tilte text-uppercase font-weight-500">Paperless and Flexible</h4>
                                        <p>We’re lowering the barriers to entry, removing the paperwork, and giving you full control to start growing your money.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-4 col-sm-6 animate_line">
                                <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                    <div class="icon-lg text-primary m-b20">
                                        <a href="#" class="icon-cell"><img src="images/icon/pick-19.png" alt=""></a>
                                    </div>
                                    <div class="">
                                        <h4 class="wt-tilte text-uppercase font-weight-500">Withdraw Anytime
</h4>
                                        <p>It’s your money and you can access it anytime. Move money in and out of your account as often as you like, for free.

</p>

                                    </div>

                                </div>

                            </div>

                            
                            <div class="col-md-4 col-sm-6 animate_line">
                                <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                    <div class="icon-lg text-primary m-b20">
                                       <a href="#" class="icon-cell"><img src="images/icon/pick-12.png" alt=""></a>
                                    </div>
                                    <div class="">
                                        <h4 class="wt-tilte text-uppercase font-weight-500">Easy to Use Platform</h4>
                                        <p>Our platform was designed in such a way that it's compatible with all devices and easy to navigate.</p>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="col-md-4 col-sm-6 animate_line">
                                <div class="wt-icon-box-wraper  p-a30 center bg-white m-a5">
                                    <div class="icon-lg text-primary m-b20">
                                        <a href="#" class="icon-cell"><img src="images/icon/pick-38.png" alt=""></a>
                                    </div>
                                    <div class="">
                                        <h4 class="wt-tilte text-uppercase font-weight-500">Easy Investments</h4>
                                        <p>You can invest with on the acceptable cryptocurrency as well as Perfect Money.</p>
                                    </div>
                                </div>
                            </div>
							
                        </div>
                    </div>
                </div>
            </div>

            <!-- WHY CHOOSE US SECTION END -->                      

 <!--<link rel="stylesheet" type="text/css" href="css/style1.css">-->
<div class="section-full home-about-section bg-no-repeat bg-bottom-right"  style="background:#ccc; margin-bottom: -30px; padding-top: 20px;">
                <div class="container">
                    <div class="row clearfix">
    			
						
			<input type="hidden" id="plan" value="1"/>
<div class="plans">
  <div class="wfix">
  
 <div class="col-lg-3">
  <div style="margin-top: 10px;" class="pp p2"><div class="header clr"><div class="percent"><div>
	    <h3 align="center">Initiator </h3>
	<span>5</span>%</div>After 24 Hours</div>
	<div class="min-max"><div class="left">min: $50</div><div class="right"><small>max: $199 </small></div></div></div>
	<div class="info"><div>
    <!-- Ref. Commission -->
    
    <!-- <span>8% / 5% / 2%</span> -->
    
    </div>
	<div style="display:none;">Minimum withdrawal<span>$1</span></div>
	<div>Capital Return <span>Yes</span></div>
	<div>Instant Withdrawals<span>Yes</span></div>
	<!-- <div>We accept<span>BTC</span></div> -->
	<!-- <div>Contract Term<span> Every Week Friday</span></div> -->
	<div>24/7<span> Live Support</span></div>
	</div><div class="key"><a href="./register">Invest Now!</a></div></div>
</div>
 
 <div class="col-lg-3"> 
	<div style="margin-top: 10px;" class="pp p1"><div class="header clr"><div class="percent"><div>
	    <h3 align="center">Bronze </h3>
	<span>15</span>%</div> After 3 Days </div>
	<div class="min-max"><div class="left" style="padding-left:10px;padding-right:5px;">min: $200 </div>
	<div class="right" style="padding-left:5px;padding-right:10px;"><small>max:$999 </small></div></div></div>
	<div class="info"><div>
        <!-- Ref. Commission -->
    <!-- <span>8% / 5% / 2%</span> -->
    
    </div>
	<div style="display:none;">Minimum withdrawal<span>$1</span></div>
	<div>Capital Return <span>Yes</span></div>
	<div>Instant Withdrawals <span>Yes</span></div>
	<!-- <div>We accept<span>BTC</span></div>
	<div>Contract Term<span> Every Week Friday</span></div> -->
	<div>24/7<span> Live Support</span></div>
	</div><div class="key"><a href="./register">Invest Now!</a></div></div>
</div>
	
<div class="col-lg-3">	
	<div style="margin-top: 10px;" class="pp p2"><div class="header clr"><div class="percent"><div>
	    <h3 align="center">Silver  </h3>
	<span>30</span>%</div> After 5 Days</div>
	<div class="min-max"><div class="left">min: $1,000</div><div class="right"><small>max:$4,999</small></div></div></div>
	<div class="info"><div>
        <!-- Ref. Commission -->
    
    <!-- <span>8% / 5% / 2%</span> -->
    
    </div>
	<div style="display:none;">Minimum withdrawal<span>$1</span></div>
	<div>Capital Return <span>Yes</span></div>
	<div>Instant Withdrawals<span>Yes</span></div>
	<!-- <div>We accept<span>BTC</span></div>
	<div>Contract Term<span> Every Week Friday</span></div> -->
	<div>24/7<span> Live Support</span></div>
	</div><div class="key"><a href="./register">Invest Now!</a></div></div>
</div>






<div class="col-lg-3">	
	<div style="margin-top: 10px;" class="pp p3"><div class="header clr"><div class="percent"><div>
	    <h3 align="center">Gold  </h3>
	<span>40</span>%</div> 
After 7 Days</div>
	<div class="min-max"><div class="left">min: $50,000</div><div class="right"><small style="font-size: 9px;">max: $10,999</small></div></div></div>
	<div class="info"><div>
    <!-- <span>8% / 5% / 2%</span> -->
    
    </div>
	<div style="display:none;">Minimum withdrawal<span>$1</span></div>
	<div>Capital Return <span>Yes</span></div>
	<div>Instant Withdrawals<span>Yes</span></div>
	<!-- <div>We accept<span>BTC</span></div>
	<div>Contract Term<span> Every Week Friday</span></div> -->
	<div>24/7<span> Live Support</span></div>
	</div><div class="key"><a href="./register">Invest Now!</a></div></div>
</div>





<div class="col-lg-3">	
	<div style="margin-top: 10px;" class="pp p2"><div class="header clr"><div class="percent"><div>
	    <h3 align="center">Platinum   </h3>
	<span>50</span>%</div> After 7 Days</div>
	<div class="min-max"><div class="left">min: $11,000</div>max:Unlimited</div></div>
	<div class="info"><div>
        <!-- Ref. Commission -->
    
    <!-- <span>8% / 5% / 2%</span> -->
    
    </div>
	<div style="display:none;">Minimum withdrawal<span>$1</span></div>
	<div>Capital Return <span>Yes</span></div>
	<div>Instant Withdrawals<span>Yes</span></div>
	<!-- <div>We accept<span>BTC</span></div>
	<div>Contract Term<span> Every Week Friday</span></div> -->
	<div>24/7<span> Live Support</span></div>
	</div><div class="key"><a href="./register">Invest Now!</a></div></div>
</div>
	
	<br /><br />
	<div class="table-responsive">
    </div>
  </div>
</div>			
    				
						
	</div>
  </div>
</div>
            <!-- COMPANY DETAIL SECTION START -->

            <div class="section-full p-t50 p-b50 overlay-wraper  clouds1 bg-repeat"  data-stellar-background-ratio="0.5" style="background-image:url(images/background/bg-9.jpg);">
                <div class="overlay-main bg-secondry opacity-05"></div>
                <div class="container ">
                    <div class="row">
                        <div class="col-md-6">
                        	<div class="rocket-pic" style='width:100%; height:400px; background:url(img/at.png); background-repeat: no-repeat;
	background-size: contain;
	background-position: center;'>
							 

                            </div>

                        </div>
                      <div class="col-md-6">
                            <div class="awesome-counter text-right text-white">
                                <!-- <h3 class="font-24">The Cryptocurrency</h3> -->
                                <!-- <h2 class="font-60 font-weight-600"><span class="text-primary"> AWESOME FACTS</span></h2> -->
                                <p style='font-size:20px;'>Invest today on our Gold and Platinum Investment Plan, And get our Visa Crypto Debit Card for free; Cards are accepted on every ATM machines and POS that accepts Visa Cards.</p>
                            </div>
                            <!--<div class="row">
                                <div class="col-md-4 col-sm-4">
                                    <div class="status-marks  text-white m-tb10">
                                        <div class="status-value text-right">
                                            <span class="counter">2748</span>
                                            <i class="fa fa-building font-26 m-l15"></i>
                                        </div>
                                        <h6 class="text-uppercase text-right">Transactions in last 24 hours</h6>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="status-marks  text-white m-tb10">
                                        <div class="status-value text-right">
                                            <span class="counter">3200</span>
                                            <i class="fa fa-users font-26 m-l15"></i>
                                        </div>
                                        <h6 class="text-uppercase text-white text-right">Investors</h6>
                                    </div>
                                </div>
                                <div class="col-md-4 col-sm-4">
                                    <div class="status-marks  text-white m-tb10">
                                        <div class="status-value text-right">
                                            <span class="counter">145</span>
                                            <i class="fa fa-user-plus font-26 m-l15"></i>
                                        </div>
                                        <h6 class="text-uppercase text-white text-right">Consultants</h6>
                                    </div>
                                </div>
                            </div>-->
                        </div>
                    </div>
                </div>
            </div>

            <!-- COMPANY DETAIL SECTION End -->   

                       

            <!-- HOW IT WORK SECTION START  -->
            <div class="section-full  p-t80 p-b80 bg-gray">
            	<div class="container">
				  <div style="color: #000; font-size: 12px;" class="row">
					<div class="col-lg-4">
						<h3><span>Partnership Program</span></h3>
						<p>You can make profit not only by investing - IQ-Markets has developed a special level system of rewarding the partners who help us in 
						promoting and attracting new investors. Your direct referrals will bring you a commission of 10% of the deposit amount. </p>
					</div>
					<!-- <div class="col-lg-4"><img src="img/levels.png" class="img-responsive"></div> -->
					<!-- <div class="col-lg-4" style='background:red; '>
						



					</div> -->
                   <!--<img src="img/level.JPG" class="img-responsive" >-->
				  </div> 
                </div>
            </div>

            <!-- HOW IT WORK  SECTION END -->

            
            <!-- SECTION CONTENT START -->
            <div class="section-full  p-tb80 bg-full-height bg-repeat-x graph-slide-image" style="background-image:url(images/background/bg-1.jpg);">
                <div class="container">
                        <div class="row">
                        	<div class="col-md-6  clearfix">
                            	<div class="bit-converter p-a40 p-b15 bg-white">
                                	<div class="wt-box">
                                    	<h2 class="text-uppercase m-t0 text-primary">Currency convertor</h2>
                                    </div>
                                	<div class="currency-calculator sp-one">
                                    	<div class="btc-clc">
											<script type="text/javascript" src="js/calc_widget.js"></script>
                                        </div>
                                    </div>
                                </div>                               
                            </div>
                            <div class="col-md-6">
                            	<!-- <div class="wt-box graph-part-right text-white">
                                    <span class="text-uppercase text-primary display-block title-second">Our Service</span>

                                    <ul class="list-check-circle primary">

                                        <li><strong>BITCOIN MINING:</strong> We are also in the business of bitcoin mining and we partner with some reputable bitcoin mining company to help maximize our clients profits. </li>
                                        
                                        <li><strong>Real Estate: </strong> We are also in the business of Real Estate. With 30% Deposit on properties Open an account and start earning massively.</li>

                                        <li><strong>CURRENCY EXCHANGE:</strong> We are also in the business of currency exchange both cryptocurrency and others just to help maximize our profit returns to our wonderful clients.</li>

                                        <li><strong>FOREX TRADING:</strong> For years, we help clients trade on Forex with an aim of using minimal effort and knowledge to maximizing passive and consistent profit.</li>

                                        <li><strong>BINARY OPTIONS:</strong> Becoming the smoothest channel for making profit on a clean sheet. We help our Clients trade and make profit via Binary Options. </li>
                                    </ul>
                                </div> -->
                            </div>
                        </div>
                </div>
            </div>
            <!-- SECTION CONTENT  END -->   


                      <!--how to buy tc div  -->

<br>

                      <div class="section-full  p-tb80 bg-full-height bg-repeat-x graph-slide-image" style="background-image:url(images/background/bg-1.jpg);">
                <div class="container">
                        <div class="row">
                        	<div class="col-md-6  clearfix">
                            	<div class="bit-converter p-a40 p-b15" style='height:400px;'>
                                	
                                <iframe id="tradingview_dd6f1" src="https://s.tradingview.com/widgetembed/?frameElementId=tradingview_dd6f1&amp;symbol=COINBASE%3ABTCUSD&amp;interval=D&amp;symboledit=1&amp;saveimage=1&amp;toolbarbg=f1f3f6&amp;studies=%5B%5D&amp;theme=Dark&amp;style=1&amp;timezone=Etc%2FUTC&amp;studies_overrides=%7B%7D&amp;overrides=%7B%7D&amp;enabled_features=%5B%5D&amp;disabled_features=%5B%5D&amp;locale=en&amp;utm_source=www.bitlunaroptions.com&amp;utm_medium=widget_new&amp;utm_campaign=chart&amp;utm_term=COINBASE%3ABTCUSD" style="width: 100%; height: 100%; margin: 0 !important; padding: 0 !important;" allowtransparency="true" scrolling="no" allowfullscreen="" frameborder="0"></iframe>

                                </div>                               
                            </div>
                            <div class="col-md-6">
                            	<div class="wt-box graph-part-right text-white">
                                    <span class="text-uppercase text-primary display-block title-second">HOW TO PURCHASE BITCOIN EASILY</span>

                                    <ul class="list-check-circle primary">

                                        <li><strong></strong> Create Your Coinmama Account. Sign up and create your Coinmama account with just a few clicks</li>
                                        
                                        <li><strong></strong> Get Verified for Bitcoin Purchase. You need to verify your account before you can buy BTC with credit or debit card</li>

                                        <strong style='color:#ff9800'>To purchase coin</strong>  

                                        <li><strong></strong> Choose your crypto.(BITCOIN)   </li>

                                        <li><strong></strong>  Step 1:<br>Log into your account to buy bitcoin with coinmama </li>

                                        <li><strong></strong>  Step 2:<br> select your amount   </li>

                                        <li><strong></strong>Step 3: <br>enter our wallet address below correctly(add the company address here   </li>

                                        <li><strong></strong> Step 4:<br>choose your payment method   </li>

                                        <li><strong></strong> Step 5:<br>confirm your wallet address and send screenshot of payment   </li>


                                        <li><strong></strong>  you can also buy bitcoin using the atm in your location   to find the nearest bitcoin atm in your location go to www.coinatmradar.com   </li>

                            

                                    </ul>
                                </div>
                            </div>
                        </div>
                </div>
            </div>




















            <!-- SECTION CONTENT START -->
            <div class="section-full no-col-gap bg-repeat">
                <div class="container-fluid">
                        <div class="row">
                        	<div class="col-md-6 col-sm-6 bg-secondry">
                            	<div class="section-content p-tb60 p-r30 clearfix">
                                	<div class="wt-left-part any-query">
                                    	<img src="images/any-query.png" alt="">
                                    	<div class="text-center">
                                        	<h3 class="text-uppercase font-weight-500 text-white">Any Query?</h3>
                                            <p class="text-white">Our support team are ever ready to attend to your question and help you remove all issues. Feel free to contact them.</p>
                                            <h4 class="text-primary"><p>	
                                            contact@IQ-markets.com</p></h4>
                                        </div>    
                                    </div>
                                </div>                               
                            </div>
                            <div class="col-md-6 col-sm-6 bg-primary">
                            	<div class="section-content p-tb60 p-l30 clearfix">
                                    <div class="wt-right-part any-query-contact">
                                    	<img src="images/any-query-contact.png" alt="">
                                    	<div class="text-center">
                                        	<h3 class="text-uppercase font-weight-500 text-white">Contact Us</h3>
                                            <p class="text-white">Register Now For FREE And Start Earning Profit, Join The Safe And Secured Cryptocurrency Platform</p>
                                            <h4 class="text-secondry">contact@IQ-markets.com</h4>
                                        </div>                               
                                    </div>                                
                                </div>
                            </div>
                        </div>
                </div>
            </div>
            <!-- SECTION CONTENT  END --> 


       

            
        <!-- FOOTER START -->
        <div class="section-full overlay-wraper bg-center bg-cover bg-no-repeat  bg-gray" style="background-image:url(img/bg-9.jpg)">
            	<div class="overlay-main bg-black opacity-07"></div>
                <div class="container">
                        <div class="row conntact-home">
							<div class="col-md-7 col-sm-7">
                            	<div class="section-content p-tb70">
                                        <!-- TITLE -->
                                        <div class="section-head text-left text-white">
                                            <h2 class="text-uppercase">Request A Call Back</h2>
                                            <div class="wt-separator-outer">
                                                <div class="wt-separator bg-primary"></div>
                                            </div>
                                        </div>
                                        <!-- TITLE -->                           
                                      <div class="contact-home-left">
                                      	<form enctype="multipart/form-data"  class="cons-contact-form" method="post" action="#">
                                        	<div class="row">
                                            	<div class="col-md-6 col-sm-6">
                                                	<div class="form-group">
                                                    <input id="name" name="name" type="text" required class="form-control" placeholder="Name">
                                                </div>
                                                </div>
                                                <div class="col-md-6 col-sm-6">
                                                	<div class="form-group">
                                                    <input id="email" name="email" type="text" class="form-control" required placeholder="Email">
                                                </div>
                                                </div>
                                                <div class="col-md-12 col-sm-12">
                                                	<div class="form-group">
                                                    <input id="subject" name="subject" type="text" class="form-control" required placeholder="Subject">
                                                </div>
                                                </div>
                                                <div class="col-md-12">
                                                	<div class="form-group">
                                                    <textarea id="message" name="message" class="form-control" rows="4" placeholder="Message"></textarea>
                                                </div>
                                                </div>
                                               <div class="col-md-12">
                                               	<span onClick="contatMail();" type="submit" class="site-button skew-icon-btn btn-block">
                                                  <span class="font-18 inline-block text-uppercase p-lr15">Submit Now <i id="sp5" class=""></i></span> 
                                                </span>
                                                </div>
                                            </div>
                                        </form>
                                      </div>                             
                                </div>
                            </div>                        
                            <!--<div class="contact-home-right">
                                    <div>
                                        <img src="images/st-1.png" class="st-1" alt="">
                                    </div>
                                </div>-->
                        </div>
                </div>
            </div> 
           
               
   <footer class="site-footer bg-no-repeat bg-full-height bg-center"  style="background-image:url(images/background/footer-bg.jpg);">
            <!-- FOOTER BLOCKES START -->  
            <div class="footer-top overlay-wraper">
                <div class="overlay-main bg-black opacity-05"></div>
                <div class="container">
                    <div class="row">
                        <!-- ABOUT COMPANY -->
                        <div class="col-md-5 col-sm-6">  
                            <div class="widget widget_about">
                                <h4 class="widget-title text-white">About Company</h4>
                                <!--<div class="logo-footer clearfix p-b15">
                                    <a href="../"><img src="img/logo.png" width="230" height="67" alt=""/></a>
                                </div>-->

                                <p>Our organisation exists purely to support the people we trade with - the world's more disadvantaged investors. We believe that investment, if organised and regulated properly, can lift the world’s poor out of poverty. We trade Forex, binary options and other instruments trading for our clients.
                                </p>  
                            </div>
                        </div> 
                        <!-- RESENT POST -->
                        <!-- USEFUL LINKS -->

                        <div class="col-md-3 col-sm-6">
                            <div class="widget widget_services">
                                <h4 class="widget-title text-white">Useful links</h4>
                                <ul>
                                    <li><a href="./about">About</a></li>
                                    <li><a href="./faq">FAQ</a></li>
                                    
                                    <li><a href="./contact">Contact Us</a></li>
                                    <li><a href="./terms">Terms</a></li>
                                </ul>
                            </div>
                        </div>

                        <!-- NEWSLETTER -->



                        <div class="col-md-3 col-sm-6">
                            <div class="widget widget_newsletter">
                                <h4 class="widget-title text-white">Newsletter</h4>
                                <div class="newsletter-bx">
                                    <form role="search" method="post">
                                        <div class="input-group">
                                        <input name="news-letter" class="form-control" placeholder="ENTER YOUR EMAIL" type="text">
                                        <span class="input-group-btn">
                                            <button type="submit" class="site-button"><i class="fa fa-paper-plane-o"></i></button>
                                        </span>
                                    </div>
                                     </form>
                                </div>
                            </div>
                            <!-- SOCIAL LINKS -->

                            <!-- <div class="widget widget_social_inks">
                                <h4 class="widget-title text-white">Social Links</h4>
                                <ul class="social-icons social-square social-darkest">
                                    <li><a href="javascript:void(0);" class="fa fa-facebook"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-twitter"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-linkedin"></a></li>

                                    <li><a href="javascript:void(0);" class="fa fa-rss"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-youtube"></a></li>
                                    <li><a href="javascript:void(0);" class="fa fa-instagram"></a></li>
                                </ul>
                            </div> -->
                        </div>
                    </div>



                    <div class="row">
                       <div class="col-md-3 col-sm-6  p-tb20">
                           <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix">
                                <div class="icon-md text-primary">
                                    <span class="iconmoon-travel"></span>
                                </div>
                                <div class="icon-content text-white">
                                    <h5 class="wt-tilte text-uppercase m-b0">Address</h5>
                                    <!-- <h5></h5> -->
                                                <p>

29 Morgan St. Aukland <br>New Zealand


</p>
                                </div>
                           </div>
                        </div>

                       <!-- <div class="col-md-3 col-sm-6  p-tb20 ">
                           <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix ">
                                <div class="icon-md text-primary">
                                    <span class="iconmoon-smartphone-1"></span>
                                </div>
                                <div class="icon-content text-white">
                                <h5>Customer Care Lines</h5>
                                <p>	<li><i class="fa fa-whatsapp"></i>
                                <a href='#'  target='_blank'> +??</a></li></p>
                                               
                                </div>
                           </div>
                       </div> -->
                       <div class="col-md-6 col-sm-6 p-tb20">
                           <div class="wt-icon-box-wraper left  bdr-1 bdr-gray-dark p-tb15 p-lr10 clearfix">
                                <div class="icon-md text-primary">
                                    <span class="iconmoon-email"></span>
                                </div>
                                <div class="icon-content text-white">
                                    <h5 class="wt-tilte text-uppercase m-b0">Email</h5>
                                    <p class="m-b0">contact@IQ-markets.com</p>
                                    <!-- <p>support@coinasset.ltd</p> -->
                                </div>
                            </div>
                        </div>


                  </div>
                </div>
            </div>
            <div class="section-full p-t80">
                <div class="container">
                    <!-- CONTACT DETAIL BLOCK -->
                    <div class="section-content ">
                        <div class="row">
                            <!-- <div class="wt-box text-center"> -->
                              
                                <div class="row">
                                
                                    <div class="col-md-4 col-sm-12 m-b30">
                                        <div class="wt-icon-box-wraper center p-a30">
                                            <div class="wt-icon-box-md text-black"><span class="icon-cell"><i class="iconmoon-smartphone-1"></i></span></div>
                                            <div class="icon-content" style='height:50px; background: url("par/a1.png"); background-repeat: no-repeat;
	background-size: contain;
	background-position: center;'>
                                              



                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12 m-b30">
                                        <div class="wt-icon-box-wraper center p-a30">
                                            <div class="wt-icon-box-md text-black"><span class="icon-cell"><i class="iconmoon-email"></i></span></div>
                                            <div class="icon-content" style='height:50px; background: url("par/a2.png"); background-repeat: no-repeat;
	background-size: contain;
	background-position: center;'>
                                              



                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12 m-b30">
                                        <div class="wt-icon-box-wraper center p-a30">
                                            <div class="wt-icon-box-md  text-black"><span class="icon-cell"><i class="iconmoon-travel"></i></span></div>
                                            <div class="icon-content" style='height:50px; background: url("par/a3.jpg"); background-repeat: no-repeat;
	background-size: contain;
	background-position: center;'>
                                              



                                            </div>
                                        </div>
                                    </div>
                                
                                <!-- </div> -->
                            </div>
                        </div>
                    </div>

            
            <!-- FOOTER COPYRIGHT -->
            <div class="footer-bottom  overlay-wraper">
                <div class="overlay-main"></div>
                <div class="constrot-strip"></div>
                <div class="container p-t30">
                    <div class="row">
                        <div class="wt-footer-bot-left">
                            <span class="copyrights-text">© 2021 IQ-Markets All Rights Reserved. </span>
                        </div>
                        <div class="wt-footer-bot-right">
                            <ul class="copyrights-nav pull-right"> 
                                <!--<li><a href="terms-and-conditions">Terms  & Condition</a></li>-->
                                <li><a href="./contact">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- FOOTER END -->
        <!-- BUTTON TOP START -->
        <button class="scroltop"><span class=" iconmoon-house relative" id="btn-vibrate"></span>Top</button>
        <!-- MODAL  LOGIN -->
        <div id="Login-form" class="modal fade " role="dialog">
          <div class="modal-dialog modal-sm">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-white">Login Your Account</h4>
              </div>
              <div class="modal-body p-a30">
                <form id="log-form">
                    <div class="form-group">
                       <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <input class="form-control" placeholder="Enter Username" type="text">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input class="form-control" placeholder="Enter email" type="email">
                        </div>
                    </div>
                    <button type="button" class="site-button-secondry text-uppercase btn-block m-b10">Submit</button>
                    <span class="font-12">Don't have an account? <a href="javascript:;" class="text-primary">Register Here</a></span>
                </form>
              </div>
              <div class="modal-footer text-center">
                <div class="text-center"><img src="img/logo.png" alt=""></div>
              </div>
            </div>
          </div>
        </div>
         <!-- MODAL  REGISTER -->
        <div id="Register-form" class="modal fade " role="dialog">
          <div class="modal-dialog modal-sm">
            <!-- Modal content-->
            <div class="modal-content">
              <div class="modal-header bg-primary">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title text-white">Register here</h4>
              </div>
              <div class="modal-body p-a30">
                <form id="reg-form">
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user"></i></span>
                            <input class="form-control" placeholder="Enter Username" type="text">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                            <input class="form-control" placeholder="Enter email" type="email">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-key"></i></span>
                            <input class="form-control" placeholder="Enter Password" type="email">
                        </div>
                    </div>
                    <button type="button" class="site-button-secondry text-uppercase btn-block m-b10">Submit</button>
                    <span class="font-12">Already Have an Account? <a href="javascript:;" class="text-primary">Login</a></span>
                </form>
              </div>
              <div class="modal-footer text-center">
                <div class="text-center"><img src="img/log.png" alt=""></div>
              </div>
            </div>
          </div>
        </div>             
    </div>
<!-- JAVASCRIPT  FILES ========================================= --> 
<script src="js/jquery-1.12.4.min.js"></script><!-- JQUERY.MIN JS -->
<script   src="js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->
<script   src="js/bootstrap-select.min.js"></script><!-- FORM JS -->
<script   src="js/jquery.bootstrap-touchspin.min.js"></script><!-- FORM JS -->
<script   src="js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->
<script   src="js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script   src="js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script   src="js/waypoints-sticky.min.js"></script><!-- COUNTERUP JS -->
<script  src="js/isotope.pkgd.min.js"></script><!-- MASONRY  -->
<script   src="js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->
<script   src="js/stellar.min.js"></script><!-- PARALLAX BG IMAGE   --> 
<script   src="js/scrolla.min.js"></script><!-- ON SCROLL CONTENT ANIMTE   -->
<script   src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script   src="js/shortcode.js"></script><!-- SHORTCODE FUCTIONS  -->
<script   src="js/switcher.js"></script><!-- SWITCHER FUCTIONS  -->
<script  src="js/jquery.bgscroll.js"></script><!-- BACKGROUND SCROLL -->
<script  src="js/tickerNews.min.js"></script><!-- TICKERNEWS-->
<!-- TICKERNEWS FUNCTiON -->
<script type="text/javascript">
	jQuery(function(){

		var timer = !1;

		_Ticker = jQuery("#T1").newsTicker();

		_Ticker.on("mouseenter",function(){

			var __self = this;

			timer = setTimeout(function(){

				__self.pauseTicker();

			},200);

		});

		_Ticker.on("mouseleave",function(){

			clearTimeout(timer);

			if(!timer) return !1;

			this.startTicker();

		});

	});
</script>
<script  src="plugins/revolution/revolution/js/jquery.themepunch.tools.min.js"></script>
<script  src="plugins/revolution/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script  src="plugins/revolution/revolution/js/extensions/revolution-plugin.js"></script>
<script   src="js/rev-script-1.js"></script>
<script type="text/javascript">
function contatMail(){
$('i#sp5').attr("class","fa fa-spinner fa-spin");
var hr = new XMLHttpRequest();
var url = "reg_process.php";
var  cotactmail = document.getElementById('email').value;
var  name = document.getElementById('name').value;
var  subject = document.getElementById('subject').value;
var  message = document.getElementById('message').value;
var vars = "cotactmail="+cotactmail+"&name="+name+"&subject="+subject+"&message="+message;
if(cotactmail=="" || subject =="" || message =="" ){
	sweetUnpre("Please fill all necessary fields!");
	$('i#sp5').attr("class","");
	}else{
var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
		if( !emailReg.test(cotactmail) ) {
					sweetUnpre('Please use a valid email address!');
			        $('i#sp5').attr("class","");
		}else{
           
		   hr.open("POST.php", url, true);
	hr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	// Access the onreadystatechange event for the XMLHttpRequest object
	hr.onreadystatechange = function() {
	  //  console.log(hr);
		if(hr.readyState == 4 && hr.status == 200) {
			var return_data = hr.responseText;
			sweetUnpre(return_data);
			$('i#sp5').attr("class","");
			//setTimeout(refreshPage,2000);
			document.getElementById('email').value="";
			document.getElementById('name').value="";
			document.getElementById('subject').value="";
			document.getElementById('message').value="";
		}
	}
	hr.send(vars); // Actually execute the request
           }//email
		sweetUnpre('processing...');
      }//else empty
}
</script>


  
</body>
</html>