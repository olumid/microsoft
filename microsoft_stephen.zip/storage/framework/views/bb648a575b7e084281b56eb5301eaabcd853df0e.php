<!DOCTYPE html>
<html class="no-js" lang="en">
   
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1" />
        <title>Hair Desk:: Beauty Saloon</title>
        <!--== Favicon ==-->
        <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" />
        <!--== Google Fonts ==-->
      <link href="../../../external.html?link=https://fonts.googleapis.com/css?family=Lato:100,400,400i,700" rel="stylesheet" />
        <link href="../../../external.html?link=https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/app14.min.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" />
        <link rel="stylesheet" href="assets/css/bootstrap.css" />
       
    </head>
    <body>
        <!--== Start Header Area ==-->
        <div class="header-top-text">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="header-top-text-content"><p>5 FREE TREATS + SHIPPING WITH $40 ORDERS.*CODE: BBPAIR</p></div>
                    </div>
                </div>
            </div>
        </div>
        <header class="header-area">
            <!-- Start Header Config Area -->
            <div class="header-config-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-lg-6 d-none d-md-block">
                            <div class="header-config-content">
                                <ul class="config-nav nav">
                                    
                                    <li class="config-item">
                                        <a href="#">Language: English</a>
                                        
                                    </li>
                                    
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-4 col-lg-6">
                            <div class="header-config-buttons">
                                <ul class="media-icons nav">
                                <?php if(Cart::count() > 0): ?> 
                                    <li class="btn-cart">
                                        <a href="<?php echo e(route('cart')); ?>"><i class="ion-bag"></i> <span>Shopping Cart:</span> <strong class="amount">₦<?php echo e(Cart::total()); ?></strong></a>
                                    </li>
                                <?php else: ?>
                                    <li class="btn-cart">
                                        <a href="<?php echo e(route('cart')); ?>"><i class="ion-bag"></i> <span>Shopping Cart:</span> <strong class="amount">₦0.00</strong></a>
                                    </li>
                                <?php endif; ?>
                                    <li>
                                        <a href="#"><i class="ion-social-facebook"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="ion-social-linkedin"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="ion-social-instagram"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="ion-social-vimeo"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Header Config Area --><!-- Start Header Navigation Area -->
            <div class="header-nav-area">
                <div class="container">
                    <div class="row align-items-center position-relative">
                        <div class="col-8 col-lg-2 col-xl-3">
                            <!-- Start Logo Wrapper -->
                            <div class="logo-wrap">
                                <a href="./"><img src="<?php echo e(asset('assets/img/logo4.png')); ?>" alt="Logo" /></a>
                            </div>
                            <!-- End Logo Wrapper -->
                        </div>
                        <div class="col-lg-9 position-static col-xl-8 d-none d-lg-block">
                            <!-- Start Site Navigation -->
                            <nav class="site-navigation">
                                <ul class="main-nav nav">
                                    <li class=" active">
                                        <a href="<?php echo e(route('/')); ?>">Home</a>
                                       
                                    </li>
                                   
                                    <li class="">
                                        <a href="<?php echo e(route('about')); ?>">Who Area We</a>
                                    </li>
                                    
                                    <li class="has-submenu">
                                        <a href="<?php echo e(route('shop', ['category' => 'hair'])); ?>">Shop</a>
                                        <ul class="submenu-nav">
                                             <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('shop', ['category' => $category->slug])); ?>"><?php echo e($category->name); ?></a></li>                                           
                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('cart')); ?>">Cart</a></li>
                                            <li><a href="<?php echo e(route('checkout')); ?>">Checkout</a></li>
                                        </ul>
                                    </li>
                                  
                                    <li class="">
                                        <a href="<?php echo e(route('get-login')); ?>">My Account</a>
                                    </li>
                                    <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                    
                                </ul>
                            </nav>
                            <!-- End Site Navigation -->
                        </div>
                        <div class="col-4 col-lg-1">
                            <!-- Start Search Box Area -->
                            <div class="search-box-wrap">
                                <ul class="search-box-inner nav">
                                    <li>
                                        <a href="#" class="btn-search"><i class="ion-search"></i> <i class="ion-close"></i></a>
                                         <div class="header-search-box">
                                            <form action="<?php echo e(route('search')); ?>" method="GET" class="search-form">
                                                <div class="search-box-content"><label for="search" class="sr-only"></label> <input type="text" name="query" id="query" value="<?php echo e(request()->input('query')); ?>" placeholder="type here and hit enter" /></div>
                                            </form>
                                        </div>
                                    </li>
                                    <li class="d-lg-none">
                                        <a href="javascript:void(0)" class="btn-menu"><i class="ion-navicon"></i></a>
                                    </li>
                                </ul>
                            </div>
                            <!-- End Search Box Area -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Header Navigation Area -->
        </header>
        <!--== End Header Area ==-->
        
        <!--== Start Slider Area ==-->
        <div class="slider-area-wrapper">
            <div class="slider-content-wrap slider-home-4 large-height slider-banner">
                <div class="slider-slide-item bg-img" data-bg="assets/img/slider/home5/01.jpg">
                    <div class="container">
                        <div class="slider-slide-item-inner">
                            <div class="slide-content">
                                <h2 class="layer-1">New Season trend</h2>
                                <h5 class="layer-2">15 haircut styles</h5>
                                <a href="contact.html" class="layer-3">Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="slider-slide-item bg-img" data-bg="assets/img/slider/home5/02.jpg">
                    <div class="container">
                        <div class="slider-slide-item-inner">
                            <div class="slide-content">
                                <h5 class="layer-4 layer-2">Don't blow it</h5>
                                <h3 class="layer-5">In our hand <strong>your hair</strong> comes <span class="layer-6">alive</span></h3>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="slider-slide-item bg-img" data-bg="assets/img/slider/home5/03.jpg">
                    <div class="container">
                        <div class="slider-slide-item-inner">
                            <div class="slide-content">
                                <h5 class="layer-4 layer-2">Don't blow it</h5>
                                <h3 class="layer-5">In our hand <strong>your hair</strong> comes <span class="layer-6">alive</span></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
        
        <!--== End Slider Area ==-->
        
      <!--== Start Feature Area ==-->
        <div class="feature-area sm-top bg-img sp-y" data-bg="assets/img/slider/home3/slide-bg.png">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="section-title section-title--3">
                            <h2>Welcome to HairDesk</h2>
                            <p>
                                Whether it’s edgy and modern or sleek and elegant, we strive to create the perfect look for each individual client. We’re also determined to provide each and every client with the highest degree of customer
                                service in a friendly and professional setting. We are dedicated to performing our craft exceptionally well. To sum up: we do not want any single client to believe he or she can be better served at any other
                                salon.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row mtn-30">
                    <div class="col-sm-6 col-lg-3 text-center">
                        <div class="feature-item">
                            <div class="feature-item__icon"><img src="assets/img/feature/scissors.png" alt="Salon" /></div>
                            <div class="feature-item__text"><p class="mb-0">The hair cutting and styling with 10 years of experience.</p></div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 text-center">
                        <div class="feature-item">
                            <div class="feature-item__icon"><img src="assets/img/feature/spray.png" alt="Salon" /></div>
                            <div class="feature-item__text"><p class="mb-0">Update the latest technology and tendency in the world.</p></div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 text-center">
                        <div class="feature-item">
                            <div class="feature-item__icon"><img src="assets/img/feature/hair-dry.png" alt="Salon" /></div>
                            <div class="feature-item__text"><p class="mb-0">Using the best products from the top providers.</p></div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3 text-center">
                        <div class="feature-item">
                            <div class="feature-item__icon"><img src="assets/img/feature/razor.png" alt="Salon" /></div>
                            <div class="feature-item__text"><p class="mb-0">Our staffs have high experience in customer service.</p></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--== End Feature Area ==-->
         <!--== Start Products Area ==-->
         <div class="about-area"  style="margin-top: 120px;">
            <div class="container" style="margin-top: -40px;">
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="section-title section-title--2">
                            <h2>Top Sale</h2>
                            <hr style="background-color:burlywood; margin-top: -20px; margin-right: 40px;
                            margin-left: 30px;">
                            <h4>New Collection</h4>
                        </div>
                    </div>
                </div>
                <div class="row mt-30" style="margin-top: -40px;">
                 <?php $__currentLoopData = $product->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  

                    <div class="col-sm-6 col-lg-3">
                    <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Start Product Item -->
                    
                        <div class="product-item product-item--2 pull-left">
                            <div class="product-item__thumb" style="margin-left: 5px; margin-top: 5px;">
                            
                                <?php if($product->promo == 1): ?>
                                    <a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="product-item__sale">
                                        <img src="dashboard/products/<?php echo e($product->image1); ?>" alt="Product" />
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="">
                                        <img src="dashboard/products/<?php echo e($product->image1); ?>" alt="Product" />
                                    </a>
                                <?php endif; ?>  
                            
                                
                            </div>
                            <?php if($product->rating == 3): ?>
                            <div class="rating" style="margin-left: 50px; color: #fd7e14">
                                <span class="fa fa-star"></span>  <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span style="color:grey;" class="fa fa-star"></span> <span style="color:grey;" class="fa fa-star"></span>
                            </div>
                            <?php elseif($product->rating == 4): ?>
                            <div class="rating" style="margin-left: 50px; color: #fd7e14">
                                <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span style="color:grey;" class="fa fa-star"></span>
                            </div>
                            <?php else: ?>
                            <div class="rating" style="margin-left: 50px; color: #fd7e14">
                                <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span>
                            </div>
                            <?php endif; ?>
                            <div class="product-item__info" style="font-family: BlinkMacSystemFont; font-size: 18px;">
                    
                                <h4 style="margin-top:-10px; margin-bottom: -1px; font-size: 17px;">
                                    <?php echo e(strtoupper($product->name)); ?>

                                </h4>
                            
                                <?php if($product->bundles_set == 1 || $product->inches_set == 1 ||$product->frontal_set == 1 || $product->closure_set == 1 ||$product->wigging_set == 1): ?>
                                <span style="margin-top:-20px" class="price">₦<?php echo e(number_format($product->cur_start_price)); ?> - ₦<?php echo e(number_format($product->cur_finish_price)); ?></span>
                                <div style="margin-top:7px">
                                <a style="background-color: rgba(255, 166, 0, 0.74);; border: 1px solid rgba(255, 166, 0, 0.904); padding:4px;" href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="btn btn-hvr-brand">
                                <i class="ion-bag"></i>Select Option</a>
                                <?php else: ?>
                                <span style="margin-top:-20px" class="price">₦<?php echo e(number_format($product->cur_price, 2)); ?></span>
                                <div style="margin-top:7px">
                                    <form action="<?php echo e(route('cartStore')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                        <input type="hidden" name="cur_price" value="<?php echo e($product->cur_price); ?>">
                                        <input type="hidden" name="quantity" value="1" />
                                        <input type="hidden" name="photo" value="<?php echo e($product->image1); ?>">
                                        <button style="color:black; background-color: rgba(255, 166, 0, 0.74); border: 1px solid rgba(255, 166, 0, 0.904); padding:4px;" type="submit" class="btn btn-hvr-brand">
                                        <i class="ion-bag"></i>Add to Cart</button>
                                    </form>
                                
                                <?php endif; ?> 
                                </div>
                            </div>
                    
                        </div> 
                    
                      
                    <!-- End Product Item -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
              </div>
                
            </div>
            
            <a style="position: absolute; left: 0; right: 0; margin-left: auto; margin-right: auto; width: 200px; margin-top: 20px; background-color: orange" href="<?php echo e(route('shop', ['category' => 'hair'])); ?>" class="btn ">Shop Now</a>
        </div>
        <!--== End Products Area ==-->
      
        <!--== Start Products Area ==-->
        <div class="about-area" style="margin-top: 200px;">
            <div class="container" style="margin-top: -40px;">
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="section-title section-title--2">
                            <h2>Trending Items</h2>
                            <hr style="background-color:burlywood; margin-top: -20px; margin-right: 40px;
                            margin-left: 30px;">
                            <h4>New Collection</h4>
                        </div>
                    </div>
                </div>
                <div class="row mt-30" style="margin-top: -40px;">
                 <?php $__currentLoopData = $tool->chunk(2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="col-sm-6 col-lg-3">
                    <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Start Product Item -->
                    
                        <div class="product-item product-item--2 pull-left">
                            <div class="product-item__thumb" style="margin-left: 5px; margin-top: 5px;">
                            
                                <?php if($product->promo == 1): ?>
                                    <a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="product-item__sale">
                                        <img src="dashboard/products/<?php echo e($product->image1); ?>" alt="Product" />
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="">
                                        <img src="dashboard/products/<?php echo e($product->image1); ?>" alt="Product" />
                                    </a>
                                <?php endif; ?>  
                            
                                
                            </div>
                            
                             <?php if($product->rating == 3): ?>
                            <div class="rating" style="margin-left: 50px; color: #fd7e14">
                                <span class="fa fa-star"></span>  <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span style="color:grey;" class="fa fa-star"></span> <span style="color:grey;" class="fa fa-star"></span>
                            </div>
                            <?php elseif($product->rating == 4): ?>
                            <div class="rating" style="margin-left: 50px; color: #fd7e14">
                                <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span style="color:grey;" class="fa fa-star"></span>
                            </div>
                            <?php else: ?>
                            <div class="rating" style="margin-left: 50px; color: #fd7e14">
                                <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span>
                            </div>
                            <?php endif; ?>
                            <div class="product-item__info" style="font-family: BlinkMacSystemFont; font-size: 18px;">
                    
                                <h4 style="margin-top:-10px; margin-bottom: -1px; font-size: 17px;">
                                    <?php echo e(strtoupper($product->name)); ?>

                                </h4>
                            
                                <?php if($product->bundles_set == 1 || $product->inches_set == 1 ||$product->frontal_set == 1 || $product->closure_set == 1 ||$product->wigging_set == 1): ?>
                                <span style="margin-top:-20px" class="price">₦<?php echo e(number_format($product->cur_start_price)); ?> - ₦<?php echo e(number_format($product->cur_finish_price)); ?></span>
                                <div style="margin-top:7px">
                                <a style="background-color: rgba(255, 166, 0, 0.74);; border: 1px solid rgba(255, 166, 0, 0.904); padding:4px;" href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="btn btn-hvr-brand">
                                <i class="ion-bag"></i>Select Option</a>
                                <?php else: ?>
                                <span style="margin-top:-20px" class="price">₦<?php echo e(number_format($product->cur_price, 2)); ?></span>
                                <div style="margin-top:7px">
                                    <form action="<?php echo e(route('cartStore')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                        <input type="hidden" name="cur_price" value="<?php echo e($product->cur_price); ?>">
                                        <input type="hidden" name="quantity" value="1" />
                                        <input type="hidden" name="photo" value="<?php echo e($product->image1); ?>">
                                        <button style="color:black; background-color: rgba(255, 166, 0, 0.74); border: 1px solid rgba(255, 166, 0, 0.904); padding:4px;" type="submit" class="btn btn-hvr-brand">
                                        <i class="ion-bag"></i>Add to Cart</button>
                                    </form>
                                
                                <?php endif; ?> 
                                </div>
                            </div>
                    
                        </div> 
                       
                    <!-- End Product Item -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                </div>
        
            </div>
        
            <a style="position: absolute; left: 0; right: 0; margin-left: auto; margin-right: auto; width: 200px; margin-top: 20px; background-color: orange;"
                href="<?php echo e(route('shop', ['category' => 'hair'])); ?>" class="btn ">Shop Now</a>
        </div>
        <!--== End Products Area ==-->

         <!--== Start Portfolio Page Content  ==-->
       
        <!--== End Products Area ==-->
       <!--== Start Call to action Area ==-->
        <div class="call-to-action-area sp-top sm-top bg-img" data-bg="assets/img/extra/call-to-action.jpg" style="margin-top: 80px;">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                    <div class="call-to-action-content">
                        <h4>IN OUR HANDS, YOUR HAIR COMES ALIVE</h4>
                        <img src="assets/img/extra/call-to-action-woman.png" alt="Hairdesk"> 
                        <a href="../../../external.html?link=https://www.youtube.com/watch?v=7e90gBu4pas" class="btn-watch btn-video-popup"><i class="ion-play"></i> Watch Video</a>
                    </div>
                </div>
            </div>
        </div>
        </div>
      <!--== End Call to action Area ==-->
        <!--== Start Portfolio Page Content  ==-->
       <!--== Start Brand Logo Area Wrapper ==-->
      <div class="brand-logo-area sm-top-wp sm-bottom">
         <div class="container">
            <div class="row">
               <div class="col-12 text-center">
                  <div class="section-title section-title--2">
                    
                     <h2>What's New</h2>
                     <hr style="background-color:burlywood; margin-top: -10px; margin-right: 40px;
                            margin-left: 30px;">
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-12">
                  <div class="brand-logo-content slick-row-20">
                   <?php $__currentLoopData = $feature; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="brand-logo-item">
                     <div class="" style="width:280px; height:430px; margin-left:30px; margin-right:30px;">
                           
                            <div class="product-item__thumb1" style="margin-left: 5px; margin-top: 5px;">
                            
                                <?php if($product->promo == 1): ?>
                                    <a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="product-item__sale">
                                        <img style="height: 250px; width: 300px;" src="dashboard/products/<?php echo e($product->image1); ?>" alt="Product" />
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="">
                                        <img style="height: 250px; width: 300px;" src="dashboard/products/<?php echo e($product->image1); ?>" alt="Product" />
                                    </a>
                                <?php endif; ?>  
                            
                                
                            </div>
                            
                            <?php if($product->rating == 3): ?>
                            <div class="rating" style="margin-left: 50px; color: #fd7e14">
                                <span class="fa fa-star"></span>  <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span style="color:grey;" class="fa fa-star"></span> <span style="color:grey;" class="fa fa-star"></span>
                            </div>
                            <?php elseif($product->rating == 4): ?>
                            <div class="rating" style="margin-left: 50px; color: #fd7e14">
                                <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span style="color:grey;" class="fa fa-star"></span>
                            </div>
                            <?php else: ?>
                            <div class="rating" style="margin-left: 50px; color: #fd7e14">
                                <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span> <span class="fa fa-star"></span>
                            </div>
                            <?php endif; ?>
                            <div class="product-item__info" style="font-family: BlinkMacSystemFont; font-size: 18px;">
                    
                                <h4 style="margin-top:-10px; margin-bottom: -1px; font-size: 19px;">
                                    <?php echo e($product->name); ?>

                                </h4>
                            
                                <?php if($product->bundles_set == 1 || $product->inches_set == 1 ||$product->frontal_set == 1 || $product->closure_set == 1 ||$product->wigging_set == 1): ?>
                                <span style="margin-top:-20px" class="price">₦<?php echo e(number_format($product->cur_start_price)); ?> - ₦<?php echo e(number_format($product->cur_finish_price)); ?></span>
                                <div style="margin-top:7px">
                                <a style="background-color: rgba(255, 166, 0, 0.74);; border: 1px solid rgba(255, 166, 0, 0.904); padding:4px;" href="<?php echo e(route('singleProduct', $product->slug)); ?>" class="btn btn-hvr-brand">
                                <i class="ion-bag"></i>Select Option</a>
                                <?php else: ?>
                                <span style="margin-top:-20px" class="price">₦<?php echo e(number_format($product->cur_price, 2)); ?></span>
                                <div style="margin-top:7px">
                                    <form action="<?php echo e(route('cartStore')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
                                        <input type="hidden" name="cur_price" value="<?php echo e($product->cur_price); ?>">
                                        <input type="hidden" name="quantity" value="1" />
                                        <input type="hidden" name="photo" value="<?php echo e($product->image1); ?>">
                                        <button style="color:black; background-color: rgba(255, 166, 0, 0.74); border: 1px solid rgba(255, 166, 0, 0.904); padding:4px;" type="submit" class="btn btn-hvr-brand">
                                        <i class="ion-bag"></i>Add to Cart</button>
                                    </form>
                                
                                <?php endif; ?> 
                                </div>
                            </div>
                    
                        
                        </div>
                     </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                     
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!--== End Brand Logo Area Wrapper ==-->
        <!--== End Portfolio Page Content  ==-->
        <!--== Start Footer Area ==-->
        <footer class="footer-area bg-img" data-bg="assets/img/extra/footer_bg.png">
            <div class="footer-widget-area">
                <div class="container">
                    <div class="row mtn-40">
                        <div class="col-sm-6 col-lg-3">
                            <div class="widget-item">
                                <h4 class="widget-title">About Us</h4>
                                <div class="widget-body">
                                    <p>HairDesk was founded in 2008 with the mission of providing hair care services with a professional but casual atmosphere.</p>
                                    <div class="social-icons mt-20">
                                        <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-instagram"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="widget-item">
                                <h4 class="widget-title">Keep in touch</h4>
                                <div class="widget-body">
                                    <div class="keepintouch">
                                        <p><i class="ion-android-call"></i>(61 2) 9251 5600</p>
                                        <p><i class="ion-email"></i><a href="mailto:your@example.com">your@example.com</a></p>
                                        <p><i class="ion-map"></i>no.200 Joseph, Canada</p>
                                        <p><i class="ion-printer"></i>(61 2) 9200 5700</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="widget-item">
                                <h4 class="widget-title">Customer Care</h4>
                                <div class="widget-body">
                                    <ul class="widget-list">
                                        <li><a href="#">Contact Us</a></li>
                                        <li><a href="#">Delivery Information</a></li>
                                        <li><a href="#">Returns Policy</a></li>
                                        <li><a href="#">Privacy & Security</a></li>
                                        <li><a href="#">Work With Us</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-copyright-area">
                <div class="container">
                    <div class="row">
                        <div class="col-12 text-center">
                            <div class="copyright-content"><p class="mb-0">© HairDesk. All right reserved 2019.</p></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--== End Footer Area ==--><!-- Scroll Top Button -->
        <button class="btn-scroll-top"><i class="ion-chevron-up"></i></button>
      <!-- Start Responsive Menu Wrapper -->
        <aside class="off-canvas-wrapper off-canvas-menu">
            <div class="off-canvas-overlay"></div>
            <div class="off-canvas-inner">
                <!-- Start Off Canvas Content -->
                <div class="off-canvas-content">
                    <div class="off-canvas-header">
                        <div class="logo">
                            <a href="index.html"><img src="assets/img/logo.png" alt="Logo" /></a>
                        </div>
                        <div class="close-btn">
                            <button class="btn-close"><i class="ion-close"></i></button>
                        </div>
                    </div>
                    <div class="res-mobile-menu mobile-menu"></div>
                    <div class="mobile-menu res-site-config"></div>
                </div>
            </div>
        </aside>
        <!-- End Responsive Menu Wrapper --><!--=======================Javascript============================-->
        <script src="assets/js/app.min.js"></script>
    </body>
    
</html>
