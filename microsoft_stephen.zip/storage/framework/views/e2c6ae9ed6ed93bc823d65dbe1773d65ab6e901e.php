
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Welcome to Credit Invest</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/themify-icons/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">


    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>
    <!-- Left Panel -->

   <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo"></a>
                <a class="navbar-brand hidden" href="./"><img src="<?php echo e(asset('images/logo2.png')); ?>" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.html"> <i class="menu-icon fa fa-home"></i>Home</a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-user"></i>My Profile</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-user"></i><a href="maps-gmap.html">Update Account</a></li>
                            <li><i class="menu-icon fa fa-lock"></i><a href="maps-vector.html">Security</a></li>
                            <li><i class="menu-icon fa fa-cogs"></i><a href="maps-gmap.html">Wallet Details</a></li>
                            <li><i class="menu-icon fa fa-group"></i><a href="maps-vector.html">Verify Account</a></li>
                        </ul>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-th-list"></i>Withdrawal</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-th-list"></i>Deposit</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-list"></i>Transaction Log</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-suitcase"></i>Investment Packages</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-suitcase"></i>Loan</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-users"></i>My Downlines</a>
                    </li>
                     <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-users"></i>Credit Score</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('logout')); ?>"> <i class="menu-icon fa fa-dashboard"></i>Logout</a>
                    </li>
                    
                   
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
           <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        <button class="search-trigger"><i class="fa fa-search"></i></button>
                        <div class="form-inline">
                            <form class="search-form">
                                <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                                <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                            </form>
                        </div>

                        
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="<?php echo e(asset('images/admin.jpg')); ?>" alt="User Avatar">
                        </a>

                       
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a class="dropdown-toggle" href="#" data-toggle="dropdown"  id="language" aria-haspopup="true" aria-expanded="true">
                            <i class="flag-icon flag-icon-us"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="language">
                            <div class="dropdown-item">
                                <span class="flag-icon flag-icon-fr"></span>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-es"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-us"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-it"></i>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </header><!-- /header -->
        

        <div class="content mt-3">
            <div class="animated fadeIn">

                <div class="row">
                    
                   <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <strong class="card-title">Account Details</strong>
                            </div>
                            <div class="card-body">
                                <!-- Credit Card -->
                                <div id="pay-invoice">
                                    <div class="card-body">
                                        <div class="card-title">
                                            <h3 class="text-center">Account Setting</h3>
                                        </div>
                                 
                                        <?php if(Session::has('message')): ?>   
                                            <div id="info" style="font-size:13px;" class="alert alert-success alert-dismissible fade show" role="alert">
                                                <strong><?php echo e(Session::get('message')); ?></strong>
                                                <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(Request::get('errorMessage') !== null): ?>
                                          <p style='padding:15px;' class=''><?php echo e(Request::get('errorMessage')); ?></p>
                                        <?php endif; ?>
                                        <hr>
                                        <form action="<?php echo e(route('updateUserSettings')); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                                
                                                <div class="form-group<?php echo e($errors->has('fullname') ?  'has-error' : ''); ?>">
                                                    <label for="cc-payment" class="control-label mb-1">Last Name</label>
                                                    <input id="cc-pament" name="fullname" type="text" class="form-control" value="<?php echo e($profile->fullname); ?>">
                                                    <small style="color: red;"><?php echo e($errors->first('fullname')); ?></small>    
                                                </div>
                                               
                                                <div class="form-group<?php echo e($errors->has('name') ?  'has-error' : ''); ?>">
                                                    <label for="cc-number" class="control-label mb-1">User ID</label>
                                                    <input id="cc-number" name="name" type="tel" class="form-control" value="<?php echo e(Auth::user()->name); ?>">
                                                    <span class="help-block" data-valmsg-for="cc-number" data-valmsg-replace="true"></span>
                                                    <small style="color: red;"><?php echo e($errors->first('name')); ?></small>  
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('email') ?  'has-error' : ''); ?>">
                                                    <label for="cc-payment" class="control-label mb-1">Email</label>
                                                    <input id="cc-pament" value="<?php echo e(Auth::user()->email); ?>" name="email" type="email" class="form-control">
                                                    <small style="color: red;"><?php echo e($errors->first('email')); ?></small>  
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('phone') ?  'has-error' : ''); ?>">
                                                    <label for="cc-payment" class="control-label mb-1">Telephone No</label>
                                                    <input id="cc-pament" name="phone" type="text" class="form-control" value="<?php echo e($profile->phone); ?>">
                                                    <small style="color: red;"><?php echo e($errors->first('phone')); ?></small>  
                                                </div>
                                                <div>
                                                    <button id="payment-button" type="submit" class="btn btn-lg btn-primary btn-block">
                                                        <i class="fa fa-lock fa-lg"></i>&nbsp;
                                                        <span id="payment-button-amount">Update Account</span>
                                                </div>
                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div> <!-- .card -->

                    </div>
                </div>

             
        </div><!-- .content -->


    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <script src="<?php echo e(asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/popper.js/dist/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>


</body>

</html>