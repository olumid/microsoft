
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Coin Finance Pro -- Deposit Requests </title>
    <!-- Favicon icon -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/chartist/css/chartist.min.css')); ?>">
    <link href="<?php echo e(asset('vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap-sweetalert/sweetalert.css')); ?>">
    <link href="<?php echo e(asset('css/style11.css')); ?>" rel="stylesheet">
	<style>
		@import  url(https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&family=Titillium+Web:wght@400;700&display=swap);
		select{
			font-size: 20px;
			font-weight: bolder;
			
		}
	</style>
	
</head>
<body style="font-family: 'Titillium Web'; color:white">

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="<?php echo e(route('dashboard1')); ?>" class="brand-logo">
               <img src="<?php echo e(asset('img/new/log.png')); ?>" alt="">
            </a>
            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		
		<!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="dashboard_bar">
                                
                            </div>

                        <ul class="navbar-nav header-right">
							
							
							
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <img src="images/profile/pic1.jpg" width="20" alt=""/>
									<div class="header-info">
										<span><?php echo e(Auth::user()->name); ?></span>
									</div>
                                </a>
                                
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('dashboard1')); ?>" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        

                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('manageWallet')); ?>">
						<i class="flaticon-381-television"></i>
							<span class="nav-text">Wallets</span>
						</a>
                       
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('investment')); ?>">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">Packages</span>
						</a>
                        
                    </li>
                   
                    <li><a href="<?php echo e(route('password')); ?>" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Update Password</span>
						</a>
					</li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('withdrawRequest')); ?>" aria-expanded="false">
							<i class="flaticon-381-notepad"></i>
							<span class="nav-text">Withdraw</span>
						</a>
                       
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('transactionAll')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Transactions</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('depositHistory')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Orders</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('showDownlines')); ?>" aria-expanded="false">
							<i class="flaticon-381-heart"></i>
							<span class="nav-text">Referral</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('logout')); ?>" aria-expanded="false">
							<i class="flaticon-381-exit"></i>
							<span class="nav-text">Logout</span>
						</a> 
                    </li>
                    
                </ul>
				
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                
                <!-- row -->
                <div class="row">
                    <div class="col-xl-6 col-lg-6"  style="margin: auto;">
                        <div class="card" >
                            <div class="card-header">
                                <h4 class="card-title">Deposit</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form method="POST" id="saveDeposit" action="<?php echo e(route('saveDeposit')); ?>" onsubmit="return checkBalance()">
										<?php echo e(csrf_field()); ?>

										<?php if(Session::has('msg')): ?>   
                                            <div id="info" style="font-size:13px;" class="alert alert-success alert-dismissible fade show" role="alert">
                                                <strong><?php echo e(Session::get('msg')); ?></strong>
                                                <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </a>
                                            </div>
                                        <?php endif; ?>	
										
                                        <div class="form-group">
										
											<label for="method">Choose Crypto Type</label>
											<select style="color: white;" class="form-control" name="type" id="type" required> 
                                                    <option value="Bitcoin">Bitcoin</option>
                                                    <option value="Etherium">Etherium</option>
                                                    <option value="Cardano">Cardano</option>
                                                    <option value="Binance Coin">Binance Coin</option>
													<option value="Xrp">Xrp</option>
                                                    <option value="Doge Coin">Doge Coin</option>
                                                    <option value="Bitcoin Cash">Bitcoin Cash</option>
                                                    <option value="Litecoin">Litecoin</option>
													<option value="Bitcoin Gold">Bitcoin Gold</option>
                                                    <option value="Shiba InuETH">Shiba Inu</option>
                                                    <option value="Digital Yuan">Digital Yuan</option>                                               
                                            </select>
                                            
                                        </div>
                                        <div class="form-group">
										    <label for="amount">Amount </label>
                                            <input type="text" class="form-control" placeholder="0.00" name="amount" id="amount"  value="<?php echo e($amount); ?> " readonly>
                                        </div>

										<label for="address">Payment Address</label>
										<div style="padding-bottom: 30px;">
											<img src="<?php echo e(asset('qr/1615690987.jpg')); ?>" alt="QR">
										</div>
										<div class="input-group mb-3">
										   
                                           
                                            <div class="custom-file">
                                                
                                                <input type="text" class="form-control" placeholder="" id="address" name="address" value="<?php echo e($det->etherium_address); ?>">
                                                    <input type="hidden" id="etherium_address" name="etherium_address" value="<?php echo e($det->etherium_address); ?>" />
													<input type="hidden" id="e_qr" value="qr/<?php echo e($det->etherium_qr); ?>" />

													<input type="hidden" id="cardano_address" name="cardano_address" value="<?php echo e($det->cardano_address); ?>" />
													<input type="hidden" id="c_qr" value="qr/<?php echo e($det->cardano_qr); ?>" />

													<input type="hidden" id="litecoin_address" name="litecoin_address" value="<?php echo e($det->litecoin_address); ?>" />
													<input type="hidden" id="l_qr" value="qr/<?php echo e($det->litecoin_qr); ?>" />

													<input type="hidden" id="bitcoin_address" name="bitcoin_address" value="<?php echo e($det->bitcoin_address); ?>" />
													<input type="hidden" id="b_qr" value="qr/<?php echo e($det->bitcoin_qr); ?>" />

													<input type="hidden" id="shibaI_address" name="shibaI_address" value="<?php echo e($det->shibaI_address); ?>" />
													<input type="hidden" id="s_qr" value="qr/<?php echo e($det->shibaI_qr); ?>" />

													<input type="hidden" id="digitalY_address" name="digitalY_address" value="<?php echo e($det->digitalY_address); ?>" />
													<input type="hidden" id="d_qr" value="qr/<?php echo e($det->digitalY_qr); ?>" />

													<input type="hidden" id="doge_address" name="doge_address" value="<?php echo e($det->doge_address); ?>" />
													<input type="hidden" id="do_qr" value="qr/<?php echo e($det->doge_qr); ?>" />

													<input type="hidden" id="binanceC_address" name="binanceC_address" value="<?php echo e($det->binanceC_address); ?>" />
													<input type="hidden" id="bc_qr" value="qr/<?php echo e($det->binanceC_qr); ?>" />

													<input type="hidden" id="bitcoinC_address" name="bitcoinC_address" value="<?php echo e($det->bitcoinC_address); ?>" />
													<input type="hidden" id="bic_qr" value="qr/<?php echo e($det->bitcoinC_qr); ?>" />

													<input type="hidden" id="bitcoinG_address" name="bitcoinG_address" value="<?php echo e($det->bitcoinG_address); ?>" />
													<input type="hidden" id="b_qr" value="qr/<?php echo e($det->bitcoinG_qr); ?>" />

													<input type="hidden" id="xrp_address" name="xrp_address" value="<?php echo e($det->xrp_address); ?>" />
													<input type="hidden" id="x_qr" value="qr/<?php echo e($det->xrp_qr); ?>" />

													<input type="hidden" id="crypto" name="crypto" />
                                                    <input type="hidden" id="wallet_id" name="wallet_id" value="<?php echo e($wallet_id); ?>"/>
                                            </div>
											
                                        </div>
										<label id="l1" for="" style="display:none; color:white;">Copied!!</label>
                                        <div class="col-xl-6 col-lg-6" style="margin-bottom: 20px;">
                                            <button type="button" class="btn btn-lg btn-primary btn-block btn-dep" onclick="copyToClipboard()">
                                                <i class="fa fa-copy fa-lg"></i>&nbsp;
                                                <span id="dep">Copy</span>
                                            </button>	
                                        </div>
										<button type="submit" class="btn btn-lg btn-warning btn-block btn-dep" onclick="copyToClipboard()">
                                               
                                                <span id="dep">Submit</span>
                                            </button>		
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>
			

			
                </div>
            </div>
        </div>

		
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright ©  <a href="#" target="_blank"></a> 2021</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

	</div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->

	<script src="<?php echo e(asset('j/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap-sweetalert/sweetalert.min.js')); ?>"></script>
	<script type="text/javascript">
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
                    
        });

		$('#type').on('change', function(e){
			var txt = document.getElementById("type");
			$('#crypto').val(txt.options[txt.selectedIndex].text)
            console.log('working');
			if($(this).val() == 'Bitcoin')
			{
	            var crypt = $('#bitcoin_address').val();
				$('#address').val(crypt);
                
			}
			else if($(this).val() == 'Etherium')
			{
	            var crypt = $('#etherium_address').val();
				$('#address').val(crypt);
			}
			else if($(this).val() == 'Litecoin')
			{
	            var crypt = $('#litecoin_address').val();
				$('#address').val(crypt);
			}

			else if($(this).val() == 'Cardano')
			{
	            var crypt = $('#cardano_address').val();
				$('#address').val(crypt);
			}
			else if($(this).val() == 'Binance Coin')
			{
	            var crypt = $('#binanceC_address').val();
				$('#address').val(crypt);
			}
			else if($(this).val() == 'Bitcoin Gold')
			{
	            var crypt = $('#bitcoinG_address').val();
				$('#address').val(crypt);
			}

			else if($(this).val() == 'Shiba Inu')
			{
	            var crypt = $('#shibaI_address').val();
				$('#address').val(crypt);
			}
			else if($(this).val() == 'Digital Yuan')
			{
	            var crypt = $('#digitalY_address').val();
				$('#address').val(crypt);
			}
			
			else if($(this).val() == 'Xrp')
			{
	            var crypt = $('#xrp_address').val();
				$('#address').val(crypt);
			}

			else if($(this).val() == 'Bitcoin Cash')
			{
	            var crypt = $('#bitcoinC_address').val();
				$('#address').val(crypt);
			}
			
			else if($(this).val() == 'Doge Coin')
			{
	            var crypt = $('#doge_address').val();
				$('#address').val(crypt);
			}
			

        })

		function copyToClipboard(){
            $('#address').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l1').show()
           setTimeout(function(){
              $('#l1').hide();
            },3000)
        }

		 function checkBalance()
		  {

          
		   var txt = document.getElementById("type");
		   var amt = parseFloat($('#amount').val());
          
           if(txt.value == '----')
           {
                swal({
					title: "Oops!",
					text: "Invalid Selection, Enter a valid Crypto Type",
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonClass: "btn-default",
					cancelButtonClass: "btn-warning",
					confirmButtonText: "Warning",
					closeOnConfirm: false
				});
                return false;
           }
		   else if(amt < 1)
           {
                swal({
					title: "Oops!",
					text: "Invalid Amount, Enter a valid Amount",
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonClass: "btn-default",
					cancelButtonClass: "btn-warning",
					confirmButtonText: "Warning",
					closeOnConfirm: false
				});
                return false;
           }
		   else
		   {
			  return true; 
		   }
         
            
         }

	</script>	

    <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	
	<!-- Chart piety plugin files -->
    <script src="<?php echo e(asset('vendor/peity/jquery.peity.min.js')); ?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo e(asset('vendor/apexchart/apexchart.js')); ?>"></script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo e(asset('js/dashboard/dashboard-1.js')); ?>"></script>
	
	<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/deznav-init.js')); ?>"></script>

	

</body>
</html>