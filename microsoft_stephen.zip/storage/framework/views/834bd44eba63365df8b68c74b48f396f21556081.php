
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />




	<!-- META -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />    
    <meta name="description" content="" />
    
    <!-- FAVICONS ICON -->
    <link href="<?php echo e(asset('img/logo/logo6.png')); ?>" rel="icon">
    
    <!-- PAGE TITLE HERE -->
    <title>Contact us</title>
    
    <!-- MOBILE SPECIFIC -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
  <!-- PAYOUT PROGRESS BAR CSS -->
 

<link rel="stylesheet" href="payout/main.html">


    
    <!-- [if lt IE 9]>
        <script src="js/html5shiv.min.js"></script>
        <script src="js/respond.min.js"></script>
	<![endif] -->
    
    
    
    <!-- BOOTSTRAP STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <!-- FONTAWESOME STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/fontawesome/css/font-awesome.min.css" />
    <!-- FLATICON STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/flaticon.min.css">
    <!-- ANIMATE STYLE SHEET --> 
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">
    <!-- OWL CAROUSEL STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
    <!-- BOOTSTRAP SELECT BOX STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap-select.min.css">
    <!-- MAGNIFIC POPUP STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.min.css">
    <!-- LOADER STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/loader.min.css">    
    <!-- MAIN STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <!-- THEME COLOR CHANGE STYLE SHEET -->
    <link rel="stylesheet" class="skin" type="text/css" href="css/skin/skin-1.css">
    <!-- CUSTOM  STYLE SHEET -->
    <link rel="stylesheet" type="text/css" href="css/custom.css">
   

    
    <!-- REVOLUTION SLIDER CSS -->
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/settings.css">
    <!-- REVOLUTION NAVIGATION STYLE -->
    <link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/navigation.css">
    
    <!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">  
	<link href="https://fonts.googleapis.com/css?family=Crete+Round:400,400i&amp;subset=latin-ext" rel="stylesheet">
  
 
<style type="text/css">
#apDiv1 {
	position:absolute;
	left:1px;
	top:3155px;
	width:445px;
	height:294px;
	z-index:100000;
	font-size: 0.9em;
	color: #FFF;
	background-color: #903;
	text-align: center;
	display:none;
}
</style>
</head>

<body>

	<div style="padding-bottom:0px; margin-bottom:0px; overflow:hidden" class="page-wraper"> 
       	
        <!-- HEADER START -->
              
<header class="site-header header-style-3 topbar-transparent">
        
            
            
            <div class="sticky-header main-bar-wraper">
                <div class="main-bar">
                    <div class="container">
                        <a href="./">
                            <div style="background-image:url(img/new/log6.png); width:200px; background-position:left; background-size:contain; background-repeat:no-repeat" class="logo-header mostion">
                            </div>   
                        </a>
                            
                            <!-- NAV Toggle Button -->
                            <button data-target=".header-nav" data-toggle="collapse" type="button" class="navbar-toggle collapsed">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            
                           
                            <!-- ETRA Nav -->
                            
                             
                            <!-- SITE Search -->
                            
                            <!-- MAIN Vav -->
                            <div class="header-nav navbar-collapse collapse ">
                              <ul class=" nav navbar-nav">
                                <li>
                                    <a href="./">TRADING<i></i></a>
                                       
                                </li>
                                
                                
                                 <li>
                                    <a href="./market">MARKET<i></i></a>
                                       
                                </li>
                              
                                
                                <li>
                                    <a href="./login">LOGIN<i></i></a>
                                       
                                </li>
                                
                                  <li>
                                    <a href="./register">REGISTER<i></i></a>
                                       
                                </li>
                            
                               
                              <li>
                                    <a href="./why">WHY US<i></i></a>
                                       
                              </li>
                              <li>
                                    <a href="./about">ABOUT US<i></i></a>
                                       
                              </li>
                              
                             <li>
                                    <a href="./contact">SUPPORT<i></i></a>
                                       
                              </li>
                              <li>
                                    <a href="./faq">FAQ<i></i></a>
                                       
                              </li>
                                
                                <li>
                                  
                                </li>
                            </ul>
                        </div>
        
                    </div>
                </div>
            </div>
            
        </header>
 <div style="width:100%; height:150px; background-color:#000000"></div>
        <!-- HEADER END -->
            
        <!-- CONTENT START -->
        <div style="padding-bottom:0px; margin-bottom:0px; overflow:hidden" class="page-content">
            
            <!-- INNER PAGE BANNER -->
            <div class="wt-bnr-inr overlay-wraper" style="background-image:url(images/banner/contactus.jpg);">
                <div class="overlay-main bg-black opacity-07"></div>
                <div class="container">
                    <div class="wt-bnr-inr-entry">
                        <h1 class="text-white">Contact Us</h1>
                    </div>
                </div>
            </div>
            <!-- INNER PAGE BANNER END --> 
            <!-- SECTION CONTENT --> 
            <div class="section-full p-t80 p-b50">
                <div class="container">
                <div id="google_translate_element"></div>
                    <div class="wt-box col-md-6">
                        <h4 class="text-uppercase">Contact Detail </h4>
                        
                        
                            <div class="m-b30">
                                <div class="wt-icon-box-wraper bx-style-1 p-a15 left clearfix bg-gray">
                                    <div class="icon-sm">
                                        <span class="icon-cell text-primary">
                                            <i class="fa fa-phone"></i>
                                        </span>
                                    </div>
                                    <div class="icon-content text-black">
                                        <h5 class="wt-tilte text-uppercase">Phone</h5>
                                        <p>+487 3212 1265</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="m-b30">
                                <div class="wt-icon-box-wraper bx-style-1 p-a15 left clearfix bg-gray">
                                    <div class="icon-sm">
                                        <span class="icon-cell text-primary">
                                            <i class="fa fa-envelope"></i>
                                        </span>
                                    </div>
                                    <div class="icon-content text-black">
                                        <h5 class="wt-tilte text-uppercase">Email</h5>
                                       <ul>
                                       
                                        <li style="margin-bottom:20px"><i class="fa fa-envelope"></i><strong></strong><a style="font-weight:bold; color:#333333" href="mailto:contact@globalfxcoin.co.uk">contact@CoinFinancePro.com</a></li>                                
                                  
                                  
                                    <li><i class="fa fa-envelope"></i><strong></strong><a style="font-weight:bold; color:#333333" href="mailto:support@globalfxcoin.co.uk">support@CoinFinancePro.com</a></li>
                                  
                                       
                                       </ul>
                                    </div>
                                </div>
                            </div>
                            
                       
                            
                            <div class="m-b30">
                                <div class="wt-icon-box-wraper bx-style-1 p-a15 left clearfix bg-gray">
                                    <div class="icon-sm">
                                        <span class="icon-cell text-primary">
                                            <i class="fa fa-map-marker"></i>
                                        </span>
                                    </div>
                                    <div class="icon-content text-black">
                                        <h5 class="wt-tilte text-uppercase">Address</h5>
                                        <p> KrakowskiePrzedmiescie 15/17 00-071 Warsaw </p>
                                    </div>
                                </div>
                            </div>
                       
                    </div>
                    <div class="wt-box col-md-6">
                   
                        
                        
                              <h4 class="text-uppercase">COMPANY PROFILE </h4>
                        
                        <div class="p-a50 p-b60 bg-gray">
                        	 <div class="text-right">
                                   <center>
 <a style="font-weight:bold; color:#333333" href="download/Vanguards_invest.pdf"><button style="border-radius:9px; font-weight:bolder" name="submit" type="button" value="Send us an email" >Click to download our profile</button></a>
</center>
                                   
                                </div>
                        </div>
                  </div>
            </div>
            <!-- SECTION CONTENT END -->
           

            
       </div>
        <!-- CONTENT END -->
        </div>
        <!-- FOOTER START -->
         <div>
      

<footer class="site-footer bg-no-repeat bg-full-height bg-center"  style="padding:0px; margin:0px;background-image:url(images/background/footer-bg.jpg);">
            <!-- FOOTER BLOCKES START -->  
            <div class="footer-top overlay-wraper">
                <div class="overlay-main bg-black opacity-05"></div>
                <div class="container">
                    <div class="row">
                        <!-- ABOUT COMPANY -->
                        <div style="padding-right:20px" class="col-md-3 col-sm-6">  
                            <div class="widget widget_about">
                                <h4 class="widget-title text-white">About Company</h4>
                         <a href="./">
                            <div style="background-image:url(img/new/log6.png); width:200px; background-position:left; background-size:contain; background-repeat:no-repeat" class="logo-header mostion">
                            </div>   
                        </a>
                                <p style="color:#FFFFFF">CoinFinancePro is designed to give direct return to investors thereby limiting investor’s risk due to fatal loss.
                              </p>  
                            </div>
                            
                            
                            
                                <div class="logo-footer clearfix p-b15">
                                    <a href="http://www.forex.com/"><img src="images/british.png" width="221" height="95" alt=""/></a>
                                </div>
                                <p style="color:#FFFFFF"><strong style="font-weight:bold">Forex.com</strong> Trusted and Ofiicial forex broker. 
                              </p>  
                       
                            
                        </div> 
                        <!-- RESENT POST -->
                        <div class="col-md-3 col-sm-6">
                            <div class="widget recent-posts-entry-date">
                                <h4 class="widget-title text-white">Supporters</h4>
                                <div class="widget-post-bx">
                                 <span style="color:#FFF">Company House U.K <small style="color:#999">Office of the official register of company in North Ireland, Scotland,England and Wales</small></span>
                                    <a style="margin-bottom:20px" href="https://beta.companieshouse.gov.uk/company/11568582/officers"><img src="images/companyhousel.png" width="250" height="130" alt=""/></a>
                                    <div style="margin-top:30px" class="bdr-light-blue widget-post clearfix  bdr-b-1 m-b10 p-b10">
                                                     <span style="color:#FFF">Paxful <small style="color:#999">Trusted Online Bitcoin Exchang Market</small></span>
                                       <a href="https://paxful.com/"><img src="images/paxful.png" width="250" height="130"  alt=""/></a>
                                        
                                    </div>
                                    
                              </div>
                            </div>
                        </div>      
                        <!-- USEFUL LINKS -->
                        <div class="col-md-3 col-sm-6">
                            <div class="widget widget_services">
                                <h4 class="widget-title text-white">Useful links</h4>
                                <ul>
                                    <li><a href="about.html">About</a></li>
                                    <li><a href="faq.html">FAQ</a></li>
                                    <li><a href="team.html">Our Team</a></li>
                                    <li><a href="terms.html">Terms</a></li>
                                    <li><a href="contact%20us.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <!-- NEWSLETTER -->
                        <div class="col-md-3 col-sm-6">
                        <div style="width:300px; height:270px; background-image:url(img/tv.html); background-position:center; background-repeat:no-repeat">
                            
                           <center>
 <div style="width:98%; padding-top:24px; overflow:hidden;height:240px">
 <iframe width="255" height="168" src="https://www.youtube.com/embed/kubGCSj5y3k?autoplay=1" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
 
 </div>
                            
</center>
                            
                             </div>
                            <div class="widget widget_newsletter">
                                <h4 class="widget-title text-white">Newsletter</h4>
                                <div class="newsletter-bx">
                                    <form role="search" method="post">
                                        <div class="input-group">
                                        <input name="news-letter" class="form-control" placeholder="ENTER YOUR EMAIL" type="text">
                                        <span class="input-group-btn">
                                            <button type="submit" class="site-button"><i class="fa fa-paper-plane-o"></i></button>
                                        </span>
                                    </div>
                                     </form>
                                </div>
                            </div>
                            <!-- SOCIAL LINKS -->
                            <div class="widget widget_social_inks">
                                <h4 class="widget-title text-white">Social Links</h4>
                                <ul class="social-icons social-square social-darkest">
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-facebook"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-twitter"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-linkedin"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-rss"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-youtube"></a></li>
                                    <li><a href="https://m.facebook.com/groups/215952759081955" class="fa fa-instagram"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
              </div>
            </div>
            <!-- FOOTER COPYRIGHT --></footer>        
        </div>
        <!-- FOOTER END -->

        <!-- BUTTON TOP START -->
   <div></div>

        <!-- MODAL  LOGIN -->
        
        
        <!-- MODAL  REGISTER -->
         
        
    </div>

<script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript">
        (function(){var gtConstEvalStartTime = new Date();/*

    Copyright The Closure Library Authors.
    SPDX-License-Identifier: Apache-2.0
    */
    var h=this||self,l=/^[\w+/_-]+[=]{0,2}$/,m=null;function n(a){return(a=a.querySelector&&a.querySelector("script[nonce]"))&&(a=a.nonce||a.getAttribute("nonce"))&&l.test(a)?a:""}function p(a,b){function c(){}c.prototype=b.prototype;a.i=b.prototype;a.prototype=new c;a.prototype.constructor=a;a.h=function(g,f,k){for(var e=Array(arguments.length-2),d=2;d<arguments.length;d++)e[d-2]=arguments[d];return b.prototype[f].apply(g,e)}}function q(a){return a};function r(a){if(Error.captureStackTrace)Error.captureStackTrace(this,r);else{var b=Error().stack;b&&(this.stack=b)}a&&(this.message=String(a))}p(r,Error);r.prototype.name="CustomError";function u(a,b){a=a.split("%s");for(var c="",g=a.length-1,f=0;f<g;f++)c+=a[f]+(f<b.length?b[f]:"%s");r.call(this,c+a[g])}p(u,r);u.prototype.name="AssertionError";function v(a,b){throw new u("Failure"+(a?": "+a:""),Array.prototype.slice.call(arguments,1));};var w;function x(a,b){this.g=b===y?a:""}x.prototype.toString=function(){return this.g+""};var y={};function z(a){var b=document.getElementsByTagName("head")[0];b||(b=document.body.parentNode.appendChild(document.createElement("head")));b.appendChild(a)}
    function _loadJs(a){var b=document;var c="SCRIPT";"application/xhtml+xml"===b.contentType&&(c=c.toLowerCase());c=b.createElement(c);c.type="text/javascript";c.charset="UTF-8";if(void 0===w){b=null;var g=h.trustedTypes;if(g&&g.createPolicy){try{b=g.createPolicy("goog#html",{createHTML:q,createScript:q,createScriptURL:q})}catch(t){h.console&&h.console.error(t.message)}w=b}else w=b}a=(b=w)?b.createScriptURL(a):a;a=new x(a,y);a:{try{var f=c&&c.ownerDocument,k=f&&(f.defaultView||f.parentWindow);k=k||h;
    if(k.Element&&k.Location){var e=k;break a}}catch(t){}e=null}if(e&&"undefined"!=typeof e.HTMLScriptElement&&(!c||!(c instanceof e.HTMLScriptElement)&&(c instanceof e.Location||c instanceof e.Element))){e=typeof c;if("object"==e&&null!=c||"function"==e)try{var d=c.constructor.displayName||c.constructor.name||Object.prototype.toString.call(c)}catch(t){d="<object could not be stringified>"}else d=void 0===c?"undefined":null===c?"null":typeof c;v("Argument is not a %s (or a non-Element, non-Location mock); got: %s",
    "HTMLScriptElement",d)}a instanceof x&&a.constructor===x?d=a.g:(d=typeof a,v("expected object of type TrustedResourceUrl, got '"+a+"' of type "+("object"!=d?d:a?Array.isArray(a)?"array":d:"null")),d="type_error:TrustedResourceUrl");c.src=d;(d=c.ownerDocument&&c.ownerDocument.defaultView)&&d!=h?d=n(d.document):(null===m&&(m=n(h.document)),d=m);d&&c.setAttribute("nonce",d);z(c)}
    function _loadCss(a){var b=document.createElement("link");b.type="text/css";b.rel="stylesheet";b.charset="UTF-8";b.href=a;z(b)}function _isNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)if(!(b=b[a[c]]))return!1;return!0}function _setupNS(a){a=a.split(".");for(var b=window,c=0;c<a.length;++c)b.hasOwnProperty?b.hasOwnProperty(a[c])?b=b[a[c]]:b=b[a[c]]={}:b=b[a[c]]||(b[a[c]]={});return b}
    window.addEventListener&&"undefined"==typeof document.readyState&&window.addEventListener("DOMContentLoaded",function(){document.readyState="complete"},!1);
    if (_isNS('google.translate.Element')){return}(function(){var c=_setupNS('google.translate._const');c._cest = gtConstEvalStartTime;gtConstEvalStartTime = undefined;c._cl='en';c._cuc='googleTranslateElementInit';c._cac='';c._cam='';c._ctkk='449410.1855493327';var h='translate.googleapis.com';var s=(true?'https':window.location.protocol=='https:'?'https':'http')+'://';var b=s+h;c._pah=h;c._pas=s;c._pbi=b+'/translate_static/img/te_bk.gif';c._pci=b+'/translate_static/img/te_ctrl3.gif';c._pli=b+'/translate_static/img/loading.gif';c._plla=h+'/translate_a/l';c._pmi=b+'/translate_static/img/mini_google.png';c._ps=b+'/translate_static/css/translateelement.css';c._puh='translate.google.com';_loadCss(c._ps);_loadJs(b+'/translate_static/js/element/main.js');})();})();
</script>
<!-- JAVASCRIPT  FILES ========================================= --> 
<script   src="js/jquery-1.12.4.min.js"></script><!-- JQUERY.MIN JS -->
<script   src="js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->

<script   src="js/bootstrap-select.min.js"></script><!-- FORM JS -->
<script   src="js/jquery.bootstrap-touchspin.min.js"></script><!-- FORM JS -->

<script   src="js/magnific-popup.min.js"></script><!-- MAGNIFIC-POPUP JS -->

<script   src="js/waypoints.min.js"></script><!-- WAYPOINTS JS -->
<script   src="js/counterup.min.js"></script><!-- COUNTERUP JS -->
<script   src="js/waypoints-sticky.min.js"></script><!-- COUNTERUP JS -->

<script  src="js/isotope.pkgd.min.js"></script><!-- MASONRY  -->

<script   src="js/owl.carousel.min.js"></script><!-- OWL  SLIDER  -->

<script   src="js/stellar.min.js"></script><!-- PARALLAX BG IMAGE   --> 
<script   src="js/scrolla.min.js"></script><!-- ON SCROLL CONTENT ANIMTE   --> 

<script src="https://maps.google.com/maps/api/js?sensor=false"  ></script><!-- GOOGLE MAP -->
<script   src="js/map.script.js"></script><!-- MAP FUCTIONS [ this file use with google map]  -->

<script   src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script   src="js/shortcode.js"></script><!-- SHORTCODE FUCTIONS  -->

<script  src="js/jquery.bgscroll.js"></script><!-- BACKGROUND SCROLL -->
<script  src="js/tickerNews.min.js"></script><!-- TICKERNEWS-->
<script  src="js/user2b58.js?164030"></script><!-- MY CUSTOM SCRIPT--><!-- LOADING AREA START ===== -->

<!-- LOADING AREA  END ====== -->




 


</body>


</html>