
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Coin Finance Pro -- Dashboard </title>
    <!-- Favicon icon -->
     <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('img/new/android-icon-48x48.png')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/chartist/css/chartist.min.css')); ?>">
    <link href="<?php echo e(asset('vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style11.css')); ?>" rel="stylesheet">
	<style>
		@import  url(https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&family=Titillium+Web:wght@400;700&display=swap);
		select{
			font-size: 20px;
			font-weight: bolder;
			
		}
	</style>
	
</head>
<body style="font-family: 'Titillium Web'; color:white">


    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="<?php echo e(route('dashboard1')); ?>" class="brand-logo"  style="margin-right: 40%;">
               <img src="<?php echo e(asset('img/new/log1.png')); ?>" alt="" style="margin-left: 40px;">
            </a>
            <div class="nav-control" style="margin-left: 150px;">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		
		<!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="dashboard_bar">
                               
                            </div>

                        <ul class="navbar-nav header-right">
							
							
							
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <img src="<?php echo e(asset('images/profile/pic1.jpg')); ?>" width="20" alt=""/>
									<div class="header-info">
										<span><?php echo e(Auth::user()->name); ?></span>
										
									</div>
                                </a>
                                
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('dashboard1')); ?>" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        

                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('manageWallet')); ?>">
						<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Profile</span>
						</a>
                       
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('investment')); ?>">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">Packages</span>
						</a>
                        
                    </li>
                      <li><a class="has-arrow ai-icon" href="<?php echo e(route('transactionAll')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Transactions</span>
						</a> 
                    </li>
                   
                     <li><a class="has-arrow ai-icon" href="<?php echo e(route('nft')); ?>" aria-expanded="false">
							<i class="flaticon-381-layer-1"></i>
							<span class="nav-text">Market Place</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('loan')); ?>" aria-expanded="false">
							<i class="flaticon-381-heart"></i>
							<span class="nav-text">Loan</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('logout')); ?>" aria-expanded="false">
							<i class="flaticon-381-exit"></i>
							<span class="nav-text">Logout</span>
						</a> 
                    </li>
                   
                </ul>
                    
			</div>
                   
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
       <div class="content-body">
            <div class="container-fluid" style="Background-color: white;">
				 
				<div class="row">
					<div class="col-xl-12" style="margin-bottom: 40px;">
						<h3 style="font-weight: bold;">Hi   <?php echo e(Auth::user()->name); ?></h3>
					</div> 
					<div class="col-xl-12">
						<div class="" style="color: black">
                            
                            <div class="">
									<div class="custom-tab-1" style="margin-bottom: 20px;">
										<ul class="nav">
											
											<li class="nav-item">
												<a href="#navpills2-1" class="nav-link active" data-toggle="tab" aria-expanded="false">Overview</a>
											</li>
											
											<li class="nav-item">
												<a href="#navpills2-3" class="nav-link" data-toggle="tab" aria-expanded="true">Marketplace</a>
											</li>
										</ul>
									</div>
                                
                                <div class="tab-content">
                                    <div id="navpills2-1" class="tab-pane active">
                                        <div class="row card">
										    <div class="col-lg-12">
													<?php $balance = 0; $earning = 0;?>
													<?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<?php
															$balance = $balance + $list->wallet_balance;
															$earning = $earning + $list->wallet_earning;
														?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<div>
														<p style="color:grey;" class="fs-18 mb-1">Overall Balance</p>
														<h3 style=" margin-top: -7px;" class="fs-21 font-w600 text-black">$<?php echo e(number_format($balance)); ?>.00</h3>
													</div>
													
													<div>
														<p style="color:grey;" class="fs-18 mb-1">Overall Earnings</p>
														<h3 style=" margin-top: -7px;" class="fs-18 font-w600 text-black">$<?php echo e(number_format($earning)); ?>.00</h3>
													</div>
												
										    </div>
                                            <div class="col-lg-12 card">
												<div class="">
													
													<div class="">
														<a class="btn btn-sm btn-primary" style="font-size: 18px; font-weight:bold; margin-right: 5px; width:100px;" href="<?php echo e(route('depositRequest')); ?>">Deposit</a>
														<a class="btn btn-sm btn-light" style="font-size: 18px; font-weight:bold; margin-right: 5px; width:100px;" href="<?php echo e(route('withdrawRequest')); ?>">Withdraw</a>
														<a  class="btn btn-sm btn-light" style="font-size: 18px; font-weight:bold; margin-right: 5px; width:100px;" href="<?php echo e(route('showDownlines')); ?>">Downline</a>
													</div>
												</div>
										    </div>
											<!-- TradingView Widget BEGIN -->
										<div class="col-xl-12 card">
											<div class="tradingview-widget-copyright"><a href="https://www.tradingview.com" rel="noopener" target="_blank"><span class="blue-text"></span></a></div>
												<script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
												{
												"symbols": [
													{
													"proName": "FOREXCOM:SPXUSD",
													"title": "S&P 500"
													},
													{
													"proName": "FOREXCOM:NSXUSD",
													"title": "Nasdaq 100"
													},
													{
													"proName": "FX_IDC:EURUSD",
													"title": "EUR/USD"
													},
													{
													"proName": "BITSTAMP:BTCUSD",
													"title": "BTC/USD"
													},
													{
													"proName": "BITSTAMP:ETHUSD",
													"title": "ETH/USD"
													}
												],
												"showSymbolLogo": true,
												"colorTheme": "light",
												"isTransparent": false,
												"displayMode": "regular",
												"locale": "en"
												}
												</script>
										</div>
               
            <!-- TradingView Widget END -->
											<div class="col-xl-12 card">
												<div class="table-responsive table-hover fs-14">
													<table class="table display mb-4 font-w600 short-one border-no card-table text-black" id="example6">
														
														<tbody>
														<?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<tr>
																
																<td class="wspace-no">
																			<?php if($list->wallet_name == 'BTC'): ?>
																															
																					<svg width="20" height="20" viewBox="0 0 201 200" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
																						<!-- Generator: Sketch 46.2 (44496) - http://www.bohemiancoding.com/sketch -->
																						<title>BTC</title>
																						<desc>Created with Sketch.</desc>
																						<defs></defs>
																						<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																							<g id="Artboard" transform="translate(-422.000000, -1254.000000)">
																								<g id="BTC" transform="translate(422.000000, 1253.000000)">
																									<path d="M200.1463,100.9964 C200.1463,156.2254 155.3753,200.9964 100.1463,200.9964 C44.9173,200.9964 0.1463,156.2254 0.1463,100.9964 C0.1463,45.7674 44.9173,0.9964 100.1463,0.9964 C155.3753,0.9964 200.1463,45.7674 200.1463,100.9964" id="Fill-504" fill="#F7931A"></path>
																									<path d="M124.426,130.222 C123.589,133.035 121.706,135.353 119.124,136.749 C116.542,138.147 113.572,138.455 110.759,137.617 L82.598,129.23 L88.872,108.167 L117.031,116.555 L117.032,116.555 C122.838,118.284 126.156,124.415 124.426,130.222 M133.924,87.057 C135.32,89.639 135.628,92.609 134.791,95.423 C133.061,101.228 126.927,104.544 121.124,102.818 L121.123,102.818 L92.963,94.431 L99.235,73.368 L127.396,81.755 C130.209,82.593 132.527,84.475 133.924,87.057 M146.53,80.237 C143.311,74.288 137.968,69.948 131.487,68.018 L127.761,66.909 L132.977,49.395 L119.594,45.409 L114.378,62.923 L102.952,59.52 L108.169,42.006 L104.963,41.051 L91.975,37.183 L86.947,54.065 L71.119,49.351 L66.652,64.351 L82.48,69.066 L66.219,123.664 L50.391,118.95 L45.924,133.951 L61.751,138.664 L57.508,152.913 L60.713,153.868 L73.701,157.736 L78.133,142.855 L89.586,146.266 L85.154,161.148 L98.483,165.118 L102.915,150.236 L106.667,151.353 C109.059,152.065 111.502,152.418 113.93,152.418 C118.08,152.418 122.191,151.387 125.944,149.356 C131.893,146.137 136.232,140.795 138.163,134.312 C140.193,127.493 139.191,120.488 135.962,114.722 C141.824,111.663 146.495,106.336 148.527,99.514 C150.458,93.031 149.748,86.185 146.53,80.237" id="Fill-505" fill="#FFFFFF"></path>
																								</g>
																							</g>
																						</g>
																					</svg>
																			<?php elseif($list->wallet_name == 'ETH'): ?>
																				
																					<svg width="20" height="20" viewBox="0 0 201 200" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
																						<!-- Generator: Sketch 46.2 (44496) - http://www.bohemiancoding.com/sketch -->
																						<title>ETH</title>
																						<desc>Created with Sketch.</desc>
																						<defs></defs>
																						<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																							<g id="Artboard" transform="translate(-766.000000, -1254.000000)">
																								<g id="ETH" transform="translate(766.000000, 1253.000000)">
																									<path d="M200.9128,100.9964 C200.9128,156.2254 156.1418,200.9964 100.9128,200.9964 C45.6848,200.9964 0.9128,156.2254 0.9128,100.9964 C0.9128,45.7674 45.6848,0.9964 100.9128,0.9964 C156.1418,0.9964 200.9128,45.7674 200.9128,100.9964" id="Fill-506" fill="#497391"></path>
																									<polygon id="Fill-507" fill="#FFFFFF" points="56.6355 113.387 99.5275 25.034 99.5275 135.965"></polygon>
																									<polygon id="Fill-508" fill="#FFFFFF" points="145.1917 113.387 102.1477 135.965 102.1477 25.004"></polygon>
																									<polygon id="Fill-509" fill="#FFFFFF" points="56.6355 116.619 99.5275 138.095 99.5275 172.629"></polygon>
																									<polygon id="Fill-510" fill="#FFFFFF" points="145.1917 116.619 102.1477 172.629 102.1477 138.095"></polygon>
																								</g>
																							</g>
																						</g>
																					</svg>
																			<?php elseif($list->wallet_name == 'DOGE'): ?>
																					<svg width="20" height="20" viewBox="0 0 201 201" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
																						<!-- Generator: Sketch 46.2 (44496) - http://www.bohemiancoding.com/sketch -->
																						<title>DOGE</title>
																						<desc>Created with Sketch.</desc>
																						<defs></defs>
																						<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																							<g id="Artboard" transform="translate(-408.000000, -4265.000000)">
																								<g id="DOGE" transform="translate(408.000000, 4265.000000)">
																									<path d="M200.9363,100.9847 C200.9363,156.2127 156.1653,200.9847 100.9363,200.9847 C45.7083,200.9847 0.9363,156.2127 0.9363,100.9847 C0.9363,45.7557 45.7083,0.9847 100.9363,0.9847 C156.1653,0.9847 200.9363,45.7557 200.9363,100.9847" id="Fill-146" fill="#C3A723"></path>
																									<path d="M111.2517,135.0657 L89.1507,135.0657 L89.1507,106.5677 L111.0667,106.5677 L111.0667,95.0677 L89.1507,95.0677 L89.1507,67.0707 L109.9197,67.0707 C109.9197,67.0707 135.4827,67.0707 135.4827,98.7077 C135.4827,136.0097 111.2517,135.0657 111.2517,135.0657 M107.8167,47.0677 L68.8167,47.0677 L68.8167,95.0677 L55.8167,95.0677 L55.8167,106.5677 L68.8167,106.5677 L68.8167,155.0677 L110.3167,155.0677 C110.3167,155.0677 155.8167,156.5677 155.8167,97.3177 C155.8167,47.0677 107.8167,47.0677 107.8167,47.0677" id="Fill-148" fill="#FFFFFF"></path>
																								</g>
																							</g>
																						</g>
																					</svg>
																			<?php elseif($list->wallet_name == 'XRP'): ?>
																					<svg width="20" height="20" viewBox="0 0 201 200" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
																							<!-- Generator: Sketch 46.2 (44496) - http://www.bohemiancoding.com/sketch -->
																							<title>XRP</title>
																							<desc>Created with Sketch.</desc>
																							<defs></defs>
																							<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																								<g id="Artboard" transform="translate(-1456.000000, -1254.000000)">
																									<g id="XRP" transform="translate(1456.000000, 1253.000000)">
																										<path d="M100.4465,0.9964 C45.2175,0.9964 0.4465,45.7674 0.4465,100.9964 C0.4465,156.2254 45.2175,200.9964 100.4465,200.9964 C155.6755,200.9964 200.4465,156.2254 200.4465,100.9964 C200.4465,45.7674 155.6755,0.9964 100.4465,0.9964" id="Fill-513" fill="#266BA6"></path>
																										<path d="M100.4465,192.5755 C49.8685,192.5755 8.8675,151.5745 8.8675,100.9965 C8.8675,50.4185 49.8685,9.4175 100.4465,9.4175 C151.0245,9.4175 192.0255,50.4185 192.0255,100.9965 C192.0255,151.5745 151.0245,192.5755 100.4465,192.5755" id="Fill-514" fill="#FFFFFF"></path>
																										<path d="M122.0457,111.993 C120.6717,111.993 119.3217,112.097 118.0037,112.296 C114.0607,108.939 111.0167,104.769 111.2837,99.98 C111.4917,96.248 113.2337,93.139 115.7347,90.568 C117.5427,90.951 119.4157,91.156 121.3377,91.156 C136.2087,91.156 148.2637,79.1 148.2637,64.229 C148.2637,49.358 136.2087,37.302 121.3377,37.302 C106.4657,37.302 94.4107,49.358 94.4107,64.229 C94.4107,71.143 97.0187,77.447 101.3017,82.215 C100.7087,85.776 99.4097,88.922 96.8907,90.565 C94.2057,92.316 88.8847,92.591 83.0877,92.205 C79.1507,82.217 69.4217,75.146 58.0357,75.146 C43.1647,75.146 31.1087,87.201 31.1087,102.073 C31.1087,116.944 43.1647,129 58.0357,129 C70.2817,129 80.6107,120.822 83.8787,109.631 C88.6017,108.91 92.8617,108.974 95.1187,110.761 C97.9857,113.03 99.4417,117.879 100.1137,123.307 C96.9727,127.712 95.1187,133.098 95.1187,138.92 C95.1187,153.791 107.1747,165.847 122.0457,165.847 C136.9177,165.847 148.9727,153.791 148.9727,138.92 C148.9727,124.049 136.9177,111.993 122.0457,111.993" id="Fill-515" fill="#2C71AE"></path>
																									</g>
																								</g>
																							</g>
																						</svg> 
																			<?php elseif($list->wallet_name == 'LTC'): ?>
																			<svg width="20" height="20" viewBox="0 0 201 201" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
																					<!-- Generator: Sketch 46.2 (44496) - http://www.bohemiancoding.com/sketch -->
																					<title>LTC</title>
																					<desc>Created with Sketch.</desc>
																					<defs></defs>
																					<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																						<g id="Artboard" transform="translate(-767.000000, -1610.000000)">
																							<g id="LTC" transform="translate(767.000000, 1610.000000)">
																								<path d="M100.0647,0.7772 C44.8357,0.7772 0.0647,45.5482 0.0647,100.7772 C0.0647,156.0062 44.8357,200.7772 100.0647,200.7772 C155.2937,200.7772 200.0647,156.0062 200.0647,100.7772 C200.0647,45.5482 155.2937,0.7772 100.0647,0.7772" id="Fill-491" fill="#3D3E3C"></path>
																								<path d="M100.0647,9.1107 C150.6097,9.1107 191.7317,50.2327 191.7317,100.7777 C191.7317,151.3217 150.6097,192.4437 100.0647,192.4437 C49.5197,192.4437 8.3977,151.3217 8.3977,100.7777 C8.3977,50.2327 49.5197,9.1107 100.0647,9.1107" id="Fill-492" fill="#FFFFFF"></path>
																								<path d="M163.0828,63.619 C160.8668,59.866 158.2668,56.28 155.3218,52.889 L52.1768,156.034 C55.5678,158.978 59.1538,161.579 62.9068,163.795 L163.0828,63.619 Z" id="Fill-493" fill="#B6B7BA"></path>
																								<path d="M146.8382,44.5628 C143.3772,41.6758 139.7102,39.1648 135.8932,37.0178 L36.3052,136.6048 C38.4522,140.4228 40.9632,144.0888 43.8512,147.5498 L146.8382,44.5628 Z" id="Fill-494" fill="#B6B7BA"></path>
																								<path d="M124.3343,31.7654 C119.4593,30.0554 114.4383,28.8924 109.3623,28.2464 L27.5343,110.0754 C28.1813,115.1494 29.3423,120.1714 31.0533,125.0464 L124.3343,31.7654 Z" id="Fill-495" fill="#B6B7BA"></path>
																								<path d="M92.7957,28.0032 C76.5687,29.6142 60.7777,36.6292 48.3477,49.0592 C35.9177,61.4892 28.9017,77.2812 27.2907,93.5082 L92.7957,28.0032 Z" id="Fill-496" fill="#B6B7BA"></path>
																								<path d="M172.3469,89.6566 C171.5849,84.6786 170.2999,79.7686 168.5089,75.0036 L74.2909,169.2206 C79.0559,171.0116 83.9659,172.2976 88.9439,173.0586 L172.3469,89.6566 Z" id="Fill-497" fill="#B6B7BA"></path>
																								<path d="M173.0125,105.8006 L105.0885,173.7246 C122.0975,172.5606 138.7805,165.4976 151.7825,152.4946 C164.7855,139.4916 171.8485,122.8106 173.0125,105.8006" id="Fill-498" fill="#B6B7BA"></path>
																								<polygon id="Fill-499" fill="#F8F9F7" points="91.9568 126.346 96.2398 95.56 123.2748 76.102 123.2748 57.435 99.1268 74.81 104.0778 39.223 74.5318 39.223 68.1928 97.067 49.3798 110.603 49.3798 129.285 65.9708 117.345 62.4108 149.831 91.9568 149.831 159.0828 149.831 159.0828 126.346"></polygon>
																								<path d="M64.9197,147.5823 L156.8347,147.5823 L156.8347,128.5943 L89.3727,128.5943 L94.1457,94.2973 L121.0277,74.9503 L121.0277,61.8233 L96.1757,79.7033 L101.4947,41.4713 L76.5487,41.4713 L70.3197,98.3073 L51.6287,111.7563 L51.6287,124.8963 L68.7567,112.5693 L64.9197,147.5823 Z M161.3307,152.0793 L59.9027,152.0793 L63.1867,122.1203 L47.1317,133.6733 L47.1317,109.4513 L66.0667,95.8273 L72.5167,36.9743 L106.6617,36.9743 L102.0757,69.9173 L125.5237,53.0483 L125.5237,77.2533 L98.3327,96.8223 L94.5407,124.0983 L161.3307,124.0983 L161.3307,152.0793 Z" id="Fill-500" fill="#3D3E3C"></path>
																							</g>
																						</g>
																					</g>
																				</svg>
																			<?php elseif($list->wallet_name == 'AVAX'): ?>
																				<svg version="1.1" width="20" height="20" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
																						viewBox="0 0 254 254" style="enable-background:new 0 0 254 254;" xml:space="preserve">
																					<style type="text/css">
																						.st0{fill-rule:evenodd;clip-rule:evenodd;fill:#E84142;}
																						.st1{fill:#FFFFFF;}
																					</style>
																					<g>
																						<circle class="st0" cx="127" cy="127" r="127"/>
																						<path class="st1" d="M171.8,130.3c4.4-7.6,11.5-7.6,15.9,0l27.4,48.1c4.4,7.6,0.8,13.8-8,13.8h-55.2c-8.7,0-12.3-6.2-8-13.8
																							L171.8,130.3z M118.8,37.7c4.4-7.6,11.4-7.6,15.8,0l6.1,11L155.1,74c3.5,7.2,3.5,15.7,0,22.9l-48.3,83.7
																							c-4.4,6.8-11.7,11.1-19.8,11.6H46.9c-8.8,0-12.4-6.1-8-13.8L118.8,37.7z"/>
																					</g>
																				</svg>
																			<?php elseif($list->wallet_name == 'ADA'): ?>
																			<svg width="20" height="20" viewBox="0 0 201 200" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
																					<!-- Generator: Sketch 46.2 (44496) - http://www.bohemiancoding.com/sketch -->
																					<title>ADA</title>
																					<desc>Created with Sketch.</desc>
																					<defs></defs>
																					<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																						<g id="Artboard" transform="translate(-1456.000000, -1620.000000)" fill="#000000">
																							<g id="ADA" transform="translate(1456.000000, 1619.000000)">
																								<path d="M110.0095,54.1893 C103.4675,57.9163 101.1845,66.2413 104.9115,72.7843 C108.6385,79.3263 116.9635,81.6083 123.5055,77.8823 C130.0485,74.1553 132.3305,65.8303 128.6045,59.2873 C124.8775,52.7453 116.5515,50.4623 110.0095,54.1893" id="Fill-579"></path>
																								<path d="M96.9285,31.0399 C92.3035,33.6749 90.6895,39.5599 93.3245,44.1849 C95.9585,48.8099 101.8445,50.4239 106.4695,47.7889 C111.0945,45.1539 112.7075,39.2689 110.0735,34.6439 C107.4385,30.0189 101.5535,28.4049 96.9285,31.0399" id="Fill-580"></path>
																								<path d="M96.9285,138.5872 C92.3035,141.2222 90.6895,147.1072 93.3245,151.7322 C95.9585,156.3582 101.8445,157.9712 106.4695,155.3362 C111.0945,152.7022 112.7075,146.8162 110.0735,142.1912 C107.4385,137.5662 101.5535,135.9532 96.9285,138.5872" id="Fill-581"></path>
																								<path d="M143.2932,57.661 C138.6682,60.296 137.0542,66.181 139.6892,70.806 C142.3242,75.432 148.2092,77.045 152.8342,74.41 C157.4592,71.776 159.0732,65.89 156.4382,61.265 C153.8032,56.64 147.9182,55.027 143.2932,57.661" id="Fill-582"></path>
																								<path d="M49.6072,111.5145 C44.9822,114.1495 43.3682,120.0345 46.0032,124.6595 C48.6382,129.2845 54.5232,130.8985 59.1482,128.2635 C63.7732,125.6295 65.3872,119.7435 62.7522,115.1185 C60.1172,110.4935 54.2322,108.8805 49.6072,111.5145" id="Fill-583"></path>
																								<path d="M48.97,57.661 C44.345,60.296 42.731,66.181 45.366,70.806 C48.001,75.432 53.886,77.045 58.511,74.41 C63.136,71.776 64.75,65.89 62.115,61.265 C59.48,56.64 53.595,55.027 48.97,57.661" id="Fill-584"></path>
																								<path d="M143.2932,110.8773 C138.6682,113.5123 137.0542,119.3973 139.6892,124.0223 C142.3242,128.6473 148.2092,130.2613 152.8342,127.6263 C157.4592,124.9913 159.0732,119.1063 156.4382,114.4813 C153.8032,109.8563 147.9182,108.2423 143.2932,110.8773" id="Fill-585"></path>
																								<path d="M167.6926,86.2381 C164.0156,88.3331 162.7336,93.0111 164.8276,96.6881 C166.9216,100.3651 171.6006,101.6481 175.2776,99.5531 C178.9546,97.4591 180.2376,92.7801 178.1426,89.1031 C176.0476,85.4261 171.3696,84.1441 167.6926,86.2381" id="Fill-586"></path>
																								<path d="M26.5266,86.2381 C22.8496,88.3331 21.5666,93.0111 23.6616,96.6881 C25.7556,100.3651 30.4346,101.6481 34.1116,99.5531 C37.7886,97.4591 39.0706,92.7801 36.9766,89.1031 C34.8816,85.4261 30.2036,84.1441 26.5266,86.2381" id="Fill-587"></path>
																								<path d="M129.301,32.0779 C129.223,36.3089 132.59,39.8019 136.821,39.8799 C141.051,39.9569 144.544,36.5909 144.622,32.3599 C144.7,28.1289 141.333,24.6359 137.103,24.5579 C132.872,24.4799 129.379,27.8469 129.301,32.0779" id="Fill-588"></path>
																								<path d="M57.1819,153.432 C57.1039,157.663 60.4709,161.156 64.7019,161.234 C68.9319,161.311 72.4259,157.945 72.5029,153.714 C72.5809,149.483 69.2149,145.99 64.9839,145.912 C60.7529,145.834 57.2599,149.201 57.1819,153.432" id="Fill-589"></path>
																								<path d="M61.4158,38.6175 C65.0808,40.7325 69.7668,39.4765 71.8818,35.8115 C73.9968,32.1465 72.7408,27.4605 69.0758,25.3455 C65.4098,23.2305 60.7248,24.4865 58.6088,28.1515 C56.4938,31.8165 57.7508,36.5025 61.4158,38.6175" id="Fill-590"></path>
																								<path d="M132.7288,160.4466 C136.3948,162.5616 141.0798,161.3046 143.1948,157.6396 C145.3108,153.9746 144.0538,149.2896 140.3888,147.1746 C136.7238,145.0586 132.0378,146.3156 129.9228,149.9806 C127.8078,153.6456 129.0638,158.3316 132.7288,160.4466" id="Fill-591"></path>
																								<path d="M125.6238,81.4613 C119.0818,85.1883 116.7988,93.5133 120.5258,100.0553 C124.2528,106.5983 132.5778,108.8803 139.1208,105.1533 C145.6628,101.4263 147.9448,93.1023 144.2188,86.5593 C140.4918,80.0173 132.1658,77.7343 125.6238,81.4613" id="Fill-592"></path>
																								<path d="M110.0095,108.7327 C103.4675,112.4597 101.1845,120.7847 104.9115,127.3267 C108.6385,133.8697 116.9635,136.1517 123.5055,132.4247 C130.0485,128.6987 132.3305,120.3737 128.6045,113.8307 C124.8775,107.2887 116.5515,105.0057 110.0095,108.7327" id="Fill-593"></path>
																								<path d="M91.7991,54.1893 C98.3411,57.9163 100.6241,66.2413 96.8981,72.7843 C93.1711,79.3263 84.8451,81.6083 78.3031,77.8823 C71.7601,74.1553 69.4781,65.8303 73.2051,59.2873 C76.9321,52.7453 85.2571,50.4623 91.7991,54.1893" id="Fill-594"></path>
																								<path d="M76.1848,81.4613 C82.7268,85.1883 85.0098,93.5133 81.2828,100.0553 C77.5568,106.5983 69.2308,108.8803 62.6888,105.1533 C56.1458,101.4263 53.8638,93.1023 57.5908,86.5593 C61.3168,80.0173 69.6428,77.7343 76.1848,81.4613" id="Fill-595"></path>
																								<path d="M91.7991,108.7327 C98.3411,112.4597 100.6241,120.7847 96.8981,127.3267 C93.1711,133.8697 84.8451,136.1517 78.3031,132.4247 C71.7601,128.6987 69.4781,120.3737 73.2051,113.8307 C76.9321,107.2887 85.2571,105.0057 91.7991,108.7327" id="Fill-596"></path>
																								<path d="M106.8127,7.0462 C106.8127,10.3902 104.1027,13.1012 100.7577,13.1012 C97.4147,13.1012 94.7037,10.3902 94.7037,7.0462 C94.7037,3.7022 97.4147,0.9912 100.7577,0.9912 C104.1027,0.9912 106.8127,3.7022 106.8127,7.0462" id="Fill-597"></path>
																								<path d="M106.8127,178.3255 C106.8127,181.6695 104.1027,184.3805 100.7577,184.3805 C97.4147,184.3805 94.7037,181.6695 94.7037,178.3255 C94.7037,174.9815 97.4147,172.2715 100.7577,172.2715 C104.1027,172.2715 106.8127,174.9815 106.8127,178.3255" id="Fill-598"></path>
																								<path d="M29.3542,45.0174 C32.2592,46.6734 33.2712,50.3704 31.6162,53.2754 C29.9602,56.1814 26.2632,57.1934 23.3572,55.5374 C20.4532,53.8814 19.4402,50.1844 21.0962,47.2794 C22.7512,44.3744 26.4492,43.3614 29.3542,45.0174" id="Fill-599"></path>
																								<path d="M178.1589,129.8343 C181.0639,131.4903 182.0759,135.1873 180.4209,138.0923 C178.7649,140.9973 175.0679,142.0103 172.1619,140.3543 C169.2569,138.6983 168.2449,135.0013 169.9009,132.0963 C171.5559,129.1913 175.2539,128.1783 178.1589,129.8343" id="Fill-600"></path>
																								<path d="M23.3391,129.7952 C26.2451,128.1412 29.9421,129.1552 31.5961,132.0612 C33.2511,134.9672 32.2361,138.6642 29.3301,140.3182 C26.4241,141.9732 22.7281,140.9582 21.0731,138.0522 C19.4191,135.1472 20.4331,131.4502 23.3391,129.7952" id="Fill-601"></path>
																								<path d="M172.1863,45.053 C175.0923,43.399 178.7893,44.413 180.4433,47.319 C182.0983,50.225 181.0833,53.922 178.1773,55.576 C175.2713,57.231 171.5743,56.216 169.9203,53.31 C168.2663,50.405 169.2803,46.708 172.1863,45.053" id="Fill-602"></path>
																								<path d="M57.5823,10.8699 C57.5823,13.5989 55.3703,15.8109 52.6413,15.8109 C49.9113,15.8109 47.6993,13.5989 47.6993,10.8699 C47.6993,8.1409 49.9113,5.9289 52.6413,5.9289 C55.3703,5.9289 57.5823,8.1409 57.5823,10.8699" id="Fill-603"></path>
																								<path d="M154.1047,174.661 C154.1047,177.39 151.8927,179.602 149.1637,179.602 C146.4347,179.602 144.2217,177.39 144.2217,174.661 C144.2217,171.932 146.4347,169.72 149.1637,169.72 C151.8927,169.72 154.1047,171.932 154.1047,174.661" id="Fill-604"></path>
																								<path d="M151.365,15.0677 C148.981,16.3957 145.971,15.5397 144.643,13.1557 C143.315,10.7717 144.172,7.7617 146.555,6.4337 C148.94,5.1057 151.949,5.9617 153.277,8.3457 C154.605,10.7307 153.749,13.7397 151.365,15.0677" id="Fill-605"></path>
																								<path d="M55.2488,179.0975 C52.8648,180.4255 49.8548,179.5695 48.5268,177.1855 C47.1988,174.8015 48.0548,171.7915 50.4388,170.4635 C52.8238,169.1355 55.8328,169.9915 57.1608,172.3755 C58.4888,174.7605 57.6328,177.7695 55.2488,179.0975" id="Fill-606"></path>
																								<path d="M193.4626,96.7747 C191.1076,95.3957 190.3166,92.3687 191.6956,90.0137 C193.0746,87.6587 196.1026,86.8677 198.4576,88.2467 C200.8126,89.6267 201.6036,92.6527 200.2236,95.0077 C198.8446,97.3627 195.8166,98.1537 193.4626,96.7747" id="Fill-607"></path>
																								<path d="M3.3469,97.2845 C0.9919,95.9055 0.2009,92.8775 1.5799,90.5225 C2.9599,88.1685 5.9869,87.3775 8.3419,88.7565 C10.6969,90.1355 11.4879,93.1625 10.1079,95.5175 C8.7289,97.8725 5.7019,98.6635 3.3469,97.2845" id="Fill-608"></path>
																							</g>
																						</g>
																					</g>
																				</svg> 
																			<?php elseif($list->wallet_name == 'BNB'): ?>
																			<svg width="20" height="20" viewBox="0 0 201 200" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
																					<!-- Generator: Sketch 46.2 (44496) - http://www.bohemiancoding.com/sketch -->
																					<title>BNB</title>
																					<desc>Created with Sketch.</desc>
																					<defs></defs>
																					<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																						<g id="Artboard" transform="translate(-414.000000, -4631.000000)">
																							<g id="BNB" transform="translate(414.000000, 4630.000000)">
																								<path d="M200.9573,100.9891 C200.9573,156.2181 156.1863,200.9891 100.9573,200.9891 C45.7283,200.9891 0.9573,156.2181 0.9573,100.9891 C0.9573,45.7601 45.7283,0.9891 100.9573,0.9891 C156.1863,0.9891 200.9573,45.7601 200.9573,100.9891" id="Fill-158" fill="#212121"></path>
																								<polygon id="Fill-160" fill="#F4BB0B" points="100.9573 120.6131 81.3323 100.9891 100.9573 81.3641 120.5823 100.9891"></polygon>
																								<polygon id="Fill-162" fill="#F4BB0B" points="145.5549 100.9891 145.4719 101.0711 163.6739 119.2721 181.9569 100.9891 163.5479 82.5791 145.3459 100.7801"></polygon>
																								<polygon id="Fill-164" fill="#F4BB0B" points="69.4138 87.9344 100.9568 56.3914 132.9638 88.3984 151.1648 70.1974 100.9568 19.9894 51.2128 69.7334"></polygon>
																								<polygon id="Fill-166" fill="#F4BB0B" points="133.0901 113.4539 100.9571 145.5869 69.1091 113.7379 50.9081 131.9389 100.9571 181.9889 151.2911 131.6549"></polygon>
																								<polygon id="Fill-168" fill="#F4BB0B" points="56.3596 100.9891 57.0316 100.3171 38.8306 82.1151 19.9576 100.9891 38.5256 119.5571 56.7266 101.3561"></polygon>
																							</g>
																						</g>
																					</g>
																				</svg>
																			<?php elseif($list->wallet_name == 'BCH'): ?>
																				<svg width="20" height="20" viewBox="0 0 201 200" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
																					<!-- Generator: Sketch 46.2 (44496) - http://www.bohemiancoding.com/sketch -->
																					<title>BCH</title>
																					<desc>Created with Sketch.</desc>
																					<defs></defs>
																					<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																						<g id="Artboard" transform="translate(-1111.000000, -1254.000000)">
																							<g id="BCH" transform="translate(1111.000000, 1253.000000)">
																								<path d="M200.6799,100.9964 C200.6799,156.2254 155.9089,200.9964 100.6799,200.9964 C45.4509,200.9964 0.6799,156.2254 0.6799,100.9964 C0.6799,45.7674 45.4509,0.9964 100.6799,0.9964 C155.9089,0.9964 200.6799,45.7674 200.6799,100.9964" id="Fill-511" fill="#8AC072"></path>
																								<path d="M137.6731,103.493 C139.0271,106.097 139.2871,109.072 138.4021,111.871 C137.5191,114.671 135.6001,116.958 132.9941,118.312 L106.9271,131.87 L96.7871,112.373 L122.8541,98.815 L122.8541,98.815 C128.2291,96.02 134.8771,98.118 137.6731,103.493 M114.4771,65.871 C117.2761,66.755 119.5641,68.676 120.9181,71.28 C123.7131,76.654 121.6121,83.303 116.2421,86.099 C116.2411,86.099 116.2401,86.099 116.2401,86.099 L90.1731,99.657 L80.0311,80.16 L106.1001,66.601 C108.7031,65.248 111.6781,64.988 114.4771,65.871 M118.7931,52.204 C112.3421,50.168 105.4851,50.765 99.4851,53.886 L96.0371,55.68 L87.6051,39.468 L75.2151,45.911 L83.6481,62.123 L73.0721,67.624 L64.6391,51.411 L61.6721,52.955 L49.6491,59.208 L57.7771,74.836 L43.1261,82.456 L50.3481,96.342 L65.0001,88.722 L91.2871,139.262 L76.6351,146.882 L83.8581,160.768 L98.5091,153.148 L105.3691,166.338 L108.3371,164.795 L120.3591,158.541 L113.1941,144.766 L123.7961,139.252 L130.9611,153.028 L143.3001,146.61 L136.1351,132.834 L139.6081,131.028 C141.8221,129.876 143.8231,128.431 145.5681,126.743 C148.5491,123.856 150.7861,120.256 152.0701,116.186 C154.1071,109.736 153.5091,102.88 150.3881,96.879 C147.1051,90.567 141.5121,86.23 135.1821,84.333 C137.2671,78.058 136.9191,70.982 133.6341,64.666 C130.5131,58.665 125.2411,54.24 118.7931,52.204" id="Fill-512" fill="#FFFFFF"></path>
																							</g>
																						</g>
																					</g>
																				</svg>
																			<?php elseif($list->wallet_name == 'LUNA'): ?>
																			<svg width="20" height="20" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
																						viewBox="0 0 2000 2000" style="enable-background:new 0 0 2000 2000;" xml:space="preserve">
																					<style type="text/css">
																						.st0{fill:#172852;}
																						.st1{fill:#FFD83D;}
																						.st2{fill:#FF6F03;}
																					</style>
																					<circle class="st0" cx="1000" cy="1000" r="1000"/>
																					<g>
																						<path class="st1" d="M805.5,446.9c117.1-43.8,248.9-43.9,368.2-7.9c155.3,48.2,286.4,165.4,354.9,312.5
																							c18.9,41.9,37,85.6,38.8,132.2c-87.3-50.6-183-83.4-278.9-113.3c-153.4-55.3-314-93.7-459.2-169.7c-33.8-20.2-76.9-40.9-86.1-83
																							C739.5,481.3,778,461,805.5,446.9"/>
																						<path class="st1" d="M452,800.9c33.9-92,89.5-177.4,165-240.7c19.2,157.9,86.4,310.5,197.4,425.3
																							c133.1,138.3,322.7,223.2,515.6,220c76.6,2.4,151.5-15.3,226.2-29.6c-73.5,265.6-364.6,441.9-634.3,399.5
																							c-162.8-20.8-313.1-117.2-403.8-253.3C415.8,1171.7,390,972,452,800.9z"/>
																					</g>
																					<path class="st2" d="M1288.5,770.4c95.9,29.9,191.6,62.7,278.9,113.3l5.9,3.1c8.1,60.9,14,123,3.2,184
																						c-43.9-18.6-79.5-51.3-116.7-80.2C1388.2,931,1315.1,862.8,1288.5,770.4"/>
																				</svg>
																			<?php elseif($list->wallet_name == 'SOL'): ?>
																				<svg width="20" height="20" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><g fill="none"><circle fill="#66F9A1" cx="16" cy="16" r="16"/><path d="M9.925 19.687a.59.59 0 01.415-.17h14.366a.29.29 0 01.207.497l-2.838 2.815a.59.59 0 01-.415.171H7.294a.291.291 0 01-.207-.498l2.838-2.815zm0-10.517A.59.59 0 0110.34 9h14.366c.261 0 .392.314.207.498l-2.838 2.815a.59.59 0 01-.415.17H7.294a.291.291 0 01-.207-.497L9.925 9.17zm12.15 5.225a.59.59 0 00-.415-.17H7.294a.291.291 0 00-.207.498l2.838 2.815c.11.109.26.17.415.17h14.366a.291.291 0 00.207-.498l-2.838-2.815z" fill="#FFF"/></g></svg>
																				<?php elseif($list->wallet_name == 'TRON'): ?>
																				<svg width="20" height="20" viewBox="0 0 201 201" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
																					<!-- Generator: Sketch 46.2 (44496) - http://www.bohemiancoding.com/sketch -->
																					<title>TRX</title>
																					<desc>Created with Sketch.</desc>
																					<defs></defs>
																					<g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
																						<g id="Artboard" transform="translate(-1099.000000, -6533.000000)">
																							<g id="TRX" transform="translate(1099.000000, 6533.000000)">
																								<path d="M200.6628,100.7332 C200.6628,155.9622 155.8918,200.7332 100.6628,200.7332 C45.4338,200.7332 0.6628,155.9622 0.6628,100.7332 C0.6628,45.5042 45.4338,0.7332 100.6628,0.7332 C155.8918,0.7332 200.6628,45.5042 200.6628,100.7332" id="Fill-435" fill="#020100"></path>
																								<path d="M43.1331,38.6258 L139.3241,60.7958 C139.5951,60.8578 139.8511,60.9708 140.0801,61.1288 L159.9421,74.8148 C160.9501,75.5098 161.2001,76.8928 160.4981,77.8958 L93.4391,173.7438 C92.4201,175.1998 90.1851,174.9148 89.5651,173.2488 L40.5711,41.5438 C39.9591,39.8978 41.4221,38.2308 43.1331,38.6258" id="Fill-436" fill="#FFFFFF"></path>
																								<polygon id="Fill-437" fill="#020100" points="46.679 46.7205 133.766 66.7915 152.846 79.9395 91.6 167.4775"></polygon>
																								<path d="M91.6121,174.8983 C91.5451,174.8983 91.4771,174.8953 91.4091,174.8883 C90.3101,174.7773 89.5091,173.7963 89.6201,172.6983 L96.3111,106.2983 L41.4051,43.3083 C40.6801,42.4753 40.7661,41.2123 41.5991,40.4863 C42.4321,39.7603 43.6951,39.8473 44.4211,40.6803 L99.8961,104.3233 C100.2581,104.7403 100.4331,105.2883 100.3781,105.8373 L93.5991,173.0983 C93.4961,174.1293 92.6261,174.8983 91.6121,174.8983" id="Fill-438" fill="#FFFFFF"></path>
																								<path d="M98.3889,107.6375 C97.7639,107.6375 97.1559,107.3445 96.7689,106.8125 C96.2079,106.0385 96.2719,104.9765 96.9229,104.2765 L135.8539,62.3905 C136.6059,61.5815 137.8709,61.5335 138.6809,62.2865 C139.4899,63.0385 139.5359,64.3045 138.7839,65.1135 L106.7849,99.5405 L157.1599,76.1895 C158.1639,75.7265 159.3519,76.1595 159.8159,77.1625 C160.2809,78.1645 159.8449,79.3535 158.8429,79.8185 L99.2289,107.4515 C98.9589,107.5775 98.6719,107.6375 98.3889,107.6375" id="Fill-439" fill="#FFFFFF"></path>
																							</g>
																						</g>
																					</g>
																				</svg>
																			<?php endif; ?> 
																	
																	<span style="margin-left: 10px;" class="text-black"><?php echo e($list->wallet_name); ?></span>	
																</td>
																<td> </td>
																<td> </td>
																<td> </td>
																<td> </td>
																<td> </td>
																<td> </td>
																<td> </td>
																<td> </td>
																<td> </td>
																
																<?php if($list->wallet_balance + $list->wallet_earning < 1): ?>
																<td>$0.00</td>
																<?php else: ?>
																<td>$<?php echo e($list->wallet_balance + $list->wallet_earning); ?></td>
																<?php endif; ?>
														
															</tr>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														</tbody>
													</table>
														
												</div>	
													
											</div>
                                        </div>
                                    </div>
                                   
                                    <div id="navpills2-3" class="tab-pane">
                                        	<div class="row">
												<?php $__currentLoopData = $nft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												
												<div class="col-xl-3 col-xxl-4">
													<div class="card">
														<div class="card-body" style="margin-top: -10px;">
															<div class="text-center mb-3">
																<img src="<?php echo e(asset('nfts/'.$list->nft)); ?>" width="290" height="310" alt="" />										
															</div>
															<div class="text-left mb-3">
																<h8 class=" mb-0"><?php echo e($list->username); ?>

																<?php if($list->verification_status == 1): ?> 
																<svg height="15" viewBox="0 0 512 512" width="13" xmlns="http://www.w3.org/2000/svg"><path d="m512 268c0 17.9-4.3 34.5-12.9 49.7s-20.1 27.1-34.6 35.4c.4 2.7.6 6.9.6 12.6 0 27.1-9.1 50.1-27.1 69.1-18.1 19.1-39.9 28.6-65.4 28.6-11.4 0-22.3-2.1-32.6-6.3-8 16.4-19.5 29.6-34.6 39.7-15 10.2-31.5 15.2-49.4 15.2-18.3 0-34.9-4.9-49.7-14.9-14.9-9.9-26.3-23.2-34.3-40-10.3 4.2-21.1 6.3-32.6 6.3-25.5 0-47.4-9.5-65.7-28.6-18.3-19-27.4-42.1-27.4-69.1 0-3 .4-7.2 1.1-12.6-14.5-8.4-26-20.2-34.6-35.4-8.5-15.2-12.8-31.8-12.8-49.7 0-19 4.8-36.5 14.3-52.3s22.3-27.5 38.3-35.1c-4.2-11.4-6.3-22.9-6.3-34.3 0-27 9.1-50.1 27.4-69.1s40.2-28.6 65.7-28.6c11.4 0 22.3 2.1 32.6 6.3 8-16.4 19.5-29.6 34.6-39.7 15-10.1 31.5-15.2 49.4-15.2s34.4 5.1 49.4 15.1c15 10.1 26.6 23.3 34.6 39.7 10.3-4.2 21.1-6.3 32.6-6.3 25.5 0 47.3 9.5 65.4 28.6s27.1 42.1 27.1 69.1c0 12.6-1.9 24-5.7 34.3 16 7.6 28.8 19.3 38.3 35.1 9.5 15.9 14.3 33.4 14.3 52.4zm-266.9 77.1 105.7-158.3c2.7-4.2 3.5-8.8 2.6-13.7-1-4.9-3.5-8.8-7.7-11.4-4.2-2.7-8.8-3.6-13.7-2.9-5 .8-9 3.2-12 7.4l-93.1 140-42.9-42.8c-3.8-3.8-8.2-5.6-13.1-5.4-5 .2-9.3 2-13.1 5.4-3.4 3.4-5.1 7.7-5.1 12.9 0 5.1 1.7 9.4 5.1 12.9l58.9 58.9 2.9 2.3c3.4 2.3 6.9 3.4 10.3 3.4 6.7-.1 11.8-2.9 15.2-8.7z" fill="#1da1f2"/></svg>
																<?php endif; ?>
																</h8>
																<p class=""><?php echo e($list->name); ?></p>											
															</div>
															<div class="text-right mb-3" style="float:right; margin-top:-66px">
																<h6 class="fs-10 mb-0">Price</h6>
																<p class="fs-14 font-w600 text-black">
															<img src="<?php echo e(asset('svg/'.$list->type.'.svg')); ?>" /><?php echo e($list->amount); ?></p>
																										
															</div>
															<div class="text-left" style="padding-bottom: -50px;">
																<a class="btn btn-primary" href="<?php echo e(route('nftRequest',['nft_id'=>$list->nft_id])); ?>">Buy Now</a>
																									
															</div>
														</div>
													</div>
												</div>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</div>
										</div>
                                </div>
                            </div>
                        </div>
                   

					</div>
					
					
				</div>
						
            </div>
			
        </div>

		
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
      
        <!--**********************************
            Footer end
        ***********************************-->
	
	</div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	
	<!-- Chart piety plugin files -->
    <script src="<?php echo e(asset('vendor/peity/jquery.peity.min.js')); ?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo e(asset('vendor/apexchart/apexchart.js')); ?>"></script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo e(asset('js/dashboard/dashboard-1.js')); ?>"></script>
	
	<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/dezz.js')); ?>"></script>
	
    
	<script>
		function carouselReview(){
			jQuery('.testimonial-one').owlCarousel({
				loop:true,
				autoplay:true,
				margin:20,
				nav:false,
				rtl:true,
				dots: false,
				navText: ['', ''],
				responsive:{
					0:{
						items:3
					},
					450:{
						items:4
					},
					600:{
						items:5
					},	
					991:{
						items:5
					},			
					
					1200:{
						items:7
					},
					1601:{
						items:5
					}
				}
			})
		}
		jQuery(window).on('load',function(){
			setTimeout(function(){
				carouselReview();
			}, 1000); 
		});			
	</script>
</body>
</html>