<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="theme-color" content="#33363f">
<meta property="og:locale" content="en_US" />
<meta property="og:site_name" content="Avaro" />

<link href="{{asset('img/new/android-icon-48x48.png')}}" rel="icon">
<title>Coinfinancepro| Sign Up</title>
<link rel="stylesheet" href="public/css/style.css?97487">
<link rel="stylesheet" href="public/vendor/bootstrap/css/bootstrap.css?94930">
<link rel="stylesheet" href="public/vendor/fontawesome/css/all.css">
</head>
<body>
<div id="custom-loader" class="">
<div id="app-loader-bg">
<div id="app-loader"></div>
</div>
</div>
<nav class="navbar navbar-light custom-nav-bg">
<div class="container">
<a class="navbar-brand" href="en-us">
<img src="public/img/logo/oraimo-dark.png" alt="" width="" height="40">
</a>
<div class="">
<img class="me-2 nav-img" src="" id="tt" alt="">
<button onclick="location.href='signin'" class="btn btn-outline-primary">Log In</button>
</div>
</div>
</nav>
<div class="container-fluid pb-5 pt-5">
<div class="d-flex justify-content-center align-items-center full-page-containter">
<div class="col-12 col-md-5 col-lg-3">
<center class="mb-4">
<h3>Sign Up</h3>
<p>It takes just a few minutes</p>
</center>


<form action="signup" method="POST">
<input type="hidden" name="_token" value="edRJwjWKusypIRqW6zFpIjeBxABaAgpXSNLLAcOf">
<div class="form-floating mb-3">
<input type="text" name="fullname" class="form-control" id="floatingInput" placeholder="John Hawkings Doe" value="">
<label for="floatingInput">Fullname</label>
 </div>
<div class="form-floating mb-3">
<input type="text" name="username" class="form-control" id="floatingInput" placeholder="John123" value="">
<label for="floatingInput">Username</label>
</div>
<div class="form-floating mb-3">
<input type="password" name="password" class="form-control" id="floatingInput" placeholder="********">
<label for="floatingInput">Password</label>
</div>
<div class="form-floating mb-3">
<input type="password" name="password_confirmation" class="form-control" id="floatingInput" placeholder="********">
<label for="floatingInput">Password Confirmation</label>
</div>
<div class="row">
<div class="col-3">
<div class="form-floating mb-3">
<input type="text" name="calling_code" class="form-control" id="floatingPhone" placeholder="John@example.com">
<label for="floatingPhone">Calling code</label>
</div>
</div>
<div class="col-9">
<div class="form-floating mb-3">
<input type="number" name="phone" class="form-control" id="floatingInput" placeholder="John@example.com" value="">
<label for="floatingInput">Phone Number</label>
</div>
</div>
</div>
<div class="form-floating mb-3">
<input type="text" name="country" class="form-control" placeholder="John@example.com">
<label for="floatingInput" id="ccc">Country </label>
</div>
<div class="form-floating mb-3">
<input type="email" name="email" class="form-control" id="floatingInput" placeholder="John@example.com" value="">
<label for="floatingInput">Email address</label>
</div>
<select name="security_question" class="form-control p-3 mb-3" aria-label="Default select example">
<option value="" selected>Select a security question</option>
<option value="What primary school did you attend?">What primary school did you attend?</option>
<option value="In what town or city did your parents meet?">In what town or city did your parents meet?</option>
<option value="What is the middle name of your oldest child?">What is the middle name of your oldest child?</option>
</select>
<div class="form-floating">
<input type="text" name="security_answer" class="form-control" id="floatingPassword" placeholder="Answer" value="">
<label for="floatingPassword">Enter answer for security question</label>
</div>
<div class="form-check mt-4 mb-4">
<input name="idemny" class="form-check-input" type="checkbox" value="yes" id="flexCheckDefault" checked>
<label class="form-check-label montserrat" for="flexCheckDefault">
I confirm that i am 18 years old or older and accept <a href="terms">Terms & Conditions</a> and <a href="privacy-policy">Privacy Policy</a>
</label>
</div>
<div class="d-grid d-block">
<button class="btn btn-success btn-lg mb-4" data-processing="true" type="submit">Open an account</button>
</div>
<p class="text-center montserrat text-muted">Already have an account? <a href="signin">Log In</a> now</p>
</form>
</div>
</div>
</div>
<script src="public/vendor/jquery/jquery.js"></script>
<script src="public/vendor/bootstrap/js/bootstrap.bundle.js?"></script>
<script src="public/vendor/fontawesome/js/all.js"></script>
<script src="public/js/app.js"></script>
<script src="public/js/auth.js"></script>


    </script>

</body>
</html>
