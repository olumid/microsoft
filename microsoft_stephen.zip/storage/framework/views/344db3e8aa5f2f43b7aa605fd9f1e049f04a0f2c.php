<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->

  <link rel="stylesheet" href="account/css/style.css">
  <link rel="stylesheet" href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- endinject -->
  <link rel="shortcut icon" href="account/images/favicon.png" />
 <title>CreditInvest - Best trading platform - Register</title>

</head>

<body>
    <style> #hide{display:none;}</style>

  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper full-page-wrapper">
      <div class="content-wrapper d-flex align-items-stretch auth auth-img-bg">
        <div class="row flex-grow">
          <div class="col-lg-6 d-flex align-items-center justify-content-center">
            <div class="auth-form-transparent text-left p-3">
              <div class="brand-logo">
                  <strong style="color:goldenrod; padding-top:20px;">CREDITINVEST.UK</strong>
              </div>
              <h4>New here?</h4>
              <h6 class="font-weight-light">Join us today! It takes only few steps</h6>
            <form class="pt-3" action="<?php echo e(route('addAccount')); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="rfnumber" value="1429359" readonly="true" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password">
              <input type="text" id="hide" name="subject"  value="Thanks for joining us" class="form-control form-control-lg border-left-0">

                <div class="form-group <?php echo e($errors->has('fullname') ?  'has-error' : ''); ?>">
                  <label>Full Name</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-user-circle text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="fullname" class="form-control form-control-lg border-left-0" placeholder="First Name">
                  </div>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('fullname')); ?></p>
                </div>
                
                <div class="form-group <?php echo e($errors->has('email') ?  'has-error' : ''); ?>">
                  <label>Email</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-address-card-o text-primary"></i>
                      </span>
                    </div>
                    <input type="email" name="email" class="form-control form-control-lg border-left-0" placeholder="Email">
                  </div>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('email')); ?></p>
                </div>
                <div class="form-group <?php echo e($errors->has('username') ?  'has-error' : ''); ?>">
                  <label>USER ID</label>
                  <div class="input-group" style="margin-bottom:10px;">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-user-secret text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="username" class="form-control form-control-lg border-left-0" placeholder="USER ID">
                  </div>
                  <span>minimum of 6 characters required. space not allowed</span>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('username')); ?></p>
                </div>
               
                <div class="form-group <?php echo e($errors->has('password') ?  'has-error' : ''); ?>">
                  <label>Password</label>
                  <div class="input-group" style="margin-bottom:10px;">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-low-vision text-primary"></i>
                      </span>
                    </div>
                    <input type="password"  name="password" class="form-control form-control-lg border-left-0" placeholder="Password">                        
                  </div>
                  <span>Minimum of 8 characters required with at least 1 of each: upper case, lower case and numeric character</span>
                 <p style="color: red; font-size: 14px; margin-top: 6px;"><?php echo e($errors->first('password')); ?></p>
                </div>
                <div class="form-group">
                  <label>Confirm Password</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-low-vision text-primary"></i>
                      </span>
                    </div>
                    <input type="password"  name="password_confirmation" class="form-control form-control-lg border-left-0" id="" placeholder="Confirm Password">                        
                  </div>
                </div>
                <div class="form-group">
                  <label>Phone Number(optional)</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-phone-square text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="phone" class="form-control form-control-lg border-left-0" placeholder="Phone Number">
                  </div>
                </div>
                <?php if(Session::has('referrer')): ?>  
                 <div class="form-group">
                  <label>Referral ID(optional)</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="text-primary"></i>
                      </span>
                    </div>
                    <input readonly type="text" value="<?php echo e(Session::get('referrer')); ?>" name="referral_id" class="form-control form-control-lg border-left-0" placeholder="YFLM813A">
                  </div>
                 </div>
                <?php else: ?>
                <div class="form-group">
                  <label>Referral ID(optional)</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="referral_id" class="form-control form-control-lg border-left-0" placeholder="YFLM813A">
                  </div>
                 </div>
                <?php endif; ?>
                <div class="form-group <?php echo e($errors->has('security_question') ?  'has-error' : ''); ?>">
                  <label>Security Question</label>
                  <div class="input-group">
                   
                    <select name="security_question" class="form-control form-control-lg border-left-0">
                      <option value="0">Security Question</option>
                      <option value="What was your childhood nickname?">What was your childhood nickname?</option>
                      <option value="What is the name of your favourite childhood friend?">What is the name of your favourite childhood friend?</option>
                      <option value="What street did you live in in third Grade?">What street did you live in in third Grade?</option>
                      <option value="What schood did you attend for sixth grade?">What schood did you attend for sixth grade?</option>
                      <option value="What is your maternal grandmother's maiden name?">What is your maternal grandmother's maiden name?</option>
                  </select>
                  </div>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"> <p style="color: red;"><?php echo e($errors->first('security_question')); ?></p>
                </div>
                <div class="form-group <?php echo e($errors->has('answer') ?  'has-error' : ''); ?>">
                  <label>Answer</label>
                  <div class="input-group">
                    <div class="input-group-prepend bg-transparent">
                      <span class="input-group-text bg-transparent border-right-0">
                        <i class="fa fa-question-circle text-primary"></i>
                      </span>
                    </div>
                    <input type="text" name="answer" class="form-control form-control-lg border-left-0" placeholder="Answer">
                  </div>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"> <p style="color: red;"><?php echo e($errors->first('answer')); ?></p>
                </div>
                <div style="margin-left: 5%" class="mb-4 <?php echo e($errors->has('terms') ?  'has-error' : ''); ?>">
                  <div class="form-check">
                    <label class=" text-muted">
                      <input type="checkbox" class="form-check-input" checked="checked" name="terms">
                      I agree to all Terms & Conditions
                    </label>
                  </div>
                  <p style="color: red; font-size: 14px; margin-top: 6px;"> <p style="color: red;"><?php echo e($errors->first('terms')); ?></p>
                </div>
                <div class="mt-3">
                  <button class="btn btn-block btn-primary btn-lg font-weight-medium auth-form-btn"  type="submit" name="submit">SIGN UP</button>
                </div>
                <div class="text-center mt-4 font-weight-light">
                  Already have an account? <a href="./login" class="text-primary">Login</a>
                </div>
              </form>
            </div>
          </div>
          <div class="col-lg-6 register-half-bg d-flex flex-row">
            <p class="text-white font-weight-medium text-center flex-grow align-self-end">Copyright &copy; 2020  All rights reserved.</p>
          </div>
        </div>
      </div>
      <!-- content-wrapper ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
    <!-- container-scroller -->
  <!-- plugins:js -->

</body>

</html>
