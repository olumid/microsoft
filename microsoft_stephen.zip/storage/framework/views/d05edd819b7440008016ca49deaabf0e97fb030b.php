
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Coin Finance Pro -- Packages </title>
    <!-- Favicon icon -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
     <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('img/new/android-icon-48x48.png')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/chartist/css/chartist.min.css')); ?>">
    <link href="<?php echo e(asset('vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap-sweetalert/sweetalert.css')); ?>">
	<link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('css/style11.css')); ?>" rel="stylesheet">
    
    
	<style>
    .article{margin-bottom:240px}.article__wrap{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between}.article__left{width:10%;}.article__right{width:90%}.article__right-title{margin-bottom:121px}.article__right-info,.article__right-mining,.article__right-profit{font-size:32px;line-height:22px;margin-bottom:20px}.article__right-info:before,.article__right-mining:before,.article__right-profit:before{content:'';position:absolute;background-repeat:no-repeat;background-size:31px 36px;background-position:center;width:40px;height:40px;left:-69px;top:-15px}.article__right-men:before{background-image:url(images/articleimg/Union.svg)}.article__right-mining:before{background-image:url(images/articleimg/ico2.svg)}.article__right-profit:before{background-image:url(images/articleimg/ico13.svg)}.article__right-discription{max-width:509px;width:100%;line-height:22px;color:black;font-size:14px}.article__right-text{margin:0 0 58px 90px;position:relative}.technology{padding-bottom:130px;margin-bottom:115px}.technology__title-discription{max-width:463px;color:rgba(255,255,255,.6);font-family:Roboto;font-size:18px;font-style:normal;font-weight:400;line-height:22px;margin:40px 0 76px 0}.technology__rules{color:rgba(255,255,255,.6);max-width:447px;width:100%;padding-left:22px;position:relative;padding-bottom:28px}.technology__rules:before{content:'';position:absolute;width:6px;height:6px;background-color:#5555e8;left:0;top:5px}.technology__wrap{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;padding-bottom:130px;border-bottom:1px solid rgba(255,255,255,.6)}.technology__left{width:50%}.technology__right{width:50%;background-image:url(images/tc1.png);background-position:80% 60%;background-size:140%;background-repeat:no-repeat}.reviews__slider{margin:100px 0 0 0;padding-bottom:140px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;position:relative}.reviews__slider .slick-active{width:670px}.reviews__slider .slick-prev{position:absolute;top:-162px;right:85px;background-image:url(images/prev.svg);background-position:center;background-repeat:no-repeat}.reviews__slider .slick-next{position:absolute;right:0;top:-162px;background-image:url(images/next.svg);background-position:center;background-repeat:no-repeat}
    }.package-content{margin-bottom:150px;position:relative}.package-body{display:-webkit-box;display:-ms-flexbox;display:flex;-ms-flex-wrap:wrap;flex-wrap:wrap}.package-item{-webkit-box-flex:0;-ms-flex:0 1 25%;flex:0 1 25%;padding:0 8px 15px 8px}@media (max-width:1140px){.package-item{-webkit-box-flex:0;-ms-flex:0 1 33.333333%;flex:0 1 33.333333%}}@media (max-width:868px){.package-item{-webkit-box-flex:0;-ms-flex:0 1 50%;flex:0 1 50%}}@media (max-width:480px){.package-item{-webkit-box-flex:0;-ms-flex:0 1 100%;flex:0 1 100%;padding:0 0 10px 0}}.package-itemContent{padding:20px 35px;background-color:#F0F8FF;background-image:url(images/bg-package.svg);background-position:0 0;background-repeat:repeat-x;border-radius:6px;position:relative;overflow:hidden}.package-itemAccount{-webkit-box-flex:0;-ms-flex:0 1 33.333333%;flex:0 1 33.333333%;padding:0 8px 20px 8px}@media (max-width:1140px){.package-itemAccount{-webkit-box-flex:0;-ms-flex:0 1 33.333333%;flex:0 1 33.333333%}}@media (max-width:868px){.package-itemAccount{-webkit-box-flex:0;-ms-flex:0 1 50%;flex:0 1 50%}}@media (max-width:580px){.package-itemAccount{-webkit-box-flex:0;-ms-flex:0 1 100%;flex:0 1 100%;padding:0 0 20px 0}}.package-itemAccountContent{padding:25px 30px;background-color:#151053;background-image:url(images/bg-package.svg);background-position:0 0;background-repeat:repeat-x;border-radius:6px;position:relative;overflow:hidden}.package-limited{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:end;-ms-flex-align:end;align-items:flex-end;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;max-width:130px;min-height:50px;padding:5px 15px;border-radius:40px;background:#a7885b;color:#fff;font-size:14px;font-family:Roboto,sans-serif;font-weight:400;position:absolute;top:-25px;left:0;right:0;margin:0 auto}.package-discount{width:120px;height:30px;padding-bottom:4px;display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;color:#fff;font-size:14px;font-family:Roboto,sans-serif;font-weight:400;position:absolute;top:10px;right:-31px;background:-webkit-gradient(linear,left top,left bottom,color-stop(-15%,#ff1f00),to(rgba(235,14,0,0)));background:linear-gradient(180deg,#ff1f00 -15%,rgba(235,14,0,0) 100%);-webkit-transform:rotate(45deg);transform:rotate(45deg)}.package-name{padding:20px 0;color:#1c1c1f;font-size:20px;font-family:'Titillium Web',sans-serif;font-weight:400;letter-spacing:2px;text-align:center}.package-price{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:end;-ms-flex-align:end;align-items:flex-end;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;padding-bottom:30px}.package-price span{color:#fff;font-size:44px;font-family:'Titillium Web',sans-serif;font-weight:400;text-align:center;position:relative}.package-price span.symbol{font-size:20px;position:absolute;left:-15px;top:7px}.package-price span.old-price{margin-left:20px;padding-bottom:5px;font-size:16px;color:rgba(255,255,255,.5);text-decoration:line-through}.package-price span.old-price span.symbol{color:#1c1c1f;font-size:12px;text-decoration:line-through;position:absolute;left:-8px;top:2px}.package-info>div.package-infoItem:last-of-type{border-bottom:0;margin-bottom:25px}.package-infoItem{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.1)}.package-infoItem p{color:#3d3d42;font-size:12px;font-family:'Titillium Web',sans-serif;font-weight:400;text-transform:uppercase}.package-infoItem span{color:#fff;font-size:14px;font-family:'Titillium Web',sans-serif;font-weight:400}.package-link{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center}.package-link a{display:-webkit-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;min-height:56px;padding:5px 30px;border:1px solid #ec5598;border-radius:40px;background:0 0;color:#fff;font-size:16px;font-family:'Titillium Web',sans-serif;font-weight:700;-webkit-transition:background .5s linear;transition:background .5s linear}.package-link a:hover{background:#FF3737}</style>
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="<?php echo e(route('dashboard1')); ?>" class="brand-logo"  style="margin-right: 40%;">
               <img src="<?php echo e(asset('img/new/log1.png')); ?>" alt="" style="margin-left: 40px;">
            </a>
            <div class="nav-control" style="margin-left: 150px;">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		<!--**********************************
            Chat box start
        ***********************************-->
	
		<!--**********************************
            Chat box End
        ***********************************-->
		
		<!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="dashboard_bar">
                                
                            </div>

                        <ul class="navbar-nav header-right">
							
							
							
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <img src="<?php echo e(asset('avatar/'.Auth::user()->avatar)); ?>" width="20" alt=""/>
									<div class="header-info">
										<span><?php echo e(Auth::user()->name); ?></span>
									</div>
                                </a>
                                
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
         <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('dashboard1')); ?>" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        

                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('manageWallet')); ?>">
						<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Profile</span>
						</a>
                       
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('investment')); ?>">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">Packages</span>
						</a>
                        
                    </li>
                      <li><a class="has-arrow ai-icon" href="<?php echo e(route('transactionAll')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Transactions</span>
						</a> 
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('nft')); ?>" aria-expanded="false">
							<i class="flaticon-381-layer-1"></i>
							<span class="nav-text">Market Place</span>
						</a> 
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('loan')); ?>" aria-expanded="false">
							<i class="flaticon-381-heart"></i>
							<span class="nav-text">Loan</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('logout')); ?>" aria-expanded="false">
							<i class="flaticon-381-exit"></i>
							<span class="nav-text">Logout</span>
						</a> 
                    </li>
                   
                </ul>
                    
			</div>
                  
                    
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                
                <!-- row -->
            <div class="row">
                <section class="content">
                    
                
                    <div class="staticTitle">
                        <h2 style="color:black;">Packages</h2>
                    </div>
                    
                    <div class="package-content">
                                    <div class="timer-body">
                                
                                <div class="discount-timer"></div>
                            </div>
                    
                        <div class="tab_content tab-pane fade show active" id="plans1">
                            <div class="package-body">
                                <div class="package-item">
                                    <div class="package-itemContent">
                                            
                                            <div class="package-discount">
                                            
                                            </div>
                                        <div style="font-size:30px" class="package-name">
                                            Basic 
                                        </div>
                                        <div class="package-price">
                                            
                                                <span style="font-size: 25px; color:black;">
                                                    <span class="symbol"></span>
                                                5% After <br> 24Hrs
                                                </span>
                                        </div>
                                        
                                        <div class="package-info">
                                            <div class="package-infoItem">
                                               
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Min: $50</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Max: $1999</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;"> Referrals: 10%</p>
                                                
                                            </div>
                                            
                                        </div>
                                        <div class="package-link">
                                            <a style="color:black;" href="<?php echo e(route('saveInvest',['name'=>'Basic', 'min'=>'50', 'max'=>'1999', 'period'=>'1', 'reward'=>'5'])); ?>">Invest</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="package-item">
                                    <div class="package-itemContent">
                                            
                                            <div class="package-discount">
                                            
                                            </div>
                                        <div style="font-size:30px" class="package-name">
                                            Business 
                                        </div>
                                        <div class="package-price">
                                            
                                                <span style="font-size: 25px; color:black;">
                                                    <span class="symbol"></span>
                                                15% After 7 days
                                                </span>
                                        </div>
                                        
                                        <div class="package-info">
                                            <div class="package-infoItem">
                                               
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Min: $2000</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Max: $4999</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Referrals: 10%</p>
                                                
                                            </div>
                                            
                                        </div>
                                        <div class="package-link">
                                            <a style="color:black;" href="<?php echo e(route('saveInvest',['name'=>'Business', 'max'=>'2000', 'min'=>'4999', 'period'=>'7', 'reward'=>'15'])); ?>">Invest</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="package-item">
                                    <div class="package-itemContent">
                                            
                                            <div class="package-discount">
                                            
                                            </div>
                                        <div style="font-size:30px" class="package-name">
                                            Company 
                                        </div>
                                        <div class="package-price">
                                            
                                                <span style="font-size: 25px; color:black;">
                                                    <span class="symbol"></span>
                                                30% After 10 Days
                                                </span>
                                        </div>
                                        
                                        <div class="package-info">
                                            <div class="package-infoItem">
                                               
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Min: $5000</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Max: $9999</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">3 Referrals: 30%</p>
                                                
                                            </div>
                                            
                                        </div>
                                        <div class="package-link">
                                            <a style="color:black;" href="<?php echo e(route('saveInvest',['name'=>'Basic', 'max'=>'9999', 'min'=>'5000', 'period'=>'10', 'reward'=>'30'])); ?>">Invest</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="package-item">
                                    <div class="package-itemContent">
                                            
                                            <div class="package-discount">
                                            
                                            </div>
                                        <div style="font-size:30px" class="package-name">
                                            Expert
                                        </div>
                                        <div class="package-price">
                                            
                                                <span style="font-size: 25px; color:black;">
                                                    <span class="symbol"></span>
                                               60% After <br> 30 Days
                                                </span>
                                        </div>
                                        
                                        <div class="package-info">
                                            <div class="package-infoItem">
                                               
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Min: $10000</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">Max: Unlimited</p>
                                            </div>
                                            <div class="package-infoItem">
                                                <p style="font-size: 16px;">3 Referrals: 30%</p>
                                                
                                            </div>
                                            
                                        </div>
                                        <div class="package-link">
                                            <a style="color:black;" href="<?php echo e(route('saveInvest',['name'=>'Expert', 'max'=>'10000000', 'min'=>'10000', 'period'=>'30', 'reward'=>'60'])); ?>">Invest</a>
                                        </div>
                                    </div>
                                </div>
                                            
                            </div>
                        </div> 
                    </div> 
                <section>
            </div>   
           
           
            </div>
        </div>

		
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
  
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

	</div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!-- Required vendors -->
    <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	
	<!-- Chart piety plugin files -->
    <script src="<?php echo e(asset('vendor/peity/jquery.peity.min.js')); ?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo e(asset('vendor/apexchart/apexchart.js')); ?>"></script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo e(asset('js/dashboard/dashboard-1.js')); ?>"></script>
	
	<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
	<script src=" <?php echo e(asset('js/dezz.js')); ?>"></script>

</body>
</html>