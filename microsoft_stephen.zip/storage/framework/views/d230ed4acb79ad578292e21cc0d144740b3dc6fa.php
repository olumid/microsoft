<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="TradeMinePay is the best and modern platform to invest in cryptocurrencies!">
    <meta name="keywords" content="Crypto, investments, TradeMinePay">
    <meta name="author" content="1DevLab">

    <!-- Page Title -->
    <title>REGISTER HERE</title>
    <!-- Favicon Icon -->
    <link rel="icon" type="image/png" href="images/favicon.ico">
    <!-- Icon fonts -->
    <link href="<?php echo e(asset('css/css-themify-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-flaticon.css')); ?>" rel="stylesheet">
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('css/css-bootstrap.min.css')); ?>" rel="stylesheet">
    <!-- Plugins for this template -->
    <link href="<?php echo e(asset('css/css-font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-owl.theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-slick.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-slick-theme.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-owl.transitions.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-jquery.fancybox.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('https://www.google.com/recaptcha/api.js')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/css-odometer-theme-default.css')); ?>" rel="stylesheet"><!-- Custom styles for this template -->
    <link href="<?php echo e(asset('css/css-style.css')); ?>" rel="stylesheet">
<style>
 
</style>
</head><body>

    <!-- start of page-wrapper -->
    <div class="page-wrapper">

        <!-- start of preloader -->
        <div class="preloader">
            <div class="sk-fading-circle">
                <div class="sk-circle1 sk-circle"></div>
                <div class="sk-circle2 sk-circle"></div>
                <div class="sk-circle3 sk-circle"></div>
                <div class="sk-circle4 sk-circle"></div>
                <div class="sk-circle5 sk-circle"></div>
                <div class="sk-circle6 sk-circle"></div>
                <div class="sk-circle7 sk-circle"></div>
                <div class="sk-circle8 sk-circle"></div>
                <div class="sk-circle9 sk-circle"></div>
                <div class="sk-circle10 sk-circle"></div>
                <div class="sk-circle11 sk-circle"></div>
                <div class="sk-circle12 sk-circle"></div>
            </div>
        </div>
        <!-- end of preloader -->

        <!-- Start of header -->
        <header id="header" class="site-header header-style-1"><nav class="navigation navbar navbar-default"><div class="container">
                    <div class="navbar-header">
                        <button type="button" class="open-btn">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="/">

                            <a class="navbar-brand" href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('images/image2-logo.png')); ?>" alt>
                         </a>
                    </div>
                    <div id="navbar" class="navbar-collapse collapse navbar-right navigation-holder">
                        <button class="close-navbar"><i class="ti-close"></i></button>
                        <ul class="nav navbar-nav">
                            <li><a href="<?php echo e(route('/')); ?>">Home</a></li>
                            <li><a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                            <li><a href="<?php echo e(route('terms')); ?>">Terms of Services</a></li>
                            <li><a href="<?php echo e(route('get-login')); ?>">Login</a></li>


                        </ul></div><!-- end of nav-collapse -->

                    


                </div><!-- end of container -->
            </nav></header><!-- end of header --><!-- start of hero slider -->


        <!-- TradingView Widget BEGIN -->
        <div class="tradingview-widget-container">
            <div class="tradingview-widget-container__widget"></div>
            <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com" rel="noopener" target="_blank"><span class="blue-text">Ticker Tape</span></a> by TradingView</div>
            <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-ticker-tape.js" async>
                {
                    "symbols": [
                    {
                        "proName": "FOREXCOM:SPXUSD",
                        "title": "S&P 500"
                    },
                    {
                        "proName": "FOREXCOM:NSXUSD",
                        "title": "Nasdaq 100"
                    },
                    {
                        "proName": "FX_IDC:EURUSD",
                        "title": "EUR/USD"
                    },
                    {
                        "proName": "BITSTAMP:BTCUSD",
                        "title": "BTC/USD"
                    },
                    {
                        "proName": "BITSTAMP:ETHUSD",
                        "title": "ETH/USD"
                    }
                ],
                        "colorTheme": "light",
                        "isTransparent": false,
                        "displayMode": "adaptive",
                        "locale": "en"
                }
            </script>
        </div>
        <!-- TradingView Widget END -->

        <!-- start of Choos Section -->



        <section class="service_section padding"><div class="container">
                <div class="section_heading  mb-50">

                    <div class="row" style="padding-left: 10px;">
                        <div class="col-xl-10" >
                            <div class="register-form login-form">
                                <div class="form-header">
                                    <h3 class="login-form-title" style="text-align: center;">Account Registration</h3>
                                </div>
                                <form method="POST" action="<?php echo e(route('addAccount')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php if($errors->any()): ?>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="alert alert-danger" style="font-size:15px;">
                                                <i class=""></i><?php echo e($error); ?>

                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <div class="form-group">
                                        <label for="name">Email</label>
                                        <input id="email" type="email" class="form-control " name="email" value="" required autocomplete="email">
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-12">
                                            <label for="name">Username</label>
                                            <input id="name" type="text" class="form-control " name="username" value="" required autocomplete="username" autofocus>
                                        </div>

                                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-12">
                                            <label for="first_name">First Name</label>
                                            <input id="first_name" type="text" class="form-control " name="first_name" value="" required autocomplete="first_name" autofocus>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-12">
                                            <label for="last_name">Last Name</label>
                                            <input id="last_name" type="text" class="form-control " name="last_name" value="" required autocomplete="last_name" autofocus>
                                        </div>

                                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-12">
                                            <label for="telephone">Telephone</label>
                                            <input id="telephone" type="text" class="form-control " name="phone" value="" required autocomplete="phone" autofocus>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-12">
                                            <div class="d-block">
                                                <label for="password" class="control-label ">Password</label>
                                            </div>
                                            <input id="password" type="password" class="form-control " name="password"  required="">
                                        </div>

                                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-12">
                                            <div class="d-block">
                                                <label for="password" class="control-label ">Confirm Password</label>
                                            </div>
                                            <input  type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" name="agree" class="custom-control-input" id="agree">
                                            <label class="custom-control-label" for="agree">I agree with the terms and conditions</label>
                                        </div>
                                    </div>

                                    <div class="text-center">
                                        <div class="g-recaptcha" data-sitekey="6LfbLc0UAAAAAFyOVwScCKfFuLo4sp4yjG3LH8jB" data-theme="light" data-size="normal" id="recaptcha-element"></div>
                                    </div>

                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-lg btn-block">
                                            Register
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>

                </div><!-- /Section Heading -->
            </div>
        </section><!-- end of Service Section --><!-- start of fun-fact section -->


        <!-- start of callback section -->
        <section class="callback_section"><div class="container">
            </div>
            <!-- start of footer section --><footer class="footer_section"><div class="container">
                    <div class="row widget_wrapper">
                        <div class="col-lg-3 col-sm-6 col-xs-12 sm-padding">
                            <p>TradeMinePay is the best and modern platform to invest in cryptocurrencies!</p>
                            <ul class="footer_social"><li class="fstitle">Follow Us <span>:</span></li>
                                <li><a href="https://facebook.com"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="https://twitter.com"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://telegram.com"><i class="fa fa-telegram"></i></a></li>
                            </ul></div>

                        <div class="col-lg-3 col-sm-6 col-xs-12 sm-padding">
                            <h4>Contact us</h4>
                            <ul class="widget_info"><li>
                                    <p class="text-color">Address :</p>
                                    <p>Krakowskie Prezedmiescie 20/21 00-071 Warshaw, Poland</p>
                                </li>
                                <li>
                                    <p class="text-color">Call Us :</p>
                                    <p>(481) 778-110-86</p>
                                </li>
                                <li>
                                    <p class="text-color">Email:</p>
                                    <p>info@trademinepay.com</p>
                                </li>
                            </ul></div>

                        <div class="col-lg-3 col-sm-6 col-xs-12 sm-padding">
                            <h4>Quick Links</h4>
                            <ul class="widget_info">
                            <li><a href="<?php echo e(route('terms')); ?>">Terms of Services</a></li>
                            <li><a href="<?php echo e(route('privacy')); ?>">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="row">
                        <div class="copyright">TradeMinePay © 2010 All Right Reserved</div>
                    </div>
                </div>
            </footer><!-- end of footer section--></div>
    <!-- end of page-wrapper -->



    <!-- All JavaScript files
    ================================================== -->
    <script src="<?php echo e(asset('js/js-jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/js-bootstrap.min.js')); ?>"></script>
    <!-- Plugins for this template -->
    <script src="<?php echo e(asset('js/js-jquery-plugin-collection.js')); ?>"></script>
    <!-- Custom script for this template -->
    <script src="<?php echo e(asset('js/js-script.js')); ?>"></script>
    </body></html>
