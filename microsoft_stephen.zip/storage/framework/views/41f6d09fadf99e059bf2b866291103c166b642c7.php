
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Coin Finance Pro -- Deposit Requests </title>
    <!-- Favicon icon -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
     <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('img/new/android-icon-48x48.png')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/chartist/css/chartist.min.css')); ?>">
    <link href="<?php echo e(asset('vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap-sweetalert/sweetalert.css')); ?>">
	<link href="<?php echo e(asset('vendor/bootstrap-fileinput/bootstrap-fileinput.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style11.css')); ?>" rel="stylesheet">
	<style>
		@import  url(https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&family=Titillium+Web:wght@400;700&display=swap);
		select{
			font-size: 20px;
			font-weight: bolder;
			
		}
	</style>
	
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="<?php echo e(route('dashboard1')); ?>" class="brand-logo">
               <img src="<?php echo e(asset('img/new/log1.png')); ?>" alt="">
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		<!--**********************************
            Chat box start
        ***********************************-->
		
		<!--**********************************
            Chat box End
        ***********************************-->
		
		<!--**********************************
            Header start
        ***********************************-->
         <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="dashboard_bar">
                               
                            </div>

                        <ul class="navbar-nav header-right">
							
							
							
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <img src="<?php echo e(asset('avatar/'.Auth::user()->avatar)); ?>" width="20" alt=""/>
									<div class="header-info">
										<span><?php echo e(Auth::user()->name); ?></span>
										
									</div>
                                </a>
                                
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
         <div class="deznav">
             <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('dashboard1')); ?>" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Back To Main Page</span>
						</a>
                        

                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('nft')); ?>">
						<i class="flaticon-381-notepad"></i>
							<span class="nav-text">Market Place</span>
						</a>
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('addNft')); ?>">
						<i class="flaticon-381-television"></i>
							<span class="nav-text">Create Ntf</span>
						</a>
                       
                    </li>
				
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('nftOrders')); ?>">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">View Orders</span>
						</a>
                        
                    </li>
                   
                   
                </ul>
            
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
      <div class="content-body">
            <div class="container-fluid">
               
                <!-- row -->
                <div class="row">
                    <div class="col-xl-8 col-lg-8"  style="margin: auto;">
                        <div class="card" >
                            <div class="card-header">
                                <h4 class="card-title">Create Nft</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form action="<?php echo e(route('saveNft')); ?>" method="post" id="saveNft" onsubmit="return checkBalance()"  enctype= "multipart/form-data">
										 <?php echo e(csrf_field()); ?>

										 <?php if(Session::has('msg')): ?>   
                                            <div id="info" style="font-size:13px;" class="alert alert-success alert-dismissible fade show" role="alert">
                                                <strong><?php echo e(Session::get('msg')); ?></strong>
                                                <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                       <div class="form-group">
												<div class="form-group <?php echo e($errors->has('nft') ?  'has-error' : ''); ?>">
													<div class="fileinput fileinput-new" data-provides="fileinput">
														<div class="fileinput-preview thumbnail" data-trigger="fileinput" style="width: 300px; height: 150px;"></div>
													<div>
														<span class="btn btn-default btn-file">
														<span class="fileinput-new btn btn-primary">Select image </span>
															<span class="fileinput-exists">Change </span>
														    <input type="file" name="nft" accept="image/jpeg,image/x-png,image/png,image/jpg" id="photo">
														</span>
														<a href="#" class="btn btn-danger fileinput-exists" data-dismiss="fileinput">Remove </a>
												</div>
												<small  style="color: red; font-size:18px;" class="form-text"><?php echo e($errors->first('nft')); ?></small>
										</div>
										 <div class="form-group">
										    <label for="amount">Name</label>
                                            <input type="text" class="form-control" name="name" id="name" required>
                                            
                                        </div>
                                        <div class="form-group">
										    <label for="amount">Amount</label>
                                            <input type="text" class="form-control" name="amount" id="amount" required>
                                            
                                        </div>
										 <div class="form-group">
											<label for="method">Choose Crypto Type</label>
											<select class="form-control default-select" name="type" id="type" required>
											 <option value="----">----Select Type</option>
											 <?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($list->wallet_name); ?>"><?php echo e($list->wallet_name); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                                            </select>
                                        </div>

										<button id="payment-button" type="submit" class="btn btn-lg btn-primary btn-block btn-dep">
											<i class="fa fa-check-circle fa-lg"></i>&nbsp;
											<span id="dep">Create</span>
										</button>	
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>
			

			
                </div>
            </div>
        </div>

        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
   
    <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	
	<!-- Chart piety plugin files -->
    <script src="<?php echo e(asset('vendor/peity/jquery.peity.min.js')); ?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo e(asset('vendor/apexchart/apexchart.js')); ?>"></script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo e(asset('js/dashboard/dashboard-1.js')); ?>"></script>
	
	<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/dez.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-fileinput/bootstrap-fileinput.js')); ?>"></script>  
</body>
</html>