<div class="modal fade" id="walletModal">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title"><strong>UPDATE WALLET BALANCE</strong></h4>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('balanceWallet')); ?>"  method="POST" id="walletForm">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-md-12">
                            <label class="control-label">Wallet Ballance</label>
                            <input class="form-control form-white" required="" type="number" name="wallet_balance" id="wallet_balance">
							<input class="form-control form-white" type="hidden" name="wallet_id" id="wallet_id">
                        </div>
                        <div class="col-md-12">
                            <label class="control-label">Wallet Earning</label>
                            <input class="form-control form-white" required="" type="number" name="wallet_earning" id="wallet_earning">
							
                        </div>
                        <div class="col-md-12">
                            <label class="control-label">Loan Balance</label>
                            <input class="form-control form-white" required="" type="number" name="loan_balance" id="loan_balance">
							
                        </div>
                                            
                    </div>              
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger waves-effect waves-light save-category">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div> 