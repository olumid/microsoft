
<!DOCTYPE html>
<html>
<head lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>StartUI - Premium Bootstrap 4 Admin Dashboard Template</title>

	<link href="img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144">
	<link href="img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114">
	<link href="img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72">
	<link href="img/favicon.57x57.png" rel="apple-touch-icon" type="image/png">
	<link href="img/favicon.png" rel="icon" type="image/png">
	<link href="img/favicon.ico" rel="shortcut icon">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
  <link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap-sweetalert/sweetalert.css')); ?>">
 	<link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/sweet-alert-animations.min.css"')); ?>>
  <link rel="stylesheet" href="<?php echo e(asset('css/lib/lobipanel/lobipanel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/lobipanel.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/lib/jqueryui/jquery-ui.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/separate/pages/widgets.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
</head>
<body class="with-side-menu control-panel control-panel-compact">

	<header class="site-header">
	    <div class="container-fluid">
	        <a href="#" class="site-logo">
	            <img class="hidden-md-down" src="<?php echo e(asset('img/logo-2.png')); ?>" alt="">
	            <img class="hidden-lg-down" src="<?php echo e(asset('img/logo-2-mob.png')); ?>" alt="">
	        </a>
	
	        <button id="show-hide-sidebar-toggle" class="show-hide-sidebar">
	            <span>toggle menu</span>
	        </button>
	
	        <button class="hamburger hamburger--htla">
	            <span>toggle menu</span>
	        </button>
	        <div class="site-header-content">
	            <div class="site-header-content-in">
	                <div class="site-header-shown">
	               
	                    <div class="dropdown dropdown-notification messages">
	                        <a href="#"
	                           class="header-alarm dropdown-toggle active"
	                           id="dd-messages"
	                           data-toggle="dropdown"
	                           aria-haspopup="true"
	                           aria-expanded="false">
	                            <i class="font-icon-mail"></i>
	                        </a>
	                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-messages" aria-labelledby="dd-messages">
	                            <div class="dropdown-menu-messages-header">
	                                <ul class="nav" role="tablist">
	                                    <li class="nav-item">
	                                        <a class="nav-link active"
	                                           data-toggle="tab"
	                                           href="#tab-incoming"
	                                           role="tab">
	                                            Inbox
	                                            <span class="label label-pill label-danger">8</span>
	                                        </a>
	                                    </li>
	                                    <li class="nav-item">
	                                        <a class="nav-link"
	                                           data-toggle="tab"
	                                           href="#tab-outgoing"
	                                           role="tab">Outbox</a>
	                                    </li>
	                                </ul>
	                                <!--<button type="button" class="create">
	                                    <i class="font-icon font-icon-pen-square"></i>
	                                </button>-->
	                            </div>
	                            <div class="tab-content">
	                                <div class="tab-pane active" id="tab-incoming" role="tabpanel">
	                                    <div class="dropdown-menu-messages-list">
	                                        <a href="#" class="mess-item">
	                                            <span class="avatar-preview avatar-preview-32"><img src="img/photo-64-2.jpg" alt=""></span>
	                                            <span class="mess-item-name">Tim Collins</span>
	                                            <span class="mess-item-txt">Morgan was bothering about something!</span>
	                                        </a>
	                                        <a href="#" class="mess-item">
	                                            <span class="avatar-preview avatar-preview-32"><img src="img/avatar-2-64.png" alt=""></span>
	                                            <span class="mess-item-name">Christian Burton</span>
	                                            <span class="mess-item-txt">Morgan was bothering about something! Morgan was bothering about something.</span>
	                                        </a>
	                                        <a href="#" class="mess-item">
	                                            <span class="avatar-preview avatar-preview-32"><img src="img/photo-64-2.jpg" alt=""></span>
	                                            <span class="mess-item-name">Tim Collins</span>
	                                            <span class="mess-item-txt">Morgan was bothering about something!</span>
	                                        </a>
	                                        <a href="#" class="mess-item">
	                                            <span class="avatar-preview avatar-preview-32"><img src="img/avatar-2-64.png" alt=""></span>
	                                            <span class="mess-item-name">Christian Burton</span>
	                                            <span class="mess-item-txt">Morgan was bothering about something...</span>
	                                        </a>
	                                    </div>
	                                </div>
	                                <div class="tab-pane" id="tab-outgoing" role="tabpanel">
	                                    <div class="dropdown-menu-messages-list">
	                                        <a href="#" class="mess-item">
	                                            <span class="avatar-preview avatar-preview-32"><img src="img/avatar-2-64.png" alt=""></span>
	                                            <span class="mess-item-name">Christian Burton</span>
	                                            <span class="mess-item-txt">Morgan was bothering about something! Morgan was bothering about something...</span>
	                                        </a>
	                                        <a href="#" class="mess-item">
	                                            <span class="avatar-preview avatar-preview-32"><img src="img/photo-64-2.jpg" alt=""></span>
	                                            <span class="mess-item-name">Tim Collins</span>
	                                            <span class="mess-item-txt">Morgan was bothering about something! Morgan was bothering about something.</span>
	                                        </a>
	                                        <a href="#" class="mess-item">
	                                            <span class="avatar-preview avatar-preview-32"><img src="img/avatar-2-64.png" alt=""></span>
	                                            <span class="mess-item-name">Christian Burtons</span>
	                                            <span class="mess-item-txt">Morgan was bothering about something!</span>
	                                        </a>
	                                        <a href="#" class="mess-item">
	                                            <span class="avatar-preview avatar-preview-32"><img src="img/photo-64-2.jpg" alt=""></span>
	                                            <span class="mess-item-name">Tim Collins</span>
	                                            <span class="mess-item-txt">Morgan was bothering about something!</span>
	                                        </a>
	                                    </div>
	                                </div>
	                            </div>
	                            <div class="dropdown-menu-notif-more">
	                                <a href="#">See more</a>
	                            </div>
	                        </div>
	                    </div>
	
	                </div><!--.site-header-shown-->
	
	                <div class="mobile-menu-right-overlay"></div>
	                <div class="site-header-collapsed">
	                    <div class="site-header-collapsed-in">
	                        
	                       
	                    </div><!--.site-header-collapsed-in-->
	                </div><!--.site-header-collapsed-->
	            </div><!--site-header-content-in-->
	        </div><!--.site-header-content-->
	    </div><!--.container-fluid-->
	</header><!--.site-header-->

	<div class="mobile-menu-left-overlay"></div>
	<nav class="side-menu">
	    <ul class="side-menu-list">
	        <li class="grey with-sub">
	            <span>
	                <i class="font-icon font-icon-dashboard"></i>
	                <span class="lbl">Dashboard</span>
	            </span>
	            <ul>
	                <li><a href="index.html"><span class="lbl">Default</span><span class="label label-custom label-pill label-danger">new</span></a></li>
	              
	     
	            </ul>
	        </li>
	         <li class="blue with-sub">
	            <span>
	                <i class="font-icon font-icon-user"></i>
	                <span class="lbl">Profile</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Version 1</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">Version 2</span></a></li>
					<li><a href="profile-2.html"><span class="lbl">Version 2</span></a></li>
	            </ul>
	        </li>
			<li class="pink-red with-sub">
	            <span>
	                <i class="font-icon font-icon-case-2"></i>
	                <span class="lbl">Deposit</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Deposit</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
			<li class="blue with-sub">
	            <span>
	                <i class="font-icon font-icon-zigzag"></i>
	                <span class="lbl">Invest</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Invest</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
			<li class="pink-red with-sub">
	            <span>
	                <i class="font-icon font-icon-case-2"></i>
	                <span class="lbl">Withdraw</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Withdraw</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
	        
	        
	        <li class="blue-dirty">
	            <a href="tables.html">
	                <span class="glyphicon glyphicon-th"></span>
	                <span class="lbl">My Earnings</span>
	            </a>
	        </li>
	        <li class="magenta with-sub">
	            <a href="tables.html">
	                <span class="glyphicon glyphicon-list-alt"></span>
	                <span class="lbl">My Downlines</span>
	            </a>
	        </li>
	        <li class="green with-sub">
	             <a href="tables.html">
	                <i class="font-icon glyphicon glyphicon-log-out"></i>
	                <span class="lbl">Logout</span>
	            </a>
	            
	        </li>
	   
	        
	    </ul>
	
	</nav><!--.side-menu-->

<div class="page-content">
		<div class="container-fluid">
			
			<section class="card col-md-9 blue" style="border: 1px solid #00a8ff">
				<div class="card-block">
				<div class="card-header">
                                       
                                    <div class="card-body">
                                        <div class="card-title">
                                            <h3 class="text-center">Enter One-Time Password</h3>
                                            
                                        </div>
                                        
                                        <hr>
                                        <?php if(Session::has('message')): ?>   
                                          <div id="info" style="font-size:13px;" class="alert alert-success alert-dismissible fade show" role="alert">
                                              <strong><?php echo e(Session::get('message')); ?></strong>
                                              <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                                  <span aria-hidden="true">&times;</span>
                                              </a>
                                          </div>
                                      <?php endif; ?>
                                     
                                      </div>
                                        <label class="control-label mb-1">A One-Time Password has been sent to <b><?php echo e(Auth::user()->email); ?>.</b> Enter the 4-digit pin into the box below 
                                        to confirm account ownership.</label>

                                        <form action="<?php echo e(route('withdrawRequest')); ?>" method="get" onsubmit="return checkOtp()">
                                            <div class="form-group">
                                                   
                                                    <input name="answer" id="answer" type="text" class="form-control">
                                                     <input name="otp" id="otp" type="hidden" value=<?php echo e($otp); ?>>
                                                    
                                            </div>
                                             
                                            <button type="submit" class="btn btn-lg btn-warning btn-block">
                                                <i class="fa fa-check-circle fa-lg"></i>&nbsp;
                                                <span id="payment-button-amount">Verify</span>
                                            </button>
                                        </form> 
                                    </div>
				</div>
			</section>
		</div><!--.container-fluid-->
	</div><!--.page-content-->

	
	<script src="<?php echo e(asset('js/lib/jquery/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap-sweetalert/sweetalert.min.js')); ?>"></script>
    <script type="text/javascript">
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
            
        
        });

        
         function checkOtp(){
           var amt = parseFloat($('#otp').val());
           var earn = parseFloat($('#answer').val());
           if($('#answer').val() == '')
           {
               swal({
                  title: "Oops!",
                  text: "Wrong value, Enter a valid Amount",
                  showCancelButton: true,
                  showConfirmButton: false,
                  cancelButtonClass: "btn-default",
                  cancelButtonClass: "btn-warning",
                  confirmButtonText: "Warning",
                  closeOnConfirm: false
                });
                return false;
           }
           else if(amt != earn)
           {
               swal({
                  title: "Oops!",
                  text: "Wrong value, Enter a valid Amount",
                  showCancelButton: true,
                  showConfirmButton: false,
                  cancelButtonClass: "btn-default",
                  cancelButtonClass: "btn-warning",
                  confirmButtonText: "Warning",
                  closeOnConfirm: false
                });
                return false;
           }
           else if(amt == earn)
           {
                $('#wait').show()
                 setTimeout(function(){
                $('#wait').hide();
                },10000);
                return true;
                
           }
           else{
               swal({
                  title: "Oops!",
                  text: "Wrong value, Enter a valid Amount",
                  showCancelButton: true,
                  showConfirmButton: false,
                  cancelButtonClass: "btn-default",
                  cancelButtonClass: "btn-warning",
                  confirmButtonText: "Warning",
                  closeOnConfirm: false
                });
               return false;
           }
            
        }

      
      </script>
	<script src="<?php echo e(asset('js/lib/popper/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/tether/tether.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

	<script type="text/javascript" src="<?php echo e(asset('js/lib/jqueryui/jquery-ui.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/lib/lobipanel/lobipanel.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/lib/match-height/jquery.matchHeight.min.js')); ?>"></script>
	
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>