
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Welcome to Credit Invest</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
   
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/themify-icons/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link href="<?php echo e(asset('vendors/bootstrap-fileinput/bootstrap-fileinput.css')); ?>" rel="stylesheet">


    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>
    <!-- Left Panel -->

   <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo"></a>
                <a class="navbar-brand hidden" href="./"><img src="<?php echo e(asset('images/logo2.png')); ?>" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="<?php echo e(route('dashboard1')); ?>"> <i class="menu-icon fa fa-home"></i>Home</a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-user"></i>My Profile</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-user"></i><a href="maps-gmap.html">Update Account</a></li>
                            <li><i class="menu-icon fa fa-lock"></i><a href="maps-vector.html">Security</a></li>
                            <li><i class="menu-icon fa fa-cogs"></i><a href="maps-gmap.html">Wallet Details</a></li>
                            <li><i class="menu-icon fa fa-group"></i><a href="maps-vector.html">Verify Account</a></li>
                        </ul>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-th-list"></i>Withdrawal</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-th-list"></i>Deposit</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-list"></i>Transaction Log</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-suitcase"></i>Investment Packages</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-suitcase"></i>Loan</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-users"></i>My Downlines</a>
                    </li>
                     <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-users"></i>Credit Score</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('logout')); ?>"> <i class="menu-icon fa fa-dashboard"></i>Logout</a>
                    </li>
                    
                   
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
           <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        <button class="search-trigger"><i class="fa fa-search"></i></button>
                        <div class="form-inline">
                            <form class="search-form">
                                <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                                <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                            </form>
                        </div>

                        
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="<?php echo e(asset('images/admin.jpg')); ?>" alt="User Avatar">
                        </a>

                       
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a class="dropdown-toggle" href="#" data-toggle="dropdown"  id="language" aria-haspopup="true" aria-expanded="true">
                            <i class="flag-icon flag-icon-us"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="language">
                            <div class="dropdown-item">
                                <span class="flag-icon flag-icon-fr"></span>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-es"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-us"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-it"></i>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </header><!-- /header -->
        

        <div class="content mt-3">
            
            <div class="animated fadeIn">

                <div class="row">
                <div class="col-xl-5 col-lg-8">
                    <div class="card">
                            <div class="card-body">
                                <div class="stat-widget-one">
                                    <div class="stat-icon dib"><i class="ti-wallet text-warning border-warning"></i></div>
                                        <div class="stat-content dib">
                                            <div class="stat-heading text-warning" style="font-size:20px; font-weight:bold;">Available Earnings</div>
                                            <div class="stat-heading" style="font-size:25px;"><?php echo e($det1->earnings); ?></div>
                                            <input type="hidden" id="earnings"  name="earnings" value="<?php echo e($det1->earnings); ?>">
                                        </div>
                                    </div>
                            </div>
                            </div>
                        </div>
                </div>
                    
                    <div class="col-lg-6">
                        <div class="card">
                            
                            <div style="font-family: roboto; width:100%; padding:8px; font-weight:bold; font-size:20px; text-align: center; " class="btn  btn-warning">
                                *Select Withdraw Mode Below.*                               
                            </div>
                             <?php if(Session::has('msg')): ?>   
                                <div id="info" style="font-family: roboto; font-size:15px; margin:25px;" class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong><?php echo e(Session::get('msg')); ?></strong>
                                    <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </a>
                                </div>
                              <?php endif; ?>
                                <div id="invalid" style="font-family: roboto; font-size:15px; margin:30px; display:none;" class="alert alert-warning">
                                    <strong>Invalid Amount. Please, Enter a valid Amount</strong>
                                   
                                </div>
                                <div id="error" style="font-family: roboto; font-size:15px; margin:30px; display:none;" class="alert alert-danger fade show" role="alert">
                                    <strong>Error!, Insufficient balance</strong>
                                   
                                </div>
                                <div id="wait" style="font-family: roboto; font-size:15px; margin:30px; display:none;" class="alert alert-warning fade show" role="alert">
                                    <strong>Please wait.........</strong>
                                    
                                </div>
                        
                            <div class="card-body">
                                <div class="custom-tab">
                                        
                                    <nav>
                                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                            <a class="nav-item nav-link active" id="custom-nav-home-tab" data-toggle="tab" href="#custom-nav-home" role="tab" aria-controls="custom-nav-home" aria-selected="true">BTC</a>
                                            <a class="nav-item nav-link" id="custom-nav-eth-tab" data-toggle="tab" href="#custom-nav-eth" role="tab" aria-controls="custom-nav-eth" aria-selected="false">ETH</a>
                                            <a class="nav-item nav-link" id="custom-nav-ltc-tab" data-toggle="tab" href="#custom-nav-ltc" role="tab" aria-controls="custom-nav-ltc" aria-selected="false">LTC</a>
                                             <a class="nav-item nav-link" id="custom-nav-tron-tab" data-toggle="tab" href="#custom-nav-tron" role="tab" aria-controls="custom-nav-tron" aria-selected="false">TRON</a>
                                            <a class="nav-item nav-link" id="custom-nav-xrp-tab" data-toggle="tab" href="#custom-nav-xrp" role="tab" aria-controls="custom-nav-xrp" aria-selected="false">XRP</a>
                                        </div>
                                    </nav>
                                    <div class="tab-content pl-3 pt-2" id="nav-tabContent">
                                        <div class="tab-pane fade show active" id="custom-nav-home" role="tabpanel" aria-labelledby="custom-nav-home-tab" onsubmit="return checkBalance()">
                                            <form action="<?php echo e(route('saveWithdraw')); ?>" method="post" id="saveDeposit" onsubmit="return checkBalance()">
                                                <?php echo e(csrf_field()); ?>

                                                <div style="margin-top: 2%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                       
                                                        
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" name="tag" value="BTC">
                                                            </div>
                                                        </div>
                                                                             
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                <input type="hidden" id="b_val" value="<?php echo e($det->bitcoin_value); ?>">
                                                                <input type="text"  id="btc_value" placeholder="Value in BTC is displayed here" disabled="" class="form-control"></div>
                                                            </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                 <input id="usd" style="margin-top:20px;" required="" type="number" name="amount" placeholder="Enter Amount in USD" class="form-control">
                                                            </div>
                                                        </div>
                                                         <div class="col-12 col-md-9">
                                                                <p style="margin-left: 2%; font-family:Roboto; margin-top:40px; font-weight:bold; font-size:20px;">Enter  Your Bitcoin Wallet Address below</p>
                                                         </div>
                                                        
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                 <input name="transaction_id" style="background-color: #f3f0f0; margin-top:-5px;" type="text" value ="<?php echo e($det1->bitcoin_address); ?>" required="" placeholder="Enter Your BTC Wallet Address Here" class="form-control">
                                                            </div>
                                                        </div>
                                                        <button type="submit" style="margin-left: 3%; margin-top:10px;" class="save btn btn-warning">Click Here To Request Withdraw</button>
                                                    </div>
                                            
                                            </form>
                                        </div>
                                        <div class="tab-pane fade" id="custom-nav-eth" role="tabpanel" aria-labelledby="custom-nav-eth-tab">
                                            <form action="<?php echo e(route('saveWithdraw')); ?>" method="post" onsubmit="return checkBalance1()">
                                                <?php echo e(csrf_field()); ?>

                                                <div style="margin-top: 2%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                       
                                                        
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" name="tag" value="ETH">
                                                            </div>
                                                        </div>
                                                                             
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                <input type="hidden" id="e_val" value="<?php echo e($det->etherium_value); ?>">
                                                                <input type="text"  id="eth_value" placeholder="Value in ETH is displayed here" disabled="" class="form-control"></div>
                                                            </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                 <input id="usd1" style="margin-top:20px;" required="" type="number" name="amount" placeholder="Enter Amount in USD" class="form-control">
                                                            </div>
                                                        </div>
                                                         <div class="col-12 col-md-9">
                                                                <p style="margin-left: 2%; font-family:Roboto; margin-top:40px; font-weight:bold; font-size:20px;">Enter  Your Etherium Wallet Address below</p>
                                                         </div>
                                                        
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                 <input name="transaction_id" style="background-color: #f3f0f0; margin-top:-5px;" type="text" value ="<?php echo e($det1->etherium_address); ?>" required="" placeholder="Enter Your ETH Wallet Address Here" class="form-control">
                                                            </div>
                                                        </div>
                                                        <button type="submit" style="margin-left: 3%; margin-top:10px;" class="save btn btn-warning">Click Here To Request Withdraw</button>
                                                    </div>
                                            
                                            </form>
                                        </div>
                                        <div class="tab-pane fade" id="custom-nav-ltc" role="tabpanel" aria-labelledby="custom-nav-ltc-tab">
                                            <form action="<?php echo e(route('saveWithdraw')); ?>" method="post" onsubmit="return checkBalance2()">
                                                <?php echo e(csrf_field()); ?>

                                                <div style="margin-top: 2%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                       
                                                        
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" name="tag" value="LTC">
                                                            </div>
                                                        </div>
                                                                             
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                <input type="hidden" id="l_val" value="<?php echo e($det->litecoin_value); ?>">
                                                                <input type="text"  id="ltc_value" placeholder="Value in LTC is displayed here" disabled="" class="form-control"></div>
                                                            </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                 <input id="usd2" style="margin-top:20px;" required="" type="number" name="amount" placeholder="Enter Amount in USD" class="form-control">
                                                            </div>
                                                        </div>
                                                         <div class="col-12 col-md-9">
                                                                <p style="margin-left: 2%; font-family:Roboto; margin-top:40px; font-weight:bold; font-size:20px;">Enter  Your Litecoin Wallet Address below</p>
                                                         </div>
                                                        
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                 <input name="transaction_id" style="background-color: #f3f0f0; margin-top:-5px;" type="text" value ="<?php echo e($det1->litecoin_address); ?>" required="" placeholder="Enter Your LTC Wallet Address Here" class="form-control">
                                                            </div>
                                                        </div>
                                                         <button type="submit" style="margin-left: 3%; margin-top:10px;" class="save btn btn-warning">Click Here To Request Withdraw</button>
                                                    </div>
                                            
                                            </form>
                                           
                                        </div>

                                        <div class="tab-pane fade" id="custom-nav-tron" role="tabpanel" aria-labelledby="custom-nav-tron-tab">
                                             <form action="<?php echo e(route('saveWithdraw')); ?>" method="post" onsubmit="return checkBalance3()">
                                                <?php echo e(csrf_field()); ?>

                                                <div style="margin-top: 2%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                       
                                                        
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" name="tag" value="TRON">
                                                            </div>
                                                        </div>
                                                                             
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                <input type="hidden" id="t_val" value="<?php echo e($det->tron_value); ?>">
                                                                <input type="text"  id="tron_value" placeholder="Value in TRON is displayed here" disabled="" class="form-control"></div>
                                                            </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                 <input id="usd3" style="margin-top:20px;" required="" type="number" name="amount" placeholder="Enter Amount in USD" class="form-control">
                                                            </div>
                                                        </div>
                                                         <div class="col-12 col-md-9">
                                                                <p style="margin-left: 2%; font-family:Roboto; margin-top:40px; font-weight:bold; font-size:20px;">Enter  Your TRON Wallet Address below</p>
                                                         </div>
                                                        
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                 <input name="transaction_id" style="background-color: #f3f0f0; margin-top:-5px;" type="text" value ="<?php echo e($det1->tron_address); ?>" required="" placeholder="Enter Your ETH Wallet Address Here" class="form-control">
                                                            </div>
                                                        </div>
                                                         <button type="submit" style="margin-left: 3%; margin-top:10px;" class="save btn btn-warning">Click Here To Request Withdraw</button>
                                                    </div>
                                            
                                            </form>
                                        </div>

                                        <div class="tab-pane fade" id="custom-nav-xrp" role="tabpanel" aria-labelledby="custom-nav-xrp-tab">
                                             <form action="<?php echo e(route('saveWithdraw')); ?>" method="post" onsubmit="return checkBalance4()">
                                                <?php echo e(csrf_field()); ?>

                                                <div style="margin-top: 2%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                       
                                                        
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                            <input type="hidden" name="tag" value="XRP">
                                                            </div>
                                                        </div>
                                                                             
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                <input type="hidden" id="x_val" value="<?php echo e($det->xrp_value); ?>">
                                                                <input type="text"  id="xrp_value" placeholder="Value in XRP is displayed here" disabled="" class="form-control"></div>
                                                            </div>
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                 <input id="usd4" style="margin-top:20px;" required="" type="number" name="amount" placeholder="Enter Amount in USD" class="form-control">
                                                            </div>
                                                        </div>
                                                         <div class="col-12 col-md-9">
                                                                <p style="margin-left: 2%; font-family:Roboto; margin-top:40px; font-weight:bold; font-size:20px;">Enter  Your XRP Wallet Address below</p>
                                                         </div>
                                                        
                                                        <div class="form-group">
                                                            <div class="col-12 col-md-9">
                                                                 <input name="transaction_id" style="background-color: #f3f0f0; margin-top:-5px;" type="text" value ="<?php echo e($det1->xrp_address); ?>" required="" placeholder="Enter Your ETH Wallet Address Here" class="form-control">
                                                            </div>
                                                        </div>
                                                         <button type="submit" style="margin-left: 3%; margin-top:10px;" class="save btn btn-warning">Click Here To Request Withdraw</button>
                                                    </div>
                                            
                                            </form>
                                        </div>
                                        
                                    </div>
                                     
                                </div>

                                <div class="col-xl-3 col-lg-6">
                
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                </div>

           
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

    <!-- Right Panel -->

    
    <script src="<?php echo e(asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>    
    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
            
        
        });

        //BTC calc
        $(document).on("change keyup", "#usd", function(){
            var fee = parseFloat($('#usd').val());
            var b_val = parseInt($('#b_val').val());
            var res = parseFloat($('#b_val').val()) / 100000000;
            $('#btc_value').val( fee * res);
            $('#crypto_value').val( fee * res);
        });

         //ETH calc
        $(document).on("change keyup", "#usd1", function(){
            var fee = parseFloat($('#usd1').val());
            var b_val = parseInt($('#e_val').val());
            var res = parseFloat($('#e_val').val()) / 100000000;
            $('#eth_value').val( fee * res);
            $('#crypto_value1').val( fee * res);
        });

         //LTC calc
        $(document).on("change keyup", "#usd2", function(){
            var fee = parseFloat($('#usd2').val());
            var b_val = parseInt($('#l_val').val());
            var res = parseFloat($('#l_val').val()) / 100000000;
            $('#ltc_value').val( fee * res);
            $('#crypto_value2').val( fee * res);
        });

         //TRON calc
        $(document).on("change keyup", "#usd3", function(){
            var fee = parseFloat($('#usd3').val());
            var b_val = parseInt($('#t_val').val());
            var res = parseFloat($('#t_val').val()) / 100000000;
            $('#tron_value').val( fee * res);
            $('#crypto_value3').val( fee * res);
         });

         //XRP calc
        $(document).on("change keyup", "#usd4", function(){
            var fee = parseFloat($('#usd4').val());
            var b_val = parseInt($('#x_val').val());
            var res = parseFloat($('#x_val').val()) / 100000000;
            $('#xrp_value').val( fee * res);
            $('#crypto_value4').val( fee * res);
        });

    

        // Clipboard
        function copyToClipboard(){
            $('#link1').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l1').show()
           setTimeout(function(){
              $('#l1').hide();
            },3000)
        }

        function copyToClipboard1(){
            $('#link2').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l2').show()
           setTimeout(function(){
              $('#l2').hide();
            },3000)
        }

        function copyToClipboard2(){
            $('#link3').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l3').show()
           setTimeout(function(){
              $('#l3').hide();
            },3000)
        }


        function copyToClipboard3(){
            $('#link4').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l4').show()
           setTimeout(function(){
              $('#l4').hide();
            },3000)
        }

        function copyToClipboard4(){
            $('#link5').select();
            document.execCommand("copy");
            //alert('copied to clipboard');
           $('#l5').show()
           setTimeout(function(){
              $('#l5').hide();
            },3000)
        }
    
          function checkBalance(){
           var amt = parseFloat($('#usd').val());
           var earn = parseFloat($('#earnings').val());
           if(amt == 0)
           {
                $('#invalid').show()
                 setTimeout(function(){
                $('#invalid').hide();
                },3000);
                return false;
           }
           else if(amt > earn)
           {
               $('#error').show()
                 setTimeout(function(){
                $('#error').hide();
                },3000);
                return false;
           }
           else
           {
                $('#wait').show();
                 setTimeout(function(){
                $('#wait').hide();
                },10000);
                return true;
                
           }
            
         }

         function checkBalance1(){
           var amt = parseFloat($('#usd1').val());
           var earn = parseFloat($('#earnings').val());
           if(amt == 0)
           {
                $('#invalid').show()
                 setTimeout(function(){
                $('#invalid').hide();
                },3000);
                return false;
           }
           else if(amt > earn)
           {
               $('#error').show()
                 setTimeout(function(){
                $('#error').hide();
                },3000);
                return false;
           }
           else
           {
                $('#wait').show()
                 setTimeout(function(){
                $('#wait').hide();
                },10000);
                return true;    
           }
            
        }

         function checkBalance2(){
           var amt = parseFloat($('#usd2').val());
           var earn = parseFloat($('#earnings').val());
           if(amt == 0)
           {
                $('#invalid').show()
                 setTimeout(function(){
                $('#invalid').hide();
                },3000);
                return false;
           }
           else if(amt > earn)
           {
               $('#error').show()
                 setTimeout(function(){
                $('#error').hide();
                },3000);
                return false;
           }
           else
           {
                $('#wait').show()
                 setTimeout(function(){
                $('#wait').hide();
                },10000);
                return true;  
           }
            
        }

         function checkBalance3(){
           var amt = parseFloat($('#usd3').val());
           var earn = parseFloat($('#earnings').val());
           if(amt == 0)
           {
                $('#invalid').show()
                 setTimeout(function(){
                $('#invalid').hide();
                },3000);
                return false;
           }
           else if(amt > earn)
           {
               $('#error').show()
                 setTimeout(function(){
                $('#error').hide();
                },3000);
                return false;
           }
           else
           {
                $('#wait').show()
                 setTimeout(function(){
                $('#wait').hide();
                },10000);
                return true;
           }
            
        }

         function checkBalance4(){
           var amt = parseFloat($('#usd4').val());
           var earn = parseFloat($('#earnings').val());
           if(amt == 0)
           {
                $('#invalid').show()
                 setTimeout(function(){
                $('#invalid').hide();
                },3000);
                return false;
           }
           else if(amt > earn)
           {
               $('#error').show()
                 setTimeout(function(){
                $('#error').hide();
                },3000);
                return false;
           }
           else
           {
                $('#wait').show()
                 setTimeout(function(){
                $('#wait').hide();
                },10000);
                return true;
                
           }
            
        }

    
        </script>
    
    <script src="<?php echo e(asset('vendors/popper.js/dist/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap-fileinput/bootstrap-fileinput.js')); ?>"></script>    


</body>

</html>