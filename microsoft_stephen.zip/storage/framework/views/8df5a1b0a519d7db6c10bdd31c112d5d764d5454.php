<!DOCTYPE html>
<html class="no-js" lang="zxx">
   
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width,initial-scale=1" />
        <title>Checkout :: Hopkins - A Modern Barber Bootstrap4 Template</title>
        <!--== Favicon ==-->
        <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" />
        <!--== Google Fonts ==-->
        
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/app.min.css')); ?>" />
        
    </head>
    <body class="preloader-active">
        <!--== Start Header Area ==-->
        <div class="header-top-text">
            <div class="container">
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="header-top-text-content">
                            <p>5 FREE TREATS + SHIPPING WITH $40 ORDERS.*CODE: BBPAIR</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <header class="header-area">
            <!-- Start Header Config Area -->
            <div class="header-config-area">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-lg-6 d-none d-md-block">
                            <div class="header-config-content">
                                <ul class="config-nav nav">

                                    <li class="config-item">
                                        <a href="#">Language: English</a>

                                    </li>

                                </ul>
                            </div>
                        </div>
                        <div class="col-md-4 col-lg-6">
                            <div class="header-config-buttons">
                                <ul class="media-icons nav">
                                    <li class="btn-cart">
                                        <a href="cart.html"><i class="ion-bag"></i> <span>Shopping Cart:</span> <strong
                                                class="amount">$0.00</strong></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="ion-social-facebook"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="ion-social-linkedin"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="ion-social-instagram"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="ion-social-vimeo"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Header Config Area -->
            <!-- Start Header Navigation Area -->
            <div class="header-nav-area">
                <div class="container">
                    <div class="row align-items-center position-relative">
                        <div class="col-8 col-lg-2 col-xl-3">
                            <!-- Start Logo Wrapper -->
                            <div class="logo-wrap">
                                <a href="index.html"><img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="Logo" /></a>
                            </div>
                            <!-- End Logo Wrapper -->
                        </div>
                        <div class="col-lg-9 position-static col-xl-8 d-none d-lg-block">
                            <!-- Start Site Navigation -->
                            <nav class="site-navigation">
                                <ul class="main-nav nav">
                                    <li class=" active">
                                       <a href="<?php echo e(route('/')); ?>">Home</a>
                                   </li>

                                   <li class="">
                                       <a href="<?php echo e(route('about')); ?>">Who Area We</a>
                                   </li>

                                   <li class="has-submenu">
                                        <a href="<?php echo e(route('shop', ['category' =>'hair'])); ?>">Shop</a>
                                        <ul class="submenu-nav">
                                            <li><a href="<?php echo e(route('shop', ['category' =>'hair'])); ?>">Hair</a></li>
                                            <li><a href="<?php echo e(route('shop', ['category' =>'wigging tool'])); ?>">Wigging Tool</a></li>
                                            <li><a href="<?php echo e(route('cart')); ?>">Cart</a></li>
                                            <li><a href="<?php echo e(route('checkout')); ?>">Checkout</a></li>
                                        </ul>
                                    </li>
                                   
                                   <li class="">
                                     <a href="<?php echo e(route('get-login')); ?>">My Account</a>
                                   </li>
                                   <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                </ul>
                            </nav>
                            <!-- End Site Navigation -->
                        </div>
                        <div class="col-4 col-lg-1">
                            <!-- Start Search Box Area -->
                            <div class="search-box-wrap">
                                <ul class="search-box-inner nav">
                                    <li>
                                        <a href="#" class="btn-search"><i class="ion-search"></i> <i
                                                class="ion-close"></i></a>
                                        <div class="header-search-box">
                                            <form action="#">
                                                <div class="search-box-content"><label for="search"
                                                        class="sr-only"></label> <input type="search" id="search"
                                                        placeholder="type here and hit enter" /></div>
                                            </form>
                                        </div>
                                    </li>
                                    <li class="d-lg-none">
                                        <a href="javascript:void(0)" class="btn-menu"><i class="ion-navicon"></i></a>
                                    </li>
                                </ul>
                            </div>
                            <!-- End Search Box Area -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Header Navigation Area -->
        </header>
        <!--== End Header Area ==-->
        <!--== Start Checkout Page Content Wrapper ==-->
        <div class="checkout-page-wrapper" style="margin-bottom:50px;">
            <div class="container">
                <?php if(Session::has('msg')): ?> 
                <div class="row">
                    <div class="col-12">
                        <div class="checkout-page-coupon-area">
                            <!-- Checkout Coupon Accordion Start -->
                            <div class="checkoutAccordion" id="checkOutAccordion">
                                <div class="card">
                                    
                                    <h3><i class="fa fa-info-circle"></i><?php echo e(Session::get('msg')); ?>.</h3>
                                </div>
                            </div>
                            <!-- Checkout Coupon Accordion End -->
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-lg-6">
             
                        <!-- Checkout Form Area Start -->
                        <div class="checkout-billing-details-wrap">
                            <h2>Enter Log-in Details</h2>
                            <div class="billing-form-wrap">
                                <form method="POST" action="<?php echo e(route('logins')); ?>">
                                     <?php echo e(csrf_field()); ?>

                                    
                                    <div class="form-input-item"><label for="ID" class="sr-only required">User ID</label> <input type="text" name ="username" placeholder="User ID" required /></div>
                                    <div class="form-input-item"><label for="com-name" class="sr-only">Password</label> <input type="password" name="password" placeholder="Password" /></div>
                                    <button class="btn btn-hvr-brand mt-40">Login</button>
                                </form>
                            </div>
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
        <!--== End Checkout Page Content Wrapper ==--><!--== Start Footer Area ==-->
        <footer class="footer-area bg-img" data-bg="<?php echo e(asset('assets/img/extra/footer_bg.png')); ?>">
            <div class="footer-widget-area">
                <div class="container">
                    <div class="row mtn-40">
                        <div class="col-sm-6 col-lg-3">
                            <div class="widget-item">
                                <h4 class="widget-title">About Us</h4>
                                <div class="widget-body">
                                    <p>Hopkins was founded in 2008 with the mission of providing hair care services with a professional but casual atmosphere.</p>
                                    <div class="social-icons mt-20">
                                        <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-instagram"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="widget-item">
                                <h4 class="widget-title">Keep in touch</h4>
                                <div class="widget-body">
                                    <div class="keepintouch">
                                        <p><i class="ion-android-call"></i>(61 2) 9251 5600</p>
                                        <p><i class="ion-email"></i><a href="mailto:your@example.com">your@example.com</a></p>
                                        <p><i class="ion-map"></i>no.200 Joseph, Canada</p>
                                        <p><i class="ion-printer"></i>(61 2) 9200 5700</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="widget-item">
                                <h4 class="widget-title">Customer Care</h4>
                                <div class="widget-body">
                                    <ul class="widget-list">
                                        <li><a href="#">Contact Us</a></li>
                                        <li><a href="#">Delivery Information</a></li>
                                        <li><a href="#">Returns Policy</a></li>
                                        <li><a href="#">Privacy & Security</a></li>
                                        <li><a href="#">Work With Us</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-3">
                            <div class="widget-item">
                                <h4 class="widget-title">Working hours</h4>
                                <div class="widget-body">
                                    <div class="working-hours">
                                        <strong>Mon – Thurs:</strong> 10:00 AM – 8:00 PM<br />
                                        <strong>Thurs – Fri:</strong> 10:00 AM – 7:00 PM<br />
                                        <strong>Saturday:</strong> 12:00 - 17:30<br />
                                        <hr />
                                        <strong>Sunday:</strong> CLOSED
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-copyright-area">
                <div class="container">
                    <div class="row">
                        <div class="col-12 text-center">
                            <div class="copyright-content"><p class="mb-0">© Hopkins. All right reserved 2019.</p></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--== End Footer Area ==--><!-- Scroll Top Button -->
        <button class="btn-scroll-top"><i class="ion-chevron-up"></i></button>
       <!-- Start Responsive Menu Wrapper -->
        <aside class="off-canvas-wrapper off-canvas-menu">
            <div class="off-canvas-overlay"></div>
            <div class="off-canvas-inner">
                <!-- Start Off Canvas Content -->
                <div class="off-canvas-content">
                    <div class="off-canvas-header">
                        <div class="logo">
                            <a href="index.html"><img src="assets/img/logo.png" alt="Logo" /></a>
                        </div>
                        <div class="close-btn">
                            <button class="btn-close"><i class="ion-close"></i></button>
                        </div>
                    </div>
                    <div class="res-mobile-menu mobile-menu"></div>
                    <div class="mobile-menu res-site-config"></div>
                </div>
            </div>
        </aside>
        <!-- End Responsive Menu Wrapper --><!--=======================Javascript============================-->
        <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
    </body>
    <!-- Mirrored from demo.hasthemes.com/hopkins-preview/hopkins/checkout.html by HTTrack Website Copier/3.x [XR&CO'2017], Wed, 10 Feb 2021 09:08:42 GMT -->
</html>
