<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="theme-color" content="#33363f">
<meta property="og:locale" content="en_US" />
<meta property="og:site_name" content="Coinfinancepro" />
<meta property="og:title" content="Online Investment Platform With 24/7 Support | Coinfinancepro" />

<link href="{{asset('img/new/android-icon-48x48.png')}}" rel="icon">
<title>Online Crypto investment Platform with 24/7 Support | Coinfinancepro</title>
<link rel="stylesheet" href="public/css/style.css">
<link rel="stylesheet" href="public/css/scale.css">
<link rel="stylesheet" type="text/css" href="public/vendor/DataTables/datatables.css" />
<link rel="stylesheet" href="public/vendor/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="public/vendor/fontawesome/css/all.css">
<scrip src="public/vendor/jquery/jquery.js"></scrip>
<script type="text/javascript" src="public/vendor/DataTables/datatables.js"></script>
<script src="public/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<script src="public/vendor/fontawesome/js/all.js"></script>
</head>
<body>
<div id="custom-loader" class="">
<div id="app-loader-bg">
<div id="app-loader"></div>
</div>
</div>
<div class="app-header-pages">
<nav id="sticky-nav" class="navbar navbar-expand-md navbar-light fixed-header p-0">
<div class="container">
<a class="navbar-brand" href="https://Coinfinancepro.trade/en-us">
<img src="https://Coinfinancepro.trade/public/img/logo/oraimo-dark.png" alt="" width="" height="40">
</a>
<span class="navbar-text">
<button onclick="location.href='./sign-up'" class=" btn btn-success">Open account</button>
</span>
</div>
</nav>
</div>
<div class="page-container">
<div class="container mb-5">
<h1 class="my-dark my-montserrat my-300 my-gradient mb-5">Privacy Policy</h1>
<strong>Introduction</strong>
<p class="my-montserrat my-dark">The same as most online businesses, Coinfinancepro recognizes the importance of our client’s privacy. As a financial services firm, we must obtain certain personal and financial information from the client, in order to setup and service the client accounts.</p>
<p class="my-montserrat my-dark">Coinfinancepro makes use of the client’s personal and financial information exclusively for the following purposes:</p>
<ul>
<li>
<p class="my-montserrat my-dark">Verification of the client’s identity</p>
</li>
<li>
<p class="my-montserrat my-dark">Account set up, maintenance and management of client accounts</p>
</li>
<li>
<p class="my-montserrat my-dark">Processing deposits and withdrawals into client’s trading accounts or back to the clients funding accounts</p>
</li>
<li>
<p class="my-montserrat my-dark">Informing the client about news, updates, promotions and additional products and services that may be of interest and at times offered by third party providers</p>
</li>
<li>
<p class="my-montserrat my-dark">Providing the client with the best quality of customer support</p>
</li>
</ul>
<p class="my-montserrat my-dark">Coinfinancepro will never use, disclose, sell, rent or lease the client’s personal and financial information to any third parties except those stated in “Disclosure of Client’s Personal Information”. The income, credit history, net worth or income information will not be shared by the Company under any circumstances.</p>
<strong>Disclosure of Client’s Personal Information</strong>
<p class="my-montserrat my-dark">Coinfinancepro may disclose the client’s personal information to third-party entities in the following cases:</p>
<ul>
<li>
<p class="my-montserrat my-dark">to the Company’s affiliates or introducing brokers, mainly for the calculation of their compensation.</p>
</li>
<li>
<p class="my-montserrat my-dark">to the Company’s partner network offering third party trading related services.</p>
</li>
<li>
<p class="my-montserrat my-dark">to persons holding a legal or beneficial interest relating to the client’s trading account.</p>
</li>
<li>
<p class="my-montserrat my-dark">to persons acting in a judiciary, representative, or attorney capacity in relation to the client’s trading account, in order to protect against fraud, money laundering, unauthorized transactions, claims or other liabilities.</p>
</li>
<li>
<p class="my-montserrat my-dark">to government, regulatory or law enforcement agencies to the extent permitted or required by law, or to comply with applicable legal requirements.</p>
</li>
<li>
<p class="my-montserrat my-dark">to comply with civil, criminal or regulatory investigations, judicial process, summons or warrant by appropriate authorities.</p>
</li>
</ul>
<strong>Information Collected from the Client</strong>
<p class="my-montserrat my-dark">Information Collected from the Client</p>
<ul>
<li>
<p class="my-montserrat my-dark">When opening a Live/Demo trading account with the Company and filling in electronic registration form.</p>
</li>
<li>
<p class="my-montserrat my-dark">When funding the trading account – such information is never stored or archived on the Company’s servers.</p>
</li>
<li>
<p class="my-montserrat my-dark">When withdrawing from the trading account.</p>
</li>
</ul>
<p class="my-montserrat my-dark">The information collected online may be combined with other information provided to the Company in hard copy or through Coinfinancepro’s customer service department. The information may be transferred across national borders for the purposes of data consolidation, storage and customer data management.</p>
<p class="my-montserrat my-dark">The information collected may include: Full name, Address, Date of Birth, ID Number, Copy of ID document, Occupation, Utility Bills, Bank Statement.</p>
<p class="my-montserrat my-dark">The financial information may include the assets, investment experience, and monthly income, in order to evaluate the client’s trading experience, understand his financial needs and provide him with products and services suitable to his specific needs.</p>
<strong>Use of Cookies</strong>
<p class="my-montserrat my-dark">Coinfinancepro uses a number of cookies on its website.</p>
<p class="my-montserrat my-dark">A cookie, also known as an HTTP cookie, web cookie or browser cookie is a small file saved on users’ computers to help store preferences and other information on web pages that were visited. Cookies contain information transferred to the visitor’s computer hard drive. This information allows Coinfinancepro management and employees to better understand the visitor’s navigation across the website, determine the users’ type of browser and computer, improve the services by tailoring the website and advertising to the client’s preferences.</p>
<p class="my-montserrat my-dark">The client can choose if and how these cookies will be accepted by changing his browser settings and options. However, it is important to note, that there is not any personally identifiable information collected in this process and it is also possible to block any third-party cookies.</p>
<p class="my-montserrat my-dark">Should you have any further questions regarding the Privacy Policy you may email our support team for further clarification or assistance.</p>
<div class="mt-5">
<button onclick="print()" class="btn btn-secondary btn-lg"><i class="fad fa-share"></i> Print Document</button>
</div>
</div>
</div>
<div class="container">
<div class="cta-block p-5">
<h1 class="my-dark my-montserrat my-300 text-center">Trade with confidence. Trade with Coinfinancepro.</h1>
<p class="my-dark my-montserrat text-center mb-4">Join thousands of people who choose to trade with us, enjoying over 100 instruments including 24/7 trading of Digital Assets.</p>
<center class="mb-3">
<div class="col-12 col-md-6">
<button onclick="location.href='https://Coinfinancepro.trade/signin'" class="btn btn-primary">Open an account</button>
</div>
</center>
</div>
</div>
<div class="footer-block">
<div class="container">
<div class="row">
<div class="col-6 col-md-4 mb-3 mb-md-0">
<div class="foot-header">Company</div>
<div class="foot-body">
<a href="./about" class="foot">About Us</a>
<a href="tel:+1(260) 488 6441" class="foot"><b>Phone:</b> +1(260) 488 6441</a>
<a href="https://maps.google.com/?q=Irvington, Carlisle CA6 4NW, United Kingdom" class="foot"><b>UK Address:</b> Irvington, Carlisle CA6 4NW, United Kingdom</a>
<a href="https://maps.google.com/?q=9030 Metropolitan Ave, Queens, NY 11374, United States" class="foot"><b>US Address:</b> 9030 Metropolitan Ave, Queens, NY 11374, United States</a>
</div>
</div>

<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Trading</div>
<div class="foot-body">
<a href="./sign-up" class="foot">Open Live Account</a>
<a href="./sign-up" class="foot">Instruments</a>

<a href="./sign-up" class="foot">Market Analysis</a>
</div>
</div>
<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Funding</div>
<div class="foot-body">
<a href="./sign-up" class="foot">Funding Methods</a>
<a href="./sign-up" class="foot">Clients Protection</a>
</div>
</div>
<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Legal</div>
<div class="foot-body">
<a href="./aml-policy" class="foot">AML Policy</a>
<a href="./cookie-policy" class="foot">Cookie Policy</a>
<a href="./privacy-policy" class="foot">Privacy Policy</a>
<a href="./risk-disclosure" class="foot">Risk Disclosure</a>
<a href="./terms" class="foot">Terms & Conditions</a>
</div>
</div>
</div>
<div class="footer-sub mb-4 mt-5">
<p><strong>Risk Warning:</strong> CFD and Spot Forex trading both come with a high degree of risk. You must be prepared to sustain a total loss of any funds deposited with us, as well as any additional losses, charges, or other costs we incur in recovering any payment from you. Given the possibility of losing more than your entire investment, speculation in certain investments should only be conducted with risk capital funds that if lost will not significantly affect your personal or institution’s financial well-being. Before deciding to trade the products offered by us, you should carefully consider your objectives, financial situation, needs and level of experience. You should also be aware of all the risks associated with trading on margin. Please read our <a href="./risk-disclosure">Risk Disclosure document</a></p>
</div>
<div class="footer-sub mb-2">
<p>© Copyright 2019 All Rights Reserved. Coinfinancepro Ltd, 8 Copthall, Roseau Valley 00152, The Commonwealth of Dominica. <br>
This website is not directed at any jurisdiction and is not intended for any use that would be contrary to local law or regulation.</p>
</div>
<div class="text-center mt-5">
<img src="https://www.eaglefx.com/images/logos_payments-1.png.webp" alt="">
</div>
<div class="text-center mt-4">
<p class="footer-credit">© 2019 Coinfinancepro - ALL RIGHTS RESERVED.</p>
</div>
<div class="text-center mt-4">
<center>
<div class="d-flex col-5 col-lg-3">
<div class=""><img src="public/img/award001.png" width="80%" alt=""></div>
<div class=""><img src="public/img/award002.png" width="80%" alt=""></div>
<div class=""><img src="public/img/award003.png" width="80%" alt=""></div>
</div>
</center>
</div>
</div>
</div>
 <script src="public/js/app.js"></script>


    </script>

</body>
</html>
