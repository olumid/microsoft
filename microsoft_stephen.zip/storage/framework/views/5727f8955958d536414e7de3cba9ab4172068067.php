
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Coin Finance Pro -- Wallets </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">
	<link href="<?php echo e(asset('vendor/jqvmap/css/jqvmap.min.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/chartist/css/chartist.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
    <link href="<?php echo e(asset('vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style11.css')); ?>" rel="stylesheet">
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
           <a href="<?php echo e(route('dashboard1')); ?>" class="brand-logo">
               <img src="<?php echo e(asset('img/new/log.png')); ?>" alt="">
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		
		<!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            <div class="dashboard_bar">
                                Wallets
                            </div>
                        </div>

                        <ul class="navbar-nav header-right">
							
							
							
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <img src="images/profile/pic1.jpg" width="20" alt=""/>
									<div class="header-info">
										<span><?php echo e(Auth::user()->name); ?></span>
									</div>
                                </a>
                                
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('dashboard1')); ?>" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        

                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('manageWallet')); ?>">
						<i class="flaticon-381-television"></i>
							<span class="nav-text">Wallets</span>
						</a>
                       
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('investment')); ?>">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">Packages</span>
						</a>
                        
                    </li>
                   
                    <li><a href="<?php echo e(route('password')); ?>" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Update Password</span>
						</a>
					</li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('withdrawRequest')); ?>" aria-expanded="false">
							<i class="flaticon-381-notepad"></i>
							<span class="nav-text">Withdraw</span>
						</a>
                       
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('transactionAll')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Transactions</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('depositHistory')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Orders</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('showDownlines')); ?>" aria-expanded="false">
							<i class="flaticon-381-heart"></i>
							<span class="nav-text">Referral</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('logout')); ?>" aria-expanded="false">
							<i class="flaticon-381-exit"></i>
							<span class="nav-text">Logout</span>
						</a> 
                    </li>
                    
                </ul>
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
                <div class="row">
                    <?php if(Session::has('msg')): ?>   
                        <div id="info" style="font-size:13px; margin-left:20px; margin-right:20px; margin-bottom:20px;" class="alert alert-success alert-dismissible fade show" role="alert">
                            <strong style="padding: 20px;"><?php echo e(Session::get('msg')); ?></strong>
                                <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </a>
                        </div>
                    <?php endif; ?>	
                </div>
				<div class="row">
                  
					<div class="col-xl-3 col-xxl-4">
						<div class="card">
							<div class="card-header pb-0 border-0">
								<h5 class="mb-0 text-black fs-20">My Profile</h5>
								
							</div>
							<div class="card-body">
								<div class="text-center">
									<img src="images/profile/11.jpg" alt= "" class="rounded ds-img-profile">
									<h4 class="fs-26 mt-sm-3 mt-2 mb-sm-3 mb-0 font-w600 text-black"><?php echo e(Auth::user()->name); ?></h4>	
									<p class="mb-0 text-black ">Join on  <?php echo e(Auth::user()->created_at->format('Y-m-d')); ?></p>
									<a href="<?php echo e(route('profile')); ?>" class="btn btn-rounded btn-outline-warning mt-sm-4 mt-2"><i class="fa fa-pencil scale5 mr-3"></i>Edit prorfile</a>
                                    <a href="<?php echo e(route('kyc')); ?>" class="btn btn-rounded btn-outline-warning mt-sm-4 mt-2"><i class="fa fa-pencil scale5 mr-3"></i>Upload Kyc</a>
								</div>
								
							</div>
						</div>
					</div>
					<div class="col-xl-9 col-xxl-8">
						<div class="card">
							<div class="card-header border-0 pb-0">
								<h5 class="mb-0 text-black fs-20">Trading Wallets</h5>
								
								<a data-toggle="modal" data-target="#basicModal" class="btn btn-warning btn-rounded" style="color: white;">+ Add Wallet</a>
							</div>
							<div class="card-body">
								<div class="row">
								<?php if(count($wallet)> 0): ?>

                         			<?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
										<div class="col-lg-6">
											<div class="card border coin-holding-card border-warning">
												<div class="card-body bg-warning rounded">
													<div class="d-flex align-items-center">
														<svg class="mr-3" width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
															<path d="M28.4998 16.5002C28.4984 14.844 27.1558 13.5018 25.5001 13.5H16.5V19.4999H25.5001C27.1558 19.4985 28.4984 18.1559 28.4998 16.5002Z" fill="white"/>
															<path d="M16.5 28.5H25.5001C27.1567 28.5 28.4998 27.157 28.4998 25.5003C28.4998 23.8432 27.1567 22.5001 25.5001 22.5001H16.5V28.5Z" fill="white"/>
															<path d="M20.9999 0.00012207C9.40201 0.00012207 0 9.40213 0 21C0 32.5979 9.40201 41.9999 20.9999 41.9999C32.5978 41.9999 41.9998 32.5979 41.9998 21C41.9865 9.40762 32.5923 0.0133972 20.9999 0.00012207ZM31.5001 25.4998C31.496 28.8122 28.8121 31.4961 25.5002 31.4998V32.9998C25.5002 33.8284 24.8282 34.4999 24.0001 34.4999C23.1715 34.4999 22.5 33.8284 22.5 32.9998V31.4998H19.5003V32.9998C19.5003 33.8284 18.8283 34.4999 18.0002 34.4999C17.1716 34.4999 16.5001 33.8284 16.5001 32.9998V31.4998H12.0003C11.1717 31.4998 10.5002 30.8282 10.5002 30.0001C10.5002 29.1716 11.1717 28.5 12.0003 28.5H13.4999V13.5H12.0003C11.1717 13.5 10.5002 12.8285 10.5002 11.9999C10.5002 11.1714 11.1717 10.4998 12.0003 10.4998H16.5001V9.00021C16.5001 8.17166 17.1716 7.50012 18.0002 7.50012C18.8287 7.50012 19.5003 8.17166 19.5003 9.00021V10.4998H22.5V9.00021C22.5 8.17166 23.1715 7.50012 24.0001 7.50012C24.8286 7.50012 25.5002 8.17166 25.5002 9.00021V10.4998C28.7997 10.4861 31.4859 13.1494 31.5001 16.4489C31.5074 18.1962 30.7498 19.8593 29.4264 21C30.7375 22.128 31.4941 23.77 31.5001 25.4998Z" fill="white"/>
														</svg>
														<div>
															<h4 class="font-w500 text-white title mb-0"><?php echo e($list->wallet_name); ?></h4>
															<span class="text-white fs-14 op7"><?php echo e($list->crypto_type); ?></span>
														</div>
													</div>
													<div class="d-flex flex-wrap mt-4 align-items-center">	
														<div class="d-flex align-items-center mr-auto pr-3 mb-2">
															<svg class="mr-3" width="42" height="26" viewBox="0 0 24 26" fill="none" xmlns="http://www.w3.org/2000/svg">
																<rect width="3.42856" height="25.1428" rx="1.71428" transform="matrix(-1 0 0 1 24 0)" fill="white"/>
																<rect width="3.42856" height="18.2856" rx="1.71428" transform="matrix(-1 0 0 1 17.1431 6.85712)" fill="white"/>
																<rect width="3.42856" height="7.99997" rx="1.71428" transform="matrix(-1 0 0 1 10.2861 17.1428)" fill="white"/>
																<rect width="3.86812" height="15.4725" rx="1.93406" transform="matrix(-1 0 0 1 3.86816 9.67029)" fill="white"/>
															</svg>
															<h4 class="font-w500 text-white amount mb-0">$<?php echo e($list->wallet_balance); ?></h4>
														</div>
														<div class="mb-2">
															<svg width="14" height="8" viewBox="0 0 14 8" fill="none" xmlns="http://www.w3.org/2000/svg">
																<path d="M0.707108 6.06712C0.0771426 6.69709 0.523309 7.77423 1.41421 7.77423L12.3601 7.77423C13.251 7.77423 13.6972 6.69709 13.0672 6.06712L7.59426 0.594186C7.20373 0.203662 6.57057 0.203662 6.18005 0.594186L0.707108 6.06712Z" fill="#61C277"/>
															</svg>
															<span class="text-white fs-14"></span>
														</div>
													</div>	
												</div>
												<div class="card-footer d-flex justify-content-between border-0">
													<button class="btn btn-warning  btn-edit" data-name="<?php echo e($list->wallet_name); ?>" data-id="<?php echo e($list->wallet_id); ?>">UPDATE</button>
												</div>
											</div>
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
								<?php else: ?>
									<p style="color: orangered; font-size: 25px; font-weight: bold; margin-top: 30px; text-align: center">Error! No Entry Found, Try Again  </p>
								<?php endif; ?>	
								</div>
							</div>
						</div>
					</div>
                    <div class="col-xl-3 col-xxl-4">
						<div class="">
							
						</div>
					</div>
                    <div class="col-xl-9 col-xxl-8">
						<div class="card">
							<div class="card-header border-0 pb-0">
								<h5 class="mb-0 text-black fs-20">Minning Wallets</h5>
								
										
								<a data-toggle="modal" data-target="#basicModal1" class="btn btn-warning btn-rounded" style="color: white;">+ Add Wallet</a>
							</div>
							<div class="card-body">
								<div class="row">
								<?php if(count($wallet1)> 0): ?>

                         			<?php $__currentLoopData = $wallet1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>  $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
										<div class="col-lg-6">
											<div class="card border coin-holding-card border-warning">
												<div class="card-body bg-warning rounded">
													<div class="d-flex align-items-center">
														<svg class="mr-3" width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
															<path d="M28.4998 16.5002C28.4984 14.844 27.1558 13.5018 25.5001 13.5H16.5V19.4999H25.5001C27.1558 19.4985 28.4984 18.1559 28.4998 16.5002Z" fill="white"/>
															<path d="M16.5 28.5H25.5001C27.1567 28.5 28.4998 27.157 28.4998 25.5003C28.4998 23.8432 27.1567 22.5001 25.5001 22.5001H16.5V28.5Z" fill="white"/>
															<path d="M20.9999 0.00012207C9.40201 0.00012207 0 9.40213 0 21C0 32.5979 9.40201 41.9999 20.9999 41.9999C32.5978 41.9999 41.9998 32.5979 41.9998 21C41.9865 9.40762 32.5923 0.0133972 20.9999 0.00012207ZM31.5001 25.4998C31.496 28.8122 28.8121 31.4961 25.5002 31.4998V32.9998C25.5002 33.8284 24.8282 34.4999 24.0001 34.4999C23.1715 34.4999 22.5 33.8284 22.5 32.9998V31.4998H19.5003V32.9998C19.5003 33.8284 18.8283 34.4999 18.0002 34.4999C17.1716 34.4999 16.5001 33.8284 16.5001 32.9998V31.4998H12.0003C11.1717 31.4998 10.5002 30.8282 10.5002 30.0001C10.5002 29.1716 11.1717 28.5 12.0003 28.5H13.4999V13.5H12.0003C11.1717 13.5 10.5002 12.8285 10.5002 11.9999C10.5002 11.1714 11.1717 10.4998 12.0003 10.4998H16.5001V9.00021C16.5001 8.17166 17.1716 7.50012 18.0002 7.50012C18.8287 7.50012 19.5003 8.17166 19.5003 9.00021V10.4998H22.5V9.00021C22.5 8.17166 23.1715 7.50012 24.0001 7.50012C24.8286 7.50012 25.5002 8.17166 25.5002 9.00021V10.4998C28.7997 10.4861 31.4859 13.1494 31.5001 16.4489C31.5074 18.1962 30.7498 19.8593 29.4264 21C30.7375 22.128 31.4941 23.77 31.5001 25.4998Z" fill="white"/>
														</svg>
														<div>
															<h4 class="font-w500 text-white title mb-0"><?php echo e($list->wallet_name); ?></h4>
															<span class="text-white fs-14 op7"><?php echo e($list->crypto_type); ?></span>
														</div>
													</div>
													<div class="d-flex flex-wrap mt-4 align-items-center">	
														<div class="d-flex align-items-center mr-auto pr-3 mb-2">
															<svg class="mr-3" width="42" height="26" viewBox="0 0 24 26" fill="none" xmlns="http://www.w3.org/2000/svg">
																<rect width="3.42856" height="25.1428" rx="1.71428" transform="matrix(-1 0 0 1 24 0)" fill="white"/>
																<rect width="3.42856" height="18.2856" rx="1.71428" transform="matrix(-1 0 0 1 17.1431 6.85712)" fill="white"/>
																<rect width="3.42856" height="7.99997" rx="1.71428" transform="matrix(-1 0 0 1 10.2861 17.1428)" fill="white"/>
																<rect width="3.86812" height="15.4725" rx="1.93406" transform="matrix(-1 0 0 1 3.86816 9.67029)" fill="white"/>
															</svg>
															<h4 class="font-w500 text-white amount mb-0">$<?php echo e($list->wallet_balance); ?></h4>
                                                            
														</div>
														<div class="mb-2">
															<svg width="14" height="8" viewBox="0 0 14 8" fill="none" xmlns="http://www.w3.org/2000/svg">
																<path d="M0.707108 6.06712C0.0771426 6.69709 0.523309 7.77423 1.41421 7.77423L12.3601 7.77423C13.251 7.77423 13.6972 6.69709 13.0672 6.06712L7.59426 0.594186C7.20373 0.203662 6.57057 0.203662 6.18005 0.594186L0.707108 6.06712Z" fill="#61C277"/>
															</svg>
															<span class="text-white fs-14"></span>
														</div>
													</div>	
												</div>
                                                <div class="progress mt-3"style="margin: 10px;">
                                                    <div class="progress-bar bg-success" style="width: 60%; height:12px;" role="progressbar">
                                                        <span class="sr-only">60% Complete</span>
                                                    </div>
                                                </div>
												<div class="card-footer d-flex justify-content-between border-0">
													<button class="btn btn-warning  btn-edit" data-name="<?php echo e($list->wallet_name); ?>" data-id="<?php echo e($list->wallet_id); ?>">UPDATE</button>
												</div>
											</div>
										</div>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
								<?php else: ?>
									<p style="color: orangered; font-size: 25px; font-weight: bold; margin-top: 30px; text-align: center">Error! No Entry Found, Try Again  </p>
								<?php endif; ?>	
								</div>
							</div>
						</div>
					</div>
					
					
				</div>
            </div>
        </div>
		            <div class="modal fade" id="basicModal">
                        <div class="modal-dialog" role="document">
                             <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title"><strong>CREATE NEW TRADING WALLET</strong></h4>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('addWallet')); ?>"  method="POST">
                                       <?php echo e(csrf_field()); ?>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="control-label">Wallet Name</label>
                                                <input class="form-control form-white" required="" placeholder="Enter name" type="text" name="wallet_name">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="control-label">Choose Coin Type</label>
                                                <select class="form-control form-white" required="" data-placeholder="Choose Coin Type..." name="crypto_type">
                                                    <option value="Bitcoin">Bitcoin</option>
                                                    <option value="Etherium">Etherium</option>
                                                    <option value="Cardano">Cardano</option>
                                                    <option value="Binance Coin">Binance Coin</option>
													<option value="Xrp">Xrp</option>
                                                    <option value="Doge Coin">Doge Coin</option>
                                                    <option value="Bitcoin Cash">Bitcoin Cash</option>
                                                    <option value="Litecoin">Litecoin</option>
													<option value="Bitcoin Gold">Bitcoin Gold</option>
                                                    <option value="Shiba InuETH">Shiba Inu</option>
                                                    <option value="Digital Yuan">Digital Yuan</option>
                                                    
                                                </select>
                                            </div>
                                        </div>
                                    
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-danger waves-effect waves-light">Save</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>


					<div class="modal fade" id="basicModal1">
                        <div class="modal-dialog" role="document">
                             <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title"><strong>CREATE NEW MINNING WALLET</strong></h4>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('addWallet1')); ?>"  method="POST">
                                       <?php echo e(csrf_field()); ?>

                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="control-label">Wallet Name</label>
                                                <input class="form-control form-white" required="" placeholder="Enter name" type="text" name="wallet_name">
                                            </div>
                                            <div class="col-md-6">
                                                <label class="control-label">Choose Coin Type</label>
                                                <select class="form-control form-white" required="" data-placeholder="Choose Coin Type..." name="crypto_type">
                                                    <option value="Bitcoin">Bitcoin</option>
                                                    <option value="Etherium">Etherium</option>
                                                    <option value="Cardano">Cardano</option>
                                                    <option value="Binance Coin">Binance Coin</option>
													<option value="Xrp">Xrp</option>
                                                    <option value="Doge Coin">Doge Coin</option>
                                                    <option value="Bitcoin Cash">Bitcoin Cash</option>
                                                    <option value="Litecoin">Litecoin</option>
													<option value="Bitcoin Gold">Bitcoin Gold</option>
                                                    <option value="Shiba InuETH">Shiba Inu</option>
                                                    <option value="Digital Yuan">Digital Yuan</option>
                                                    
                                                </select>
                                            </div>
                                        </div>
                                    
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-danger waves-effect waves-light">Save</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>   
                </div>


        <!--**********************************
            Content body end
        ***********************************-->
				<div class="modal fade" id="editModal">
                        <div class="modal-dialog" role="document">
                             <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title"><strong>EDIT WALLET</strong></h4>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('editWallet')); ?>"  method="POST" id="editForm">
                                       <?php echo e(csrf_field()); ?>

                                        <div class="row">
                                            <div class="col-md-12">
                                                <label class="control-label">Wallet Name</label>
                                                <input class="form-control form-white" required="" placeholder="Enter name" type="text" name="wallet_name1" id="wallet_name1">
												<input class="form-control form-white" type="hidden" name="wallet_id1" id="wallet_id1">
                                            </div>
                                            
                                        </div>
                                    
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-danger waves-effect waves-light save-category">Update</button>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>   
                </div>


        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright ©  <a href="#" target="_blank"></a> 2021</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->


	</div>
  

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
	

    <script src="<?php echo e(asset('j/jquery-3.2.1.min.js')); ?>"></script>	
	<script type="text/javascript">
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });

			  //=============invoke select plan Modal
			$('.btn-edit').on('click',function(e) {
				e.preventDefault();
				$('#wallet_name1').val($(this).data('name'));
				$('#wallet_id1').val($(this).data('id'));
				
			$('#editModal').modal('show');
			});

			
                    
        });
	</script>		
    <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	
	<!-- Chart piety plugin files -->
    <script src="<?php echo e(asset('vendor/peity/jquery.peity.min.js')); ?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo e(asset('vendor/apexchart/apexchart.js')); ?>"></script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo e(asset('js/dashboard/my-wallet.js')); ?>"></script>
	
	<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/dezna.js')); ?>"></script>
	
    
	<script>
		jQuery('.cards-slider').owlCarousel({
			loop:false,
			margin:30,
			nav:true,
            rtl:(getUrlParams('dir') == 'rtl')?true:false,
			autoWidth:true,
            //rtl:true,
			dots: false,
			navText: ['', ''],
		});	
	</script>
</body>
</html>