
<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Welcome to Credit Invest</title>
    <meta name="description" content="Sufee Admin - HTML5 Admin Template">
   
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('vendors/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/themify-icons/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link href="<?php echo e(asset('vendors/bootstrap-fileinput/bootstrap-fileinput.css')); ?>" rel="stylesheet">


    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

</head>

<body>
    <!-- Left Panel -->

   <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo"></a>
                <a class="navbar-brand hidden" href="./"><img src="<?php echo e(asset('images/logo2.png')); ?>" alt="Logo"></a>
            </div>

            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active">
                        <a href="index.html"> <i class="menu-icon fa fa-home"></i>Home</a>
                    </li>
                    <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-user"></i>My Profile</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="menu-icon fa fa-user"></i><a href="maps-gmap.html">Update Account</a></li>
                            <li><i class="menu-icon fa fa-lock"></i><a href="maps-vector.html">Security</a></li>
                            <li><i class="menu-icon fa fa-cogs"></i><a href="maps-gmap.html">Wallet Details</a></li>
                            <li><i class="menu-icon fa fa-group"></i><a href="maps-vector.html">Verify Account</a></li>
                        </ul>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-th-list"></i>Withdrawal</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-th-list"></i>Deposit</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-list"></i>Transaction Log</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-suitcase"></i>Investment Packages</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-suitcase"></i>Loan</a>
                    </li>
                    <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-users"></i>My Downlines</a>
                    </li>
                     <li class="">
                        <a href="index.html"> <i class="menu-icon fa fa-users"></i>Credit Score</a>
                    </li>
                    <li class="">
                        <a href="<?php echo e(route('logout')); ?>"> <i class="menu-icon fa fa-dashboard"></i>Logout</a>
                    </li>
                    
                   
                </ul>
            </div><!-- /.navbar-collapse -->
        </nav>
    </aside><!-- /#left-panel -->

    <!-- Left Panel -->

    <!-- Right Panel -->

    <div id="right-panel" class="right-panel">

        <!-- Header-->
           <!-- Header-->
        <header id="header" class="header">

            <div class="header-menu">

                <div class="col-sm-7">
                    <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa fa-tasks"></i></a>
                    <div class="header-left">
                        <button class="search-trigger"><i class="fa fa-search"></i></button>
                        <div class="form-inline">
                            <form class="search-form">
                                <input class="form-control mr-sm-2" type="text" placeholder="Search ..." aria-label="Search">
                                <button class="search-close" type="submit"><i class="fa fa-close"></i></button>
                            </form>
                        </div>

                        
                    </div>
                </div>

                <div class="col-sm-5">
                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img class="user-avatar rounded-circle" src="<?php echo e(asset('images/admin.jpg')); ?>" alt="User Avatar">
                        </a>

                       
                    </div>

                    <div class="language-select dropdown" id="language-select">
                        <a class="dropdown-toggle" href="#" data-toggle="dropdown"  id="language" aria-haspopup="true" aria-expanded="true">
                            <i class="flag-icon flag-icon-us"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="language">
                            <div class="dropdown-item">
                                <span class="flag-icon flag-icon-fr"></span>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-es"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-us"></i>
                            </div>
                            <div class="dropdown-item">
                                <i class="flag-icon flag-icon-it"></i>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </header><!-- /header -->
        

        <div class="content mt-3">
        
            <div class="animated fadeIn">

                <div class="row">

                    
                    <div class="col-lg-6">
                        <div class="card">
                           
                            <div class="card-body">
                                <div class="custom-tab">

                                    <nav>
                                        <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                            <a class="nav-item nav-link active" id="custom-nav-home-tab" data-toggle="tab" href="#custom-nav-home" role="tab" aria-controls="custom-nav-home" aria-selected="true">BTC</a>
                                            <a class="nav-item nav-link" id="custom-nav-eth-tab" data-toggle="tab" href="#custom-nav-eth" role="tab" aria-controls="custom-nav-eth" aria-selected="false">ETH</a>
                                            <a class="nav-item nav-link" id="custom-nav-ltc-tab" data-toggle="tab" href="#custom-nav-ltc" role="tab" aria-controls="custom-nav-ltc" aria-selected="false">LTC</a>
                                             <a class="nav-item nav-link" id="custom-nav-tron-tab" data-toggle="tab" href="#custom-nav-tron" role="tab" aria-controls="custom-nav-tron" aria-selected="false">TRON</a>
                                            <a class="nav-item nav-link" id="custom-nav-xrp-tab" data-toggle="tab" href="#custom-nav-xrp" role="tab" aria-controls="custom-nav-xrp" aria-selected="false">XRP</a>
                                        </div>
                                    </nav>
                                    <div class="tab-content pl-3 pt-2" id="nav-tabContent">
                                        <div class="tab-pane fade show active" id="custom-nav-home" role="tabpanel" aria-labelledby="custom-nav-home-tab">
                                            <div style="margin-top: 10%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                 <img src="qr/<?php echo e($det->bitcoin_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 30%;">
                                                 <h5 style=" margin-left: 34%; margin-top:10px;">BTC Address:</h5><br>
                                                 <h5 style="margin-top: -15px;"><?php echo e($det->bitcoin_address); ?></h5>
                                            </div>
                                            <button id="update_btc" class="btn btn-primary" data-qr="<?php echo e($det->bitcoin_qr); ?>" data-values="<?php echo e($det->bitcoin_value); ?>"  data-address="<?php echo e($det->bitcoin_address); ?>">Update</button>
                                        </div>
                                        <div class="tab-pane fade" id="custom-nav-eth" role="tabpanel" aria-labelledby="custom-nav-eth-tab">
                                            <div style="margin-top: 10%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                 <img src="qr/<?php echo e($det->etherium_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 30%;">
                                                 <h5 style=" margin-left: 34%; margin-top:10px;">ETH Address:</h5><br>
                                                 <h5 style="margin-top: -15px;text-allign:centre; "><?php echo e($det->etherium_address); ?></h5>
                                            </div>
                                            <button id="update_eth" class="btn btn-primary" data-qr="<?php echo e($det->etherium_qr); ?>" data-values="<?php echo e($det->etherium_value); ?>" data-address="<?php echo e($det->etherium_address); ?>">Update</button>
                                        </div>
                                        <div class="tab-pane fade" id="custom-nav-ltc" role="tabpanel" aria-labelledby="custom-nav-ltc-tab">
                                            <div style="margin-top: 10%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                 <img src="qr/<?php echo e($det->litecoin_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 30%;">
                                                 <h5 style=" margin-left: 34%; margin-top:10px;">LTC Address:</h5><br>
                                                 <h5 style="margin-top: -15px;text-allign:centre; "><?php echo e($det->litecoin_address); ?></h5>
                                                 
                                            </div>
                                            <button id="update_ltc" class="btn btn-primary" data-qr="<?php echo e($det->litecoin_qr); ?>" data-values="<?php echo e($det->litecoin_value); ?>" data-address="<?php echo e($det->litecoin_address); ?>">Update</button>
                                        </div>

                                        <div class="tab-pane fade" id="custom-nav-tron" role="tabpanel" aria-labelledby="custom-nav-tron-tab">
                                             <div style="margin-top: 10%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                 <img src="qr/<?php echo e($det->tron_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 30%;">
                                                 <h5 style=" margin-left: 34%; margin-top:10px;">TRON Address:</h5><br>
                                                 <h5 style="margin-top: -15px;text-allign:centre; "><?php echo e($det->tron_address); ?></h5>
                                                 
                                            </div>
                                            <button id="update_tron" class="btn btn-primary" data-qr="<?php echo e($det->tron_qr); ?>" data-values="<?php echo e($det->tron_value); ?>" data-address="<?php echo e($det->tron_address); ?>">Update</button>
                                        </div>

                                        <div class="tab-pane fade" id="custom-nav-xrp" role="tabpanel" aria-labelledby="custom-nav-xrp-tab">
                                            <div style="margin-top: 10%; margin-bottom: 15%; color:grey; font-family: roboto">
                                                 <img src="qr/<?php echo e($det->xrp_qr); ?>" alt="" style="width: 140px; height:140px; margin-left: 30%;">
                                                 <h5 style=" margin-left: 34%; margin-top:10px;">XRP Address:</h5><br>
                                                 <h5 style="margin-top: -15px;text-allign:centre; "><?php echo e($det->xrp_address); ?></h5>
                                                 
                                            </div>
                                            <button id="update_xrp" class="btn btn-primary" data-qr="<?php echo e($det->xrp_qr); ?>" data-values="<?php echo e($det->xrp_value); ?>" data-address="<?php echo e($det->xrp_address); ?>">Update</button>
                                        </div>
                                        
                                    </div>
                                     
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /# column -->
                </div>

                     
           



            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

    <!-- Right Panel -->


    <script src="<?php echo e(asset('vendors/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
     <?php echo $__env->make('admin.modal.updateBitcoin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <script src="<?php echo e(asset('assets/js/jquery.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
            
        
        });

        
        //=============invoke Bitcoin Modal
        $('#update_btc').on('click',function(e){
            $('#value').val($(this).data('values'));
            $('#address').val($(this).data('address'));
            $('#chk').val($(this).data('qr'));
            $('#tag').val('1');
            var title = document.getElementById('title')
            title.innerHTML = 'Update BTC Wallet';
            $('#updateBitcoins').modal('show')
        });


         //=============invoke Etherium Modal
        $('#update_eth').on('click',function(e){
            $('#value').val($(this).data('values'));
            $('#address').val($(this).data('address'));
            $('#chk').val($(this).data('qr'));
            $('#tag').val('2');
            var title = document.getElementById('title')
            title.innerHTML = 'Update ETH Wallet';
            $('#updateBitcoins').modal('show')
        });


         //=============invoke Litecoin Modal
        $('#update_ltc').on('click',function(e){
            $('#value').val($(this).data('values'));
            $('#address').val($(this).data('address'));
            $('#chk').val($(this).data('qr'));
            $('#tag').val('3');
            var title = document.getElementById('title')
            title.innerHTML = 'Update LTC Wallet';
            $('#updateBitcoins').modal('show')
        });


         //=============invoke Tron Modal
        $('#update_tron').on('click',function(e){
            $('#value').val($(this).data('values'));
            $('#address').val($(this).data('address'));
            $('#chk').val($(this).data('qr'));
            $('#tag').val('4');
            var title = document.getElementById('title')
            title.innerHTML = 'Update TRON Wallet';
            $('#updateBitcoins').modal('show')
        });


         //=============invoke XRP Modal
        $('#update_xrp').on('click',function(e){
            $('#value').val($(this).data('values'));
            $('#address').val($(this).data('address'));
            $('#chk').val($(this).data('qr'));
             $('#tag').val('5');
            var title = document.getElementById('title')
            title.innerHTML = 'Update XRP Wallet';
            $('#updateBitcoins').modal('show')
        });


        $(document).on("click", ".btn-updateBtc", function(){
       // var file_data = $("#photo").prop("files")[0];
        var form_data = new FormData();
        form_data.append('qr', $("#qr").prop("files")[0]);
        form_data.append('value', $("#value").val());
        form_data.append('address', $("#address").val());
        form_data.append('tag', $("#tag").val());
        form_data.append('chk', $("#chk").val());
        $.ajax({
            url: "<?php echo e(route('updateWallet')); ?>",
            dataType: 'script',
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type:'POST',
            success:function(data){
                window.location.href = '<?php echo e(route('walletDetail')); ?>'
            }
        });


    })
        </script>

    <script src="<?php echo e(asset('vendors/popper.js/dist/umd/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bootstrap-fileinput/bootstrap-fileinput.js')); ?>"></script>    


</body>

</html>