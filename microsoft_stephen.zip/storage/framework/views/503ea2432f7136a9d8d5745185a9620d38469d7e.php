<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<meta name="theme-color" content="#33363f">
<meta property="og:locale" content="en_US" />
<meta property="og:site_name" content="Coinfinancepro" />
<meta property="og:title" content="Online Investment Platform With 24/7 Support | Coinfinancepro" />

<link href="{{asset('img/new/android-icon-48x48.png')}}" rel="icon">
<title>Online Crypto investment Platform with 24/7 Support | Coinfinancepro</title>
<link rel="stylesheet" href="public/css/style.css">
<link rel="stylesheet" href="public/css/scale.css">
<link rel="stylesheet" type="text/css" href="public/vendor/DataTables/datatables.css" />
<link rel="stylesheet" href="public/vendor/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="public/vendor/fontawesome/css/all.css">
<scrip src="public/vendor/jquery/jquery.js"></scrip>
<script type="text/javascript" src="public/vendor/DataTables/datatables.js"></script>
<script src="public/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<script src="public/vendor/fontawesome/js/all.js"></script>
</head>
<body>
<div id="custom-loader" class="">
<div id="app-loader-bg">
<div id="app-loader"></div>
</div>
</div>
<div class="app-header-pages">
<nav id="sticky-nav" class="navbar navbar-expand-md navbar-light fixed-header p-0">
<div class="container">
<a class="navbar-brand" href="https://Coinfinancepro.trade/en-us">
<img src="https://Coinfinancepro.trade/public/img/logo/oraimo-dark.png" alt="" width="" height="40">
</a>
<span class="navbar-text">
<button onclick="location.href='./sign-up'" class=" btn btn-success">Open account</button>
</span>
</div>
</nav>
</div>
<div class="page-container">
<div class="container mb-5">
<h1 class="my-dark my-montserrat my-300 my-gradient mb-5">Risk Disclosure</h1>
<strong>Introduction</strong>
<p class="my-montserrat my-dark">This document does not seek to explain and warn against all of the risks of dealing in Financial Instruments and Derivatives. It is exclusively created to explain the nature of the risks when dealing in the Financial Instruments and Derivatives provided by Coinfinancepro and helping you – the Client - to decide upon your investments on an informed basis.</p>
<strong>Risk Warnings</strong>
<p class="my-montserrat my-dark">We do not recommend any Client to get involved in any investment, directly or indirectly without first understanding the risks concerning each one of the Financial Instruments they are getting involved. Thus, before opening an account, the Client should carefully examine whether investing in a specific Financial Instrument is convenient for him, taking into consideration his circumstances and financial situation.</p>
<p class="my-montserrat my-dark">Below, we aim to highlight some of the risks that the Client may be exposed to when undertaking to trade in the financial markets. The Client should also understand that this is not an exhaustive list, instead, it is an attempt to highlight the key risks that they may face;</p>
<ol>
<li>
<p class="my-montserrat my-dark">The value of any investment in Financial Instruments may fluctuate downwards or upwards, irrespective of any information which may be presented by Coinfinancepro, it is even possible that the investment may become of no value.</p>
</li>
<li>
<p class="my-montserrat my-dark">The purchase and/or sale of any Financial Instrument may result in losses and damages. The Client must recognize and accept this risk.</P>
</li>
<li>
<p class="my-montserrat my-dark">Prior performance of a Financial Instrument does not predict its future performance and neither does it guarantee its current value. The historical data does not ensure any safe forecast of the related Financial Instruments.</p>
</li>
<li>
<p class="my-montserrat my-dark">The Client is hereby informed that the transactions performed through the services of Coinfinancepro are of a speculative nature. This means that in a short time frame large loss may take place, even equalling to the total of Client’s funds deposited. In the event that such a situation arises, any negative balances are for the account of the Client, however, the Client will not be compelled to pay said negative balances on continuous use of the account.</p>
</li>
<li>
<p class="my-montserrat my-dark">Herewith the Client is informed that performing any withdrawal(s), while holding negative balance(s) will result in Us (Coinfinancepro) to take the measures of equalling out any negative balance beforehand. This course of action will take place by moving, transferring or re-allocating any in-credit/positive outstanding balances available on alternative accounts held by the Client under their possession before releasing any further profits gained.</p>
</li>
<li>
<p class="my-montserrat my-dark">As a result of specific situations, e.g. excessive volatility in the market, some Financial Instruments may witness a huge reduction in liquidity. In the event that such a scenario occurs, the Client may not be able to buy/sell the financial instrument, acquire information of their value or transact in the marketplace for a period of time.</p>
</li>
<li>
<p class="my-montserrat my-dark">All the products offered by Coinfinancepro are a Derivative Financial Instrument (i.e. option, future, forward, swap, contract for difference) and are therefore a non-delivery spot transaction. It allows the Client to benefit from changes in currency rates, commodity, stock market indices or share prices of the underlying asset.</p>
</li>
<li>
<p class="my-montserrat my-dark">The value of the Derivative Financial Instrument can be influenced by the price of the underlying security or any other external factor such as interest rates etc.</p>
</li>
<li>
 <p class="my-montserrat my-dark">An acquisition of a Derivative Financial Instrument should be undertaken only when the Client understands the risks and potential loss of the entire funds invested and that additional charges such as commission and SWAP fees also exist.</p>
</li>
<li>
<p class="my-montserrat my-dark">As highlighted in point (5) under particular circumstances it may be impossible to execute an order.</p>
</li>
<li>
<p class="my-montserrat my-dark">Using the Stop Loss Order helps Clients to minimize his losses. Nevertheless, under certain market conditions, the realization of a Stop Loss Order may be less favorable than its stipulated price and create larger losses. This is known as slippage.</p>
</li>
<li>
<p class="my-montserrat my-dark"> When the quantity of Client's funds does not allow him to hold current positions open anymore, the Client will be notified and invited to deposit additional funds or reduce his exposure. This should be carried out by The Client in the time frame required, to avoid the liquidation of positions and the resulting deficit. If the Client fails to deposit funds into the account to cover their obligation, Coinfinancepro will start to close out orders until such time that the Client account has sufficient funding to hold the remaining positions.</p>
</li>
<li>
<p class="my-montserrat my-dark">Coinfinancepro may be forced to close the Client positions as a result of the insolvency of Coinfinancepro, bank or broker.</p>
</li>
<li>
<p class="my-montserrat my-dark">The liquidity providers of Coinfinancepro operate in the same market as the Clients and their own involvement may be contrary to that of the interests of the Client.</p>
</li>
<li>
<p class="my-montserrat my-dark">There is a risk that the Client’s trades in Financial Instruments may become subject to tax and/or any other duty. This can happen for example after changes in legislation or connected to the Client's personal situation. Coinfinancepro cannot guarantee that tax/stamp duty will NOT be payable. The Client is responsible for any taxes and/or any other duty which can occur with reference to his trading activity and should seek professional advice if in doubt.</p>
</li>
<li>
<p class="my-montserrat my-dark">The Client should know all the associated costs of trading including the commission rates; SWAP Rates and any other fees that could possibly be incurred by the Client. If needed the Client may request information from the Client Support team to clarify any issues they may have.</p>
</li>
<li>
<p class="my-montserrat my-dark"> Trading with some Financial Instruments involves the use of “gearing” or “leverage”. Before engagement in this form of investment, the Client should know, that the high degree of “gearing” or “leverage” is a particular feature of Derivative Financial Instruments. This is bred by the margining system. It generally includes a relatively low deposit or margin in terms of the overall contract value. Then a relatively small movement in the underlying market can have a much stronger effect on the Client’s trade.</p>
</li>
<li>
<p class="my-montserrat my-dark">If this market movement is favorable for the Client, they may make substantial gains. On the other side, an adverse market movement can quickly cause the loss of the Clients’ entire deposit capital and may also result in negative balances. As highlighted in point (4 and 5).</p>
</li>
<li>
<p class="my-montserrat my-dark">The trading risk is based on the decision and understanding of the Client. At no time does Coinfinancepro provide any investment advice or recommendations as to when to buy or sell. Coinfinancepro will, however, publish daily reports on the markets which are for information purposes only. This document endeavors to highlight some of the key risks that a Client is exposed to when trading the Derivative Financial Markets but cannot claim to highlight all of the risks. The Client is obligated to ensure that the risks they exposed to on through such financial transactions are in line with their own personal circumstances. Coinfinancepro reserves the right to review this Risk Disclosure statement whenever it deems it necessary.</p>
</li>
</ol>
<p class="my-montserrat my-dark">Should you have any further questions regarding the Risk Disclosure you may email our support team for further clarification or assistance.</p>
<div class="mt-5">
<button onclick="print()" class="btn btn-secondary btn-lg"><i class="fad fa-share"></i> Print Document</button>
</div>
</div>
</div>
<div class="container">
<div class="cta-block p-5">
<h1 class="my-dark my-montserrat my-300 text-center">Trade with confidence. Trade with Coinfinancepro.</h1>
<p class="my-dark my-montserrat text-center mb-4">Join thousands of people who choose to trade with us, enjoying over 100 instruments including 24/7 trading of Digital Assets.</p>
<center class="mb-3">
<div class="col-12 col-md-6">
<button onclick="location.href='https://Coinfinancepro.trade/signin'" class="btn btn-primary">Open an account</button>
</div>
</center>
</div>
</div>
<div class="footer-block">
<div class="container">
<div class="row">
<div class="col-6 col-md-4 mb-3 mb-md-0">
<div class="foot-header">Company</div>
<div class="foot-body">
<a href="https://avaro.trade/about" class="foot">About Us</a>
<a href="tel:+1(260) 488 6441" class="foot"><b>Phone:</b> +1(260) 488 6441</a>
<a href="https://maps.google.com/?q=Irvington, Carlisle CA6 4NW, United Kingdom" class="foot"><b>UK Address:</b> Irvington, Carlisle CA6 4NW, United Kingdom</a>
<a href="https://maps.google.com/?q=9030 Metropolitan Ave, Queens, NY 11374, United States" class="foot"><b>US Address:</b> 9030 Metropolitan Ave, Queens, NY 11374, United States</a>
</div>
</div>
<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Platforms</div>
<div class="foot-body">
<a href="https://avaro.trade/signin" class="foot">Platforms</a>
<a href="https://avaro.trade/signin" class="foot">MT4 for Windows</a>
<a href="https://avaro.trade/signin" class="foot">MT4 for iOS</a>
<a href="https://avaro.trade/signin" class="foot">MT4 for Android</a>
<a href="https://trade.mql5.com/trade?servers=-Demo%2CAvaro-Live&trade_server=Avaro-Demo&demo_server=Avaro-Demo&startup_mode=open_demo&lang=en" class="foot">Web Trader</a>
</div>
</div>
<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Trading</div>
<div class="foot-body">
<a href="https://avaro.trade/signup" class="foot">Open Live Account</a>
<a href="https://avaro.trade/signin" class="foot">Instruments</a>
<a href="https://avaro.trade/signin" class="foot">Leaderboard</a>
<a href="https://avaro.trade/signin" class="foot">Market Analysis</a>
</div>
</div>
<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Funding</div>
<div class="foot-body">
<a href="https://avaro.trade/signin" class="foot">Funding Methods</a>
<a href="https://avaro.trade/signin" class="foot">Clients Protection</a>
</div>
</div>
<div class="col-6 col-md-2 mb-3 mb-md-0">
<div class="foot-header">Legal</div>
<div class="foot-body">
<a href="https://avaro.trade/aml-policy" class="foot">AML Policy</a>
<a href="https://avaro.trade/cookie-policy" class="foot">Cookie Policy</a>
<a href="https://avaro.trade/privacy-policy" class="foot">Privacy Policy</a>
<a href="https://avaro.trade/risk-disclosure" class="foot">Risk Disclosure</a>
<a href="https://avaro.trade/terms" class="foot">Terms & Conditions</a>
</div>
</div>
</div>
<div class="footer-sub mb-4 mt-5">
<p><strong>Risk Warning:</strong> CFD and Spot Forex trading both come with a high degree of risk. You must be prepared to sustain a total loss of any funds deposited with us, as well as any additional losses, charges, or other costs we incur in recovering any payment from you. Given the possibility of losing more than your entire investment, speculation in certain investments should only be conducted with risk capital funds that if lost will not significantly affect your personal or institution’s financial well-being. Before deciding to trade the products offered by us, you should carefully consider your objectives, financial situation, needs and level of experience. You should also be aware of all the risks associated with trading on margin. Please read our <a href="https://avaro.trade/risk-disclosure">Risk Disclosure document</a></p>
</div>
<div class="footer-sub mb-2">
<p>© Copyright 2019 All Rights Reserved. Avaro Ltd, 8 Copthall, Roseau Valley 00152, The Commonwealth of Dominica. <br>
This website is not directed at any jurisdiction and is not intended for any use that would be contrary to local law or regulation.</p>
</div>
<div class="text-center mt-5">
<img src="https://www.eaglefx.com/images/logos_payments-1.png.webp" alt="">
</div>
<div class="text-center mt-4">
<p class="footer-credit">© 2019 Avaro - ALL RIGHTS RESERVED.</p>
</div>
<div class="text-center mt-4">
<center>
<div class="d-flex col-5 col-lg-3">
<div class=""><img src="https://avaro.trade/public/img/award001.png" width="80%" alt=""></div>
<div class=""><img src="https://avaro.trade/public/img/award002.png" width="80%" alt=""></div>
<div class=""><img src="https://avaro.trade/public/img/award003.png" width="80%" alt=""></div>
</div>
</center>
</div>
</div>
</div>
<script src="public/js/app.js"></script>


    </script>

</body>
</html>
