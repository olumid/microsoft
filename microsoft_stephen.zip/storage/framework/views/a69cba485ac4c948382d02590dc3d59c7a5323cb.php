
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Coin Finance Pro -- Update Account  </title>
    <!-- Favicon icon -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/chartist/css/chartist.min.css')); ?>">
    <link href="<?php echo e(asset('vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap-sweetalert/sweetalert.css')); ?>">
    <link href="<?php echo e(asset('css/style1.css')); ?>" rel="stylesheet">
	<style>
		.not-selectable {
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}	
	</style>
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="<?php echo e(route('dashboard1')); ?>" class="brand-logo">
               <img src="<?php echo e(asset('img/new/log.png')); ?>" alt="">
            </a>
            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		<!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="dashboard_bar">
                              
                            </div>

                        <ul class="navbar-nav header-right">
							
							
							
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <img src="<?php echo e(asset('images/profile/pic1.jpg')); ?>" width="20" alt=""/>
									<div class="header-info">
										<span><?php echo e(Auth::user()->name); ?></span>
										
									</div>
                                </a>
                                
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('dashboard1')); ?>" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        

                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('manageWallet')); ?>">
						<i class="flaticon-381-television"></i>
							<span class="nav-text">Wallets</span>
						</a>
                       
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('investment')); ?>">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">Packages</span>
						</a>
                        
                    </li>
                   
                    <li><a href="<?php echo e(route('password')); ?>" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Update Password</span>
						</a>
					</li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('withdrawRequest')); ?>" aria-expanded="false">
							<i class="flaticon-381-notepad"></i>
							<span class="nav-text">Withdraw</span>
						</a>
                       
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('transactionAll')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Transactions</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('depositHistory')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Orders</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('showDownlines')); ?>" aria-expanded="false">
							<i class="flaticon-381-heart"></i>
							<span class="nav-text">Referral</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('logout')); ?>" aria-expanded="false">
							<i class="flaticon-381-user"></i>
							<span class="nav-text">Logout</span>
						</a> 
                    </li>
                    
                </ul>
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="row page-titles mx-0">
                    <div class="col-sm-6 p-md-0">
                        <div class="welcome-text">
                           
                        </div>
                    </div>
                    
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-xl-6 col-lg-6"  style="margin: auto;">
                        <div class="card" >
                            <div class="card-header">
                                <h4 class="card-title">UPDATE ACCOUNT</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
								     	<?php if(Session::has('message')): ?>   
                                            <div id="info" style="font-size:13px;" class="alert alert-success alert-dismissible fade show" role="alert">
                                                <strong><?php echo e(Session::get('message')); ?></strong>
                                                <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(Request::get('errorMessage') !== null): ?>
                                          <p style='padding:15px;' class=''><?php echo e(Request::get('errorMessage')); ?></p>
                                        <?php endif; ?>
                                     <form action="<?php echo e(route('updateUserSettings')); ?>" method="post">
                                        <?php echo e(csrf_field()); ?>

                                                
                                                <div class="form-group<?php echo e($errors->has('fullname') ?  'has-error' : ''); ?>">
                                                    <label for="cc-payment" class="control-label mb-1">Last Name</label>
                                                    <input id="cc-pament" name="fullname" type="text" class="form-control" value="<?php echo e($profile->fullname); ?>"
                                                     >
                                                    <small style="color: red;"><?php echo e($errors->first('fullname')); ?></small>    
                                                </div>
                                               
                                                <div class="form-group<?php echo e($errors->has('name') ?  'has-error' : ''); ?>">
                                                    <label for="cc-number" class="control-label mb-1">User ID</label>
                                                    <input id="cc-number" name="name" type="tel" class="form-control" value="<?php echo e(Auth::user()->name); ?>"
                                                     >
                                                    <span class="help-block" data-valmsg-for="cc-number" data-valmsg-replace="true"></span>
                                                    <small style="color: red;"><?php echo e($errors->first('name')); ?></small>  
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('email') ?  'has-error' : ''); ?>">
                                                    <label for="cc-payment" class="control-label mb-1">Email</label>
                                                    <input id="cc-pament" value="<?php echo e(Auth::user()->email); ?>" name="email" type="email" class="form-control"
                                                     >
                                                    <small style="color: red;"><?php echo e($errors->first('email')); ?></small>  
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('country') ?  'has-error' : ''); ?>">
                                                    <label for="cc-payment" class="control-label mb-1">Country</label>
                                                    <input id="cc-pament" name="country" type="text" class="form-control" value="<?php echo e($profile->country); ?>"
                                                    >
                                                    <small style="color: red;"><?php echo e($errors->first('country')); ?></small>  
                                                </div>
                                                <div class="form-group<?php echo e($errors->has('phone') ?  'has-error' : ''); ?>">
                                                    <label for="cc-payment" class="control-label mb-1">Telephone No</label>
                                                    <input id="cc-pament" name="phone" type="text" class="form-control" value="<?php echo e($profile->phone); ?>"
                                                    >
                                                    <small style="color: red;"><?php echo e($errors->first('phone')); ?></small>  
                                                </div>
                                                <div>
                                                    <button id="payment-button" type="submit" class="btn btn-lg btn-warning btn-block">
                                                        <i class="fa fa-check-circle fa-lg"></i>&nbsp;
                                                        <span id="payment-button-amount">Update Account</span>
                                                </div>
                                        </form>
                                </div>
                            </div>
                        </div>
					</div>
			

			
                </div>
            </div>
        </div>

		
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright ©  <a href="#" target="_blank"></a> 2021</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

	</div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!-- Required vendors -->
    <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	
	<!-- Chart piety plugin files -->
    <script src="<?php echo e(asset('vendor/peity/jquery.peity.min.js')); ?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo e(asset('vendor/apexchart/apexchart.js')); ?>"></script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo e(asset('js/dashboard/dashboard-1.js')); ?>"></script>
	
	<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/deznav-init.js')); ?>"></script>

</body>
</html>