
<!DOCTYPE html>
<html>
<head lang="en">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title>StartUI - Premium Bootstrap 4 Admin Dashboard Template</title>

	<link href="img/favicon.144x144.png" rel="apple-touch-icon" type="image/png" sizes="144x144">
	<link href="img/favicon.114x114.png" rel="apple-touch-icon" type="image/png" sizes="114x114">
	<link href="img/favicon.72x72.png" rel="apple-touch-icon" type="image/png" sizes="72x72">
	<link href="img/favicon.57x57.png" rel="apple-touch-icon" type="image/png">
	<link href="img/favicon.png" rel="icon" type="image/png">
	<link href="img/favicon.ico" rel="shortcut icon">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap-sweetalert/sweetalert.css')); ?>">
 	<link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/sweet-alert-animations.min.css"')); ?>>
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/lobipanel/lobipanel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/separate/vendor/lobipanel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/jqueryui/jquery-ui.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/separate/pages/widgets.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
</head>
<body class="with-side-menu control-panel control-panel-compact">

	<header class="site-header">
	    <div class="container-fluid">
	        <a href="#" class="site-logo">
	            <img class="hidden-md-down" src="<?php echo e(asset('img/logo-2.png')); ?>" alt="">
	            <img class="hidden-lg-down" src="<?php echo e(asset('img/logo-2-mob.png')); ?>" alt="">
	        </a>
	
	        <button id="show-hide-sidebar-toggle" class="show-hide-sidebar">
	            <span>toggle menu</span>
	        </button>
	
	        <button class="hamburger hamburger--htla">
	            <span>toggle menu</span>
	        </button>
	        <div class="site-header-content">
	            <div class="site-header-content-in">
	                <div class="site-header-shown">
	               
	                   
	
	                </div><!--.site-header-shown-->
	
	                <div class="mobile-menu-right-overlay"></div>
	                <div class="site-header-collapsed">
	                    <div class="site-header-collapsed-in">
	                        
	                       
	                    </div><!--.site-header-collapsed-in-->
	                </div><!--.site-header-collapsed-->
	            </div><!--site-header-content-in-->
	        </div><!--.site-header-content-->
	    </div><!--.container-fluid-->
	</header><!--.site-header-->

	<div class="mobile-menu-left-overlay"></div>
	<nav class="side-menu">
	    <ul class="side-menu-list">
	        <li class="grey with-sub">
	            <span>
	                <i class="font-icon font-icon-dashboard"></i>
	                <span class="lbl">Dashboard</span>
	            </span>
	            <ul>
	                <li><a href="index.html"><span class="lbl">Default</span><span class="label label-custom label-pill label-danger">new</span></a></li>
	              
	     
	            </ul>
	        </li>
	         <li class="blue with-sub">
	            <span>
	                <i class="font-icon font-icon-user"></i>
	                <span class="lbl">Profile</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Version 1</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">Version 2</span></a></li>
					<li><a href="profile-2.html"><span class="lbl">Version 2</span></a></li>
	            </ul>
	        </li>
			<li class="pink-red with-sub">
	            <span>
	                <i class="font-icon font-icon-case-2"></i>
	                <span class="lbl">Deposit</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Deposit</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
			<li class="blue with-sub">
	            <span>
	                <i class="font-icon font-icon-zigzag"></i>
	                <span class="lbl">Invest</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Invest</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
			<li class="pink-red with-sub">
	            <span>
	                <i class="font-icon font-icon-case-2"></i>
	                <span class="lbl">Withdraw</span>
	            </span>
	            <ul>
	                <li><a href="profile.html"><span class="lbl">Withdraw</span></a></li>
	                <li><a href="profile-2.html"><span class="lbl">History</span></a></li>
					
	            </ul>
	        </li>
	        
	        
	        <li class="blue-dirty">
	            <a href="tables.html">
	                <span class="glyphicon glyphicon-th"></span>
	                <span class="lbl">My Earnings</span>
	            </a>
	        </li>
	        <li class="magenta with-sub">
	            <a href="tables.html">
	                <span class="glyphicon glyphicon-list-alt"></span>
	                <span class="lbl">My Downlines</span>
	            </a>
	        </li>
	        <li class="green with-sub">
	             <a href="tables.html">
	                <i class="font-icon glyphicon glyphicon-log-out"></i>
	                <span class="lbl">Logout</span>
	            </a>
	            
	        </li>
	   
	        
	    </ul>
	
	</nav><!--.side-menu-->

<div class="page-content">
		<div class="container-fluid">
			 <div class="card col-md-6 blue" style=" border: 1px solid #00a8ff; padding: 12px;">  
			 	 <div class="stat-widget-one">
                        <div class="stat-content dib">
                            <div class="stat-heading text-primary" style="font-size:25px; font-weight:bold;">Withdrawable Balance: $<?php echo e($det1->earnings); ?></div>
                            <input type="hidden" id="earnings"  name="earnings" value="<?php echo e($det1->earnings); ?>">
                        </div>
                   </div> 
              </div>
			<section class="card col-md-6 blue" style=" border: 1px solid #00a8ff">
				<div class="card-block">
					<div class="row m-t-lg">
						<div class="col-md-12">
                  <h5 style='color:#000e2e; font-family: Georgia, serif;'>Withdraw Fund</h5> <br>
				 		   <?php if(Session::has('msg')): ?>   
                                <div id="info" style="font-family: roboto; font-size:15px; margin-bottom:40px;" class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong><?php echo e(Session::get('msg')); ?></strong>
                                    <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </a>
                                </div>
                             <?php endif; ?>
                    
                  <div style="margin-top: -25px;" class="alert alert-info alert-no-border alert-close alert-dismissible fade show" role="alert">                 
							Enter an amount in USD you wish to withdraw to your investment account and select from the Cryto available below.    
				  </div>
                 <form action="<?php echo e(route('saveWithdraw')); ?>" method="post" id="saveDeposit" onsubmit="return checkBalance()">
					<?php echo e(csrf_field()); ?>

					<div class="form-group" style="margin-top: 20px;">
						<div class="col-12 col-md-12">
						<label id="l5" for="" style="margin-bottom: -10px;">Enter Amount</label>
							<input type="hidden" name="types" id="types" value = "">
							<input id="usd" style="margin-top:20px; border: 1px solid #00a8ff;" required="" type="number" name="usd" placeholder=" Enter Amount in USD" class="form-control">
						</div>
					</div>
					<div class="form-group" style="margin-top: 15px;">
						<div class="col-12 col-md-12">
						<label id="l6" for="" style="margin-bottom: -10px;">Enter Wallet Address</label><input id="address" style="margin-top:20px; border: 1px solid #00a8ff;" required="" type="text" name="address" placeholder=" Enter wallet Address" class="form-control">
						</div>
					</div>
					<div class="col-md-12" style="margin-top: 20px">
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-2" value="BTC" checked>
						
						<label for="radio-2">Withdraw Via Bitcoin </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-1" value="ETH">
							<label for="radio-1">Withdraw Via Ethereum </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-3" value="BCH">
							<label for="radio-3">Withdraw Via Bitcoin Cash </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-4" value="TRON">
							<label for="radio-4">Withdraw Via Tron </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-5" value="LTC">
							<label for="radio-5">Withdraw Via Litecoin </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-6" value="USDT">
							<label for="radio-6">Withdraw Via Tether(USDT) </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-7" value="DOGE">
							<label for="radio-7">Withdraw Via Doge Coin </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-8" value="BNC">
							<label for="radio-8">Withdraw Via Binance Coin </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-9" value="XRP">
							<label for="radio-9">Withdraw Via Ripple </label>
						</div>
						<div class="checkbox-bird">
						<input type="radio" name="crypto" id="radio-10" value="ADA">
							<label for="radio-10">Withdraw Via Cardano </label>
						</div>
						
						
					</div>

					
					<div>
                        <button id="payment-button" type="submit" class="btn btn-lg btn-primary btn-block btn-dep">
                        <i class="fa fa-check-circle fa-lg"></i>&nbsp;
                         <span id="dep">Withdraw</span>
                    </div>
				 </form>
					</div><!--.row-->
				</div>
			</section>
		</div><!--.container-fluid-->
	</div><!--.page-content-->


	<script src="<?php echo e(asset('js/lib/jquery/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap-sweetalert/sweetalert.min.js')); ?>"></script>
    <script type="text/javascript">
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });
                    
        });

		
		  function checkBalance()
		  {
           var amt = parseFloat($('#usd').val());
           var earn = parseFloat($('#earnings').val());
		   var type = $("input[type='radio'][name='crypto']:checked").val();
           var crypt;
           if(amt == 0)
           {
                swal({
					title: "Oops!",
					text: "Invalid Amount, Enter a valid Amount",
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonClass: "btn-default",
					cancelButtonClass: "btn-warning",
					confirmButtonText: "Warning",
					closeOnConfirm: false
				});
                return false;
           }
           else if(amt > earn)
           {
               swal({
					title: "Oops!",
					text: "Error, Insufficient Balance",
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonClass: "btn-default",
					cancelButtonClass: "btn-warning",
					confirmButtonText: "Warning",
					closeOnConfirm: false
				});
                return false;
           }
           else
           {
                $('#wait').show();
                 setTimeout(function(){
                $('#wait').hide();
                },10000);

				
                return true;
                
           }
            
         }


		 $('.btn-done').on('click',function(e) { 
			    e.preventDefault();         
                window.location.href = '<?php echo e(route('finalizeDeposit')); ?>'  
        })
	


	</script>	
	<script src="<?php echo e(asset('js/lib/popper/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/tether/tether.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>

	<script type="text/javascript" src="<?php echo e(asset('js/lib/jqueryui/jquery-ui.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/lib/lobipanel/lobipanel.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('js/lib/match-height/jquery.matchHeight.min.js')); ?>"></script>
	
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>