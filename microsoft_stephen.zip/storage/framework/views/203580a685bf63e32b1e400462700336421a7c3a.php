
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Coin Finance Pro -- Buy Nft </title>
    <!-- Favicon icon -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('vendor/chartist/css/chartist.min.css')); ?>">
    <link href="<?php echo e(asset('vendor/bootstrap-select/dist/css/bootstrap-select.min.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('vendor/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/font-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/bootstrap-sweetalert/sweetalert.css')); ?>">
    <link href="<?php echo e(asset('css/style11.css')); ?>" rel="stylesheet">
	<style>
		.not-selectable {
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}	
</style>
<style>
		@import  url(https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;700&family=Titillium+Web:wght@400;700&display=swap);
		select{
			font-size: 20px;
			font-weight: bolder;
			
		}
	</style>
	
</head>
<body style="font-family: 'Titillium Web'; color:white">

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="<?php echo e(route('dashboard1')); ?>" class="brand-logo">
               <img src="<?php echo e(asset('img/new/log.png')); ?>" alt="">
            </a>
            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		
		<!--**********************************
            Header start
        ***********************************-->
        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="dashboard_bar">
                                
                            </div>

                        <ul class="navbar-nav header-right">
							
							
							
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <img src="images/profile/pic1.jpg" width="20" alt=""/>
									<div class="header-info">
										<span><?php echo e(Auth::user()->name); ?></span>
									</div>
                                </a>
                                
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('dashboard1')); ?>" >
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        

                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('manageWallet')); ?>">
						<i class="flaticon-381-television"></i>
							<span class="nav-text">Wallets</span>
						</a>
                       
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('investment')); ?>">
							<i class="flaticon-381-controls-3"></i>
							<span class="nav-text">Packages</span>
						</a>
                        
                    </li>
                   
                    <li><a href="<?php echo e(route('password')); ?>" class="ai-icon" aria-expanded="false">
							<i class="flaticon-381-settings-2"></i>
							<span class="nav-text">Update Password</span>
						</a>
					</li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('withdrawRequest')); ?>" aria-expanded="false">
							<i class="flaticon-381-notepad"></i>
							<span class="nav-text">Withdraw</span>
						</a>
                       
                    </li>
                    <li><a class="has-arrow ai-icon" href="<?php echo e(route('transactionAll')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Transactions</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('depositHistory')); ?>" aria-expanded="false">
							<i class="flaticon-381-network"></i>
							<span class="nav-text">Orders</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('showDownlines')); ?>" aria-expanded="false">
							<i class="flaticon-381-heart"></i>
							<span class="nav-text">Referral</span>
						</a> 
                    </li>
					<li><a class="has-arrow ai-icon" href="<?php echo e(route('logout')); ?>" aria-expanded="false">
							<i class="flaticon-381-exit"></i>
							<span class="nav-text">Logout</span>
						</a> 
                    </li>
                    
                </ul>
			</div>
        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
               
                <!-- row -->
                <div class="row">
                    <div class="col-xl-8 col-lg-8"  style="margin: auto;">
                        <div class="card" >
                            <div class="card-header">
                                <h4 class="card-title">Complete Purchase </h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form action="<?php echo e(route('postNftRequest')); ?>" method="post" id="postNftRequest" onsubmit="return checkBalance()">
										 <?php echo e(csrf_field()); ?>

										 <?php if(Session::has('msg')): ?>   
                                            <div id="info" style="font-size:13px;" class="alert alert-success alert-dismissible fade show" role="alert">
                                                <strong><?php echo e(Session::get('msg')); ?></strong>
                                                <a href="#" class="close" data-dismiss="alert" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                        
                                         <div class="form-group">
											<label for="method">Choose Crypto Type</label>
											<select class="form-control default-select" name="type" id="type" required>
											 <option value="----">----Select Type</option>
											
                                                <option value="ETH">ETH</option>
                                               
                                            </select>
                                            
                                        </div>
										<div class="form-group">
											<label for="method">Price</label>
											 <input type="text" class="form-control" name="amount" id="amount" value="<?php echo e($nft->amount); ?> ETH" readonly>
                                            </select>
                                            
                                        </div>
										<input type="hidden" class="form-control" name="balance" id="balance" value="<?php echo e($wallet->wallet_balance); ?>">
                                        <input type="hidden" class="form-control" name="wallet_id" id="wallet_id" value="<?php echo e($wallet->wallet_id); ?>">
                                        <input type="hidden" class="form-control" name="nft_id" id="nft_id" value="<?php echo e($nft->nft_id); ?>">
                                        <input type="hidden" class="form-control" name="nft" id="nft" value="<?php echo e($nft->name); ?>">
                                        <input type="hidden" class="form-control" name="price" id="price" value="<?php echo e($nft->amount); ?>">
										

										<button id="payment-button" type="submit" class="btn btn-lg btn-primary btn-block btn-dep">
											<i class="fa fa-check-circle fa-lg"></i>&nbsp;
											<span id="dep">Complete Purchase</span>
										</button>	
                                    </form>
                                </div>
                            </div>
                        </div>
					</div>
			

			
                </div>
            </div>
        </div>

		
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright ©  <a href="#" target="_blank"></a> 2021</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

	</div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
	<script src="<?php echo e(asset('j/jquery-3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/lib/bootstrap-sweetalert/sweetalert.min.js')); ?>"></script>
	<script type="text/javascript">
         $(document).ready(function(){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
                }
            });

			$('body').bind('cut copy', function(e) {
              e.preventDefault();
            });
                    
        });
		

		 function checkBalance()
		  {
		   var txt = document.getElementById("type");
		   var balance = parseFloat($('#balance').val());
           var amt = parseFloat($('#price').val());
           if(txt.value == '----')
           {
                swal({
					title: "Oops!",
					text: "Invalid Selection, Select a Wallet",
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonClass: "btn-default",
					cancelButtonClass: "btn-warning",
					confirmButtonText: "Warning",
					closeOnConfirm: false
				});
                return false;
           }
		   else if(amt > balance)
           {
               swal({
					title: "Oops!",
					text: "Error, Insufficient Balance",
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonClass: "btn-default",
					cancelButtonClass: "btn-warning",
					confirmButtonText: "Warning",
					closeOnConfirm: false
				});
                return false;
           }
            else if(amt < min || amt > max)
           {
               swal({
					title: "Oops!",
					text: "Sorry, You can only invest a minimum of $"+min+" and a maximum of $"+max+" for this Plan",
					showCancelButton: true,
					showConfirmButton: false,
					cancelButtonClass: "btn-default",
					cancelButtonClass: "btn-warning",
					confirmButtonText: "Warning",
					closeOnConfirm: false
				});
                return false;
           }
		  
		   else
		   {
			  return true; 
		   }
         
            
         }

	</script>	

    <!-- Required vendors -->
    <script src="<?php echo e(asset('vendor/global/global.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/bootstrap-select/dist/js/bootstrap-select.min.js')); ?>"></script>
	<script src="<?php echo e(asset('vendor/chart.js/Chart.bundle.min.js')); ?>"></script>
	
	<!-- Chart piety plugin files -->
    <script src="<?php echo e(asset('vendor/peity/jquery.peity.min.js')); ?>"></script>
	
	<!-- Apex Chart -->
	<script src="<?php echo e(asset('vendor/apexchart/apexchart.js')); ?>"></script>
	
	<!-- Dashboard 1 -->
	<script src="<?php echo e(asset('js/dashboard/dashboard-1.js')); ?>"></script>
	
	<script src="<?php echo e(asset('vendor/owl-carousel/owl.carousel.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/deznav.js')); ?>"></script>

</body>
</html>